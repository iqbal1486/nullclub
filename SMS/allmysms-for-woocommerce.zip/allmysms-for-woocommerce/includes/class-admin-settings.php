<?php
if ( ! defined( 'ABSPATH' ) ) exit;

// Check if the main settings class included or not
if ( file_exists( ALLMYSMS_PLUGIN_LIB_PATH . '/class.settings-api.php' ) ) {
    require_once ALLMYSMS_PLUGIN_LIB_PATH . '/class.settings-api.php';
}

/**
 * Settings API class
 *
 * @author geekerhub
 */

class AllMySMS_Setting_Options {

    /**
     * Settings object
     */
    private $settings_api;

    /**
     * Hold shortcodes for sms text
     */
    public static $shortcodes;

    /**
     * Load automatically when class initiate
     *
     * @since 1.0.0
     */
    function __construct() {
        $this->settings_api = new AllMySMS_Settings_API;
        self::$shortcodes = apply_filters( 'sat_sms_shortcode_insert_description', 'For order id just insert <code>[order_id]</code> and for order status insert <code>[order_status]</code>. Similarly <code>[order_items]</code>, <code>[order_items_description]</code>, <code>[order_amount]</code>, <code>[billing_firstname]</code>, <code>[billing_lastname]</code>, <code>[billing_email]</code>, <code>[billing_address1]</code>, <code>[billing_address2]</code>, <code>[billing_country]</code>, <code>[billing_city]</code>, <code>[billing_state]</code>, <code>[billing_postcode]</code>, <code>[billing_phone]</code>, <code>[shipping_address1]</code>, <code>[shipping_address2]</code>, <code>[shipping_country]</code>, <code>[shipping_city]</code>, <code>[shipping_state]</code>, <code>[shipping_postcode]</code>, <code>[payment_method]</code>' );

        add_action( 'admin_init', array($this, 'admin_init') );
        add_action( 'admin_menu', array($this, 'admin_menu') );
        add_action( 'admin_enqueue_scripts', array( $this, 'admin_enqueue_scripts' ) );
        add_action( 'ams_settings_form_bottom_geeker_message_diff_status', array( $this, 'settings_field_message_diff_status' ) );
    }

    /**
     * Admin init hook
     * @return void
     */
    function admin_init() {
        //set the settings
        $this->settings_api->set_sections( $this->get_settings_sections() );
        $this->settings_api->set_fields( $this->get_settings_fields() );

        //initialize settings
        $this->settings_api->admin_init();
    }

    /**
     * Admin Menu CB
     *
     * @return void
     */
    function admin_menu() {
        add_menu_page( 
            esc_html__( 'AllMySMS Settings', 'geeker-allmysms' ), 
            esc_html__( 'AllMySMS', 'geeker-allmysms' ), 
            'manage_woocommerce', 
            'geeker-allmysms-settings', 
            array( $this, 'plugin_page' ), 
            'dashicons-email-alt' 
        );

        add_submenu_page( 
            'geeker-allmysms-settings', 
            esc_html__( 'AllMySMS Settings', 'geeker-allmysms' ), 
            esc_html__( 'Settings', 'geeker-allmysms' ), 
            'manage_woocommerce', 
            'geeker-allmysms-settings', 
            array( $this, 'plugin_page' ) 
        );

        do_action( 'wcallmysms_load_menu' );
    }

    /**
     * Enqueue admin scripts
     *
     * Allows plugin assets to be loaded.
     *
     * @since 1.0.0
     */
    public function admin_enqueue_scripts() {
        wp_enqueue_style( 'satosms-admin-styles', ALLMYSMS_ASSETS . '/css/admin.css', false, date( 'Ymd' ) );
        wp_enqueue_script( 'satosms-admin-scripts', ALLMYSMS_ASSETS . '/js/admin.js', array( 'jquery' ), false, true );

        wp_localize_script( 'satosms-admin-scripts', 'wcallmysms', array(
            'ajaxurl' => admin_url( 'admin-ajax.php' )
        ) );
    }

    /**
     * Get All settings Field
     * @return array
     */
    function get_settings_sections() {
        $sections = array(
            array(
                'id' => 'geeker_general',
                'title' => '',
                'name' => esc_html__( 'Basic', 'geeker-allmysms' ),
                'icon'  => 'dashicons-admin-generic'
            ),
            array(
                'id' => 'geeker_gateway',
                'title' => '',
                'name' => esc_html__( 'Gateway Settings', 'geeker-allmysms' ),
                'icon'  => 'dashicons-admin-tools'
            ),

            array(
                'id' => 'geeker_message',
                'title' => '',
                'name' => esc_html__( 'SMS Text', 'geeker-allmysms' ),
                'icon'  => 'dashicons-email'
            ),

            array(
                'id' => 'geeker_message_diff_status',
                'title' => '',
                'name' => esc_html__( 'Body Settings', 'geeker-allmysms' ),
                'icon'  => 'dashicons-book'
            )
        );
        return apply_filters( 'wcallmysms_settings_sections' , $sections );
    }

    /**
     * Returns all the settings fields
     *
     * @return array settings fields
     */
    function get_settings_fields() {
        $customer_message = esc_html__( "Thanks for purchasing\nYour [order_id] is now [order_status]\nThank you", 'geeker-allmysms' );
        $admin_message = esc_html__( "You have a new Order\nThe [order_id] is now [order_status]\n", 'geeker-allmysms' );

        $settings_fields = array(
            'geeker_general' => apply_filters( 'wcallmysms_general_settings', array(
                array(
                    'name' => 'enable_notification',
                    'label' => esc_html__( 'Enable SMS Notifications', 'geeker-allmysms' ),
                    'desc' => esc_html__( 'If checked, then sms notification will be enabled', 'geeker-allmysms' ),
                    'type' => 'checkbox',
                ),

                array(
                    'name' => 'admin_notification',
                    'label' => esc_html__( 'Enable Admin Notifications', 'geeker-allmysms' ),
                    'desc' => esc_html__( 'If checked, then admin sms notification will be enabled for and order', 'geeker-allmysms' ),
                    'type' => 'checkbox',
                    'default' => 'on'
                ),

                array(
                    'name' => 'buyer_notification',
                    'label' => esc_html__( 'Enable Customer Notification', 'geeker-allmysms' ),
                    'desc' => esc_html__( 'If checked then customer will get notification checkbox options in checkout page', 'geeker-allmysms' ),
                    'type' => 'checkbox',
                ),

                array(
                    'name' => 'force_buyer_notification',
                    'label' => esc_html__( 'Force customer notification', 'geeker-allmysms' ),
                    'desc' => esc_html__( 'If select yes then customer notification option must be required in checkout page', 'geeker-allmysms' ),
                    'type' => 'select',
                    'default' => 'no',
                    'options' => array(
                        'yes' => esc_html__( 'Yes', 'geeker-allmysms' ),
                        'no'   => esc_html__( 'No', 'geeker-allmysms' )
                    )
                ),

                array(
                    'name' => 'buyer_notification_text',
                    'label' => esc_html__( 'Customer Notification Text', 'geeker-allmysms' ),
                    'desc' => esc_html__( 'Enter your text which is appeared in checkout page for the customers', 'geeker-allmysms' ),
                    'type' => 'textarea',
                    'default' => esc_html__( 'Send me order status notifications via SMS (N.B.: Your SMS will be sent in your billing phone. Make sure phone number must have an valid extension )', 'geeker-allmysms' )
                ),
                array(
                    'name' => 'order_status',
                    'label' => esc_html__( 'Check Order Status', 'geeker-allmysms' ),
                    'desc' => esc_html__( 'For which statues SMS notification will be sent to admin and customer', 'geeker-allmysms' ),
                    'type' => 'multicheck',
                    'options' => wc_get_order_statuses()
                )
            ) ),

            'geeker_gateway' => apply_filters( 'geeker_gateway_settings',  array(
                array(
                    'name' => 'allmysms_api_key',
                    'label' => esc_html__( 'API Key', 'geeker-allmysms' ),
                    'desc' => sprintf( __( 'Enter your API key for allmysms, for getting your api key please visit <a href="%s" target="_blank">API Settings</a>', 'geeker-allmysms' ), esc_url( 'https://doc.allmysms.com/api/en/' ) ),
                    'type' => 'text',
                    'default' => '',
                ),
                array(
                    'name' => 'allmysms_api_secret',
                    'label' => esc_html__( 'API Secret', 'geeker-allmysms' ),
                    'desc' => sprintf( __( 'Enter your API Secret for allmysms, for getting your api secret please visit <a href="%s" target="_blank">API Settings</a>', 'geeker-allmysms' ), esc_url( 'https://doc.allmysms.com/api/en/' ) ),
                    'type' => 'text',
                    'default' => '',
                ),
            ) ),

            'geeker_message' => apply_filters( 'geeker_message_settings',  array(
                array(
                    'name' => 'sms_admin_phone',
                    'label' => esc_html__( 'Enter admin Phone Number with extension', 'geeker-allmysms' ),
                    'desc' => esc_html__( '<br>Admin order sms notifications will be send in this number. Please make sure that the number must have a extension (e.g.: +8801626265565 where +880 will be extension )', 'geeker-allmysms' ),
                    'type' => 'text'
                ),
                array(
                    'name' => 'admin_sms_body',
                    'label' => esc_html__( 'Enter admin SMS body', 'geeker-allmysms' ),
                    'desc' => esc_html__( 'SMS text for admin. When an order is created then admin will get this formatted message.', 'geeker-allmysms' ) . ' ' . self::$shortcodes,
                    'type' => 'textarea',
                    'default' => $admin_message
                ),

                array(
                    'name' => 'sms_body',
                    'label' => esc_html__( 'Enter customer SMS body', 'geeker-allmysms' ),
                    'desc' => esc_html__( 'SMS text for customer. If customer notification is enabled then customer will get this formatted message when order is placed', 'geeker-allmysms' ) . ' ' . self::$shortcodes,
                    'type' => 'textarea',
                    'default' => $customer_message
                ),
            ) ),

            'geeker_message_diff_status' => apply_filters( 'wcallmysms_message_diff_status_settings',  array(
                array(
                    'name' => 'enable_diff_status_mesg',
                    'label' => esc_html__( 'Enable different message for different order statuses', 'geeker-allmysms' ),
                    'desc' => esc_html__( 'If checked then admin and customer will get sms text for different order statues', 'geeker-allmysms' ),
                    'type' => 'checkbox'
                ),
            ) ),
        );

        return apply_filters( 'wcallmysms_settings_section_content', $settings_fields );
    }

    /**
     * Loaded Plugin page
     * @return void
     */
    function plugin_page() {
        ?>
        <div class="wrap">
            <h1 class="wp-heading-inline"><?php esc_html__( 'Settings', 'geeker-allmysms' ) ?></h1><br>
            <div class="ams-settings-wrap">
                <?php
                    $this->settings_api->show_navigation();
                    $this->settings_api->show_forms();
                ?>
            </div>
        </div>
        <?php
    }

    /**
     * Get all the pages
     *
     * @return array page names with key value pairs
     */
    function get_pages() {
        $pages = get_pages();
        $pages_options = array();
        if ( $pages ) {
            foreach ($pages as $page) {
                $pages_options[$page->ID] = $page->post_title;
            }
        }

        return $pages_options;
    }

    function settings_field_message_diff_status() {
        $enabled_order_status = wcallmysms_get_option( 'order_status', 'geeker_general', array() );
        ?>
        <div class="geeker_different_message_status_wrapper geeker_hide_class">
            <hr>
            <?php if ( $enabled_order_status  ): ?>
                <h3><?php esc_html__( 'Set sms text for customers', 'geeker-allmysms' ); ?> </h3>
                <p>
                    <span><?php echo self::$shortcodes; ?></span>
                </p>
                <table class="form-table">
                    <?php foreach ( $enabled_order_status as $buyer_status_key => $buyer_status_value ): ?>
                        <?php
                            $buyer_display_order_status = str_replace( 'wc-', '', $buyer_status_key );
                            $buyer_content_value = wcallmysms_get_option( 'buyer-'.$buyer_status_key, 'geeker_message_diff_status', '' );
                        ?>
                        <tr valign="top">
                            <th scrope="row"><?php echo sprintf( '%s %s', ucfirst( str_replace( '-', ' ', $buyer_display_order_status ) ) , esc_html__( 'Order Status', 'geeker-allmysms' ) ); ?></th>
                            <td>
                                <textarea class="regular-text" name="geeker_message_diff_status[buyer-<?php echo sanitize_text_field($buyer_status_key); ?>]" id="geeker_message_diff_status[buyer-<?php echo sanitize_text_field($buyer_status_key); ?>]" cols="55" rows="5"><?php echo $buyer_content_value; ?></textarea>
                            </td>
                        </tr>
                    <?php endforeach ?>
                </table>

                <hr>

                <h3><?php esc_html__( 'Set SMS text for Admin', 'geeker-allmysms' ); ?></h3>
                <p>
                    <span><?php echo self::$shortcodes; ?></span>
                </p>
                <table class="form-table">
                    <?php foreach ( $enabled_order_status as $admin_status_key => $admin_status_value ): ?>
                        <?php
                            $admin_display_order_status = str_replace( 'wc-', '', $admin_status_key );
                            $admin_content_value = wcallmysms_get_option( 'admin-'.$admin_status_key, 'geeker_message_diff_status', '' );
                        ?>
                        <tr valign="top">
                            <th scrope="row"><?php echo sprintf( '%s %s', ucfirst( str_replace( '-', ' ', $admin_display_order_status ) ) , esc_html__( 'Order Status', 'geeker-allmysms' ) ); ?></th>
                            <td>
                                <textarea class="regular-text" name="geeker_message_diff_status[admin-<?php echo sanitize_text_field($admin_status_key); ?>]" id="geeker_message_diff_status[buyer-<?php echo sanitize_text_field($admin_status_key); ?>]" cols="55" rows="5"><?php echo $admin_content_value; ?></textarea>
                            </td>
                        </tr>
                    <?php endforeach ?>
                </table>

            <?php else: ?>
                <p><?php esc_html__( 'Sorry no order status will be selected for sending SMS in basic Settings tab. Please select some order status from Basic Settings Tab', 'geeker-allmysms') ?></p>
            <?php endif ?>
        </div>
        <?php
    }

} // End ofAllMySMS_Setting_Options Class