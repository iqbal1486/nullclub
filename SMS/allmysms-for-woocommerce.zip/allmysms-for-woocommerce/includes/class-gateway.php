<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * SMS Gateway handler class
 *
 * @author satosms
 */
class AllMySMS_Gateways {

    /**
     * Hold class instance
     *
     * @since 1.0.0
     */
    private static $_instance;

    /**
     * Directly called main instance using singletone pattern
     *
     * @since 1.0.0
     */
    public static function init() {
        if ( ! self::$_instance ) {
            self::$_instance = newAllMySMS_Gateways();
        }

        return self::$_instance;
    }

    /**
     * Send sms via allmysms
     *
     * @since 1.0.0
     */
    public function allmysms( $sms_data ) {
        $authUserName = wcallmysms_get_option( 'allmysms_api_key', 'geeker_gateway', '' );
        $authPassword = wcallmysms_get_option( 'allmysms_api_secret', 'geeker_gateway', '' );

        if( empty( $authUserName ) || empty( $authPassword ) ) {
            return;
        }

        $token = base64_encode($authUserName . ":" . $authPassword);
        $message_data = array(
                    'to'     => $sms_data['number'],
                    'text'   => $sms_data['sms_body'],
                );

        $curl = curl_init();
 
         curl_setopt_array($curl, array(
           CURLOPT_URL => "https://api.allmysms.com/sms/send",
           CURLOPT_RETURNTRANSFER => true,
           CURLOPT_ENCODING => "",
           CURLOPT_MAXREDIRS => 10,
           CURLOPT_TIMEOUT => 30,
           CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
           CURLOPT_CUSTOMREQUEST => "POST",
           CURLOPT_POSTFIELDS => json_encode($message_data),
           CURLOPT_HTTPHEADER => array(
             "Authorization: Basic ".$token,
             "Content-Type: application/json",
             "cache-control: no-cache"
           ),
         ));
         
         $response = curl_exec($curl);
         $err = curl_error($curl);
         curl_close($curl);
         
         
         $response = json_decode($response, true);

         if( in_array($response['code'], array(100,101))){
            return array(
                        'status' => true,
                        'result' => $response['description'] ."(". $response['code'] .")"
                    );
         }else{
            return array(
                        'status' => false,
                        'result' => $response['description'] ."(". $response['code'] .")"
                    );
         }

    }
}
