=== AutomatorWP - Google Sheets ===
Contributors: automatorwp, rubengc, eneribs
Tags: gravity, form, forms, automatorwp, submission
Requires at least: 4.4
Tested up to: 5.9
Stable tag: 1.0.0
License: GNU AGPLv3
License URI: http://www.gnu.org/licenses/agpl-3.0.html

Connect AutomatorWP with Google Sheets

== Description ==

[Google Sheets](https://www.google.com/sheets/about/ "Google Sheets") is a free online spreadsheet editor that lets you create, edit and collaborate on spreadsheets anywhere with anyone!

= Actions =

* Add a row to a spreadsheet.

== Installation ==

= From WordPress backend =

1. Navigate to Plugins -> Add new.
2. Click the button "Upload Plugin" next to "Add plugins" title.
3. Upload the downloaded zip file and activate it.

= Direct upload =

1. Upload the downloaded zip file into your `wp-content/plugins/` folder.
2. Unzip the uploaded zip file.
3. Navigate to Plugins menu on your WordPress admin area.
4. Activate this plugin.

== Frequently Asked Questions ==

== Screenshots ==

== Changelog ==

= 1.0.0 =

* Initial release.
