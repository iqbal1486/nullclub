<?php

namespace DynamicContentForElementor;

trait Conditions
{
}
