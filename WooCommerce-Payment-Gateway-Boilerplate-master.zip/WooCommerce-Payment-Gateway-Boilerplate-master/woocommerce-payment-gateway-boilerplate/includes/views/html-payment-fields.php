<?php
if( !defined( 'ABSPATH' ) ) exit; // Exit if accessed directly.

// TODO: Insert your custom payment fields here.

?>