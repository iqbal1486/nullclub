<div id="submitreview" class="clearfix">
	<?php 
		listingpro_get_all_reviews($post->ID);
	?>
</div>
