<div class="lp-listing-desription">

    <?php the_content(); ?>

</div>