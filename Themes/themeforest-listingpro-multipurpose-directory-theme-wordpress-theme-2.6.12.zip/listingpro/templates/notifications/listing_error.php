<div class="alert alert-danger">
  <strong><?php echo esc_html__('Error!', 'listingpro'); ?></strong> <?php echo esc_html__('Problem in submitting this listing', 'listingpro'); ?>
</div>