<?php 

 /*======= loading template files ======*/
function cao_load_templates( $template_name, $vars = null) {
    if( $vars != null && is_array($vars) ){
       extract( $vars );
    };

    $template_path =  CAO_PATH . "/templates/{$template_name}";
    if( file_exists( $template_path ) ){
        include  $template_path ;
    } else {
       die( "Error while loading file {$template_path}" );
    }
}

function cao_pa($arr){
	echo "<pre>";
	print_r($arr);
	echo "</pre>";
}