<?php 

/*=======Loading admin files=====*/

function tc_sandbox_enabled_payment_gateway(){
    
    $ob = new WC_Clover_Gateway_Addon;
    $sandbox_enable       = $ob->get_option('clover_enable_sandbox');
    if ($sandbox_enable=='yes') {
        return true;
    }
    else false;
}

    function sending_lineitems_to_clover_payment_gateway_checkout( $order_id ){
            
        // $line_items_arr = array();
        $order = wc_get_order($order_id);


        $tax_amount = $order->get_total_tax()*100;
        $shipping_charges = $order->get_shipping_total()*100;
        
        //Fee
        foreach( $order->get_items('fee') as $item_id => $item_fee ){

            // The fee name
            $fee_name = $item_fee->get_name();
            $fee_total = $item_fee->get_total()*100;

            $line_items_arr[] = array(
                'name'        => $fee_name,
                'price'       => $fee_total,
                'unitQty'     =>1,
            );

        }
        
        //adding Tax
        $line_items_arr[] = array(
            'name'        => 'Tax Charges',
            'price'       => $tax_amount,
            'unitQty'     =>1,
        );
        
        
        
        //adding Shipping  
        $line_items_arr[] = array(
            'name'        => 'Shipping Charges',
            'price'       => $shipping_charges,
            'unitQty'     =>1,
        );

    foreach ( $order->get_items() as $order_item_key => $order_item ) {

        $product             = $order_item->get_product();
        $product_price       = $product->get_price()*100; //in cents
        $product_name        = $order_item->get_name();
        $product_quantity        = $order_item->get_quantity();
        
        $line_items_arr[] = array(
           'name'        => $product_name,
           'price'       => $product_price,
            'unitQty'     =>$product_quantity,
        );
        
        }

        return $line_items_arr;

    }

function introtime_redirect_to_clover_payment_addon($order_id){

	$order = wc_get_order($order_id);
    $billing_email      = $order->get_billing_email();
    $billing_first_name = $order->get_billing_first_name();
    $billing_last_name  = $order->get_billing_last_name();
    $billing_phone      = $order->get_billing_phone();
    
    $ob = new IntroTime_Addon_Payment;
    $line_item_array = array(
        'customer'          => array(
            'email'         => $billing_email,
            'firstName'     => $billing_first_name,
            'lastName'      => $billing_last_name,
            'phoneNumber'   => $billing_phone = '223-555-0002',
        ),
        'shoppingCart' => array(
            'lineItems' => $ob->sending_lineitems_to_clover_payment_gateway_checkout_addon($order_id)
        ),
    );
    return $line_item_array;
}

	/*
 /*=====Clover custom Payment Checkout CUrl Statement=====*/
	/**/
function clover_custom_payment_checkout_curl_addon($data){

		$sandbox_enable = tc_sandbox_enabled_payment_gateway();
		if ($sandbox_enable) {
			$url = "https://sandbox.dev.clover.com/invoicingcheckoutservice/v1/checkouts";
		}
		else{
			$url = "https://sandbox.dev.clover.com/invoicingcheckoutservice/v1/checkouts";
		}

	$curl = curl_init($url);
	curl_setopt($curl, CURLOPT_URL, $url);
	curl_setopt($curl, CURLOPT_POST, true);
	curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

	$ob = new WC_Clover_Gateway_Addon;
	$merchat_id = $ob->get_option('clover_merchant_id');
	$private_token = $ob->get_option('clover_private_token');

	$headers = array(
	   "X-Clover-Merchant-Id: ".$merchat_id."",
	   "Authorization: Bearer ".$private_token."",
	   "Content-Type: application/json",
	);
	curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);


	curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($data));

	//for debug only!
	curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
	curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);

	$resp = curl_exec($curl);
	curl_close($curl);
	return $resp;
}

//adding The Custom Payment Gateway
add_filter( 'woocommerce_payment_gateways', 'introtime_clover_payment_addon' );

function introtime_clover_payment_addon( $gateways ) {
	$gateways[] = 'WC_Clover_Gateway_Addon'; // your class name is here
	return $gateways;
}

add_action( 'plugins_loaded', 'clover_addon_payment_gateway_init' );
function clover_addon_payment_gateway_init() {
 
	class WC_Clover_Gateway_Addon extends WC_Payment_Gateway {
 
 		/**
 		 * Class constructor, more about it in Step 3
 		 */
 		public function __construct() {
				
			$this->id = 'clover_payment_gateway_addon'; // payment gateway plugin ID
			$this->icon = apply_filters( 'woocommerce_gateway_icon', CAO_URL.'/css/images/ct-checkout-logo.jpg' ); // URL of the icon that will be displayed on checkout page near your gateway name
			$this->has_fields = true; // in case you need a custom credit card form
			$this->method_title = 'IntroTime Clover Payment Gateway';
			$this->method_description = 'Intro Time Woocommerce integration for Clover works by adding a payment option on the checkout page. This allows payments to be processed by your Clover Merchant Account. All orders can either auto print to your Clover POS or you can print them manually. Make accepting credit card payments simple with the Woocommerce Clover payment gateway.'; // will be displayed on the options page
		 
			// gateways can support subscriptions, refunds, saved payment methods,
			// but in this tutorial we begin with simple payments
			$this->supports = array(
				'products'
			);
		 
			// Method with all the options fields
			$this->init_form_fields();
		 
			// Load the settings.
			$this->init_settings();
			$this->title = $this->get_option( 'title' );
			$this->description = $this->get_option( 'description' );
			$this->enabled = $this->get_option( 'enabled' );
		 
			// This action hook saves the settings
			add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
		 
			// We need custom JavaScript to obtain a token
			add_action( 'wp_enqueue_scripts', array( $this, 'payment_scripts' ) );
			
		 
			// You can also register
 		}
 
		/**
 		 * Plugin options, we deal with it in Step 3 too
 		 */
 		public function init_form_fields(){
 				
 				$this->form_fields = array(
					'enabled' => array(
						'title'       => 'Enable/Disable',
						'label'       => 'Enable Clover Gateway',
						'type'        => 'checkbox',
						'description' => '',
						'default'     => 'no'
					),
					'title' => array(
						'title'       => 'Title',
						'type'        => 'text',
						'description' => 'This controls the title which the user sees during checkout.',
						'default'     => 'Credit Card',
						'desc_tip'    => true,
					),
					'description' => array(
						'title'       => 'Description',
						'type'        => 'textarea',
						'description' => 'This controls the description which the user sees during checkout.',
						'default'     => 'Pay with your credit card via our super-cool payment gateway.',
					),
					'clover_enable_sandbox' => array(
						'title'       => 'Clover SandBox',
						'type'        => 'checkbox',
						'description' => 'if you check this. The Order Will be Sent to Sandbox account rather then Live account of Clover',
					),

					'clover_private_token' => array(
						'title'       => 'Clover Private Token',
						'type'        => 'text',
						'description' => 'Enter Your Private Token',
					),
					'clover_merchant_id' => array(
						'title'       => 'Clover Merchant ID',
						'type'        => 'text',
						'description' => 'Enter Merchant ID',
					),
				);

	 	}
 
		/**
		 * You will need it if you want your custom credit card form, Step 4 is about it
		 */
		public function payment_fields() {

		}

		/*
		 * Custom CSS and JS, in most cases required only when you decided to go with a custom credit card form
		 */
	 	public function payment_scripts() {
        	
	 	}
 
		/*
 		 * Fields validation, more in Step 5
		 */
		public function validate_fields() {
			
		}
 
		/*
		 * We're processing the payments here, everything about it is in Step 5
		 */
		public function process_payment( $order_id ) {

	 	}
 
		/*
		 * In case you need a webhook, like PayPal IPN etc
		 */
		public function webhook() {

	 	}
 	}
}