<?php 

	$percent_input = get_option('wctc_tax_input');

 ?>
<br>
<h3>Add Percentage For Tax Calculation on Cart Totals</h3>
<br>
<form id="wctc_admin_form">
	<input type="hidden" name="action" value="wctc_save_admin_form">
	<div>
		<p><i>This percentage will be added on the checkout page in order total from cart totals</i></p>
		<b><label>Add Percentage :</label></b>
		<input style="width: 80px !important" type="number" name="wctc_tax_percent" value="<?php echo $percent_input; ?>" required>%<br><br>
		<input type="submit" class="button" value="Save">
	</div>
</form>