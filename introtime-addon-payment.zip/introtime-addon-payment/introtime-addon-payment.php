<?php 

/*
Plugin Name: IntoTime Payment Add-on
Author: Ammar Ahmad
Plugin URI: https://halalthings.ca/
Author URI: https://halalthings.ca/
Text Domain: wc-tc
Description: This plugin is an Add-on Of the IntroTime Order Online Clover Plugin As a Payment GateWay for the Clover
Version: 1.0.3
*/



/* 
**========== Direct access not allowed =========== 
*/ 
if( ! defined('ABSPATH') ) die('Not Allowed');

define( 'CAO_PATH', untrailingslashit(plugin_dir_path( __FILE__ )) );
define( 'CAO_URL' ,  untrailingslashit(plugin_dir_url( __FILE__ )) );
/* 
**========== Files Load =========== 
*/
if( file_exists( dirname(__FILE__).'/inc/helpers.php' )) include_once dirname(__FILE__).'/inc/helpers.php';
if( file_exists( dirname(__FILE__).'/inc/admin.php' )) include_once dirname(__FILE__).'/inc/admin.php';

class IntroTime_Addon_Payment {
	

	function __construct() {
		// add_action( 'wp_enqueue_scripts', array($this , 'load_script_style_files') );
		add_action( 'woocommerce_thankyou', array($this , 'send_payment_checkout') );

		// add_action ( 'wp_ajax_clover_payment_url' , array($this , 'clover_payment_url'));
		// add_action ( 'wp_ajax_nopriv_clover_payment_url' , array($this , 'clover_payment_url'));
		// add_action('init' , array($this , 'ammar'));	
	}

	function send_payment_checkout( $order_id ){
		$data = $this->introtime_redirect_to_clover_payment_addon($order_id);
		$curl_resp 		= clover_custom_payment_checkout_curl_addon($data);
		$checkout_url 	= json_decode($curl_resp)->href;
		// echo $checkout_url;
		wp_redirect($checkout_url);
	}

	function introtime_redirect_to_clover_payment_addon($order_id){

		$order = wc_get_order($order_id);
	    $billing_email      = $order->get_billing_email();
	    $billing_first_name = $order->get_billing_first_name();
	    $billing_last_name  = $order->get_billing_last_name();
	    $billing_phone      = $order->get_billing_phone();
	    
	    // $ob = new IntroTime_Addon_Payment;
	    $line_item_array = array(
	        'customer'          => array(
	            'email'         => $billing_email,
	            'firstName'     => $billing_first_name,
	            'lastName'      => $billing_last_name,
	            'phoneNumber'   => $billing_phone = '223-555-0002',
	        ),
	        'shoppingCart' => array(
	            'lineItems' => $this->sending_lineitems_to_clover_payment_gateway_checkout($order_id)
	        ),
	    );
	    return $line_item_array;
	}

	/****=======open payment url of clover======****/
	// function clover_payment_url(){

	// 	$data = $this->clover_payment_final_data($_REQUEST);

	// 	$curl_resp 		= clover_custom_payment_checkout_curl_addon($data);
	// 	$checkout_url 	= json_decode($curl_resp)->href;
	// 	if ($checkout_url) {
	// 		wp_send_json(array('clover_url'=>$checkout_url));
	// 	}
	// 	die(0);
	// }

	/****=======load files on checkout page======****/
	function load_script_style_files(){

		if (function_exists('is_checkout')) {

			wp_enqueue_script('coa_clover_addon', CAO_URL."/js/cao-script.js",  array('jquery'));
            wp_localize_script('coa_clover_addon', 'ajax_vars', array(
                'ajax_url'      =>  admin_url( 'admin-ajax.php' ),
                )
            );
		}
	}

	//testing
	function ammar(){

		cao_pa($data);exit;
		
	
	}

	function clover_payment_final_data($request){

		$line_item_array 	= array();
		$billing_email      = isset($request['email']) ? $request['email'] : '';
	    $billing_first_name = isset($request['first_name']) ? $request['first_name'] : '';
	    $billing_last_name  = isset($request['last_name']) ? $request['last_name'] : '';
	    $billing_phone      = isset($request['phone']) ? $request['phone'] : '';
	    
	    $line_item_array = array(
	        'customer'          => array(
	            'email'         => $billing_email,
	            'firstName'     => $billing_first_name,
	            'lastName'      => $billing_last_name,
	            'phoneNumber'   => $billing_phone = '223-555-0002',
	        ),
	        'shoppingCart' => array(
	            'lineItems' => $this->sending_lineitems_to_clover_payment_gateway_checkout_addon()
	        ),
	    );
	    return $line_item_array;
	}

    function sending_lineitems_to_clover_payment_gateway_checkout( $order_id ){
            
        // $line_items_arr = array();
        $order = wc_get_order($order_id);


        $tax_amount = $order->get_total_tax()*100;
        $shipping_charges = $order->get_shipping_total()*100;
        
        //Fee
        foreach( $order->get_items('fee') as $item_id => $item_fee ){

            // The fee name
            $fee_name = $item_fee->get_name();
            $fee_total = $item_fee->get_total()*100;

            $line_items_arr[] = array(
                'name'        => $fee_name,
                'price'       => $fee_total,
                'unitQty'     =>1,
            );

        }
        
        //adding Tax
        $line_items_arr[] = array(
            'name'        => 'Tax Charges',
            'price'       => $tax_amount,
            'unitQty'     =>1,
        );
        
        
        
        //adding Shipping  
        $line_items_arr[] = array(
            'name'        => 'Shipping Charges',
            'price'       => $shipping_charges,
            'unitQty'     =>1,
        );

    foreach ( $order->get_items() as $order_item_key => $order_item ) {

        $product             = $order_item->get_product();
        $product_price       = $product->get_price()*100; //in cents
        $product_name        = $order_item->get_name();
        $product_quantity        = $order_item->get_quantity();
        
        $line_items_arr[] = array(
           'name'        => $product_name,
           'price'       => $product_price,
            'unitQty'     =>$product_quantity,
        );
        
        }

        return $line_items_arr;

    }

   function sending_lineitems_to_clover_payment_gateway_checkout_addon(){


   		global $woocommerce;
    	$items = $woocommerce->cart->get_cart();
    	$line_items_arr = array();

    	foreach ($items as $cart_item) {
    		
    		$item_name = $cart_item['data']->get_title();
		   	$quantity = $cart_item['quantity'];
		   	$price = $cart_item['data']->get_price();
			
			$line_items_arr[] = array(
	           'name'        => $item_name,
	           'price'       => $quantity,
	            'unitQty'     =>$price*100,
	        );
    	
    	}

        return $line_items_arr;

    }

}

new IntroTime_Addon_Payment;