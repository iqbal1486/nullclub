"use strict";
jQuery(function($){
    
    // alert('Sarah');
    //saving the form fields

    $(document).on('click' , '#place_order' , function(e){
        e.preventDefault();

        var billing_first_name 	= $('#billing_first_name').val();
        var billing_last_name 	= $('#billing_last_name').val();
        var billing_email 		= $('#billing_email').val();
        var billing_phone 		= $('#billing_phone').val();
        
        var data = {
        	'action' : 'clover_payment_url',
        	'first_name' : billing_first_name,
        	'last_name' : billing_last_name,
        	'phone' : billing_phone,
        	'email' : billing_email,
        }
        $.post(ajax_vars.ajax_url, data, function(resp){
        	console.log(resp);
        	window.open(resp.clover_url);
       	});
    })

})