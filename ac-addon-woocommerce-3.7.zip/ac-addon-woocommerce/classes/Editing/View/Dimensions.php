<?php

namespace ACA\WC\Editing\View;

use ACP;

class Dimensions extends ACP\Editing\View {

	public function __construct() {
		parent::__construct( 'dimensions' );
	}

}
