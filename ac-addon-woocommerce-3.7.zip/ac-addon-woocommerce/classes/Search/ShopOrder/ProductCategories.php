<?php

namespace ACA\WC\Search\ShopOrder;

class ProductCategories extends ProductTaxonomy {

	public function __construct() {
		parent::__construct( 'product_cat' );
	}

}