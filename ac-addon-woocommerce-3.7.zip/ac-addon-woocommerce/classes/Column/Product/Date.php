<?php

namespace ACA\WC\Column\Product;

use ACP;

class Date extends ACP\Column\Post\Date {
	// uses pro date column
}