<?php



/**

 * Plugin Name:       Max Vimeo Video

 * Plugin URI:        https://maxenius.com/

 * Description:       This plugin uses the vimeo api to upload video.

 * Version:           1.3.0

 * Author:            Maxenius Solution

 * Author URI:        https://maxenius.com/

 * License:           GPL v2 or later

 */



defined('ABSPATH') || die();



if (!defined('MVA_PLUGIN_FILE')) {



    define('MVA_PLUGIN_FILE', __FILE__);



}



if (!defined('MVA_PLUGIN_DIR_URL')) {



    define('MVA_PLUGIN_DIR_URL', plugin_dir_url(__FILE__));



}



if (!defined('MVA_PLUGIN_DIR_PATH')) {



    define('MVA_PLUGIN_DIR_PATH', plugin_dir_path(__FILE__));



}







function mas_admin_enqueue_plugin_files() {



      /* Add Custom style/css File */



    wp_enqueue_style('mva_wp_plugin_style_file', plugins_url('/assets/css/style.css', __FILE__));







    /* Bootstrap  */



    wp_enqueue_style('mva_wp_plugin_bootstrap_css', plugins_url('/assets/bs4/css/bootstrap.min.css', __FILE__));



    wp_enqueue_script('mva_wp_plugin_bootstrap_js', plugins_url('/assets/bs4/js/bootstrap.min.js', __FILE__));



    //js for model

 



   

  // wp_enqueue_script('mva_plugin_our_scripts_js_for_model_1', 'https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js');

  wp_enqueue_script('mva_plugin_our_scripts_js_for_model_2', 'https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js');

  wp_enqueue_script('mva_plugin_our_scripts_js_for_model_3', 'https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js');

  //end of model js



  



  //select2 style



  wp_enqueue_style('select2_style', 'https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css' );



  //select2 script



  wp_enqueue_script('select2_script', 'https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js', array('jquery') );



    /* Add Custom Ajax File To Admin Dashboard */

    $version = time();
    wp_enqueue_script('mva_plugin_admin_ajax_scripts_file', plugins_url('/assets/js/mva_ajax.js', __FILE__), array('jquery'),$version,true);



     // Call Predefined Ajax File To Admin Dashboard 



    wp_localize_script('mva_plugin_admin_ajax_scripts_file', 'mva_ajax_url', array('ajax_url' => admin_url('admin-ajax.php')));







 



  











   



 



}



add_action('wp_enqueue_scripts', 'mas_admin_enqueue_plugin_files');



function MVA_admin_enqueue_plugin_files() {



    /* Bootstrap  */



    wp_enqueue_style('mva_admin_plugin_bootstrap1', plugins_url('/assets/bs4/css/bootstrap.min.css', __FILE__));



    wp_enqueue_script('mva_admin_plugin_bootstrap2', plugins_url('/assets/bs4/js/bootstrap.min.js', __FILE__));



}



add_action('admin_enqueue_scripts', 'MVA_admin_enqueue_plugin_files');



//[MVA_Upload_Vimeo_Video_Form]



add_shortcode('MVA_Upload_Vimeo_Video_Form', 'MVA_Upload_Vimeo_Video_shortcode_form_callback');



function MVA_Upload_Vimeo_Video_shortcode_form_callback() {



    require __DIR__ . '/template/test-video-upload-form.php';



}
add_shortcode('MVA_Edit_Vimeo_Video_Form', 'MVA_Edit_Vimeo_Video_shortcode_form_callback');



function MVA_Edit_Vimeo_Video_shortcode_form_callback() {
    require __DIR__ . '/template/edit_vimeo.php';
}



//[MVA_After_Video_Upload]



add_shortcode('MVA_After_Video_Upload', 'MVA_after_video_upload');



function MVA_after_video_upload() {



    require __DIR__ . '/template/after_upload_page.php';



}







//[MVA_Upload_Vimeo_Video]



add_shortcode('MVA_Upload_Vimeo_Video', 'MVA_Upload_Vimeo_Video_shortcode_callback');



function MVA_Upload_Vimeo_Video_shortcode_callback() {



    require __DIR__ . '/template/upload_vimeo_video.php';



}



function MVA_single_vimeo_video_shortcode_callback() {



    require __DIR__ . '/template/single_vimeo_video.php';



}



add_shortcode('MVA_Single_Vimeo_Video', 'MVA_single_vimeo_video_shortcode_callback');



//[MVA_Single_Vimeo_Video]











//hook  for Video Button







add_action( 'woocommerce_before_add_to_cart_form', 'vimeo_single_proudct_page_func', 10, 0 );



function vimeo_single_proudct_page_func(){







 



    $user_id = get_current_user_id(); 



    if(!empty($user_id)){



        $customer_orders = get_posts( array(



            'meta_key'    => '_customer_user',



            'meta_value'  => $user_id,



            'post_type'   => 'shop_order',



            'post_status' => array_keys( wc_get_order_statuses() ),



            'numberposts' => -1



        ));



    foreach ($customer_orders as  $value) {



        $order_id = $value->ID;



        $order = wc_get_order( $order_id );



        $items = $order->get_items();



        foreach ( $items as  $item ) {



            $product_ids[] = $item->get_product_id(); 



        }



    } 



    $current_product_id = get_the_ID();







     if (in_array($current_product_id, $product_ids))



    {



        global $wpdb;



        $table_name = $wpdb->prefix ."posts"; 



        $product_id= $wpdb->get_row( "SELECT post_mime_type FROM $table_name WHERE ID 



               = '".get_the_ID()."'" );



        $video_url = site_url('single_vimeo').'/?id='.$product_id->post_mime_type;







    ?>



        <style type="text/css">



          .single_product_btn{



            margin-left: 104px;



            margin-top: -38px;



            width: 157px;



            border-radius: 30px;



            padding: 9px;



            border: none;



            background-color: #533980;



            color: white;



          }



           .single_product_btn:hover{



              background-color:#FFD700;



              color: white;



              border: none;



          }











         



        </style>



            <button   class="single_product_btn btn  btn-sm  "   onclick="location.href='<?php echo $video_url; ?>'" type="button"> 



             Show Video



          </button>



         



        <?php  







    }







   



    



    }            



    



}















function wporg_register_taxonomy_course() {
         $labels = array(
        'name'                       => _x( 'Denominations', 'taxonomy general name', 'textdomain' ),
        'singular_name'              => _x( 'Denimination', 'taxonomy singular name', 'textdomain' ),
        'search_items'               => __( 'Search Denominations', 'textdomain' ),
        'popular_items'              => __( 'Popular Denominations', 'textdomain' ),
        'all_items'                  => __( 'All Denominations', 'textdomain' ),
        'parent_item'                => null,
        'parent_item_colon'          => null,
        'edit_item'                  => __( 'Edit Denimination', 'textdomain' ),
        'update_item'                => __( 'Update Denimination', 'textdomain' ),
        'add_new_item'               => __( 'Add New Denimination', 'textdomain' ),
        'new_item_name'              => __( 'New Denimination Name', 'textdomain' ),
        'separate_items_with_commas' => __( 'Separate Denominations with commas', 'textdomain' ),
        'add_or_remove_items'        => __( 'Add or remove Denominations', 'textdomain' ),
        'choose_from_most_used'      => __( 'Choose from the most used Denominations', 'textdomain' ),
        'not_found'                  => __( 'No Denominations found.', 'textdomain' ),
        'menu_name'                  => __( 'Denominations', 'textdomain' ),
    );
 
    $args = array(
        'hierarchical'          => false,
        'labels'                => $labels,
        'show_ui'               => true,
        'show_admin_column'     => true,
        'update_count_callback' => '_update_post_term_count',
        'query_var'             => true,
        'rewrite'               => array( 'slug' => 'denominations' ),
    );
 
    register_taxonomy( 'denominations', [ 'product' ], $args );
}
add_action( 'init', 'wporg_register_taxonomy_course' );








 







//Show Speaker on single product page 



add_action( 'woocommerce_product_meta_end', 'vimeo_single_product_show_speaker_func', 10, 0 ); 



function vimeo_single_product_show_speaker_func(  ) { 



   //SHOW TAGS



 







   //SHOW SPEAKERS



      $post_meta = get_post_meta( get_the_ID(), 'max_vimoe_post_meta', true );
      $term_slug = get_the_terms( get_the_ID(), 'denominations', true );
      $original_slug = get_site_url()."/denominations/".$term_slug['0']->slug;
      echo "<span style='font-size:14px; color:#a3a5a9; display:inline;'>Denomination: </span>";
       echo "<a href='".$original_slug."'><span style='font-size:14px; color: #533980; margin-left:5px; display:inline;'>".$post_meta['vimeo_category']."  </span></a>";

      echo "<br>";


   
    if (!empty($post_meta['speaker_first_name_1'])) {
   





      echo "<span style='font-size:14px; color:#a3a5a9; display:inline;'>Speaker 1: </span>";



      echo "<span style='font-size:14px; color: #533980; margin-left:32px; display:inline;'>".$post_meta['speaker_first_name_1']." ".$post_meta['speaker_last_name_1']." </span>";



      // echo "Speaker 1: ".$post_meta['speaker_first_name_1']." ".$post_meta['speaker_last_name_1'];



    }



    if (!empty($post_meta['speaker_first_name_2'])) {



      echo "<br>";



      // echo "Speaker 2: ".$post_meta['speaker_first_name_2']." ".$post_meta['speaker_last_name_2'];



      echo "<span style='font-size:14px; color:#a3a5a9; display:inline;'>Speaker 2: </span>";



      echo "<span style='font-size:14px; color: #533980; margin-left:32px; display:inline;'>".$post_meta['speaker_first_name_2']." ".$post_meta['speaker_last_name_2']." </span>";



    }



    if (!empty($post_meta['speaker_first_name_3'])) {



      echo "<br>";



      // echo "Speaker 3: ".$post_meta['speaker_first_name_3']." ".$post_meta['speaker_last_name_3'];



      echo "<span style='font-size:14px; color:#a3a5a9; display:inline;'>Speaker 3: </span>";



      echo "<span style='font-size:14px; color: #533980; margin-left:32px; display:inline;'>".$post_meta['speaker_first_name_3']." ".$post_meta['speaker_last_name_3']." </span>";



    }



    ?>



    <style type="text/css">



       .return_to_store{



              background-color:#533980;



              color: white;



              border: none;



          }



          .return_to_store:hover{



              background-color:#FFD700;



              color: white;



              border: none;



          }



    </style>



    <br>



    <br>



    <button  class=" btn   return_to_store  "   onclick="location.href='<?php echo site_url('/shop') ?>'" type="button"> 



             Return To Storefront



          </button>











    <?php



















    //for free video button



    $vidoe_price = get_post_meta( get_the_ID(), '_regular_price', true );



    if($vidoe_price == 'free'){



      global $wpdb;



      $table_name = $wpdb->prefix ."posts"; 



      $product_id= $wpdb->get_row( "SELECT post_mime_type FROM $table_name WHERE ID 



             = '".get_the_ID()."'" );



      $video_url = site_url('single_vimeo').'/?id='.$product_id->post_mime_type;



      ?>



       <style type="text/css">



          .free_btn{



       



          width: 157px;



          padding: 9px;



          margin-left: 194px;



          margin-top: -66px;



           background-color:#533980;



              color: white;



              border: none;



          }



        



          .free_btn:hover{



              background-color:#FFD700;



              color: white;



              border: none;



          }



         



        </style>



          <button  class="free_btn btn  btn-sm  "   onclick="location.href='<?php echo $video_url; ?>'" type="button"> 



             Show Video



          </button>











   







      <?php



    }



 



}







require_once(MVA_PLUGIN_DIR_PATH . 'include/admin_menu.php');



require_once(MVA_PLUGIN_DIR_PATH . 'template/helper.php');

require_once(MVA_PLUGIN_DIR_PATH . 'template/my_uploads.php');

require_once(MVA_PLUGIN_DIR_PATH . 'template/my_uploads_content.php');





?>