<div class="container">
	<div class="row">
		<style type="text/css">
			iframe.vimeo_single_video {
			    border: solid 1px #6A0DAD;
			    padding: 1em;
			    margin-bottom: 3em;
			}
			.fluid-width-video-wrapper {
			    padding-top: 54% !important;
			}

			img.thumimage {
                height: 180px !important; 
            }
		</style>
		<div class="col-md-12">
			<?php
				if(!empty($_GET['id'])){
					global $wpdb;
				    $table_name = $wpdb->prefix . "posts"; 
				    $video_id =  $_GET['id'];
				    $src_id= $wpdb->get_row( "SELECT ID  FROM $table_name WHERE post_mime_type 
				     = '".$video_id."'" );
				    $actual_src =  get_post_meta( $src_id->ID, 'max_vimoe_post_meta', true );
				}
				
			?>
			    <iframe class="vimeo_single_video" width="100%" height="500px"   src="https://player.vimeo.com/<?php  echo $actual_src['vimeo_video_file_id']; ?>" frameborder="0" allow="autoplay; fullscreen" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>
			<?php
			?>
		</div>
	</div>
</div>
