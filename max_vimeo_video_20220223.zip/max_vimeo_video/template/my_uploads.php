<?php
/**
 * This file is used to add custom tab in my account of woocommerce.
 *
 * @since 1.1.0
 * @package select2
 */

register_activation_hook( __FILE__, 'max_my_uploads_flush_rewrite_rules' );

/**
 * Function to add custom tab in my account page
 *
 * @since 1.1.0
 */
function max_my_uploads_flush_rewrite_rules() {
	 add_rewrite_endpoint( 'max_my_uploads', EP_ROOT | EP_PAGES );
	flush_rewrite_rules();
} // end function.

add_action( 'init', 'max_my_uploads_custom_endpoints' );

/**
 * Register new endpoint to use for My Account page
 *
 * @since 1.1.0
 */
function max_my_uploads_custom_endpoints() {
	add_rewrite_endpoint( 'max_my_uploads', EP_ROOT | EP_PAGES );
} // end function.

add_filter( 'query_vars', 'max_my_uploads_custom_query_vars', 0 );

/**
 * Add new query vars.
 *
 * @param array $vars this will create tab.
 * @since 1.1.0
 * @return array $vars
 */
function max_my_uploads_custom_query_vars( $vars ) {
	$vars[] = 'max_my_uploads';
	return $vars;
} // end function.

add_filter( 'woocommerce_account_menu_items', 'max_my_uploads_add_custom_endpoints' );

/**
 * Insert the custom endpoints into the My Account menu.
 *
 * @param array $items this will create tab.
 * @since 1.1.0
 * @return array $items
 */
function max_my_uploads_add_custom_endpoints( $items ) {
	?>
	<style type="text/css">

.woocommerce .woocommerce-MyAccount-navigation ul li.woocommerce-MyAccount-navigation-link.woocommerce-MyAccount-navigation-link--max_my_uploads a:before {
    content: '\e89f';
}


	</style>
	<?php
	$items['max_my_uploads'] = 'My Uploads';
	return $items;
} // end function.
