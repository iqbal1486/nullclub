
<?php
    if(!empty($_GET['id'])){
			global $wpdb;
		    $table_name = $wpdb->prefix ."posts"; 
		    $video_id =  $_GET['id'];
		    $product_id= $wpdb->get_row( "SELECT ID FROM $table_name WHERE post_mime_type 
		     = '".$video_id."'" );
		    $url = get_permalink( $product_id->ID );
	}else{
            $url = site_url('/shop');
	}			   
?>
<style>
	.btn.mt-2 {
 
    padding: 12px 36px 12px 36px;
    font-weight: 600;
    
}
.btn.btn-warning.mt-2 {
    padding: 12px 36px 12px 36px;
    font-weight: 600;
}
.btn.mt-2.your_upload_page {
    margin-left: 24px;
}
.retrun_to_store{
    background-color:#533980;
    color: white;
    border: none;
}
.retrun_to_store:hover{
  background-color:#FFD700;
  color: white;
  border: none;
}
.your_upload_page{
    background-color:#533980;
    color: white;
    border: none;
}
.your_upload_page:hover{
  background-color:#FFD700;
  color: white;
  border: none;
}
.go_to_profile{
    background-color:#533980;
    color: white;
    border: none;
}
.go_to_profile:hover{
  background-color:#FFD700;
  color: white;
  border: none;
}

</style>
<div class="row">
	<div class="col-md-4">
		  <button  class=" btn mt-2  retrun_to_store  "   onclick="location.href='<?php echo site_url('/shop') ?>'" type="button"> 
             Return To Storefront
          </button>
		 <!--shop page-->
	</div>
	
	<div class="col-md-4">
		 <button  class=" btn mt-2  your_upload_page "   onclick="location.href='<?php echo $url; ?>'" type="button"> 
             View Your Uploads
          </button>
		  <!--uploaded video -->
	</div>
	<div class="col-md-4">
		  <button  class=" btn mt-2  go_to_profile "   
      onclick="location.href='<?php echo site_url('/members/me/activity/') ?>'" type="button"> 
             Go To Profile
          </button>
		 <!--news feed -->
	</div>
</div>





