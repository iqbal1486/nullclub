



<?php



	if(isset($_POST['create_vimeo_post'])){




		    //upload video to api 



		    $video_title           = $_POST['video_title'];



		    $file_name    = $_FILES['vimeo_video']['tmp_name'];



			if(isset($_FILES['vimeo_video_img']['tmp_name']) && !empty($_FILES['vimeo_video_img']['tmp_name'])){



			    $vimeo_video_pic   = $_FILES['vimeo_video_img']['tmp_name'];



			}



			else{



				global $wpdb;



			    $table_name = $wpdb->prefix . "posts"; 



			    $post_id = get_option( 'defaul_vimeo_thumnail' );



			    $img = $wpdb->get_row( "SELECT * FROM $table_name WHERE ID = '".$post_id."' " );



			    $url =  $img->guid;



			    $site = site_url();



			    $site_path =dirname(dirname(dirname(dirname(dirname(__FILE__)))));



			    $vimeo_video_pic = str_replace($site, $site_path, $url);



			}



		    require_once(MVA_PLUGIN_DIR_PATH . 'vendor/autoload.php');



			require_once(MVA_PLUGIN_DIR_PATH . 'vendor/vimeo/vimeo-api/src/Vimeo/Vimeo.php');



		    $client_id     = '8a895685bc7652dfea40e76c5720eb4bb8b38a0a';



		   



		    $token         = '7d9c0ba546a97d4f48030ed60d7421fd';



		    $client_secret = 'EdVD4aPuLLNxV5UDPV58WdvGVPbB/L7dzeghAE+th3/GDM1lgyN1qc+u6TUyS20NA2YYDyFfA+7TNAVQnsuEfhW7pAudP6yla+M2kqL797RacXiqvzaUCturo44C6fog';



		    //make connection to api



		    $client = new \Vimeo\Vimeo($client_id, $client_secret, $token);



		    //upload file to 







			$vimeo_video_id = $client->upload($file_name, array(



			  'name' => $video_title



			));



			







		   $vimeo_image_id = $client->uploadImage($vimeo_video_id.'/pictures',$vimeo_video_pic, true);







		      //here we store the image in local 



	        require_once( ABSPATH . 'wp-admin/includes/image.php' );



	        require_once( ABSPATH . 'wp-admin/includes/file.php' );



	        require_once( ABSPATH . 'wp-admin/includes/media.php' );



	        if(!empty($_FILES['vimeo_video_img']['tmp_name'])){



	        	$files                  = $_FILES['vimeo_video_img'];



		        $file = array(



		          'name' => $files['name'],



		          'type' => $files['type'],



		          'tmp_name' => $files['tmp_name'],



		          'error' => $files['error'],



		          'size' => $files['size']



		        );



		        $_FILES = array("upload_file" => $file);



	            $thumnail_attachment_id = media_handle_upload("upload_file", 0);  



	            // $_SESSION['thumnail_attachment_id'] = $thumnail_attachment_id;



	        }



	        else{



	        	 $thumnail_attachment_id = get_option( 'defaul_vimeo_thumnail' );



	        	 // $_SESSION['thumnail_attachment_id'] = $thumnail_attachment_id;



	        }	



























			//Store to local



		    // $thumnail_attachment_id    = $_POST['thumnail_attachment_id'];



		    



		    $vimeo_search_tag          = $_POST['vimeo_search_tag'];

		  



		    $video_title               = $_POST['video_title'];



		    $vimeo_category            = $_POST['vimeo_category'];



			$vimeo_description         = $_POST['vimeo_description'];



			$org_post_title            = $_POST['org_post_title'];



			$speaker_first_name_1      = $_POST['speaker_first_name_1'];



			$speaker_last_name_1       = $_POST['speaker_last_name_1'];



			$pirmary_speaker_user_name = $_POST['pirmary_speaker_user_name'];



			$product_ation             = $_POST['product_ation'];



			$who_can_shop              = $_POST['who_can_shop'];











			if(!empty($_POST['max_vimeo_groups'])){



			$max_vimeo_groups          = $_POST['max_vimeo_groups'];



			}else{



				$max_vimeo_groups          = '';



			}



			if(!empty($_POST['max_vimeo_denomination'])){



			$max_vimeo_denomination    = $_POST['max_vimeo_denomination'];



			}else{



				$max_vimeo_denomination    = '';



			}







			if(!empty($_POST['other_price'])){



			    $vimeo_video_price        = $_POST['other_price'];



			}else{



				$vimeo_video_price  = $_POST['vimeo_video_price'];



			}



			// $max_vimeo_denomination    = $_POST['max_vimeo_denomination'];



			$max_vimeo_date            = $_POST['max_vimeo_date'];



		    $org_city                  = $_POST['org_city'];



			$org_region                = $_POST['org_region'];



			$max_alernate_location     = $_POST['max_alernate_location'];



			$primary_speaker_uid_1     = $_POST['primary_speaker_uid_1'];



			if(!empty($_POST['primary_speaker_uid_2'])){



			    $primary_speaker_uid_2     = $_POST['primary_speaker_uid_2'];



			    $speaker_first_name_2      = $_POST['speaker_first_name_2'];



			    $speaker_last_name_2       = $_POST['speaker_last_name_2'];



			}else{



				 $primary_speaker_uid_2     = '';



			    $speaker_first_name_2      = '';



			    $speaker_last_name_2       = '';



			}



			if(!empty($_POST['primary_speaker_uid_3'])){



				$primary_speaker_uid_3     = $_POST['primary_speaker_uid_3'];



				$speaker_first_name_3      = $_POST['speaker_first_name_3'];



				$speaker_last_name_3       = $_POST['speaker_last_name_3'];



			}else{



			    $primary_speaker_uid_3     = '';



				$speaker_first_name_3      = '';



				$speaker_last_name_3       = '';



			}



			// $vimeo_video_id            = trim($_POST['vimeo_video_id']);



			// $vimeo_image_id            = trim($_POST['vimeo_image_id']);



	        //creat post 







	        //video id



	        $vimeo_video_file_id = str_replace("/videos","video",$vimeo_video_id);



	        $create_post = array(



					  'post_title'                => $video_title,



					  'post_type'                 => 'product',



					  'pinged'                    => $vimeo_category,



					  'post_excerpt'              => $vimeo_description,



					  'post_status'               => 'publish',



					  'post_mime_type'            => $vimeo_image_id,



					  'post_content_filtered'     => $vimeo_search_tag



					   );



	       



            $post_id = wp_insert_post( $create_post );



            $sold_by = get_current_user_id(); 







			$post_meta_val = array(



				      'vimeo_video_sold_by'       => $sold_by,

				      'vimeo_category'            => $vimeo_category,



				      'vimeo_video_file_id'       => $vimeo_video_file_id,



					  'org_post_title'            => $org_post_title,



					  'speaker_first_name_1'      => $speaker_first_name_1,



					  'speaker_last_name_1'       => $speaker_last_name_1,



					  'pirmary_speaker_user_name' => $pirmary_speaker_user_name,



					  'vimeo_video_price'         => $vimeo_video_price,



					  'product_ation'             => $product_ation,



					  'who_can_shop'              => $who_can_shop,



					  'max_vimeo_groups'          => $max_vimeo_groups,



					  'max_vimeo_denomination'    => $max_vimeo_denomination,



					  'max_vimeo_date'            => $max_vimeo_date,



					  'org_city'                  => $org_city,



					  'org_region'                => $org_region,



					  'max_alernate_location'     => $max_alernate_location,



					  'primary_speaker_uid_1'     => $primary_speaker_uid_1,



					  'primary_speaker_uid_2'     => $primary_speaker_uid_2,



					  'speaker_first_name_2'      => $speaker_first_name_2,



					  'speaker_last_name_2'       => $speaker_last_name_2,



					  'primary_speaker_uid_3'     => $primary_speaker_uid_3,



					  'speaker_first_name_3'      => $speaker_first_name_3,



					  'speaker_last_name_3'       => $speaker_last_name_3,



					  'vimeo_video_id'           => $vimeo_video_id,



					  'vimeo_image_id'          => $vimeo_image_id



			); 

			

		

            update_post_meta( $post_id, 'vime_video_id', $vimeo_video_id );



			update_post_meta( $post_id, '_price', $vimeo_video_price );



			update_post_meta( $post_id, 'vimeo_search_tag', $vimeo_search_tag );



			update_post_meta( $post_id, '_regular_price', $vimeo_video_price );



			update_post_meta($post_id, 'max_vimoe_post_meta',  $post_meta_val );



			wp_set_object_terms($post_id, $vimeo_search_tag, 'product_tag');

			wp_set_object_terms($post_id, $vimeo_category, 'denominations');



			set_post_thumbnail( $post_id, $thumnail_attachment_id );







			//Make Dpwnlodable



			wp_set_object_terms( $post_id, 'simple', 'product_type');







            update_post_meta( $post_id, '_downloadable', 'yes');







            $file_url = 'https://player.vimeo.com/'.$vimeo_video_file_id;



            $files[md5( $file_url )] = array(



                'name' => $video_title,



                'file' => $file_url



            );   



            update_post_meta( $post_id, '_downloadable_files', $files );



            //end







			//get all categories



		    $taxonomy     = 'product_cat';



			$orderby      = 'name';  



			$show_count   = 0;      // 1 for yes, 0 for no



		    $pad_counts   = 0;      // 1 for yes, 0 for no



		    $hierarchical = 1;      // 1 for yes, 0 for no  



		    $title        = '';  



		    $empty        = 0;



			$args = array(



			         'taxonomy'     => $taxonomy,



			         'orderby'      => $orderby,



			         'show_count'   => $show_count,



			         'pad_counts'   => $pad_counts,



			         'hierarchical' => $hierarchical,



			         'title_li'     => $title,



			         'hide_empty'   => $empty



			);



			$all_categories = get_categories( $args );



			$lower_cat = strtolower($org_post_title); 	



			$cat_slug =  str_replace(' ', '-', $lower_cat);







			global $wpdb;    



            $table_term = $wpdb->prefix . "terms";



            $term_taxonomy = $wpdb->prefix . "term_taxonomy";











			$get_cat = [];



			$term_id = [];







			foreach ($all_categories as $key => $cat) { 



		



				$get_cat[] = $cat->slug;



				$term_id[] = $cat->term_id;







				if( $cat->slug == $cat_slug ) {



					wp_set_object_terms( $post_id, $cat->term_id, 'product_cat' );



				}







			}







			if(in_array( $cat_slug, $get_cat )){



					// $result = $wpdb->get_results( "SELECT term_id FROM $table_term WHERE slug =  '$cat_slug'",ARRAY_A); 







					// $termz_id = $result[0]['term_id'];



					// $result_two = $wpdb->get_row("SELECT term_id,term_taxonomy_id FROM $term_taxonomy WHERE term_id = '$termz_id'",ARRAY_A);



					



			  //       wp_set_object_terms( $post_id, $result_two, 'product_cat' );



			}



			else{







				$term_id = wp_insert_term( $org_post_title, 'product_cat', array( 



				    'parent' => 0, // optional



				    'slug' => $cat_slug // optional



				) );



				wp_set_object_terms( $post_id, $term_id, 'product_cat' );



			}



			







		    $video_url =  site_url('after-upload-page').'/?id='.$vimeo_image_id;



	        echo "<script>location.href = '$video_url';</script>";  



	}







	// $max_vimeo_groups          = $_POST['max_vimeo_groups'];



?>







<!--end of the hidden input-->



<div class="container ">



	



    <div class="row">



  	    <div class="col-md-12">



	  		<form method="post" class="pt-2" enctype="multipart/form-data">	



				<div class="row">



					<div class="col-md-7">



						<div class="form-group">



						    <label><b>Video Name</b> <span class="text-danger">*</span></label>



						    <?php



							    if(isset($_POST['video_title'])){



							    	$video_title = $_POST['video_title'];



							    }else{



							    	$video_title = '';



							    }



						    ?>



							<input type="text" class="form-control upload_input" name="video_title" value="<?php echo $video_title ?>"  readonly>



			        	</div>



			        	<div class="form-group">



						    <label><b>Organization Where Recorded</b> </label>



						    <?php



							    if(isset($_POST['org_post_title'])){



							    	$org_post_title = $_POST['org_post_title'];



							    }else{



							    	$org_post_title = '';



							    }



						    ?>



							<input type="text" class="form-control upload_input org_post_title"  name="org_post_title" 



							value="<?php echo $org_post_title ?>" readonly>



			        	</div>



			        	<div class="form-group">



						   <label><b>Name of PRIMARY speaker <span class="text-danger">*</span></b></label>



			        	</div>



			        	<div class="row">



			        		<div class="col-md-6">



			        			<div class="form-group">



									 <?php



										    if(isset($_POST['speaker_first_name_1'])){



										    	$speaker_first_name_1 = $_POST['speaker_first_name_1'];



										    }else{



										    	$speaker_first_name_1 = '';



										    }



									    ?>



										<input type="text" class="form-control upload_input"  name="speaker_first_name_1" 



										value="<?php echo $speaker_first_name_1 ?>" readonly>



									    <label>First</label>



			        	        </div>



			        		</div>



			        		<div class="col-md-6">



			        			<div class="form-group">



									<?php



									    if(isset($_POST['speaker_last_name_1'])){



									    	$speaker_last_name_1 = $_POST['speaker_last_name_1'];



									    }else{



									    	$speaker_last_name_1 = '';



									    }



									?>



									<input type="text" class="form-control upload_input"  name="speaker_last_name_1" 



										value="<?php echo $speaker_last_name_1 ?>" readonly>



									<label>Last</label>



			        	        </div>



			        		</div>



			        	</div>











			        	<div class="form-group">



			        		<!--zcss-->					        	



						    <label><b>Primary Speaker User Name </b></label>



							<?php



							    if (!empty($_POST['primary_speaker_uid_1'])) {



							    	global $wpdb;    



					                $table_users = $wpdb->prefix . "users";  



					                $user_name = $wpdb->get_row( "SELECT distinct display_name FROM $table_users Where ID = '".$_POST['primary_speaker_uid_1']."'");



								    







							    }



							    if(!empty($user_name)){   	



								    	$primary_speaker_uid_1 = $user_name->display_name;



								    }else{



								    	$primary_speaker_uid_1 = '';



								    }



							?>



							<input type="text" class="form-control upload_input" name="pirmary_speaker_user_name"   value="<?php echo $primary_speaker_uid_1 ?>" readonly>



			        	</div>



			        	<!---for video or thumnail-->



			        	<div class="form-group">



							<label>Upload Video &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</label>



							<input style="overflow: hidden;" type="file" name="vimeo_video" class="form-control-file border vimeo_video" required>



						</div>



						<div class="form-group">



							<label>Upload Thumbnail</label>



							<input style="overflow: hidden;" type="file" name="vimeo_video_img" class="form-control-file border"  >



							<p class="thumnail_class pt-2">A thumbnail is the image that you want to display on your video uploads <br>in the store. For example, upload an image of: Your logo, sign, or symbol.</p>



						</div>



			        	<!--end of the video or thumanill-->







			        	<label><b>Price Of Video <span class="text-danger">*</span></b> </label>



						<div class="radio-light-styling">



                          







								<label class="radio-label-styling">



								    <input class="radio-input-styling vimeo_video-price " type="radio" value="free" name="vimeo_video_price" required>



								    <span class="radio-design-styling"></span>



								    <span class="radio-text-styling"> Free</span>



								</label>



								  



								<label class="radio-label-styling">



								    <input class="radio-input-styling vimeo_video-price" type="radio" value=".99" name="vimeo_video_price">



								    <span class="radio-design-styling"></span>



								    <span class="radio-text-styling">$0.99</span>



								</label>







								<label class="radio-label-styling">



								    <input class="radio-input-styling vimeo_video-price" type="radio" value="$1.99" name="vimeo_video_price">



								    <span class="radio-design-styling"></span>



								    <span class="radio-text-styling">$1.99</span>



								</label>







								<label class="radio-label-styling">



								    <input class="radio-input-styling vimeo_video-price" type="radio" value="$4.99" name="vimeo_video_price">



								    <span class="radio-design-styling"></span>



								    <span class="radio-text-styling">$4.99</span>



								</label>











								<label class="radio-label-styling">



								    <input class="radio-input-styling vimeo_video-price" type="radio" value="$9.99" name="vimeo_video_price">



								    <span class="radio-design-styling"></span>



								    <span class="radio-text-styling">$9.99</span>



								</label>







								<label class="radio-label-styling">



								    <input class="radio-input-styling vimeo_video-price" type="radio" value="$19.99" name="vimeo_video_price">



								    <span class="radio-design-styling"></span>



								    <span class="radio-text-styling">$19.99</span>



								</label>







								 <label class="radio-label-styling">



								    <input class="radio-input-styling vimeo_video-price " type="radio"  name="vimeo_video_price" value="vimeo_video_price_other" >



								    <span class="radio-design-styling"></span>



								    <span class="radio-text-styling"> Other Amount</span>



								</label>



								<input type="text" class="form-control other_price"  name="other_price" 



										value="" style="width: 200px;display: none;" placeholder="$" >







								<!-- <label><b>Product Action <span class="text-danger">*</span></b> </label>  -->







							<!-- 	<label class="radio-label-styling">



								    <input class="radio-input-styling vimeo_video-price" type="radio" value="view_on_website" name="product_ation" required>



								    <span class="radio-design-styling"></span>



								    <span class="radio-text-styling">View On Website</span>



								</label> -->







								<!-- <label class="radio-label-styling">



								    <input class="radio-input-styling" type="radio" value="download" name="product_ation">



								    <span class="radio-design-styling"></span>



								    <span class="radio-text-styling">Download</span>



								</label> -->



								<!-- <label class="radio-label-styling">



								    <input class="radio-input-styling" type="hidden" value="both" name="product_ation" checked>







								    <span class="radio-design-styling"></span>



								    <span class="radio-text-styling">Both</span>



								</label> -->



								<input class="radio-input-styling" type="hidden" value="both" name="product_ation" >







								<label><b>Who Can Shop For This Video <span class="text-danger">*</span></b></label>







								<label class="radio-label-styling">



								    <input class="radio-input-styling" type="radio" value="anyone"  name="who_can_shop" required>



								    <span class="radio-design-styling"></span>



								    <span class="radio-text-styling">Anyone</span>



								</label>







								<label class="radio-label-styling">



								    <input class="radio-input-styling" type="radio" value="members_only" name="who_can_shop">



								    <span class="radio-design-styling"></span>



								    <span class="radio-text-styling">Members Only</span>



								</label>







							    <label class="radio-label-styling">



								    <input class="radio-input-styling" type="radio" value="group_only" name="who_can_shop">



								    <span class="radio-design-styling"></span>



								    <span class="radio-text-styling">Groups Only</span>



								</label>







								<div class="select2-blue select2_prodcut_cat_id  max_vimeo_groups "  style="width: 300px;height: 25px;margin-left: 165px; display: none;margin-bottom: 20px;">



							  	   <?php



				                    global $wpdb;    



				                    $table_name = $wpdb->prefix . "bp_groups";  



				                    $result = $wpdb->get_results( "SELECT name FROM $table_name");



				                  ?>



	                              <select name="max_vimeo_groups[]" class="js-example-placeholder-single org_post_title" multiple="multiple" data-dropdown-css-class="select2-blue" style="width: 300px;height: 25px;" >



					                   <option value="0">Select Group</option>



					                        <?php



					                           foreach ($result as  $value) {



					                        ?>



					                    <option  value="<?php echo $value->name ?>"> <?php echo $value->name; ?>



					                    </option>



					                    <?php



					                        }                           



					                     ?> 



				                   </select>



				                </div>   







								<label class="radio-label-styling">



								    <input class="radio-input-styling" type="radio" value="denomination_only" name="who_can_shop">



								    <span class="radio-design-styling"></span>



								    <span class="radio-text-styling">Denomination Only</span>



								</label>



                                







								<div class="select2-blue select2_prodcut_cat_id          max_vimeo_denomination form-group " style="display: none; width: 300px;height: 25px;margin-left: 165px;">







								  	<?php



					                    



				                        global $wpdb;    



				                        $denomination_table = $wpdb->prefix . "geodir_gd_place_detail";  



				                        $result = $wpdb->get_results( "SELECT  distinct  post_title FROM $denomination_table  where post_status = 'publish' 



				                        	ORDER BY post_title ASC limit 50");  



					                ?>



				                   



		                            <select name="max_vimeo_denomination[]" class="js-example-placeholder-single form-control" multiple="multiple" data-dropdown-css-class="select2-blue"  style="width: 300px;height: 25px;" >



					                   <option value="0">Select Group</option>



					                        <?php



					                           foreach ($result as  $value) {



					                        ?>



					                    <option  value="<?php echo $value->post_title; ?>"> <?php echo $value->post_title; ?>



					                    </option>



					                    <?php



					                        }                           



					                     ?> 



					                </select> 



				



				                </div>











						</div> 



				    </div>



				</div>    



						



						







				<!-- hidden input -->



			



				<?php 



				    if(!empty($_POST['vimeo_search_tag'])){



				    	foreach( $_POST['vimeo_search_tag'] as $value ) {



						echo '<input type="hidden" name="vimeo_search_tag[]" value="'. $value. '">';



					    }







				    }



					



				?>



				







		



			



				<input type="hidden" name="vimeo_category" value="<?php echo $_POST['vimeo_category']; ?>">



				<input type="hidden" name="vimeo_description" value="<?php echo $_POST['vimeo_description']; ?>">







				<input type="hidden" name="max_vimeo_date" value="<?php echo $_POST['max_vimeo_date']; ?>">



				<input type="hidden" name="org_city" value="<?php echo $_POST['org_city']; ?>">



				<input type="hidden" name="org_region" value="<?php echo $_POST['org_region']; ?>">



				<input type="hidden" name="max_alernate_location" value="<?php echo empty($_POST['max_alernate_location']) ? "empty" :



				 $_POST['max_alernate_location']  ?>">







				<input type="hidden" name="primary_speaker_uid_1" value="<?php echo $_POST['primary_speaker_uid_1']; ?>">







				<input type="hidden" name="primary_speaker_uid_2" value="<?php echo $_POST['primary_speaker_uid_2']; ?>">



				<input type="hidden" name="speaker_first_name_2" value="<?php echo $_POST['speaker_first_name_2']; ?>">



				<input type="hidden" name="speaker_last_name_2" value="<?php echo $_POST['speaker_last_name_2']; ?>">







				<input type="hidden" name="primary_speaker_uid_3" value="<?php echo $_POST['primary_speaker_uid_3']; ?>">



				<input type="hidden" name="speaker_first_name_3" value="<?php echo $_POST['speaker_first_name_3']; ?>">



				<input type="hidden" name="speaker_last_name_3" value="<?php echo $_POST['speaker_last_name_3']; ?>">







				<style type="text/css">



					.vimeo_video_btn_back{



						background-color:#533980;



						color: white;



		                margin-top: 2em !important;



		                border-radius: 3em;



		                padding: 8px 20px 8px 20px;



		                border: none;



         



					}



					.vimeo_video_btn_back:hover{



						background-color:#FFD700;



						color: white;



						 border: none;



					}



					.create_vimeo_post{



						background-color:#533980;



						color: white;



		                margin-top: 2em !important;



		                border-radius: 3em;



		                padding: 8px 20px 8px 20px;



		                border: none;



         



					}



					.create_vimeo_post:hover{



						background-color:#FFD700;



						color: white;



						 border: none;



					}







					



				</style>



				



		



               



                 <a class="btn text-white mt-2 vimeo_video_btn_back">Back</a>



                  



               







                <button type="submit" name="create_vimeo_post" class="btn  mt-2 create_vimeo_post" data-site_url="<?php echo site_url() ?>" >submit</button>







              



		    </form>



  	    </div>



    </div>



</div>











	







