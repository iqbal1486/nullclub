<?php


add_action( 'woocommerce_account_max_my_uploads_endpoint', 'max_display_max_my_uploads_content' );


function max_display_max_my_uploads_content() {
	

	    ?>
		<style type="text/css">

			img.vimeo_thumbnail {

			    width: 60px;

			    height: 60px !important;

			    border-radius: 2px;

			}

			.col-md-6.mt-1.bg-success {

				    background-color: transparent !important;

				    margin: 24px 0 0 0 !important;

			}

			img.attachment-thumbnail.size-thumbnail.wp-post-image{

				width: 80px;

			}

			input.btn.my_uploads_dlt_btn {

			    background-color: #FFD500;

			    color: white;

			    border-radius: 5px;

			    border: none;

			}

			a.btn.btn-primary.my_upload_edit_btn {

			    background-color: #57387F;

			    color: white;

			    border-radius: 5px;

			    border: none;

			}
		</style>
		<div class="container" >
			<div class="row">

				<div class="col-md-12">

					<form method="post">

						 <div class="input-group mb-3">

						     <input class="form-control my-0 py-1" name="vimeo_search_tag" type="search" placeholder="Search" aria-label="Search" style="height: 55px;">

						    <div class="input-group-append">

						      <span class="input-group-text">

						      	 <button type="submit" name="vimeo_search_tag_btn" class="btn text-white" style="background-color: #57387F">Search</button>

						      </span>

						    </div>

						  </div>

					</form>

		            <div class="row" >

		            

						<?php  

						    //load sdk of vimeo

							require_once(MVA_PLUGIN_DIR_PATH . 'vendor/autoload.php');

							require_once(MVA_PLUGIN_DIR_PATH . 'vendor/vimeo/vimeo-api/src/Vimeo/Vimeo.php');

						    $client_id     = '8a895685bc7652dfea40e76c5720eb4bb8b38a0a';

				            $token         = '7d9c0ba546a97d4f48030ed60d7421fd';

				            $client_secret = 'EdVD4aPuLLNxV5UDPV58WdvGVPbB/L7dzeghAE+th3/GDM1lgyN1qc+u6TUyS20NA2YYDyFfA+7TNAVQnsuEfhW7pAudP6yla+M2kqL797RacXiqvzaUCturo44C6fog';

						    //make connection to api

						    $client = new \Vimeo\Vimeo($client_id, $client_secret, $token);

						   



		                    // Delete Fuction 

						    if(isset($_POST['my_uploads_dlt_btn'])){

								$video_id = $_POST['my_upload_video_id'];

								$post_id = $_POST['max_dlt_post_id'];

							    $uri = $client->request($video_id,array(),'DELETE');

							    wp_delete_post( $post_id, true);

								

							}

							 if(isset($_POST['my_uploads_dlt_all'])){
							 	if ( !empty($_POST['selected_posts']) && isset($_POST['selected_posts'] )){
									$selected_posts = $_POST['selected_posts'];
									foreach ( $selected_posts as $post_id ) {

									$max_video_id =  get_post_meta($post_id,'vime_video_id', true);
										
									

								    $uri = $client->request($max_video_id,array(),'DELETE');

								    wp_delete_post( $post_id, true);
									  
									}
								}

								

								

							}





		                    //Update Function

							if(isset($_POST['my_uploads_update'])){

								$video_title = $_POST['update_video_title'];

								$video_id = $_POST['update_video_id'];

								$post_id = $_POST['update_post_id'];



								if(!empty($_POST['update_video_price']) &&  $_POST['update_video_price'] == 'other_amount'){

									

								    $video_price = $_POST['update_other_price'];

								}else{

									

									$video_price = $_POST['update_video_price'];

								}



							



								

								

							    update_post_meta( $post_id, '_price', $video_price );

					            update_post_meta( $post_id, '_regular_price', $video_price );

					            $my_post = array(

									      'ID'           => $post_id,

									      'post_title'   => $video_title,

									  );

								wp_update_post( $my_post );

					                $client->request($video_id, array(

									    'name' => $video_title

									), 'PATCH');



							}

		                    

		                     

		                   





						



					





						    global $wpdb;

						    $current_user_id = get_current_user_id();

						    $table_name = $wpdb->prefix . "posts"; 

						    $post_meta = $wpdb->prefix . "postmeta"; 

						    $term_relationships = $wpdb->prefix . "term_relationships"; 

						    $term_taxonomy = $wpdb->prefix . "term_taxonomy"; 

						    $terms = $wpdb->prefix . "terms";







						    

			                if(isset($_POST['vimeo_search_tag_btn'])){

			                	$search_val = $_POST['vimeo_search_tag'];

			                	$sql = "SELECT distinct

			                	               p.ID,

										       p.post_mime_type,

											   p.post_type,

											   p.post_title,

											   p.post_excerpt,

											   t.name AS product_category		  

										FROM $table_name p

										left outer join $post_meta pm on p.id = pm.post_id and pm.meta_key = 'max_vimoe_post_meta'

										LEFT JOIN $term_relationships AS tr ON tr.object_id = p.ID

										JOIN $term_taxonomy AS tt ON tt.taxonomy = 'product_cat' AND tt.term_taxonomy_id = tr.term_taxonomy_id

										JOIN $terms AS t ON t.term_id = tt.term_id

										WHERE post_mime_type like '/videos/%'

										AND post_type = 'product'

										AND post_author = '".$current_user_id."'

										AND (upper(post_excerpt) like upper('%".$search_val."%')

										     or

										     upper(pm.meta_value) like upper('%".$search_val."%')	

										    )	

										order by t.name, p.post_title";

				   			     // $result = $wpdb->get_results( "SELECT ID, post_mime_type,post_type,post_title, pinged FROM $table_name WHERE post_mime_type like '/videos/%' AND post_type = 'product' AND pinged like '%".$search_val."%' AND post_author = '".$current_user_id."'  order by ID desc  ", ARRAY_A);

			                	 $result = $wpdb->get_results( $sql, ARRAY_A);

			                

				   			     



				   			  





				   			

				   			    if(empty($result)){

				   			    	echo "No Results Founds";

				   			    }

			                }else{

			                	  $result = $wpdb->get_results( "SELECT ID, post_mime_type,post_type,post_title, pinged FROM $table_name WHERE post_mime_type like '/videos/%' AND post_type = 'product' AND post_author = '".$current_user_id."' order by ID desc  ", ARRAY_A);

			                }

			               



		                   ?>

		                   		<form method="POST" id="delete_selected">
								<div class="row">
									<div class="col-md-7 ">
														
									<input type="submit"  name="my_uploads_dlt_all" value="Delete Selected"/>				
								
									</div>
									<div class="col-md-5 pt-2" style="text-align: center;">
										<label for="max_select_all">Select All</label><br>
									<input type="checkbox" data-paret="off" id="max_select_all" name="max_select_all"></input>
									</div>
								</div>
								
							
									

							
							</form>	

		            



		                   	<table class="table table-striped table-responsive" >

									<tr>
										



										<th colspan="2" style="text-align: center;">Title</th>
										<th>Select</th>

										<th>Organization</th>

										<th>Speakers</th>

										<th>Views</th>

										<th>Edit</th>

										<th>Delete</th>

									</tr>

									

								

		                   <?php



		                   	function getVimeoStats($id) {

						    $ch = curl_init();

						    curl_setopt($ch, CURLOPT_URL, "http://vimeo.com/api/v2/video/$id.php");

						    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

						    curl_setopt($ch, CURLOPT_TIMEOUT, 30);

						    $output = unserialize(curl_exec($ch));

						    $output = $output[0];

						    curl_close($ch);

						    return $output;

							}



				           foreach ($result as  $value) {

				            $thumnail =  get_the_post_thumbnail( $value['ID'], 'thumbnail' );





				         

				           	//Get Speaker

				           	$get_meta_speaker = get_post_meta( $value['ID'], 'max_vimoe_post_meta', true );





				           	$max_video_id =  get_post_meta($value['ID'],'vime_video_id', true);

				           	$max_video_price =  get_post_meta( $value['ID'], '_price', true);

				            $id =  str_replace("/videos/","", $max_video_id);

				           	//Get the number of views 

			                $VimeoStats = getVimeoStats($id); 

							$plays = $VimeoStats['stats_number_of_plays'];



								 if(!empty($value)){

								?>

								<tr>
								

								

								    <td><?php echo $thumnail; ?></td>



									<td><?php echo $value['post_title']; ?></td>

							    <td style="text-align: center;">
									<input type="checkbox" data-check='off' name="selected_posts[]" id="<?= $value['ID'] ?>" value="<?= $value['ID'] ?>" form="delete_selected" class="checkbox" />
								</td>

									

									

									<td><?php echo $get_meta_speaker['org_post_title']; ?></td>

									<td>

										<?php

										

										if (!empty($get_meta_speaker['speaker_first_name_1'])) {

										      echo "<span style='  display:inline;'>Speaker 1: </span>";

										      echo "<span style=' color: #533980; display:inline;'>".$get_meta_speaker['speaker_first_name_1']." ".$get_meta_speaker['speaker_last_name_1']." </span>"; 

										}

										 if (!empty($get_meta_speaker['speaker_first_name_2'])) {

										      echo "<br>";

										      echo "<span style='  display:inline;'>Speaker 2: </span>";

										      echo "<span style=' color: #533980; display:inline;'>".$get_meta_speaker['speaker_first_name_2']." ".$get_meta_speaker['speaker_last_name_2']." </span>";



										}

										if (!empty($get_meta_speaker['speaker_first_name_3'])) {



										      echo "<br>";

										      echo "<span style='  display:inline;'>Speaker 3: </span>";

										      echo "<span style=' color: #533980; display:inline;'>".$get_meta_speaker['speaker_first_name_3']." ".$get_meta_speaker['speaker_last_name_3']." </span>";



										}

										?>

									</td>

									<td><?php echo $plays; ?></td>

		                            <td>

		                          
		                            	<?php
		                            	$action = get_site_url()."/edit_vimeo?id=".$value['ID'];
		                            	
		                            	?>

		                            	<form method="post" target="_blank" action="<?php echo $action; ?>">
		                            		<input type="hidden" name="edit" value="122">
		                            		<button class="btn btn-info " name="vimeo_eidt">Edit</button>
		                            	</form>
		                            </td>

									<td>

										<form method="post">

											<input type="hidden" name="max_dlt_post_id" value="<?php echo $value['ID']; ?>">

											<input type="hidden" name="my_upload_video_id" value="<?php echo $max_video_id; ?>">

											<input type="submit" value="Delete" name="my_uploads_dlt_btn" onclick="return confirm('Are You Sure You Want To Delete?');" class="btn my_uploads_dlt_btn">

										</form>

										

									</td>

								</tr>



								<?php

								}else{

								echo "There is an issue. Try Again..<br>";

								}



							

				            }



				            ?>

				        </table>

				            <?php

				            
						?> 
					</div>   
				</div>
			</div>
		</div>

	<?php






}










