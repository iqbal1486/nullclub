<?php
          
    add_action('wp_ajax_mva_org_post_title', 'mva_org_post_title');
    add_action('wp_ajax_nopriv_mva_org_post_title', 'mva_org_post_title');
    function mva_org_post_title(){

        if(!empty($_GET['q'])){

                    global $wpdb;
        
                    $get_val = $_GET['q']; 

                    $table_name = $wpdb->prefix . "geodir_gd_place_detail";

                    $result = $wpdb->get_results( "SELECT DISTINCT post_title, city, region FROM $table_name WHERE upper( post_title ) 
                        like upper('%".$get_val ."%') LIMIT 50");

                        if(!empty($result)){
                            $data[] = $result;
                        }else{
                            $data[] = array('post_title'=>"",'city'=>"",'region' => "");
                        }
                        
            echo json_encode($data);   
                
        } 
        die();
    }         


