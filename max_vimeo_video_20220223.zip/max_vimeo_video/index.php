<?php

/* Silence is golden. */