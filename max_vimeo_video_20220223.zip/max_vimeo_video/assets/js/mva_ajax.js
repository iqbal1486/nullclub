jQuery(document).ready(function ($) {

    $( "#max_select_all" ).change(function(e) {
  
      var check =  $(this).attr('data-paret');
      if(check == 'off'){
        $(this).attr('data-paret','on');
        $('.checkbox').prop('checked', true);
      }else{
        $(this).attr('data-paret','off');
        $('.checkbox').prop('checked', false);
      }

    
      

    });


      

   
 
  //////////////////////////////////////////////////////////////////////


      var selectedlocation = $("#selected_org_title").val();

      var newOption = new Option(selectedlocation, selectedlocation, true, true);

      $('#mva_search_bar').append(newOption).trigger('change');

});





jQuery(document).ready(function ($) {




  // ************************************ MY ACCOUNT PAGE **************************//

  $( ".my_account_edit_model_close_btn" ).click(function() {

      $('.update_other_price').val(''); 

      $('.update_other_price').hide();

  }); 

  // My account Update function

  $( ".my_upload_edit_btn" ).click(function() { 

    var price =  $(this).attr("data-price");

    

    var title =  $(this).attr("data-title");

    var video_id =  $(this).attr("data-video_id");

    var post_id =  $(this).attr("data-post_id");

    $('.update_video_title').val(title);

    $('.update_video_id').val(video_id);

    $('.update_post_id').val(post_id);

    switch (price) {

      case 'free':

        $("#max_update_free").prop("checked", true);

        break;

      case '0.99':

        $("#max_update_second").prop("checked", true);

        break;

      case '1.99':

        $("#max_update_three").prop("checked", true);

        break;

      case '4.99':

        $("#max_update_four").prop("checked", true);

        break;

      case '9.99':

        $("#max_update_five").prop("checked", true);

        break;

      case '19.99':

        $("#max_update_six").prop("checked", true);

        break;

      default: 

      $("#max_update_seven").prop("checked", true);

      $('.update_other_price').show(); 

      $('.update_other_price').val(price); 

    } 

  }); 



  $('input:radio[name="update_video_price"]').change( function(){



        if (this.checked && this.value == 'other_amount') {

           $('.update_other_price').show(); 

        }else{

             $('.update_other_price').hide();

        }

  });





     // End Delete code



  	$( function() {



      $( ".datepicker" ).datepicker();



    });







    $( ".vimeo_video_btn_back" ).click(function() { 



      history.go(-1);



    }); 



  



  // multiple select with AJAX search



    $(".js-data-example-ajax").select2({
      placeholder: "Select Your Organization Here",
      minimumInputLength: 3,
      ajax:{
        url: ajaxurl,
        dataType: "json",
        type: "GET",
        delay: 250,
        data: function(params){
          return {
            q:params.term,
            action: 'mva_org_post_title'
          };
        },
        processResults: function(data){

          if(data[0].post_title !== "" && data[0].city !== "" && data[0].region !== ""){

             return {
              results: $.map(data[0], function (item) {
                   return {
                    text: item.post_title,
                    id: item.post_title,
                    city: item.city,
                    region: item.region
                   }
              })
             };
          } else {

              $('.max_alernate_location').show();



            

              $('.org_city_id').val('');
              $('.org_region_id').val('');



          }



        },



        cache: true



      }



    });

  



    $('#mva_search_bar').on('select2:select', function (e) {



      var data = e.params.data;



      let selected_city = data.city;



      let selected_region = data.region;



      let post_title = data.text;



      if(selected_city == "" && selected_region == "" && post_title == ""){

         
          $('.max_alernate_location').show();

          $('.org_city_id').val('');

          $('.org_region_id').val('');

          $('#selected_org_title').val('');



      }else{

        



        sessionStorage.setItem("post_title_hidd", post_title);



        $('.max_alernate_location').hide();





        $('.org_city_id').val(selected_city);



        $('.org_region_id').val(selected_region);



        $('#selected_org_title').val(post_title);



           



      }



    });











	/////////////////////////////////////////////////////////////////////////////







	$( ".create_vimeo_post" ).click(function() {	



      var vimeo_video_price =  $('input:radio[name=vimeo_video_price]:checked').val();



      var who_can_shop      =  $('input:radio[name=who_can_shop]:checked').val();



      var file              =  $('.vimeo_video').get(0).files.length === 0;



     



      if (file == true){



          alert('VIDEO IS REQUIRED');  



          return false;



      }else if ( vimeo_video_price == undefined){



          alert('PRICE OF VIDEO IS REQUIRED'); 



          return false;



      }else if (who_can_shop == undefined ){



          alert('WHO CAN SHOP IS REQUIRED');



          return false;



      }



      else{



          var getSiteURL = $(this).attr('data-site_url');



          $('body').css('background-image', 'url(' + getSiteURL + '/wp-content/plugins/max_vimeo_video/assets/img/ezgif-6-983794785d1e.gif)');



              $("body").css('background-repeat', 'no-repeat');



              $('body').css('background-position', 'center');



              $('body').css('background-attachment', 'fixed');



              $('body *').css('opacity', '0.8');



      }



  }); 







  $('input:radio[name="vimeo_video_price"]').change(



    function(){



        if (this.checked && this.value == 'vimeo_video_price_other') {



           $('.other_price').show();



            



        }else{



             $('.other_price').hide();



        }



  });















	 $(".js-example-placeholder-single").select2({	



     placeholder: "Search Tags",



      minimumResultsForSearch: Infinity,



     allowClear: true



     });









    //first speaker



  $( ".primary_speaker_uid_1" ).change(function() {



	  var fname = $(this).find(':selected').attr('data-fname');



	  var lname = $(this).find(':selected').attr('data-lname');



	  	$('.speaker_first_name_1').val(fname);



        $('.speaker_last_name_1').val(lname);



	});







   //seconda speaker



  $( ".primary_speaker_uid_2" ).change(function() {



	  var fname = $(this).find(':selected').attr('data-fname');



	  var lname = $(this).find(':selected').attr('data-lname');



	  	$('.speaker_first_name_2').val(fname);



        $('.speaker_last_name_2').val(lname);



	});	







   //Third Speaker



  $( ".primary_speaker_uid_3" ).change(function() {



    	var fname = $(this).find(':selected').attr('data-fname');



	    var lname = $(this).find(':selected').attr('data-lname');



	  	$('.speaker_first_name_3').val(fname);



        $('.speaker_last_name_3').val(lname);



	});	



	/*



	$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ Video Upload Form $$$$$$$$$$$$$$$$$$$



	*/	



	$('input:radio[name="who_can_shop"]').change(



    function(){



        if (this.checked && this.value == 'group_only') {



            $('.max_vimeo_groups').show();



            $('.max_vimeo_denomination').hide();



        }



  });



  $('input:radio[name="who_can_shop"]').change(



    function(){



        if (this.checked && this.value == 'denomination_only') {



            $('.max_vimeo_denomination').show();



            $('.max_vimeo_groups').hide();



        }



  });



  $('input:radio[name="who_can_shop"]').change(



    function(){



        if (this.checked && this.value == 'anyone' || this.value == 'members_only' ) {



            $('.max_vimeo_denomination').hide();



            $('.max_vimeo_groups').hide();



        }



    });


  $('.upload_video_to_vimoe').click(function(e){
   var denomination =  $('.vimeo_category').val();
   if(denomination == 0){
    alert('Denomination field is required');    
    return false;
   }

  });



});











