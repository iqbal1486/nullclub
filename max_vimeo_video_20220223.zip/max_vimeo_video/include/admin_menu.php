<?php
//Admin menu
 add_action( 'admin_menu', 'max_vimeo_menus' );
function max_vimeo_menus() {
    add_menu_page(
        'Max Vimeo Video',
        'Max Vimeo Video',
        'manage_options',
        'max_vimeo_video',
        'max_vimeo_video_function',
        'dashicons-images-alt',
        20
    );
}     
function max_vimeo_video_function(){
    //here we add categories
    if(isset($_POST['submit'])){
            $files = $_FILES['vimeo_thumnail']; 
                $file = array(
                  'name' => $files['name'],
                  'type' => $files['type'],
                  'tmp_name' => $files['tmp_name'],
                  'error' => $files['error'],
                  'size' => $files['size']
                );
            $_FILES = array("upload_file" => $file);
            $attachment_id = media_handle_upload("upload_file", 0);
            update_option( 'defaul_vimeo_thumnail', $attachment_id );           
    }
    ?>
    <!--Form for adding categories-->
    <div class="container cat_container ">
    	<div class="row">
    		<div class="col-md-4 ">
    			<h3 class=" text-center text-white  p-2 mt-2" style="background-color: #831EB3" ><b>Vimeo Default Thumbnail</b></h3>
    			<form method="post" enctype="multipart/form-data">
					<div class="form-group">
					  <input type="file" name="vimeo_thumnail" class="form-control" >
					</div>
			        <button name="submit" type="submit" class="btn text-white btn-block " style="background-color: #831EB3">Add</button>
	            </form>
    		</div>
    		<div class="col-md-3"></div>
    		<div class="col-md-4">
        	    <!--display categories -->
	            <?php
	            global $wpdb;
                $table_name = $wpdb->prefix . "posts"; 
	            $post_id = get_option( 'defaul_vimeo_thumnail' );

                        $img = $wpdb->get_row( "SELECT * FROM $table_name WHERE ID = '".$post_id."' " );
	             ?>

	            <img src="<?php echo $img->guid ?>" width="100%" heigh="300px">
    		</div>
    	</div> 
    </div>
    <?php

}

   


   
