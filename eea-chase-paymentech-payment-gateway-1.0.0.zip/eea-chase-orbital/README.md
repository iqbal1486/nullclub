Event Espresso - Chase Orbital Payment Gateway
=========

The Event Espresso Chase Orbital adds 2 new payment methods: new onsite and new offsite

This plugin/addon needs to be uploaded to the "/wp-content/plugins/" directory on your server or installed using the WordPress plugins installer.