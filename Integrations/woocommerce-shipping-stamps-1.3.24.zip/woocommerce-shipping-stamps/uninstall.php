<?php
/**
 * Uninstaller.
 *
 * @package WC_Stamps_Integration
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit();
}
