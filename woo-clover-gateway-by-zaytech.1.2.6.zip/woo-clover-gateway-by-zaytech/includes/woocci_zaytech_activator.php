<?php


class Woocci_zaytech_activator
{
    public static function activate() {

    }
}