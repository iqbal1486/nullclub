jQuery(function ($) {
    $(document).on('click', '.add-more-tag-mapping', function () {
        var index = $(this).attr('data-index');
        var html = '<div class="tag_mappings_fields tag_mappings_set_' + index + '">';
        html += '<label><span>Min</span><input type="number" name="tag_mappings[' + index + '][min]" id="tag_mappings_min_' + index + '"></label>';
        html += '<label><span>Max</span><input type="number" name="tag_mappings[' + index + '][max]" id="tag_mappings_max_' + index + '"></label>';
        html += '<label><span>ActiveCampaign Tag</span><input type="text" name="tag_mappings[' + index + '][tag]" id="tag_mappings_tag_' + index + '"></label>';
        html += '<a href="javascript:void(0)" class="remove-mapping-row">x</a>';
        html += '</div>';
        $(this).attr('data-index', parseInt(index) + 1);
        $('.tag_mappings_wrapper').append(html);
    });
    $(document).on('click', '.remove-mapping-row', function () {
        $(this).parent('.tag_mappings_fields').remove();
    });
    $(document).on('click', 'input[name=activecampaign_use_custom_feilds_result]', function () {
        if($(this).val() == 'yes'){
            $('.qsm-add-ac-custom-fields').show();
        }else{
            $('.qsm-add-ac-custom-fields').hide();
        }
    });
    $(document).on('click', 'input[name=activecampaign_enable]', function () {
        if($(this).val() == 'yes'){
            $('.qsm-ac-other-settings').show();
        }else{
            $('.qsm-ac-other-settings').hide();
        }
    });
    $(document).on('click', 'input[name=activecampaign_checkbox_display]', function () {
        if($(this).val() == 'show'){
            $('.qsm-ac-checkbox-text').show();
        }else{
            $('.qsm-ac-checkbox-text').hide();
        }
    });
    qsm_ac_show_hide_element('input[name=activecampaign_enable]:checked', 'yes', 'show', '.qsm-ac-other-settings');
    qsm_ac_show_hide_element('input[name=activecampaign_checkbox_display]:checked', 'show', 'show', '.qsm-ac-checkbox-text');
    qsm_ac_show_hide_element('input[name=activecampaign_use_custom_feilds_result]:checked', 'yes', 'show', '.qsm-add-ac-custom-fields');
});


/**
 * checkbox hide show function
 * @param string element
 * @param string Value
 * @param string condition ( show/hide )
 * @param string show/hide target
 */
function qsm_ac_show_hide_element(element, val, condition, target){
    if(jQuery(element).val() == val){
        if(condition == 'show'){
            jQuery(target).show();
        }else{
            jQuery(target).hide();
        }
    }else{
        if(condition == 'show'){
            jQuery(target).hide();
        }else{
            jQuery(target).show();
        }
    }
}