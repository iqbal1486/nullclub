<?php
if (!defined('ABSPATH'))
	exit;

/**
 * Registers your tab in the addon  settings page
 *
 * @since 1.0.0
 * @return void
 */
function qsm_addon_activecampaign_register_addon_settings_tabs() {
	global $mlwQuizMasterNext;
	if (!is_null($mlwQuizMasterNext) && !is_null($mlwQuizMasterNext->pluginHelper) && method_exists($mlwQuizMasterNext->pluginHelper, 'register_quiz_settings_tabs')) {
		$mlwQuizMasterNext->pluginHelper->register_addon_settings_tab("ActiveCampaign", 'qsm_addon_activecampaign_addon_settings_tabs_content');
	}
}

/**
 * Generates the content for your addon settings tab
 *
 * @since 1.0.0
 * @return void
 */
function qsm_addon_activecampaign_addon_settings_tabs_content() {
	global $mlwQuizMasterNext;
	/**
	 * If nonce is correct, update api key from passed input
	 */
	if (isset($_POST["activecampaign_integration_nonce"]) && wp_verify_nonce($_POST['activecampaign_integration_nonce'], 'activecampaign_integration')) {
		$ac_addon_settings = get_option('qsm_addon_activecampaign_settings', '');
		if (isset($ac_addon_settings["license_key"])) {
			$license = trim($ac_addon_settings["license_key"]);
		} else {
			$license = '';
		}
		/**
		 * Save settings
		 */
		$saved_license = sanitize_text_field($_POST["license_key"]);
		$ac_addon_settings = array(
			'license_key' => $saved_license,
			'api_url' => sanitize_text_field($_POST["api_url"]),
			'api_key' => sanitize_text_field($_POST["api_key"]),
			'event_key' => sanitize_text_field($_POST["event_key"]),
			'event_id' => sanitize_text_field($_POST["event_id"]),
			'event_name' => sanitize_text_field($_POST["event_name"])
		);
		update_option('qsm_addon_activecampaign_settings', $ac_addon_settings);
		/**
		 * Checks to see if the license key has changed
		 */
		if ($license != $saved_license) {
			$api_params = array(
				'edd_action' => 'activate_license',
				'license' => $saved_license,
				'item_name' => urlencode('ActiveCampaign Integration'), // the name of our product in EDD
				'url' => home_url()
			);
			$response = wp_remote_post('http://quizandsurveymaster.com', array('timeout' => 15, 'sslverify' => false, 'body' => $api_params));
			/**
			 * If previous license key was entered
			 */
			if (!empty($license)) {
				$api_params = array(
					'edd_action' => 'deactivate_license',
					'license' => $license,
					'item_name' => urlencode('ActiveCampaign Integration'), // the name of our product in EDD
					'url' => home_url()
				);
				$response = wp_remote_post('http://quizandsurveymaster.com', array('timeout' => 15, 'sslverify' => false, 'body' => $api_params));
			}
		}
		/**
		 * Test API URL & API Key
		 */
		$msg_shown = false;
		if ($ac_addon_settings["api_url"] && $ac_addon_settings["api_key"]) {
			$ac = new ActiveCampaign($ac_addon_settings["api_url"], $ac_addon_settings["api_key"]);
			if (!(int) $ac->credentials_test()) {
				$msg_shown = true;
				$mlwQuizMasterNext->alertManager->newAlert(__( "Access denied: Invalid credentials (URL and/or API key).", 'qsm-activecampaign-integration' ), 'error');
			} else {
				$msg_shown = true;
				$mlwQuizMasterNext->alertManager->newAlert(__( 'Your API Details has been saved successfully! You can now configure ActiveCampaign when editing your quiz using the ActiveCampaign Integration tab.', 'qsm-activecampaign-integration' ), 'success');
			}
		} else {
			$msg_shown = true;
			$mlwQuizMasterNext->alertManager->newAlert(__( "Your API Details is empty. Please copy and paste your API Details below.", 'qsm-activecampaign-integration' ), 'error');
		}
		if (!$msg_shown) {

			$mlwQuizMasterNext->alertManager->newAlert(__( "Unknown error with your API Details. Please try again.", 'qsm-activecampaign-integration' ), 'error');
		}
	}
	/**
	 * Load settings
	 */
	$ac_addon_settings = get_option('qsm_addon_activecampaign_settings', '');
	$activecampaign_defaults = array(
		'license_key' => '',
		'api_url' => '',
		'api_key' => '',
		'event_key' => '',
		'event_id' => '',
		'event_name' => ''
	);
	$ac_addon_settings = wp_parse_args($ac_addon_settings, $activecampaign_defaults);
	$mlwQuizMasterNext->alertManager->showAlerts();
	?>
	<h2><?php _e( 'ActiveCampaign Integration', 'qsm-activecampaign-integration' );  ?> </h2>
	<p><?php _e( 'To use this addon, you must have a ActiveCampaign account. You will need your API URL & API KEY.', 'qsm-activecampaign-integration' ); ?></p>
	<!--<p>For assistance with this addon, please refer to the <a href="https://quizandsurveymaster.com/docs/integrations/activecampaign/?utm_campaign=qsm-plugin-activecampaign-addon&utm_medium=plugin&utm_source=addon-settings" target="_blank">ActiveCampaign Addon Documentation.</a></p>-->
	<p><?php _e( 'After you complete this step, you will see a new ActiveCampaign Integration tab when editing your quizzes. This is where you will enter in which list to add the users.', 'qsm-activecampaign-integration' ); ?>  </p>
	<form action="" method="post">
		<table class="form-table" >
			<tr valign="top">
				<th scope="row"><label for="license_key"><?php _e( 'Addon License Key', 'qsm-activecampaign-integration' ); ?> </label></th>
				<td><input type="text" name="license_key" id="license_key" value="<?php echo $ac_addon_settings["license_key"]; ?>"></td>
			</tr>
			<tr valign="top">
				<th scope="row"><label for="api_url"><?php _e( 'Your ActiveCampaign API URL', 'qsm-activecampaign-integration' ); ?> </label></th>
				<td>
					<input type="text" name="api_url" id="api_url" value="<?php echo $ac_addon_settings["api_url"]; ?>">
				</td>
			</tr>
			<tr valign="top">
				<th scope="row"><label for="api_key"><?php _e( 'Your ActiveCampaign API Key', 'qsm-activecampaign-integration' ); ?> </label></th>
				<td>
					<input type="text" name="api_key" id="api_key" value="<?php echo $ac_addon_settings["api_key"]; ?>">
				</td>
			</tr>
			<tr valign="top">
				<th scope="row"><label for="event_key"><?php _e( 'Your ActiveCampaign Event Tracking Key', 'qsm-activecampaign-integration' ); ?> </label></th>
				<td>
					<input type="text" name="event_key" id="event_key" value="<?php echo $ac_addon_settings["event_key"]; ?>">
				</td>
			</tr>
			<tr valign="top">
				<th scope="row"><label for="event_id"><?php _e( 'Your ActiveCampaign Event Tracking ID', 'qsm-activecampaign-integration' ); ?> </label></th>
				<td>
					<input type="text" name="event_id" id="event_id" value="<?php echo $ac_addon_settings["event_id"]; ?>">
				</td>
			</tr>
			<tr valign="top">
				<th scope="row"><label for="event_name"><?php _e( 'Your ActiveCampaign Event Name', 'qsm-activecampaign-integration' ); ?> </label></th>
				<td>
					<input type="text" name="event_name" id="event_name" value="<?php echo $ac_addon_settings["event_name"]; ?>">
				</td>
			</tr>
		</table>
		<?php wp_nonce_field('activecampaign_integration', 'activecampaign_integration_nonce'); ?>
		<button class="button-primary"><?php _e( 'Save Settings', 'qsm-activecampaign-integration' ); ?></button>
	</form>
	<?php
}
