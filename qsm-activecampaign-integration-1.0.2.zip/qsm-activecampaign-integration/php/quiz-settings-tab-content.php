<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers your tab in the quiz settings page
 *
 * @since 1.0.0
 * @return void
 */
function qsm_addon_activecampaign_register_quiz_settings_tabs() {
	global $mlwQuizMasterNext;
	if ( ! is_null( $mlwQuizMasterNext ) && ! is_null( $mlwQuizMasterNext->pluginHelper ) && method_exists( $mlwQuizMasterNext->pluginHelper, 'register_quiz_settings_tabs' ) ) {
		$mlwQuizMasterNext->pluginHelper->register_quiz_settings_tabs( 'ActiveCampaign', 'qsm_addon_activecampaign_quiz_settings_tabs_content' );
	}
}

/**
 * Generates the content for your quiz settings tab
 *
 * @since 1.0.0
 * @return string
 */
function qsm_addon_activecampaign_quiz_settings_tabs_content() {
	global $mlwQuizMasterNext;
	$quiz_id  = isset( $_GET['quiz_id'] ) ? intval( $_GET['quiz_id'] ) : '';
	$settings = get_option( 'qsm_addon_activecampaign_settings', '' );
	if ( empty( $settings['api_url'] ) || empty( $settings['api_key'] ) ) {
		echo '<h3>';
		esc_html_e( 'Please go to the ActiveCampaign tab on the Addon Settings page to configure this addon first', 'qsm-activecampaign-integration' );
		echo '</h3>';
		return false;
	}
	$activecampaign_api = new ActiveCampaign( $settings['api_url'], $settings['api_key'] );
	if ( ! (int) $activecampaign_api->credentials_test() ) {
		echo '<h3>';
		esc_html_e( 'Please go to the ActiveCampaign tab on the Addon Settings page to configure this addon first', 'qsm-activecampaign-integration' );
		echo '</h3>';
		return false;
	}
	/**
	 * If nonce is set and correct, save the form
	 */
	if ( isset( $_POST['activecampaign_integration_nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['activecampaign_integration_nonce'] ) ), 'activecampaign_integration' ) ) {
		$question_ans_field_id = $quiz_score_field_id = '';
		$enabled               = isset( $_POST['activecampaign_enable'] ) ? sanitize_text_field( wp_unslash( $_POST['activecampaign_enable'] ) ) : '';
		$send_result           = isset( $_POST['activecampaign_send_result'] ) ? sanitize_text_field( wp_unslash( $_POST['activecampaign_send_result'] ) ) : '';
		$send_score            = isset( $_POST['activecampaign_send_score'] ) ? sanitize_text_field( wp_unslash( $_POST['activecampaign_send_score'] ) ) : '';

		if ( 'yes' === $enabled && ( 'yes' === $send_result || 'yes' === $send_score ) ) {

			$fields_lists = $activecampaign_api->api( 'list/field_view?ids=all' );
			foreach ( $fields_lists as $fields ) {
				if ( isset( $fields->perstag ) && 'QSMQUESTIONANSWER' === $fields->perstag ) {
					$question_ans_field_id = $fields->id;
				} elseif ( isset( $fields->perstag ) && 'QSMQUIZSCORE' === $fields->perstag ) {
					$quiz_score_field_id = $fields->id;
				}
			}

			if ( 'yes' === $send_result && '' === $question_ans_field_id ) {
				$post = array(
					'title'   => 'QSM Question & Answer', // internal field name.
					'type'    => 1, // 1 = Text Field, 2 = Text Box, 3 = Checkbox, 4 = Radio, 5 = Dropdown, 6 = Hidden field, 7 = List Box, 9 = Date.
					'req'     => 0, // required? 1 or 0.
					'perstag' => 'QSMQUESTIONANSWER', // unique tag used as a placeholder for dynamic content.
					'p[0]'    => 0, // for use in lists. use 0 for All lists.
				);

				$results = $activecampaign_api->api( 'list/field_add', $post );
				if ( ! (int) $results->success ) {
					$mlwQuizMasterNext->log_manager->add( 'ActiveCampaign Error: ', json_encode( $results ), 0, 'error' );
				} else {
					$question_ans_field_id = $results->fieldid;
				}
			}

			if ( 'yes' === $send_score && '' === $quiz_score_field_id ) {
				$post = array(
					'title'   => 'QSM Quiz Score', // internal field name.
					'type'    => 1, // 1 = Text Field, 2 = Text Box, 3 = Checkbox, 4 = Radio, 5 = Dropdown, 6 = Hidden field, 7 = List Box, 9 = Date.
					'req'     => 0, // required? 1 or 0.
					'perstag' => 'QSMQUIZSCORE', // unique tag used as a placeholder for dynamic content.
					'p[0]'    => 0, // for use in lists. use 0 for All lists.
				);

				$results = $activecampaign_api->api( 'list/field_add', $post );
				if ( ! (int) $results->success ) {
					$mlwQuizMasterNext->log_manager->add( 'ActiveCampaign Error: ', json_encode( $results ), 0, 'error' );
				} else {
					$quiz_score_field_id = $results->fieldid;
				}
			}
		}
		$activecampaign_data = $mlwQuizMasterNext->pluginHelper->get_quiz_setting( 'activecampaign_settings' );
		if ( isset( $_POST['activecampaign_enable'] ) ) {
			$activecampaign_update = array(
				'enabled'                 => $enabled,
				'display_checkbox'        => isset( $_POST['activecampaign_checkbox_display'] ) ? sanitize_text_field( wp_unslash( $_POST['activecampaign_checkbox_display'] ) ) : '',
				'checkbox_text'           => isset( $_POST['activecampaign_checkbox_text'] ) ? sanitize_text_field( wp_unslash( $_POST['activecampaign_checkbox_text'] ) ) : '',
				'list_id'                 => isset( $_POST['activecampaign_subscribe_list'] ) ? sanitize_text_field( wp_unslash( $_POST['activecampaign_subscribe_list'] ) ) : '',
				'minimum_score'           => isset( $_POST['minimum_score'] ) ? sanitize_text_field( wp_unslash( $_POST['minimum_score'] ) ) : 0,
				'tag_mappings'            => isset( $_POST['tag_mappings'] ) ? qsm_sanitize_rec_array( wp_unslash( $_POST['tag_mappings'] ) ) : '', // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
				'send_result'             => $send_result,
				'send_score'              => $send_score,
				'send_request_parameters' => isset( $_POST['activecampaign_send_request_parameters'] ) ? sanitize_text_field( wp_unslash( $_POST['activecampaign_send_request_parameters'] ) ) : '',
				'question_ans_field_id'   => $question_ans_field_id,
				'quiz_score_field_id'     => $quiz_score_field_id,

			);
		} else {
			$activecampaign_update = array(
				'activecampaign_custom_fields' => isset( $_POST['activecampaign_custom_fields'] ) ? qsm_sanitize_rec_array( wp_unslash( $_POST['activecampaign_custom_fields'] ) ) : array(), // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
				'use_custom_feilds_result'     => isset( $_POST['activecampaign_use_custom_feilds_result'] ) ? sanitize_text_field( wp_unslash( $_POST['activecampaign_use_custom_feilds_result'] ) ) : '',
			);
		}
		$activecampaign_update = wp_parse_args( $activecampaign_update, $activecampaign_data );
		$mlwQuizMasterNext->pluginHelper->update_quiz_setting( 'activecampaign_settings', $activecampaign_update );
		$mlwQuizMasterNext->alertManager->newAlert( __( 'Your activecampaign settings has been saved successfully!', 'qsm-activecampaign-integration' ), 'success' );

	}

	$activecampaign_data     = $mlwQuizMasterNext->pluginHelper->get_quiz_setting( 'activecampaign_settings' );
	$activecampaign_defaults = array(
		'enabled'                      => 'no',
		'display_checkbox'             => 'show',
		'checkbox_text'                => 'Subscribe me to your newsletter!',
		'list_id'                      => '',
		'minimum_score'                => 0,
		'tag_mappings'                 => array(),
		'send_result'                  => 'no',
		'send_score'                   => 'no',
		'send_request_parameters'      => 'no',
		'use_custom_feilds_result'     => 'no',
		'activecampaign_custom_fields' => array(),
	);
	$activecampaign_data     = wp_parse_args( $activecampaign_data, $activecampaign_defaults );
	?>
	<a href="https://quizandsurveymaster.com/docs/integrations/active-campaign/" class="qsm-ac-doc-link" target="_blank" rel="noopener" ><?php esc_html_e( 'View Documentation', 'qsm-activecampaign-integration' ); ?></a>
	<div id="tabs-activecampaign-integration" class="mlw_tab_content">
		<ul class="activecampaign-sub-menu">
			<li><a class="<?php echo ! isset( $_GET['ac-tab'] ) ? esc_attr( 'active' ) : ''; ?>" href="
			<?php
			echo esc_url(
				add_query_arg(
					array(
						'page'    => 'mlw_quiz_options',
						'quiz_id' => $quiz_id,
						'tab'     => 'activecampaign',
					),
					admin_url( 'admin.php' )
				)
			);
			?>
			"><?php esc_html_e( 'ActiveCampaign Integration', 'qsm-activecampaign-integration' ); ?></a></li>
			<li>|</li>
			<li><a class="<?php echo isset( $_GET['ac-tab'] ) ? esc_attr( 'active' ) : ''; ?>" href="
			<?php
			echo esc_url(
				add_query_arg(
					array(
						'page'    => 'mlw_quiz_options',
						'quiz_id' => $quiz_id,
						'tab'     => 'activecampaign',
						'ac-tab'  => true,
					),
					admin_url( 'admin.php' )
				)
			);
			?>
			"><?php esc_html_e( 'ActiveCampaign custom fields', 'qsm-activecampaign-integration' ); ?></a></li>
		</ul>
		<?php
		if ( isset( $_GET['ac-tab'] ) ) {
			return qsm_addon_activecampaign_custom_fields_content( $activecampaign_data, $activecampaign_api, $quiz_id );
		} else {
			return qsm_addon_activecampaign_quiz_settings_tabs_content_int( $activecampaign_data, $activecampaign_api );
		}
		?>
	</div>
	<?php
}

/**
 * Generates the content for your quiz settings tab
 *
 * @since 1.0.2
 * @return void
 */
function qsm_addon_activecampaign_quiz_settings_tabs_content_int( $activecampaign_data, $activecampaign_api ) {
	/**
	 * Try to retrieve lists
	 */
	$res_lists = $activecampaign_api->api( 'list/list?ids=all' );
	$lists     = array();
	if ( ! (int) $res_lists->success ) {
		$msg_shown = true;
		$mlwQuizMasterNext->log_manager->add( 'Error With ActiveCampaign Call on Quiz Settings Page', 'From ActiveCampaign: ' . print_r( $res_lists, true ), 0, 'error' );
		$mlwQuizMasterNext->alertManager->newAlert( __( 'There was an error with your getting your ActiveCampaign lists.', 'qsm-activecampaign-integration' ), 'error' );
	} else {
		foreach ( $res_lists as $list ) {
			if ( is_object( $list ) || is_array( $list ) ) {
				$lists[] = $list;
			}
		}
		if ( empty( $lists ) ) {
			$msg_shown = true;
			$mlwQuizMasterNext->log_manager->add( 'Error With ActiveCampaign Call on Quiz Settings Page', 'Missing list property but no error. Context: ' . print_r( $res_lists, true ), 0, 'error' );
			$mlwQuizMasterNext->alertManager->newAlert( __( 'list(s) not found in your ActiveCampaign account. Please create atleast one list', 'qsm-activecampaign-integration' ), 'error' );
		}
	}
	?>
	<h2><?php esc_html_e( 'ActiveCampaign Integration', 'qsm-activecampaign-integration' ); ?> </h2>
	<form action="" method="post">
		<table class="form-table">
			<tr valign="top">
				<th scope="row">
					<label for="activecampaign_enable">
						<?php esc_html_e( 'Enable for this quiz?', 'qsm-activecampaign-integration' ); ?>
					<label>
				</th>
				<td>
					<fieldset class="buttonset buttonset-hide" data-hide="1">
						<input type="radio" id="activecampaign_enable-1" name="activecampaign_enable" <?php checked( $activecampaign_data['enabled'], 'yes' ); ?> value='yes'><label for="activecampaign_enable-1"><?php esc_html_e( 'Yes', 'qsm-activecampaign-integration' ); ?></label>
						<input type="radio" id="activecampaign_enable-2" name="activecampaign_enable" <?php checked( $activecampaign_data['enabled'], 'no' ); ?> value='no'><label for="activecampaign_enable-2"><?php esc_html_e( 'No', 'qsm-activecampaign-integration' ); ?></label>
					</fieldset>
				</td>
			</tr>
		</table>
		<table class="form-table qsm-ac-other-settings" >
			<tr valign="top">
				<th scope="row"><label for="activecampaign_subscribe_list"><?php esc_html_e( 'Subscribe user to list:', 'qsm-activecampaign-integration' ); ?> </label></th>
				<td>
					<select class="" name="activecampaign_subscribe_list" id="activecampaign_subscribe_list">
						<?php
						foreach ( $lists as $list ) {
							echo "<option value='" . esc_attr( $list->id ) . "' " . selected( $activecampaign_data['list_id'], $list->id, false ) . '>' . $list->name . '</option>';
						}
						?>
					</select>
				</td>
			</tr>
			<tr valign="top">
				<th scope="row">
					<label for="activecampaign_checkbox_display">
						<?php esc_html_e( 'Subscription Mode', 'qsm-activecampaign-integration' ); ?>
					<label>
				</th>
				<td>
					<label for="activecampaign_checkbox_display_radio2">
						<input type="radio" id="activecampaign_checkbox_display_radio2" name="activecampaign_checkbox_display" <?php checked( $activecampaign_data['display_checkbox'], 'hide' ); ?> value='hide' />
						<?php esc_html_e( 'Automatic', 'qsm-activecampaign-integration' ); ?>
					</label>
					<label for="activecampaign_checkbox_display_radio1">
						<input type="radio" id="activecampaign_checkbox_display_radio1" name="activecampaign_checkbox_display" <?php checked( $activecampaign_data['display_checkbox'], 'show' ); ?> value='show' />
						<?php esc_html_e( 'Optional', 'qsm-activecampaign-integration' ); ?>
					</label>
					<div class="qsm-ac-checkbox-text">
						<small><em>Text displayed next to checkbox</em></small><br/>
						<input type="text" name="activecampaign_checkbox_text" id="activecampaign_checkbox_text" value="<?php echo $activecampaign_data['checkbox_text']; ?>" >
					</div>
				</td>
			</tr>
			<tr valign="top">
				<th scope="row" class="qsm-opt-tr">
					<label for="activecampaign_checkbox_text">
						<?php esc_html_e( 'Minimum Score', 'qsm-activecampaign-integration' ); ?>
					</label>
					<span class="dashicons dashicons-editor-help qsm-tooltips-icon">
						<span class="qsm-tooltips"><?php esc_html_e( 'Set minimum score required for subscribing to this list.', 'qsm-activecampaign-integration' ); ?></span>
					</span>
				</th>
				<td>
					<input type="text" name="minimum_score" id="minimum_score" value="<?php echo $activecampaign_data['minimum_score']; ?>" >
				</td>
			</tr>
			<tr valign="top">
				<th scope="row" class="qsm-opt-tr">
					<label for="activecampaign_checkbox_text">
						<?php esc_html_e( 'Map Quiz Score:', 'qsm-activecampaign-integration' ); ?>
					</label>
					<span class="dashicons dashicons-editor-help qsm-tooltips-icon">
						<span class="qsm-tooltips"><?php esc_html_e( 'Map quiz score with ActiveCampaign Tag', 'qsm-activecampaign-integration' ); ?></span>
					</span>
				</th>
				<td>
					<div class="tag_mappings_wrapper">
						<?php
						if ( empty( $activecampaign_data['tag_mappings'] ) ) {
							$activecampaign_data['tag_mappings'][1] = array(
								'min' => '',
								'max' => '',
								'tag' => '',
							);
						}
						if ( ! empty( $activecampaign_data['tag_mappings'] ) ) {
							$i = 1;
							foreach ( $activecampaign_data['tag_mappings'] as $tag_data ) {
								?>
								<div class="tag_mappings_fields tag_mappings_set_<?php echo $i; ?>">
									<label><span><?php esc_html_e( 'Min', 'qsm-activecampaign-integration' ); ?></span><input type="number" name="tag_mappings[<?php echo $i; ?>][min]" id="tag_mappings_min_<?php echo $i; ?>" value="<?php echo $tag_data['min']; ?>" ></label>
									<label><span><?php esc_html_e( 'Max', 'qsm-activecampaign-integration' ); ?></span><input type="number" name="tag_mappings[<?php echo $i; ?>][max]" id="tag_mappings_max_<?php echo $i; ?>" value="<?php echo $tag_data['max']; ?>" ></label>
									<label><span><?php esc_html_e( 'ActiveCampaign Tag', 'qsm-activecampaign-integration' ); ?></span><input type="text" name="tag_mappings[<?php echo $i; ?>][tag]" id="tag_mappings_tag_<?php echo $i; ?>" value="<?php echo $tag_data['tag']; ?>" ></label>

									<?php
									if ( $i > 1 ) {
										?>
											<a href="javascript:void(0)" class="remove-mapping-row">x</a>
											<?php
									}
									?>
								</div>
								<?php
								$i++;
							}
						}
						?>
					</div>
					<div class="add-more-link">
						<a href="javascript:void(0)" class="add-more-tag-mapping" data-index="<?php echo $i; ?>"><?php esc_html_e( '+ Add More', 'qsm-activecampaign-integration' ); ?> </a>
					</div>
				</td>
			</tr>
			<tr valign="top">
				<th scope="row" class="qsm-opt-tr">
					<label for="activecampaign_send_result">
						<?php esc_html_e( 'Send question & answer', 'qsm-activecampaign-integration' ); ?>
					</label>
					<span class="dashicons dashicons-editor-help qsm-tooltips-icon">
						<span class="qsm-tooltips"><?php esc_html_e( 'Sends the user-attempted quiz question & answer to the Active Campaign Subscription list.', 'qsm-activecampaign-integration' ); ?></span>
					</span>
				</th>
				<td>
					<fieldset class="buttonset buttonset-hide" data-hide="1">
						<input type="radio" id="activecampaign_send_result-1" name="activecampaign_send_result" <?php checked( $activecampaign_data['send_result'], 'yes' ); ?> value='yes'><label for="activecampaign_send_result-1"><?php esc_html_e( 'Yes', 'qsm-activecampaign-integration' ); ?></label>
						<input type="radio" id="activecampaign_send_result-2" name="activecampaign_send_result" <?php checked( $activecampaign_data['send_result'], 'no' ); ?> value='no'><label for="activecampaign_send_result-2"><?php esc_html_e( 'No', 'qsm-activecampaign-integration' ); ?></label>
					</fieldset>
				</td>
			</tr>
			<tr valign="top">
				<th scope="row">
					<label for="activecampaign_send_result">
						<?php esc_html_e( 'Send quiz score', 'qsm-activecampaign-integration' ); ?>
					</label>
				</th>
				<td>
					<fieldset class="buttonset buttonset-hide" data-hide="1">
						<input type="radio" id="activecampaign_send_score-1" name="activecampaign_send_score" <?php checked( $activecampaign_data['send_score'], 'yes' ); ?> value='yes'><label for="activecampaign_send_score-1"><?php esc_html_e( 'Yes', 'qsm-activecampaign-integration' ); ?></label>
						<input type="radio" id="activecampaign_send_score-2" name="activecampaign_send_score" <?php checked( $activecampaign_data['send_score'], 'no' ); ?> value='no'><label for="activecampaign_send_score-2"><?php esc_html_e( 'No', 'qsm-activecampaign-integration' ); ?></label>
					</fieldset>
				</td>
			</tr>
			<tr valign="top">
				<th scope="row" class="qsm-opt-tr">
					<label for="activecampaign_send_request_parameters">
						<?php esc_html_e( 'Send request parameters', 'qsm-activecampaign-integration' ); ?>
					</label>
					<span class="dashicons dashicons-editor-help qsm-tooltips-icon">
						<span class="qsm-tooltips"><?php esc_html_e( 'Sends the URL Tracking Parameters passed on with the quiz to Active Campaign', 'qsm-activecampaign-integration' ); ?></span>
					</span>
				</th>
				<td>
					<fieldset class="buttonset buttonset-hide" data-hide="1">
						<input type="radio" id="activecampaign_send_request_parameters-1" name="activecampaign_send_request_parameters" <?php checked( $activecampaign_data['send_request_parameters'], 'yes' ); ?> value='yes'><label for="activecampaign_send_request_parameters-1"><?php esc_html_e( 'Yes', 'qsm-activecampaign-integration' ); ?></label>
						<input type="radio" id="activecampaign_send_request_parameters-2" name="activecampaign_send_request_parameters" <?php checked( $activecampaign_data['send_request_parameters'], 'no' ); ?> value='no'><label for="activecampaign_send_request_parameters-2"><?php esc_html_e( 'No', 'qsm-activecampaign-integration' ); ?></label>
					</fieldset>
				</td>
			</tr>
		</table>
		<?php
			$settings = (array) get_option( 'qmn-settings' );
		if ( isset( $settings['ip_collection'] ) && $settings['ip_collection'] == 1 ) {
			echo '<div class="error"><p>Collecting and storing IP addresses is disabled. Do you want to enable <a href="' . admin_url( 'admin.php?page=qmn_global_settings' ) . '">settings</a></p></div>';
		}
		?>
		<?php wp_nonce_field( 'activecampaign_integration', 'activecampaign_integration_nonce' ); ?>
		<button class="button-primary"><?php esc_html_e( 'Save Settings', 'qsm-activecampaign-integration' ); ?> </button>
	</form>
	<?php
}

/**
 * Generates the content for your active campaign custom fields
 *
 * @since 1.0.2
 * @return void
 */
function qsm_addon_activecampaign_custom_fields_content( $activecampaign_data, $activecampaign_api, $quiz_id ) {
	global $wpdb;
	$settings     = get_option( 'qsm_addon_activecampaign_settings', '' );
	$fields_lists = $activecampaign_api->api( 'list/field_view?ids=all' );
	$questions    = $wpdb->get_results( $wpdb->prepare( "SELECT question_id, question_settings, question_type_new FROM {$wpdb->prefix}mlw_questions WHERE quiz_id=%d AND deleted='0' ORDER BY question_order ASC", $quiz_id ), 'ARRAY_A' );
	if ( empty( $activecampaign_data['send_result'] ) || 'yes' !== $activecampaign_data['send_result'] ) {
		?>
		<div class="qsm-ac-notice notice-large notice-error">
			<p><?php esc_html_e( 'Please go to the ActiveCampaign Intigration tab and enable "Send question & answer" option first', 'qsm-activecampaign-integration' ); ?></p>
		</div>
		<?php
		return false;
	}
	?>
		<h2><?php esc_html_e( 'Map Custom Fields With Your ActiveCampaign Account Fields', 'qsm-activecampaign-integration' ); ?> </h2>
		<form action="" method="post">
			<button class="button-primary"><?php esc_html_e( 'Save Settings', 'qsm-activecampaign-integration' ); ?> </button>
			<table class="form-table" >
				<tr valign="top">
					<th scope="row" class="qsm-opt-tr">
						<label for="activecampaign_use_custom_feilds_result">
							<?php esc_html_e( 'Use custom fields for question and answer', 'qsm-activecampaign-integration' ); ?>
						</label>
						<span class="dashicons dashicons-editor-help qsm-tooltips-icon">
							<span class="qsm-tooltips"><?php esc_html_e( 'Enabling this option maps the custom field to the associated Active Campaign Contact Fields. If disabled all questions & answers will be mapped to a single field.', 'qsm-activecampaign-integration' ); ?></span>
						</span>
					</th>
					<td>
						<fieldset class="buttonset buttonset-hide">
							<input type="radio" id="activecampaign_use_custom_feilds_result-1" name="activecampaign_use_custom_feilds_result" <?php checked( $activecampaign_data['use_custom_feilds_result'], 'yes' ); ?> value='yes'><label for="activecampaign_use_custom_feilds_result-1"><?php esc_html_e( 'Yes', 'qsm-activecampaign-integration' ); ?></label>
							<input type="radio" id="activecampaign_use_custom_feilds_result-2" name="activecampaign_use_custom_feilds_result" <?php checked( $activecampaign_data['use_custom_feilds_result'], 'no' ); ?> value='no'><label for="activecampaign_use_custom_feilds_result-2"><?php esc_html_e( 'No', 'qsm-activecampaign-integration' ); ?></label>
						</fieldset>
					</td>
				</tr>
			</table>
			<div class="qsm-add-ac-custom-fields">
				<p><?php esc_html_e( 'ActiveCampaign custom fields list', 'qsm-activecampaign-integration' ); ?></p>
				<table class="form-table">
					<?php
					if ( 0 !== $fields_lists->result_code ) {
						foreach ( $fields_lists as $fields ) {
							if ( isset( $fields->title ) && 'QSMQUESTIONANSWER' !== $fields->perstag && 'QSMQUIZSCORE' !== $fields->perstag && ( in_array( '0', $fields->lists, true ) || in_array( $activecampaign_data['list_id'], $fields->lists, true ) ) ) {
								?>
							<tr valign="top">
								<th scope="row">
									<label for="activecampaign_enable<?php echo esc_attr( $fields->id ); ?>"><?php echo esc_html( $fields->title ); ?></label>
									<select id="activecampaign_enable<?php echo esc_attr( $fields->id ); ?>" class="qsm-activecampaign-select-question" name="activecampaign_custom_fields[<?php echo esc_attr( $fields->id ); ?>]">
										<option value=""><?php esc_html_e( 'Select quiz question', 'qsm-activecampaign-integration' ); ?></option>
										<?php
										foreach ( $questions as $question ) {
											$question_settings = maybe_unserialize( $question['question_settings'] );
											$field_id          = isset( $activecampaign_data['activecampaign_custom_fields'][ $fields->id ] ) ? $activecampaign_data['activecampaign_custom_fields'][ $fields->id ] : '';
											?>
											<option value="<?php echo esc_html( $question['question_id'] ); ?>" <?php echo selected( $field_id, $question['question_id'], false ); ?> ><?php echo esc_html( $question_settings['question_title'] ); ?></option>
											<?php
										}
										?>
									</select>
								</th>
							</tr>
								<?php
							}
						}
					} else {
						echo '<h4>';
						esc_html_e( 'Please create ActiveCampaign custom feilds first', 'qsm-activecampaign-integration' );
						echo '</h4>';
					}
					?>
				</table>
			</div>
		<?php wp_nonce_field( 'activecampaign_integration', 'activecampaign_integration_nonce' ); ?>
		<button class="button-primary"><?php esc_html_e( 'Save Settings', 'qsm-activecampaign-integration' ); ?> </button>
	</form>
	<?php
}
