<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Creates the checkbox for the user
 *
 * @since 1.0.0
 * @uses MLWQuizMasterNext:pluginHelper
 */
function qsm_addon_activecampaign_checkbox() {
	global $mlwQuizMasterNext;
	$ac_quiz_settings        = $mlwQuizMasterNext->pluginHelper->get_quiz_setting( 'activecampaign_settings' );
	$activecampaign_defaults = array(
		'enabled'          => 'no',
		'display_checkbox' => 'show',
		'checkbox_text'    => 'Subscribe me to your newsletter!',
		'list_id'          => 'none',
		'minimum_score'    => '',
		'tag_mappings'     => array(),
	);
	$ac_quiz_settings        = wp_parse_args( $ac_quiz_settings, $activecampaign_defaults );
	if ( 'yes' === $ac_quiz_settings['enabled'] && 'show' === $ac_quiz_settings['display_checkbox'] && ! empty( $ac_quiz_settings['checkbox_text'] ) ) {
		?>
		<div class="qsm_contact_div">
			<span class='qsm_activecampaign_checkbox_span'><input type='checkbox' name='qsm_activecampaign_checkbox' id='qsm_activecampaign_checkbox' value='1' /><label for='qsm_activecampaign_checkbox' class='qsm_activecampaign_label' style="display: inline;"><?php echo $ac_quiz_settings['checkbox_text']; ?></label></span>
		</div>
		<?php
	}
}

/**
 * Subscribes users to activecampaign account if enabled
 *
 * @since 1.0.0
 * @param $content string The results page content from filter
 * @uses MLWQuizMasterNext:pluginHelper
 * @return string The modified content to send back to filter
 */
function qsm_addon_activecampaign_integration( $content, $options, $quiz_results ) {
	global $mlwQuizMasterNext;
	$settings = get_option( 'qsm_addon_activecampaign_settings', '' );

	$ac_event_id   = isset( $settings['event_id'] ) ? $settings['event_id'] : '';
	$ac_event_key  = isset( $settings['event_key'] ) ? $settings['event_key'] : '';
	$ac_event_name = isset( $settings['event_name'] ) ? $settings['event_name'] : '';

	if ( empty( $settings['api_url'] ) || empty( $settings['api_key'] ) ) {
		return $content;
	}
	$activecampaign_api = new ActiveCampaign( $settings['api_url'], $settings['api_key'] );
	if ( ! (int) $activecampaign_api->credentials_test() ) {
		return $content;
	}
	$ac_quiz_settings        = $mlwQuizMasterNext->pluginHelper->get_quiz_setting( 'activecampaign_settings' );
	$activecampaign_defaults = array(
		'enabled'                      => 'no',
		'display_checkbox'             => 'show',
		'checkbox_text'                => 'Subscribe me to your newsletter!',
		'list_id'                      => '',
		'minimum_score'                => 0,
		'tag_mappings'                 => array(),
		'send_result'                  => 'no',
		'send_score'                   => 'no',
		'send_request_parameters'      => 'no',
		'use_custom_feilds_result'     => 'no',
		'activecampaign_custom_fields' => array(),
		'question_ans_field_id'        => '',
		'quiz_score_field_id'          => '',
	);
	$ac_quiz_settings        = wp_parse_args( $ac_quiz_settings, $activecampaign_defaults );

	$ac_list_id               = $ac_quiz_settings['list_id'];
	$question_ans_field_id    = $ac_quiz_settings['question_ans_field_id'];
	$quiz_score_field_id      = $ac_quiz_settings['quiz_score_field_id'];
	$use_custom_feilds_result = $ac_quiz_settings['use_custom_feilds_result'];
	if ( empty( $ac_list_id ) || '' === $ac_list_id ) {
		return $content;
	}
	/**
	 * Add Contact if activecampaign is enabled and either the checkbox was checked or the checkbox is set to be hidden
	 */
	if ( 'yes' === $ac_quiz_settings['enabled'] && ( isset( $_POST['qsm_activecampaign_checkbox'] ) || 'hide' === $ac_quiz_settings['display_checkbox'] ) ) {
		$total_points = isset( $quiz_results['total_points'] ) ? $quiz_results['total_points'] : 0;
		if ( isset( $ac_quiz_settings['minimum_score'] ) && $ac_quiz_settings['minimum_score'] > $total_points ) {
			return $content;
		}
		$activecampaign_tags = array();
		if ( ! empty( $ac_quiz_settings['tag_mappings'] ) ) {
			foreach ( $ac_quiz_settings['tag_mappings'] as $tag_data ) {
				if ( $total_points >= $tag_data['min'] && $total_points <= $tag_data['max'] ) {
					$activecampaign_tags[] = $tag_data['tag'];
				}
			}
		}
		/**
		 * Retrieve user name, user email, and subscription settings
		 */
		$user_email = '';
		if ( isset( $quiz_results['user_email'] ) ) {
			$user_email = sanitize_email( $quiz_results['user_email'] );
			setcookie( 'qsm_activecampaign_user_email', $user_email, strtotime( '+1 day' ), '/' );
		}
		$user_name  = isset( $quiz_results['user_name'] ) ? sanitize_text_field( $quiz_results['user_name'] ) : '';
		$user_phone = isset( $quiz_results['user_phone'] ) ? sanitize_text_field( $quiz_results['user_phone'] ) : '';
		$user_biz   = isset( $quiz_results['user_business'] ) ? sanitize_text_field( $quiz_results['user_business'] ) : '';
		$user_name  = explode( ' ', $user_name );
		if ( ! isset( $user_name[1] ) ) {
			$user_name[1] = '';
		}

		/**
		 * Add Contact to ActiveCampaign list
		 */
		$contact_info = array(
			'email'                  => $user_email,
			'first_name'             => $user_name[0],
			'last_name'              => $user_name[1],
			'phone'                  => $user_phone,
			'tags'                   => implode( ',', $activecampaign_tags ),
			'p[' . $ac_list_id . ']' => $ac_list_id,
		);

		if ( ! isset( $global_settings['ip_collection'] ) || $global_settings['ip_collection'] != 1 ) {
			$ip_keys = array( 'HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_FORWARDED', 'HTTP_X_CLUSTER_CLIENT_IP', 'HTTP_FORWARDED_FOR', 'HTTP_FORWARDED', 'REMOTE_ADDR' );
			foreach ( $ip_keys as $key ) {
				if ( getenv( $key ) ) {
					$contact_info['ip4'] = getenv( $key );
					break;
				}
				if ( isset( $_SERVER[ $key ] ) && ! empty( $_SERVER[ $key ] ) ) {
					$contact_info['ip4'] = $_SERVER[ $key ];
					break;
				}
			}
		}
		$global_settings = (array) get_option( 'qmn-settings' );
		if ( 'yes' === $ac_quiz_settings['send_request_parameters'] && ( ! isset( $global_settings['ip_collection'] ) || 1 !== intval( $global_settings['ip_collection'] ) ) ) {
			$request_parameter = isset( $_POST['qsm_activecampaign_request_parameter'] ) ? qsm_sanitize_rec_array( wp_unslash( $_POST['qsm_activecampaign_request_parameter'] ) ) : '';
			$fields_lists      = $activecampaign_api->api( 'list/field_view?ids=all' );
			$all_fields        = array();
			foreach ( $fields_lists as $fields ) {
				if ( isset( $fields->title ) && 'QSMQUESTIONANSWER' !== $fields->perstag && 'QSMQUIZSCORE' !== $fields->perstag ) {
					$all_fields[ $fields->id ] = $fields->perstag;
				}
			}
			foreach ( $request_parameter as $key => $val ) {
				$field_id = '';
				$perstag  = str_replace( ' ', '_', $key );
				if ( in_array( $perstag, $all_fields, true ) ) {
					$field_id = array_search( $perstag, $all_fields, true );
				} else {
					$post = array(
						'title'   => $key, // internal field name.
						'type'    => 1, // 1 = Text Field, 2 = Text Box, 3 = Checkbox, 4 = Radio, 5 = Dropdown, 6 = Hidden field, 7 = List Box, 9 = Date.
						'req'     => 0, // required? 1 or 0.
						'perstag' => $perstag, // unique tag used as a placeholder for dynamic content.
						'p[0]'    => 0, // for use in lists. use 0 for All lists.
					);

					$results = $activecampaign_api->api( 'list/field_add', $post );
					if ( ! (int) $results->success ) {
						$mlwQuizMasterNext->log_manager->add( 'ActiveCampaign Error: ', wp_json_encode( $results ), 0, 'error' );
					} else {
						$field_id = intval( $results->fieldid );
					}
				}
				$contact_info['field'][ "$field_id,0" ] = $val;
			}
		}
		if ( 'yes' === $ac_quiz_settings['send_score'] ) {
			$contact_info['field'][ "$quiz_score_field_id,0" ] = $total_points;
		}
		if ( 'yes' === $ac_quiz_settings['send_result'] && 'no' === $ac_quiz_settings['use_custom_feilds_result'] ) {
			$question_answers_array = $quiz_results['question_answers_array'];
			$question_answers       = '';
			foreach ( $question_answers_array as $question_answer ) {
				$question_answers .= 'Q: ' . $question_answer['question_title'] . "\n";
				$question_answers .= 'A: ' . html_entity_decode( $question_answer['1'] ) . "\n===\n";
			}
			$contact_info['field'][ "$question_ans_field_id,0" ] = $question_answers;
		} elseif ( 'yes' === $ac_quiz_settings['send_result'] && 'yes' === $ac_quiz_settings['use_custom_feilds_result'] ) {
			$question_answers_array = $quiz_results['question_answers_array'];
			foreach ( $question_answers_array as $question_answer ) {
				$custom_field_id  = array_search( $question_answer['id'], $ac_quiz_settings['activecampaign_custom_fields'], true );
				$question_answers = html_entity_decode( $question_answer['1'] );
				if ( ! empty( $custom_field_id ) ) {
					$contact_info['field'][ "$custom_field_id,0" ] = $question_answers;
				}
			}
		}

		$results = $activecampaign_api->api( 'contact/sync', $contact_info );
		if ( ! (int) $results->success ) {
			$mlwQuizMasterNext->log_manager->add( 'ActiveCampaign Error: ', wp_json_encode( $results ), 0, 'error' );
		}

		if ( $ac_event_id != '' && $ac_event_key != '' && $ac_event_name != '' ) {
			$activecampaign_api->track_actid = $ac_event_id; // your unique tracking account ID (found on the Integrations page).
			$activecampaign_api->track_key   = $ac_event_key; // your unique event key (found on the Integrations page).
			$activecampaign_api->track_email = $user_email;

			$post_data = array(
				'event'     => $ac_event_name,
				'eventdata' => isset( $_POST['qsm_quiz_url'] ) ? sanitize_text_field( wp_unslash( $_POST['qsm_quiz_url'] ) ) : '',
			);
			$response  = $activecampaign_api->api( 'tracking/log', $post_data );
			if ( ! (int) $results->success ) {
				$mlwQuizMasterNext->log_manager->add( 'ActiveCampaign Error: ', json_encode( $results ), 0, 'error' );
			}
		}
	}
	return $content;
}

/**
 * Creates hidden fields for request parameters
 *
 * @since 1.0.1
 * @param string $quiz_display The results page content from filter.
 * @param array  $options The quiz options from filter.
 * @param array  $quiz_data quiz data from filter.
 * @uses MLWQuizMasterNext:pluginHelper
 * @return string The modified content to send back to filter
 */
function qsm_addon_activecampaign_request_parameter( $quiz_display, $options, $quiz_data ) {
	global $mlwQuizMasterNext;
	$ac_quiz_settings        = $mlwQuizMasterNext->pluginHelper->get_quiz_setting( 'activecampaign_settings' );
	$activecampaign_defaults = array(
		'enabled'          => 'no',
		'display_checkbox' => 'show',
		'checkbox_text'    => 'Subscribe me to your newsletter!',
		'list_id'          => 'none',
		'minimum_score'    => 0,
		'tag_mappings'     => array(),
	);
	$ac_quiz_settings        = wp_parse_args( $ac_quiz_settings, $activecampaign_defaults );
	if ( 'yes' === $ac_quiz_settings['enabled'] && 'yes' === $ac_quiz_settings['send_request_parameters'] && isset( $_GET ) ) {
		foreach ( $_GET as $key => $val ) {
			$quiz_display .= '<input type="hidden" name="qsm_activecampaign_request_parameter[' . $key . ']" value="' . $val . '"/>';
		}
	}
	$base_url      = ( isset( $_SERVER['HTTPS'] ) && $_SERVER['HTTPS'] == 'on' ? 'https' : 'http' ) . '://' . $_SERVER['HTTP_HOST'];
	$current_url   = $base_url . $_SERVER['REQUEST_URI'];
	$quiz_display .= '<input type="hidden" name="qsm_quiz_url" value="' . $current_url . '"/>';
	return $quiz_display;
}

