<?php

/**
 * Plugin Name: QSM - ActiveCampaign Integration
 * Plugin URI: http://quizandsurveymaster.com
 * Description: Adds ActiveCampaign integration to your Quiz And Survey Master
 * Author: QSM Team
 * Text Domain: qsm-activecampaign-integration
 * Author URI: http://quizandsurveymaster.com
 * Version: 1.0.2
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The main class for the addon
 */
class QSM_ActiveCampaign {


	/**
	 * Version Number
	 *
	 * @var string
	 * @since 1.0.0
	 */
	public $version = '1.0.2';

	/**
	 * The main constructer function.
	 *
	 * @since 1.0.0
	 * @uses QSM_ActiveCampaign:load_dependencies
	 * @uses QSM_ActiveCampaign:add_hooks
	 * @return void
	 */
	public function __construct() {
		$this->load_dependencies();
		$this->add_hooks();
		$this->check_license();
	}

	/**
	 * Loads the dependencies of the add_action
	 *
	 * @since 1.0.0
	 * @return void
	 */
	private function load_dependencies() {
		define( 'QSM_ACTIVE_CAMPAIGN_ADDON_VERSION', $this->version );
		define( 'QSM_ACTIVE_CAMPAIGN_ADDON_DIR', plugin_dir_path( __FILE__ ) );
		define( 'QSM_ACTIVE_CAMPAIGN_ADDON_URL', plugin_dir_url( __FILE__ ) );
		define( 'QSM_ACTIVE_CAMPAIGN_ADDON_CSS_URL', QSM_ACTIVE_CAMPAIGN_ADDON_URL . 'css' );
		define( 'QSM_ACTIVE_CAMPAIGN_ADDON_JS_URL', QSM_ACTIVE_CAMPAIGN_ADDON_URL . 'js' );
		define( 'QSM_ACTIVE_CAMPAIGN_ADDON_PHP_DIR', QSM_ACTIVE_CAMPAIGN_ADDON_DIR . 'php' );
		include QSM_ACTIVE_CAMPAIGN_ADDON_PHP_DIR . '/activecampaign-api/ActiveCampaign.class.php';
		include QSM_ACTIVE_CAMPAIGN_ADDON_PHP_DIR . '/addon-settings-tab-content.php';
		include QSM_ACTIVE_CAMPAIGN_ADDON_PHP_DIR . '/quiz-settings-tab-content.php';
		include QSM_ACTIVE_CAMPAIGN_ADDON_PHP_DIR . '/integration.php';
	}

	/**
	 * Registers the tabs and the filter_list
	 *
	 * @since 1.0.0
	 * @return void
	 */
	private function add_hooks() {
		add_action( 'admin_init', 'qsm_addon_activecampaign_register_addon_settings_tabs' );
		add_action( 'admin_init', 'qsm_addon_activecampaign_register_quiz_settings_tabs' );
		add_action( 'wp_enqueue_scripts', array( $this, 'qsm_addon_activecampaign_tracking_code_js' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'qsm_addon_activecampaign_enqueue_scripts' ) );
		add_action( 'qsm_contact_fields_end', 'qsm_addon_activecampaign_checkbox' );
		add_filter( 'qmn_after_results_text', 'qsm_addon_activecampaign_integration', 10, 3 );
		add_filter( 'qmn_begin_quiz_form', 'qsm_addon_activecampaign_request_parameter', 10, 4 );
		add_action( 'admin_init', array( $this, 'qsm_addon_qsm_activecampaign_integration_text_domain' ) );
		add_action( 'plugins_loaded', array( $this, 'qsm_addon_qsm_activecampaign_integration_text_domain' ) );
	}

	/**
	 * Loads admin scripts and style.
	 *
	 * @since 1.0.2
	 */
	public function qsm_addon_activecampaign_enqueue_scripts( $hook ) {
		if ( isset( $_GET['tab'] ) && 'admin_page_mlw_quiz_options' === $hook && 'activecampaign' === $_GET['tab'] ) {
			wp_enqueue_style( 'qsm-activecampaign-addon-admin-css', QSM_ACTIVE_CAMPAIGN_ADDON_CSS_URL . '/admin.css', array(), QSM_ACTIVE_CAMPAIGN_ADDON_VERSION );
			wp_enqueue_script( 'qsm-activecampaign-addon-admin-js', QSM_ACTIVE_CAMPAIGN_ADDON_JS_URL . '/admin.js', array( 'jquery', 'qsm_admin_js' ), QSM_ACTIVE_CAMPAIGN_ADDON_VERSION, true );
		}
	}

	/**
	 * Checks license
	 *
	 * Checks to see if license is active and, if so, checks for updates
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function check_license() {
		if ( ! class_exists( 'EDD_SL_Plugin_Updater' ) ) {
			// load our custom updater
			include 'php/EDD_SL_Plugin_Updater.php';
		}
		/**
		 * Retrieve license key from the DB
		 */
		$license_key       = '';
		$ac_addon_settings = get_option( 'qsm_addon_activecampaign_settings', '' );
		if ( isset( $ac_addon_settings['license_key'] ) && ! empty( $ac_addon_settings['license_key'] ) ) {
			$license_key = trim( $ac_addon_settings['license_key'] );
			/**
			 * Setup The Updater
			 */
			$edd_updater = new EDD_SL_Plugin_Updater(
				'https://quizandsurveymaster.com',
				__FILE__,
				array(
					'version'   => $this->version,
					'license'   => $license_key,
					'item_name' => 'ActiveCampaign Integration',
					'author'    => 'QSM Team',
				)
			);
		}
	}


	/**
	 * Adds localization support for Advanced timer addon
	 */
	public function qsm_addon_qsm_activecampaign_integration_text_domain() {
		load_plugin_textdomain( 'qsm-activecampaign-integration', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
	}

	/**
	 * ActiveCampaign tracking JS code
	 *
	 * @return js code
	 */
	public function qsm_addon_activecampaign_tracking_code_js() {
		$settings    = get_option( 'qsm_addon_activecampaign_settings', '' );
		$ac_event_id = isset( $settings['event_id'] ) ? $settings['event_id'] : '';
		if ( $ac_event_id != '' ) {
			$user_email = '';
			if ( isset( $_COOKIE['qsm_activecampaign_user_email'] ) ) {
				$user_email = $_COOKIE['qsm_activecampaign_user_email'];
			}
			if ( is_user_logged_in() ) {
				global $current_user;
				wp_get_current_user();
				$user_email = $current_user->user_email;
			}
			$qsm_activecampaign_tracking_js = "(function(e,t,o,n,p,r,i){e.visitorGlobalObjectAlias=n;e[e.visitorGlobalObjectAlias]=e[e.visitorGlobalObjectAlias]||function(){(e[e.visitorGlobalObjectAlias].q=e[e.visitorGlobalObjectAlias].q||[]).push(arguments)};e[e.visitorGlobalObjectAlias].l=(new Date).getTime();r=t.createElement('script');r.src=o;r.async=true;i=t.getElementsByTagName('script')[0];i.parentNode.insertBefore(r,i)})(window,document,'https://diffuser-cdn.app-us1.com/diffuser/diffuser.js','vgo');
				vgo('setAccount', '" . esc_attr( $ac_event_id ) . "');
				vgo('setEmail', '" . esc_html( $user_email ) . "');
				vgo('setTrackByDefault', true);
				vgo('process');";
			wp_add_inline_script( 'jquery', $qsm_activecampaign_tracking_js );
		}
	}
}

/**
 * Loads the addon if QSM is installed and activated
 *
 * @since 1.0.0
 * @return void
 */
function qsm_addon_activecampaign_intergration_load() {
	 /**
	 * Make sure QSM is active
	 */
	if ( class_exists( 'MLWQuizMasterNext' ) ) {
		$QSM_ActiveCampaign = new QSM_ActiveCampaign();
	} else {
		add_action( 'admin_notices', 'qsm_addon_activecampaign_integration_missing_qsm' );
	}
}

add_action( 'plugins_loaded', 'qsm_addon_activecampaign_intergration_load' );

/**
 * Display notice if Quiz And Survey Master isn't installed
 *
 * @since 1.0.0
 * @return string The notice to display
 */
function qsm_addon_activecampaign_integration_missing_qsm() {
	echo '<div class="error"><p>';
	_e( 'QSM - ActiveCampaign Integration requires Quiz And Survey Master. Please install and activate the Quiz And Survey Master plugin.', 'qsm-activecampaign-integration' );
	echo '</p></div>';
}
