<?php if ( ! defined( 'ABSPATH' ) ) exit;

 _e('No notes to display', 'um-user-notes' );