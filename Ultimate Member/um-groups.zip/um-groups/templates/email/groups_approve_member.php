<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>

Your request to join to group "{group_name}" has been approved.<br /><br />
To view a group, please click the following link: <a href="{group_url}" style="color: #3ba1da;text-decoration: none;">{group_url}</a>