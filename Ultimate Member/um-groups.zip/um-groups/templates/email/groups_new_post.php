<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>

Hi {member_name},<br /><br />
{author_name} has posted new post on "{group_name}".<br /><br />
To view post, please click the following link: <a href="{group_url_postid}" style="color: #3ba1da;text-decoration: none;">{group_url_postid}</a>