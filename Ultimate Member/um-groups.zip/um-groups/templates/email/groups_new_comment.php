<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>

Hi {member_name},<br /><br />
{author_name} added a new comment on group "{group_name}".<br /><br />
To view comment, please click the following link: <a href="{group_url_commentid}" style="color: #3ba1da;text-decoration: none;">{group_url_commentid}</a>