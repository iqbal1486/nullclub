<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>

Hi {moderator_name},<br/><br/>
{member_name} has requested to join {group_name}.<br/>
You can view their profile here: {profile_link}.<br/><br/>
To approve/reject this request please click the following link:<br/>
<a href="{groups_request_tab_url}" style="color: #3ba1da;text-decoration: none;">{groups_request_tab_url}</a>