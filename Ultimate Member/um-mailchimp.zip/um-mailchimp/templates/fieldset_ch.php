<?php
/**
 * Template for the field MailChimp
 *
 * Used:   Account page, Registration page, shortcodes
 * Call:   function um_mc_field( $data )
 * Parent: account_email_newsletters.php
 *
 * This template can be overridden by copying it to yourtheme/ultimate-member/um-mailchimp/fieldset_ch.php
 */
if ( !defined( 'ABSPATH' ) ) {
	exit;
}

$namepref = "um-mailchimp[{$wp_list->ID}]";
?>

<fieldset class="um-account-fieldset" id="um-mc-<?php echo esc_attr( $wp_list->ID ); ?>" data-roles="<?php echo esc_attr( implode( ' ', (array) $wp_list->_um_roles ) ); ?>">
	<legend class="sr-only um-account-legend"><?php echo esc_html( $wp_list->post_title ); ?></legend>

	<?php include( 'field.php' ); ?>

	<section class="um-account-fieldset-dropdown">

		<?php
		if ( !empty( $groups ) ) {
			foreach ( $groups as $group_id => $group_title ) {
				$interests = UM()->Mailchimp()->api()->mc_get_interests_array( $list_id, $group_id );
				if ( !empty( $interests ) ) {
					$a_for = "um-mc-{$wp_list->ID}-group-{$group_id}";
					$a_name = $namepref . '[groups][' . $group_id . ']';
					?>

					<div class="um-field">
						<div class="um-field-label"><label><?php echo $group_title; ?></label></div>

						<?php foreach ( $interests as $id => $name ) { ?>
							<label class="um-field-checkbox <?php echo esc_attr( empty( $groups_selected[$id] ) ? '' : 'active'  ); ?>">
								<input type="checkbox" name="<?php echo esc_attr( $a_name ); ?>[]" value="<?php echo esc_attr( $id ); ?>" <?php echo checked( !empty( $groups_selected[$id] ) ); ?>>
								<span class="um-field-checkbox-state"><i class="<?php echo esc_attr( empty( $groups_selected[$id] ) ? 'um-icon-android-checkbox-outline-blank' : 'um-icon-android-checkbox-outline'  ); ?>"></i></span>
								<span class="um-field-checkbox-option"><?php echo esc_html( $name ); ?></span>
							</label>
						<?php } ?>

					</div>

					<?php
				}
			}
		}
		?>

		<?php
		if ( !empty( $tags ) ) {
			$a_for = "um-mc-{$wp_list->ID}-tags";
			$a_name = $namepref . '[tags]';
			?>

			<div class="um-field um-field-multiselect <?php echo esc_attr( $a_for ); ?>">
				<div class="um-field-label">
					<label for="<?php echo esc_attr( $a_for ); ?>"><?php _e( 'Tags', 'um-mailchimp' ); ?></label>
				</div>
				<input type="hidden" name="<?php echo esc_attr( $namepref ); ?>[tags-update]" value="1" />

				<?php foreach ( $tags as $id => $name ) { ?>
					<label class="um-field-checkbox <?php echo esc_attr( empty( $tags_selected[$id] ) ? '' : 'active'  ); ?>">
						<input type="checkbox" name="<?php echo esc_attr( $a_name ); ?>[]" value="<?php echo esc_attr( $id ); ?>" <?php echo checked( !empty( $tags_selected[$id] ) ); ?>>
						<span class="um-field-checkbox-state"><i class="<?php echo esc_attr( empty( $tags_selected[$id] ) ? 'um-icon-android-checkbox-outline-blank' : 'um-icon-android-checkbox-outline'  ); ?>"></i></span>
						<span class="um-field-checkbox-option"><?php echo esc_html( $name ); ?></span>
					</label>
				<?php } ?>

			</div>

		<?php } ?>

		<?php if ( is_user_logged_in() && um_user( 'can_manage_mc_tags' ) && um_user( 'can_create_mc_tags' ) ) { ?>

			<div class="um-field um-is-conditional um-field-textarea um-field-type_textarea">
				<div class="um-field-label">
					<label for="<?php echo esc_attr( "um-mc-{$wp_list->ID}-tags-new" ); ?>"><?php _e( 'Add New Tags', 'um-mailchimp' ); ?></label>
				</div>
				<div class="um-field-area">
					<textarea class="um-form-field" name="<?php echo esc_attr( $namepref ); ?>[tags-new]" id="<?php echo esc_attr( "um-mc-{$wp_list->ID}-tags-new" ); ?>" placeholder="<?php esc_attr_e( 'Comma separated list of tags', 'um-mailchimp' ); ?>" rows="2"></textarea>
				</div>
			</div>

		<?php } ?>

	</section>
</fieldset>