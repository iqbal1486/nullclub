<?php
/**
 * Template for the form "Newsletters unsubscribe"
 *
 * Call: UM()->Mailchimp()->shortcode()->ultimatemember_mailchimp_unsubscribe()
 * Shortcode: [ultimatemember_mailchimp_unsubscribe]
 *
 * This template can be overridden by copying it to yourtheme/ultimate-member/um-mailchimp/form_unsubscribe.php
 *
 * @var array      $fields
 * @var string     $messages
 * @var array      $notification_fields
 * @var int        $show_checkboxes
 * @var int        $show_label
 */
if ( !defined( 'ABSPATH' ) ) {
	exit;
}

UM()->fields()->set_mode = 'password';
UM()->fields()->editing = true;
UM()->fields()->viewing = false;
?>

<div class="um um-mailchimp-unsubscribe">
	<div class="um-form">

		<?php echo isset( $messages ) ? $messages : ''; ?>

		<?php do_action( 'um_mailchimp_form_unsubscribe_before' ); ?>

		<form method="post">
			<input type="hidden" name="um_action" value="mc_unsubscribe_request">

			<?php foreach ( $fields as $key => $data ) {
				echo UM()->fields()->edit_field( $key, $data );
			} ?>

			<div class="um-field um-field-mailchimp" data-key="mailchimp">
				<?php if ( $show_label && $show_checkboxes ) { ?>
					<div class="um-field-label">
						<label for="user_email"><?php _e( 'Select audiences', 'um-mailchimp' ); ?></label>
						<div class="um-clear"></div>
					</div>
				<?php } ?>

				<?php foreach ( $notification_fields as $notification_field ) {
					echo um_mc_field( $notification_field );
				} ?>
			</div>

			<?php do_action( 'um_mailchimp_form_unsubscribe_inner' ); ?>
			
			<?php wp_nonce_field( 'ultimatemember_mailchimp_unsubscribe' ); ?>

			<div class="um-col-alt um-col-alt-b">
				<div class="um-center">
					<input type="submit" value="<?php esc_attr_e( 'Unsubscribe', 'um-mailchimp' ); ?>" class="um-button" id="um-submit-btn" />
				</div>
			</div>
		</form>

		<?php do_action( 'um_mailchimp_form_unsubscribe_after' ); ?>

	</div>
</div>