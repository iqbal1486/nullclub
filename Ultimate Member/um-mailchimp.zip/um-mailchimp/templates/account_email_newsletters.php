<?php
/**
 * Template for the UM MailChimp
 *
 * Page: "Account", tab "Notifications"
 * Caller: function um_mc_account_tab()
 *
 * This template can be overridden by copying it to yourtheme/ultimate-member/um-mailchimp/account_email_newsletters.php
 */
if ( !defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="um-field um-field-mailchimp" data-key="mailchimp">
	<div class="um-field-label">
		<label><?php _e( 'Email Newsletters', 'um-mailchimp' ); ?></label>
		<div class="um-clear"></div>
	</div>

	<?php
	foreach ( $wp_lists as $wp_list ) {
		echo um_mc_field( $wp_list->ID, $user_id );
	}
	?>

</div>