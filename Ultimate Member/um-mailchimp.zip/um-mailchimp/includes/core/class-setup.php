<?php
namespace um_ext\um_mailchimp\core;


if ( ! defined( 'ABSPATH' ) ) exit;


/**
 * Class for plugin activation
 *
 * @example UM()->classes['um_mailchimp_setup']
 * @example UM()->Mailchimp()->setup()
 */
class Setup {


	/**
	 * Settings
	 *
	 * @var array
	 */
	public $settings_defaults;


	/**
	 * Class constructor
	 */
	function __construct() {
		//settings defaults
		$this->settings_defaults = array(
			'mailchimp_api'                 => '',
			'mailchimp_on_delete'           => 'unsubscribe',
			'mailchimp_on_unapprove'        => 'unsubscribe',
			'mailchimp_enable_cache'        => 1,
			'mailchimp_transient_time'      => 600,
			'mailchimp_enable_log'          => 0,
			'mailchimp_enable_log_response' => 0,
			'mailchimp_blocked_emails'      => 'support@ultimatemember.com',

			// Email Template "MailChimp - Unsubscribe"
			'mc_unsubscribe_on'   => 1,
			'mc_unsubscribe_sub'  => '{site_name} - Newsletters unsubscribe',
		);
	}


	/**
	 * Set Settings
	 */
	private function set_default_settings() {
		$options = get_option( 'um_options', array() );

		foreach ( $this->settings_defaults as $key => $value ) {
			//set new options to default
			if ( ! isset( $options[ $key ] ) ) {
				$options[ $key ] = $value;
			}
		}

		update_option( 'um_options', $options );
	}


	/**
	 * Page Setup
	 * @since 2.2.7 [2020-09-25]
	 */
	private function page_setup() {

		$options = (array) get_option( 'um_options' );
		$update = false;

		// The "Newsletters unsubscribe" page
		$mc_unsubscribe_exists = UM()->query()->find_post_id( 'page', '_um_core', 'mc_unsubscribe' );
		if ( !$mc_unsubscribe_exists ) {
			$postarr = array(
					'post_type'    => 'page',
					'post_name'    => 'newsletters_unsubscribe',
					'post_title'   => __( 'Newsletters unsubscribe', 'um-mailchimp' ),
					'post_content' => '[ultimatemember_mailchimp_unsubscribe]',
					'post_status'  => 'publish',
					'post_author'  => get_current_user_id()
			);

			$post_id = wp_insert_post( $postarr );

			if ( $post_id ) {
				update_post_meta( $post_id, '_um_core', 'mc_unsubscribe' );
				$key = UM()->options()->get_core_page_id( 'mc_unsubscribe' );
				$options[$key] = $post_id;
				$update = true;
			}
		}

		if ( $update ) {
			update_option( 'um_options', $options );
			UM()->rewrite()->reset_rules();
		}
	}


	/**
	 * Run on plugin activation
	 */
	public function run_setup() {
		$this->page_setup();
		$this->set_default_settings();
	}

}