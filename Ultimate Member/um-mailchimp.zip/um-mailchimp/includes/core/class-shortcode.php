<?php

namespace um_ext\um_mailchimp\core;

// Exit if accessed directly.
if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The class to render shortcodes
 *
 * @example UM()->classes['um_mailchimp_shortcode']
 * @example UM()->Mailchimp()->shortcode()
 */
class Shortcode {

	/**
	 * The place to store temporary data
	 * @var array
	 */
	public $data = array();

	/**
	 * The class constructor
	 */
	public function __construct() {

		add_action( 'init', array( $this, 'action_request_process' ) );

		// Render the form "Newsletters subscribe"
		if ( !shortcode_exists( 'ultimatemember_mailchimp_subscribe' ) ) {
			add_shortcode( 'ultimatemember_mailchimp_subscribe', array( $this, 'ultimatemember_mailchimp_subscribe' ) );
		}

		// Render the form "Newsletters unsubscribe"
		if ( !shortcode_exists( 'ultimatemember_mailchimp_unsubscribe' ) ) {
			add_shortcode( 'ultimatemember_mailchimp_unsubscribe', array( $this, 'ultimatemember_mailchimp_unsubscribe' ) );
		}
	}

	/**
	 * Processes the requests of UM actions
	 */
	public function action_request_process() {
		if ( empty( $_REQUEST['um_action'] ) || is_admin() ) {
			return;
		}

		switch ( $_REQUEST['um_action'] ) {
			default:
				break;

			// Process the request from the form "Newsletters subscribe"
			case 'mc_subscribe_request':
				$nonce = filter_input( INPUT_POST, '_wpnonce', FILTER_SANITIZE_STRING );
				$email_address = filter_input( INPUT_POST, 'user_email', FILTER_SANITIZE_EMAIL );

				// verify nonce
				if ( empty( $nonce ) || !wp_verify_nonce( $nonce, 'ultimatemember_mailchimp_subscribe' ) ) {
					error_log( 'ultimatemember_mailchimp_subscribe: incorrect nonce' );
					$this->add_message( 'error', __( 'The page is cached or expired.', 'um-mailchimp' ) );
					break;
				}

				// validate email
				if ( empty( $email_address ) ) {
					UM()->form()->add_error( 'user_email', __( 'Please provide your email', 'um-mailchimp' ) );
					break;
				} elseif ( !is_email( $email_address ) ) {
					UM()->form()->add_error( 'user_email', __( 'Please provide a valid email', 'um-mailchimp' ) );
					break;
				}

				// create or update contacts
				$audiences = $members = array();
				$mailchimp_array = UM()->clean_array( $_POST['um-mailchimp'] );
				foreach ( $mailchimp_array as $list_id => $data ) {
					if ( isset( $data['enabled'] ) && UM()->Mailchimp()->api()->hash_verify( $data['enabled'] ) ) {
						$audiences[] = $list_id;
						$data['status'] = 'pending';

						// get connection
						if ( is_numeric( $list_id ) ) {
							$wp_list = get_post( $list_id );
						} elseif ( isset( $data['wp_list_id'] ) ) {
							$wp_list = get_post( $data['wp_list_id'] );
						} else {
							continue;
						}

						// get merge fields
						$merged = $wp_list->_um_merge;
						if ( $merged && is_array( $merged ) ) {
							$data['merge_fields'] = array();
							$mc_merge_fields = UM()->Mailchimp()->api()->mc_get_merge_fields( $wp_list->_um_list );
							foreach ( $mc_merge_fields as $arr ) {
								if ( empty( $merged[$arr['tag']] ) ) {
									continue;
								}
								$field_name = $merged[$arr['tag']];

								$field_value = empty( $_POST[$field_name] ) ? '' : $_POST[$field_name];
								if ( is_array( $field_value ) ) {
									$field_value = implode( ',', UM()->clean_array( $field_value ) );
								} else {
									$field_value = sanitize_text_field( $field_value );
								}

								if ( !empty( $arr['required'] && empty( $field_value ) ) ) {
									UM()->form()->add_error( $field_name, sprintf( __( '%s is required.', 'ultimate-member' ), $arr['name'] ) );
								} elseif ( $field_value ) {
									$data['merge_fields'][$arr['tag']] = $field_value;
								}
							}
						}

						// add a contact
						if ( !$this->has_errors() ) {
							$members[$wp_list->ID] = $response = UM()->Mailchimp()->api()->add_member( $email_address, $wp_list, $data );

							// show errors and notifications
							if ( !$response ) {
								$message = UM()->Mailchimp()->log()->error_html( UM()->Mailchimp()->api()->get_last_error() );
								$this->add_message( 'error', $message, $wp_list->ID );
							} else {
								$this->add_message( 'success', sprintf( __( 'A new contact "%s" will be added to the audience "%s". Please look at the mailbox and confirm subscription.', 'um-mailchimp' ), $email_address, $wp_list->post_title ), $wp_list->ID );
							}
						}
					}
				}
				if ( !$audiences ) {
					$this->add_message( 'error', __( 'Please select an audience.', 'um-mailchimp' ) );
				}

				break;

			// Process the request from the link to unsubscribe
			case 'mc_unsubscribe':
				$key = filter_input( INPUT_GET, 'key', FILTER_SANITIZE_STRING );
				$data = get_transient( "mc_unsubscribe:$key" );
				if ( $data && is_array( $data ) && UM()->Mailchimp()->api()->hash_verify( $key, $data['audience_id'] . $data['email_address'] ) ) {

					$response = UM()->Mailchimp()->api()->mc_unsubscribe_member( $data['audience_id'], $data['email_address'] );

					if ( isset( $response['status'] ) && $response['status'] == 'unsubscribed' ) {
						$this->add_message( 'success', sprintf( __( 'The member %s was unsubscribed.', 'um-mailchimp' ), $data['email_address'] ) );
					} elseif ( isset( $response['status'] ) && is_numeric( $response['status'] ) ) {
						$this->add_message( 'error', UM()->Mailchimp()->log()->error_html( $response ) );
					}
					$messages = $this->get_messages();
					set_transient( "mc_messages:$key", $messages, MINUTE_IN_SECONDS );

					$redirect_url = add_query_arg( array( 'key' => $key ), um_get_core_page( 'mc_unsubscribe' ) );
					wp_redirect( $redirect_url );
					exit();
				}
				break;

			// Process the manual unsubscribe request
			// Example: [GET] https://site.domain/newsletters_unsubscribe/?um_action=mc_unsubscribe_me&nonce=50fccf4b22&user_email=umdevelopera%2Bs02%40gmail.com
			case 'mc_unsubscribe_me':

				// verify headers
				if ( empty( $_SERVER['HTTP_USER_AGENT'] ) || empty( $_SERVER['HTTP_ACCEPT'] ) || empty( $_SERVER['REMOTE_ADDR'] ) ) {
					break;
				}

				// verify nonce
				$nonce = filter_input( INPUT_GET, 'nonce', FILTER_SANITIZE_STRING );
				if ( empty( $nonce ) || !wp_verify_nonce( $nonce, 'um-frontend-nonce' ) ) {
					error_log( 'ultimatemember_mailchimp_unsubscribe_me: incorrect nonce' );
					break;
				}

				// verify time
				$locked_ip = (array) get_transient( 'mc_unsubscribe_me_ip' );
				$last_request = (int) get_option( 'mc_unsubscribe_me_time' );
				if ( in_array( $_SERVER['REMOTE_ADDR'], $locked_ip ) || $last_request + MINUTE_IN_SECONDS > time() ) {
					$locked_ip[] = $_SERVER['REMOTE_ADDR'];
					set_transient( 'mc_unsubscribe_me_ip', array_unique( $locked_ip ), HOUR_IN_SECONDS );
					exit( 'Locked by time or IP. Try later.' );
				}
				update_option( 'mc_unsubscribe_me_time', time() );

				$email_address = filter_input( INPUT_GET, 'user_email', FILTER_SANITIZE_STRING );
				$audience_ids = array_keys( UM()->Mailchimp()->api()->get_lists() );
				if ( $email_address && is_email( $email_address ) && $audience_ids ) {
					UM()->Mailchimp()->email()->send_unsubscribe_email( $email_address, $audience_ids );
					exit( __( 'The mail "Newsletters unsubscribe" is sent. Look at your mailing box.', 'um-mailchimp' ) );
				}
				break;

			// Process the request from the form "Newsletters unsubscribe"
			case 'mc_unsubscribe_request':
				$nonce = filter_input( INPUT_POST, '_wpnonce', FILTER_SANITIZE_STRING );
				$email_address = filter_input( INPUT_POST, 'user_email', FILTER_SANITIZE_EMAIL );

				// verify nonce
				if ( empty( $nonce ) || !wp_verify_nonce( $nonce, 'ultimatemember_mailchimp_unsubscribe' ) ) {
					error_log( 'ultimatemember_mailchimp_unsubscribe: incorrect nonce' );
					$this->add_message( 'error', __( 'The page is cached or expired.', 'um-mailchimp' ) );
					break;
				}

				// validate email
				if ( empty( $email_address ) ) {
					UM()->form()->add_error( 'user_email', __( 'Please provide your email', 'um-mailchimp' ) );
					break;
				} elseif ( !is_email( $email_address ) ) {
					UM()->form()->add_error( 'user_email', __( 'Please provide a valid email', 'um-mailchimp' ) );
					break;
				}

				// get audiences
				$audience_ids = array();
				$mailchimp_array = UM()->clean_array( $_POST['um-mailchimp'] );
				if ( empty( $mailchimp_array ) ) {
					$audience_ids = array_keys( UM()->Mailchimp()->api()->get_lists() );
				} else {
					foreach ( $mailchimp_array as $list_id => $data ) {
						if ( isset( $data['enabled'] ) && UM()->Mailchimp()->api()->hash_verify( $data['enabled'] ) ) {

							if ( is_numeric( $list_id ) ) {
								$wp_list = get_post( $list_id );
							} elseif ( isset( $data['wp_list_id'] ) ) {
								$wp_list = get_post( $data['wp_list_id'] );
							} else {
								continue;
							}

							$audience_ids[] = $wp_list->_um_list;
						}
					}
				}
				if ( !$audience_ids ) {
					$this->add_message( 'error', __( 'Please select an audience.', 'um-mailchimp' ) );
					break;
				}

				$sent = UM()->Mailchimp()->email()->send_unsubscribe_email( $email_address, $audience_ids );
				if ( $sent ) {
					UM()->Mailchimp()->shortcode()->add_message( 'success', __( 'The mail "Newsletters unsubscribe" is sent. Look at your mailing box.', 'um-mailchimp' ) );
				} else {
					UM()->Mailchimp()->shortcode()->add_message( 'error', __( 'You are not subscribed.', 'um-mailchimp' ) );
				}
				break;
		}
	}

	/**
	 * Add a new message
	 * @param string $type    Value: 'error' or 'success'
	 * @param string $message
	 * @param string $key
	 */
	public function add_message( $type, $message, $key = null ) {
		if ( empty( $this->data['messages'] ) ) {
			$this->data['messages'] = array();
		}
		if ( empty( $this->data['messages'][$type] ) ) {
			$this->data['messages'][$type] = array();
		}
		if ( $key ) {
			$this->data['messages'][$type][$key] = $message;
		} else {
			$this->data['messages'][$type][] = $message;
		}
	}

	/**
	 * Get error message by key
	 * @param  string   $key
	 * @param  boolean  $clear
	 * @return string
	 */
	public function get_error_message( $key, $clear = false ) {
		$message = '';
		if ( isset( $this->data['messages'] ) && isset( $this->data['messages']['error'] ) && isset( $this->data['messages']['error'][$key] ) ) {
			$message = $this->data['messages']['error'][$key];
			if ( $clear ) {
				unset( $this->data['messages']['error'][$key] );
			}
		}
		return $message;
	}

	/**
	 * Get messages
	 * @return array
	 */
	public function get_messages() {
		$messages = array(
				'error' => array(),
				'success' => array()
		);

		// Get current message
		if ( isset( $this->data['messages'] ) && is_array( $this->data['messages'] ) ) {
			$messages = array_merge_recursive( $messages, $this->data['messages'] );
		}

		// Get saved message
		$key = filter_input( INPUT_GET, 'key', FILTER_SANITIZE_STRING );
		if ( $key ) {
			$mc_messages = get_transient( "mc_messages:$key" );
			if ( isset( $mc_messages ) && is_array( $mc_messages ) ) {
				$messages = array_merge_recursive( $messages, $mc_messages );
			}
		}

		return $messages;
	}

	/**
	 * Get messages as HTML to show in template
	 * @return string
	 */
	public function get_messages_html() {
		$messages_html = '';
		$messages = $this->get_messages();

		// Render messages
		if ( isset( $messages['error'] ) ) {
			foreach ( (array) $messages['error'] as $key => $message ) {
				$messages_html .= '<p class="um-notice err"><i class="um-icon-ios-close-empty" onclick="jQuery(this).parent().fadeOut();"></i>' . $message . '</p>';
			}
		}
		if ( isset( $messages['success'] ) ) {
			foreach ( (array) $messages['success'] as $key => $message ) {
				$messages_html .= '<p class="um-notice success"><i class="um-icon-ios-close-empty" onclick="jQuery(this).parent().fadeOut();"></i>' . $message . '</p>';
			}
		}

		return $messages_html;
	}

	/**
	 * Change fields view - add placeholder
	 * @param   array $array  The array of the field settings
	 * @return  array
	 */
	public function filter_add_placeholder( $array ) {
		$array['placeholder'] = esc_attr( $array['label'] );
		return $array;
	}

	/**
	 * Change fields - add default value
	 * @param   array $array  The array of the field settings
	 * @return  array
	 */
	public function filter_default_value( $array ) {

		if ( $this->has_errors() ) {
			$array['default'] = filter_input( INPUT_POST, $array['metakey'], FILTER_SANITIZE_STRING );
		}

		return $array;
	}

	/**
	 * Change fields view - remove label
	 * @param   array $array  The array of the field settings
	 * @return  array
	 */
	public function filter_remove_label( $array ) {
		$array['label'] = null;
		return $array;
	}

	/**
	 * Return FALSE if the form is not valid
	 * @return boolean
	 */
	public function has_errors() {
		return !(empty( UM()->form()->errors ) && empty( $this->data['messages']['error'] ));
	}

	/**
	 * Render the form "Newsletters subscribe"
	 * @example [ultimatemember_mailchimp_subscribe]
	 * @param   array $atts
	 * @return  string
	 */
	public function ultimatemember_mailchimp_subscribe( $atts = array() ) {

		$args = shortcode_atts( array(
				'id' => '',
				'fields' => 'user_email',
				'messages' => '',
				'groups' => 0,
				'tags' => 0,
				'show_checkboxes' => 1,
				'show_label' => 1,
				'show_placeholder' => 1
				), $atts, 'ultimatemember_mailchimp_subscribe' );

		// Audiences
		$fields = explode( ',', $args['fields'] );
		$args['notification_fields'] = array();

		if ( empty( $args['id'] ) ) {
			$wp_lists = UM()->Mailchimp()->api()->get_wp_lists();
		} else {
			$wp_list_ids = explode( ',', $args['id'] );
			$wp_lists = array_map( 'get_post', $wp_list_ids );
		}

		foreach ( $wp_lists as $wp_list ) {
			if ( isset( $args['notification_fields'][$wp_list->_um_list] ) ) {
				continue;
			}

			$list = UM()->Mailchimp()->api()->mc_get_list( $wp_list->_um_list );
			$error = $this->get_error_message( $wp_list->ID, true );
			$notice = '';

			if ( isset( $list['visibility'] ) && $list['visibility'] === 'pub' ) {

				// the MailChimp field
				$args['notification_fields'][$wp_list->_um_list] = array(
						'mailchimp_list' => $wp_list->ID,
						'mailchimp_groups' => $args['groups'],
						'mailchimp_tags' => $args['tags'],
						'mailchimp_auto_subscribe' => !$args['show_checkboxes'],
						'hidden' => !$args['show_checkboxes'],
						'error' => $error,
						'notice' => $notice
				);

				// required merge fields
				$merged = $wp_list->_um_merge;
				if ( $merged && is_array( $merged ) ) {
					$mc_merge_fields = UM()->Mailchimp()->api()->mc_get_merge_fields( $wp_list->_um_list );
					foreach ( $mc_merge_fields as $arr ) {
						if ( !empty( $arr['required'] ) && isset( $merged[$arr['tag']] ) ) {
							$fields[] = $merged[$arr['tag']];
						}
					}
				}
			}
		}
		
		if( !in_array( 'user_email', $fields ) ){
			$fields = array_unshift($fields, 'user_email');
		}

		if ( empty( $args['notification_fields'] ) ) {
			error_log( 'ultimatemember_mailchimp_subscribe: there is no valid audiences' );
			return '';
		}

		// Prepare notifications
		$args['messages'] .= $this->get_messages_html();

		// Get fields
		$args['fields'] = array();
		foreach ( $fields as $key ) {
			$args['fields'][$key] = UM()->builtin()->get_a_field( $key );
			
			if ( $args['show_placeholder'] ) {
				add_filter( "um_get_field__{$key}", array( $this, 'filter_add_placeholder' ), 20 );
			}
			if ( !$args['show_label'] ) {
				add_filter( "um_get_field__{$key}", array( $this, 'filter_remove_label' ), 30 );
			}
			add_filter( "um_get_field__{$key}", array( $this, 'filter_default_value' ), 40 );
		}

		// Render the form
		$content = UM()->get_template( 'form_subscribe.php', um_mailchimp_plugin, $args, false );

		return $content;
	}

	/**
	 * Render the form "Newsletters unsubscribe"
	 * @example [ultimatemember_mailchimp_unsubscribe]
	 * @param   array $atts
	 * @return  string
	 */
	public function ultimatemember_mailchimp_unsubscribe( $atts = array() ) {

		$args = shortcode_atts( array(
				'id' => '',
				'messages' => '',
				'show_checkboxes' => 1,
				'show_label' => 1,
				'show_placeholder' => 1
				), $atts, 'ultimatemember_mailchimp_unsubscribe' );

		// Audiences
		$args['notification_fields'] = array();

		if ( empty( $args['id'] ) ) {
			$wp_lists = UM()->Mailchimp()->api()->get_wp_lists();
		} else {
			$wp_list_ids = explode( ',', $args['id'] );
			$wp_lists = array_map( 'get_post', $wp_list_ids );
		}

		foreach ( $wp_lists as $wp_list ) {
			if ( isset( $args['notification_fields'][$wp_list->_um_list] ) ) {
				continue;
			}

			$list = UM()->Mailchimp()->api()->mc_get_list( $wp_list->_um_list );
			$error = $this->get_error_message( $wp_list->ID, true );
			$notice = '';

			if ( isset( $list['visibility'] ) /*&& $list['visibility'] === 'pub'*/ ) {
				$args['notification_fields'][$wp_list->_um_list] = array(
						'mailchimp_list' => $wp_list->ID,
						'mailchimp_groups' => false,
						'mailchimp_tags' => false,
						'mailchimp_auto_subscribe' => !$args['show_checkboxes'],
						'hidden' => !$args['show_checkboxes'],
						'error' => $error,
						'notice' => $notice
				);
			}
		}

		if ( empty( $args['notification_fields'] ) ) {
			error_log( 'ultimatemember_mailchimp_unsubscribe: there is no valid audiences' );
			return '';
		}

		// Prepare notifications
		$args['messages'] .= $this->get_messages_html();

		// Get fields
		$args['fields'] = UM()->builtin()->get_specific_fields( 'user_email' );
		if ( $args['show_placeholder'] ) {
			add_filter( "um_get_field__user_email", array( $this, 'filter_add_placeholder' ), 20 );
		}
		if ( !$args['show_label'] ) {
			add_filter( "um_get_field__user_email", array( $this, 'filter_remove_label' ), 30 );
		}
		add_filter( 'um_get_field__user_email', array( $this, 'filter_default_value' ), 40 );

		// Render the form
		$content = UM()->get_template( 'form_unsubscribe.php', um_mailchimp_plugin, $args, false );

		return $content;
	}

}
