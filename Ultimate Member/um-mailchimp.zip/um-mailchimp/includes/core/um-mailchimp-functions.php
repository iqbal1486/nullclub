<?php if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Render the field 'MailChimp'
 * @param  int|array  $data     The array of field settings   [
			(int)'mailchimp_list',
			(boolean)'mailchimp_groups',
			(boolean)'mailchimp_tags',
			(boolean)'mailchimp_auto_subscribe',
			(string)'error',
			(string)'notice',
			(boolean)'hidden'
		]
 * @param  int|null   $user_id  User's identification number
 * @return string
 */
function um_mc_field( $data, $user_id = null ) {

	// connection
	if ( is_numeric( $data ) ) {
		$wp_list = get_post( $data );
	} elseif ( is_array( $data ) && isset( $data['mailchimp_list'] ) ) {
		$wp_list = get_post( $data['mailchimp_list'] );
	} elseif ( is_a( $data, 'WP_Post' ) ) {
		$wp_list = $data;
	} else {
		return '';
	}
	if ( !$wp_list || !$wp_list->_um_status ) {
		return '';
	}

	$error = $notice = '';
	$enabled = false;
	$label = sprintf( __( 'The audience "%s"', 'um-mailchimp' ), $wp_list->post_title );
	$list_id = $wp_list->_um_list;
	$mc_groups = $mc_groups_selected = array();
	$mc_tags = $mc_tags_selected = array();

	if( empty( $data['hidden'] ) ){
		// For visible fields

		if( is_user_logged_in() && um_user( 'ID' ) == $user_id ){
			// Display the field for member

			$mc_member = UM()->Mailchimp()->api()->mc_get_member( $list_id, $user_id );
			$enabled = isset( $mc_member['status'] ) && in_array( $mc_member['status'], array( 'pending', 'subscribed' ) );
			$error = isset( $mc_member['status'] ) && $mc_member['status'] === 'pending' ? __( 'You have to confirm subscription via email.', 'um-mailchimp' ) : '';

			// label
			if( $wp_list->_um_desc ){
				$label = translate( $wp_list->_um_desc, 'um-mailchimp' );
			}

			// groups
			if ( um_user( 'can_manage_mc_groups' ) ) {
				$mc_groups = UM()->Mailchimp()->api()->mc_get_interest_categories_array( $list_id );
				$mc_groups_selected = isset( $mc_member['interests'] ) ? $mc_member['interests'] : array();
			}

			// tags
			if ( um_user( 'can_manage_mc_tags' ) ) {
				$mc_tags = UM()->Mailchimp()->api()->mc_get_tags_array( $list_id );
				$mc_tags_selected = UM()->Mailchimp()->api()->mc_get_member_tags_array( $list_id, $user_id );
			}

		} else {
			// Display the field for guests

			$enabled = isset( $data['mailchimp_auto_subscribe'] ) && $data['mailchimp_auto_subscribe'];
			if ( isset( UM()->form()->post_form['submitted'] ) && isset( UM()->form()->post_form['submitted']['um-mailchimp'] ) ) {
				$enabled = !empty( UM()->form()->post_form['submitted']['um-mailchimp'][$wp_list->ID]['enabled'] );
			}

			$error = isset( $data['error'] ) ? $data['error'] : '';
			$notice = isset( $data['notice'] ) ? $data['notice'] : '';

			// label
			if ( isset( $data['label'] ) && $data['label'] ) {
				$label = translate( $data['label'], 'um-mailchimp' );
			} elseif( $wp_list->_um_desc_reg && isset( UM()->fields()->set_mode ) && UM()->fields()->set_mode === 'register' ) {
				$label = translate( $wp_list->_um_desc_reg, 'um-mailchimp' );
			}

			// groups
			if ( isset( $data['mailchimp_groups'] ) && $data['mailchimp_groups'] ) {
				$mc_groups = UM()->Mailchimp()->api()->mc_get_interest_categories_array( $list_id );
				foreach ( $mc_groups as $id => $name ) {
					$meta_key = "_um_reg_groups_$id";
					$mc_groups_selected = array_merge( $mc_groups_selected, (array) $wp_list->$meta_key );
				}
				$mc_groups_selected = array_combine( $mc_groups_selected, $mc_groups_selected );
			}

			// tags
			if ( isset( $data['mailchimp_tags'] ) && $data['mailchimp_tags'] ) {
				$mc_tags = UM()->Mailchimp()->api()->mc_get_tags_array( $list_id );
				if ( $wp_list->_um_reg_tags ) {
					$mc_tags_selected = array_intersect_key( $mc_tags, array_flip( $wp_list->_um_reg_tags ) );
				}
			}
		}

	} elseif ( !empty( $data['mailchimp_auto_subscribe'] ) ) {
		// For hidden fields
		$enabled = 1;
	}

	$t_args = array(
		'enabled'         => $enabled,
		'error'           => $error,
		'groups'          => $mc_groups,
		'groups_selected' => $mc_groups_selected,
		'label'           => $label,
		'list_id'         => $list_id,
		'notice'          => $notice,
		'tags'            => $mc_tags,
		'tags_selected'   => $mc_tags_selected,
		'value'           => UM()->Mailchimp()->api()->hash_create(),
		'wp_list'         => $wp_list
	);

	if( !empty( $data['hidden'] ) ){
		$output = '<input type="hidden" name="um-mailchimp['.$wp_list->ID.'][wp_list_id]" value="'.$wp_list->ID.'" /><input type="hidden" name="um-mailchimp['.$wp_list->ID.'][enabled]" value="'.$t_args['value'].'" />';
	} elseif( $mc_groups || $mc_tags || (um_user( 'can_create_mc_tags' ) && UM()->fields()->set_mode !== 'password') ){
		$fieldset_tpl = UM()->options()->get( 'mailchimp_view' ) === 'checkbox' ? 'fieldset_ch.php' : 'fieldset.php';
		$output = UM()->get_template( $fieldset_tpl, um_mailchimp_plugin, $t_args );
	} else {
		$output = UM()->get_template( 'field.php', um_mailchimp_plugin, $t_args );
	}

	wp_enqueue_script( 'um-mailchimp' );
	wp_enqueue_style( 'um-mailchimp' );

	return $output;
}