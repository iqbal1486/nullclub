<?php

namespace um_ext\um_mailchimp\core;

// Exit if accessed directly.
if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The class to configure and send E-mails
 *
 * @example UM()->classes['um_mailchimp_email']
 * @example UM()->Mailchimp()->email()
 */
class Email {

	/**
	 * Class constructor
	 */
	public function __construct() {
		add_filter( 'um_admin_settings_email_section_fields', array( $this, 'email_placeholders' ), 20, 2 );
		add_filter( 'um_email_templates_path_by_slug', array( $this, 'email_templates_path_by_slug' ) );
		add_filter( 'um_email_notifications', array( $this, 'email_notifications' ) );
	}

	/**
	 * Get the HTML of the placeholder {mc_unsubscribe}
	 * @param  array  $audience_ids   The array of the audiences to unsubscribe
	 * @param  atring $email_address  The email address to unsubscribe
	 * @return string
	 */
	public function get_placeholder_mc_unsubscribe( $audience_ids, $email_address ) {
		$mc_unsubscribe = '';

		foreach ( $audience_ids as $audience_id ) {
			if ( UM()->Mailchimp()->api()->is_subscribed( $audience_id, $email_address ) ) {
				$list = UM()->Mailchimp()->api()->mc_get_list( $audience_id );
				$link = $this->get_unsubscribe_link( $audience_id, $email_address );

				$mc_unsubscribe .= '<p>';
				$mc_unsubscribe .= sprintf( __( 'Unsubscribe me from the audience <b>%1$s</b>: <br>%2$s', 'um-mailchimp' ), $list['name'], $link );
				$mc_unsubscribe .= '</p>';
			}
		}

		return $mc_unsubscribe;
	}

	/**
	 * Get the link to unsubscribe
	 * @param  string $audience_id    The audience ID
	 * @param  string $email_address  The email address to unsubscribe
	 * @return string
	 */
	public function get_unsubscribe_link( $audience_id, $email_address ) {
		$key = UM()->Mailchimp()->api()->hash_create( $audience_id . $email_address );

		set_transient( "mc_unsubscribe:$key", array(
				'audience_id' => $audience_id,
				'email_address' => $email_address
				), MONTH_IN_SECONDS );

		$link = add_query_arg( array(
				'um_action' => 'mc_unsubscribe',
				'key' => $key
				), home_url() );

		return $link;
	}

	/**
	 * Send email "MailChimp - Newsletters unsubscribe"
	 * @param string $email_address
	 * @param string $audience_id
	 */
	public function send_unsubscribe_email( $email_address, $audience_id = '' ) {

		if ( is_string( $audience_id ) ) {
			$audience_ids = array( $audience_id );
		} elseif ( is_array( $audience_id ) ) {
			$audience_ids = $audience_id;
		} else {
			return;
		}

		$mc_unsubscribe = $this->get_placeholder_mc_unsubscribe( $audience_ids, $email_address );

		if ( $mc_unsubscribe ) {
			UM()->mail()->send( $email_address, 'mc_unsubscribe', array(
					'plain_text' => 1,
					'path' => um_mailchimp_path . 'templates/email/',
					'tags' => array(
							'{mc_unsubscribe}'
					),
					'tags_replace' => array(
							$mc_unsubscribe
					)
			) );
			return true;
		}
	}

	/**
	 * Email notifications templates
	 * @param  array $notifications
	 * @return array
	 */
	public function email_notifications( $notifications ) {

		$notifications['mc_unsubscribe'] = array(
				'key' => 'mc_unsubscribe',
				'title' => __( 'MailChimp - Newsletters unsubscribe', 'um-mailchimp' ),
				'subject' => '{site_name} - Newsletters unsubscribe',
				'body' => __( 'Use links below to unsubscribe from newsletters<br>{mc_unsubscribe}', 'um-mailchimp' ),
				'default_active' => true,
				'description' => __( 'Send a notification with unsubscribe links.', 'um-mailchimp' ),
				'recipient' => 'user'
		);

		return $notifications;
	}

	/**
	 * Sets a path to email notification templates
	 * @param  array $slugs
	 * @return array
	 */
	public function email_templates_path_by_slug( $slugs ) {
		$slugs['mc_unsubscribe'] = um_mailchimp_path . 'templates/email/';
		return $slugs;
	}

	/**
	 * Show available placeholders for the email template
	 * @param  array  $fields
	 * @param  string $email_key
	 * @return array
	 */
	public function email_placeholders( $fields, $email_key = '' ) {

		switch ( $email_key ) {
			case 'mc_unsubscribe':
				$fields[] = array(
						'id' => 'um_info_text',
						'type' => 'info_text',
						'value' => __( 'Placeholders:', 'um-groups' ) .
						' {site_name}' .
						' {site_url}' .
						' {mc_unsubscribe}'
				);
				break;

			default:
				break;
		}

		return $fields;
	}

}
