<?php

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Add a notice to the Account form
 *
 * @param type $args
 */
function um_mc_account_notice( $args ) {
	if ( isset( $args['mode'] ) && $args['mode'] === 'account' ) {

		$user_id = get_current_user_id();
		$errors = get_transient( "um_mc_api:errors_$user_id" );

		if ( !$errors ) {
			return;
		}

		foreach ( $errors as $key => $error ) {
			$error_text = "<!-- Error: $key -->";
			$error_text .= UM()->Mailchimp()->log()->error_html( $error );
			echo '<p class="um-notice err"><i class="um-icon-ios-close-empty" onclick="jQuery(this).parent().fadeOut();"></i>' . $error_text . '</p>';
		}

		delete_transient( "um_mc_api:errors_$user_id" );
		remove_action( 'um_before_form', 'um_add_update_notice', 500 );
	}
}
add_action( 'um_before_form', 'um_mc_account_notice', 200 );


/**
 * Subscribe or unsubscribe to the audience on the Account Notifications update
 *
 * @param $user_id
 * @param array $changes
 *
 * @return array|bool
 */
function um_mc_account_update( $user_id, $changes = array() ) {

	if ( empty( $_POST['um-mailchimp'] ) || !is_array( $_POST['um-mailchimp'] ) ) {
		return false;
	}
	if ( is_wp_error( $user_id ) || 'approved' !== get_user_meta( $user_id, 'account_status', true ) ) {
		return false;
	}

	$u = [
			'unsubscribe' => [],
			'subscribe' => [],
			'update' => []
	];

	$my_lists = UM()->Mailchimp()->api()->get_lists_my( $user_id );
	$form_lists = UM()->clean_array( $_POST['um-mailchimp'] );

	foreach ( $form_lists as $id => $data ) {

		$wp_list = is_numeric( $id ) ? get_post( $id ) : (isset( $data['wp_list_id'] ) ? get_post( $data['wp_list_id'] ) : null);

		if ( empty( $wp_list ) || empty( $wp_list->_um_status ) ) {
			continue;
		}

		$list_id = $wp_list->_um_list;
		$is_subscribed = isset( $my_lists[$list_id] ) && $my_lists[$list_id];
		$data['wp_list'] = $wp_list;

		if ( isset( $data['enabled'] ) && UM()->Mailchimp()->api()->hash_verify( $data['enabled'] ) ) {
			if ( $is_subscribed ) {
				$u['update'][$list_id] = (bool) UM()->Mailchimp()->api()->mc_update_member( $list_id, $user_id, $data );
			} else {
				$u['subscribe'][$list_id] = (bool) UM()->Mailchimp()->api()->add_member( $user_id, $wp_list, $data );
			}
		} elseif ( $is_subscribed ) {
			$u['unsubscribe'][$list_id] = (bool) UM()->Mailchimp()->api()->mc_unsubscribe_member( $list_id, $user_id );
		}
	}

	return $u;
}


/**
 * Update the audience contact on the Account update or Profile update
 *
 * @hook   'um_after_user_updated'
 * @hook   'um_after_user_account_updated'
 *
 * @since   2.2.5
 * @version 2.2.8
 *
 * @param   integer  $user_id
 * @param   attay    $args
 * @return  array
 */
function um_mc_after_user_updated( $user_id, $args = array() ) {
	global $um_mc_old_email;

	if ( isset( $_POST['um-mailchimp'] ) && is_array( $_POST['um-mailchimp'] ) ) {
		return um_mc_account_update( $user_id, $args );
	}

	return um_mc_auto_sync_contact( $user_id, '', (string) $um_mc_old_email );
}
add_action( 'um_after_user_updated', 'um_mc_after_user_updated', 20, 2 );
add_action( 'um_after_user_account_updated', 'um_mc_after_user_updated', 20, 2 );