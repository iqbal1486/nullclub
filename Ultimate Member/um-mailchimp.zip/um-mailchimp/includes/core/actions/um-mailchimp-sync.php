<?php

if ( !defined( 'ABSPATH' ) ) {
	exit;
}


/**
 * Update the audience contact
 *
 * @since     2.2.0
 * @version   2.2.8
 *
 * @staticvar array       $updated_users
 * @param     integer     $user_id
 * @param     null|string $role
 * @param     null|string $old_email
 * @return    array
 */
function um_mc_auto_sync_contact( $user_id, $role = '', $old_email = '' ) {
	static $u = array();

	if ( is_wp_error( $user_id ) || 'approved' !== get_user_meta( $user_id, 'account_status', true ) ) {
		return false;
	}

	$actions = [
		'unsubscribe'	 => [],
		'subscribe'		 => [],
		'update'			 => []
	];
	if ( empty( $u[$user_id] ) ) {
		$u[$user_id] = $actions;
	}

	$user = get_userdata( $user_id );
	$roles = $user->roles;
	if ( $role ) {
		array_push( $roles, $role );
		$roles = array_unique( $roles );
	}

	$my_lists = UM()->Mailchimp()->api()->get_lists_my( is_email( $old_email ) ? $old_email : $user_id );
	$wp_lists = UM()->Mailchimp()->api()->get_wp_lists();

	foreach ( $wp_lists as $wp_list ) {
		if( empty( $wp_list->_um_reg_status ) && ! is_email( $old_email ) ){
			continue;
		}

		$list_id = $wp_list->_um_list;
		$can_subscribe = (bool) array_intersect( (array) $wp_list->_um_roles, $roles );
		$is_subscribed = isset( $my_lists[$list_id] ) && $my_lists[$list_id];

		if ( !$can_subscribe && $is_subscribed && empty( $u[$user_id]['unsubscribe'][$list_id] ) ) {
			$actions['unsubscribe'][$list_id] = $wp_list;
		} elseif ( $can_subscribe && !$is_subscribed && empty( $u[$user_id]['subscribe'][$list_id] ) ) {
			$actions['subscribe'][$list_id] = $wp_list;
		} elseif ( $can_subscribe && $is_subscribed && empty( $u[$user_id]['update'][$list_id] ) ) {
			$actions['update'][$list_id] = $wp_list;
		}
	}

	$unsubscribe = array_diff_key( $actions['unsubscribe'], $actions['update'], $u[$user_id]['update'] );
	foreach ( $unsubscribe as $list_id => $wp_list ) {
		$u[$user_id]['unsubscribe'][$list_id] = (bool) UM()->Mailchimp()->api()->mc_unsubscribe_member( $list_id, $user_id );
	}

	$subscribe = array_diff_key( $actions['subscribe'], $actions['update'], $u[$user_id]['update'] );
	foreach ( $subscribe as $list_id => $wp_list ) {
		$u[$user_id]['subscribe'][$list_id] = (bool) UM()->Mailchimp()->api()->add_member( $user_id, $wp_list, [ 'status' => 'subscribed' ] );
	}

	foreach ( $actions['update'] as $list_id => $wp_list ) {
		$u[$user_id]['update'][$list_id] = (bool) UM()->Mailchimp()->api()->mc_update_member( $list_id, $user, [ 'wp_list' => $wp_list ] );
	}

	return $u[$user_id];
}
add_action( 'add_user_role', 'um_mc_auto_sync_contact', 20, 2 );
add_action( 'set_user_role', 'um_mc_auto_sync_contact', 20, 2 );
add_action( 'remove_user_role', 'um_mc_auto_sync_contact', 20, 1 );


/**
 * Subscribe or unsubscribe to audience if user status changed
 *
 * @hook    um_after_user_status_is_changed
 * @since   2.2.0
 * @version 2.2.4
 *
 * @param string $status
 */
function um_mc_after_user_status_is_changed( $status ) {
	static $lists_subscribed = array();

	$user_id = um_profile( 'ID' );
	if ( empty( $user_id ) ) {
		return;
	}

	if ( $status !== 'approved' ) {
		do_action( 'um_mc_unsubscribe_user', $user_id, UM()->options()->get( 'mailchimp_on_unapprove' ) );
		return;
	}

	/**
	 * Subscribe to the audience checked in the registration form
	 */
	$form_lists = isset( $_POST['um-mailchimp'] ) ? UM()->clean_array( $_POST['um-mailchimp'] ) : (array) get_user_meta( $user_id, 'um-mailchimp', true );
	foreach ( $form_lists as $id => $data ) {
		if ( empty( $data ) || empty( $data['enabled'] ) || !UM()->Mailchimp()->api()->hash_verify( $data['enabled'] ) ) {
			continue;
		}

		$wp_list = is_numeric( $id ) ? get_post( $id ) : (isset( $data['wp_list_id'] ) ? get_post( $data['wp_list_id'] ) : null);

		if ( empty( $wp_list ) || in_array( $wp_list->_um_list, $lists_subscribed ) ) {
			continue;
		}
		if ( $wp_list->_um_status ) {
			if ( UM()->Mailchimp()->api()->add_member( $user_id, $wp_list, $data ) ) {
				$lists_subscribed[] = $wp_list->_um_list;
			}
		}
	}

	/**
	 * Subscribe to the audience automatically
	 */
	$wp_lists = UM()->Mailchimp()->api()->get_wp_lists( true );
	foreach ( $wp_lists as $wp_list ) {
		if ( in_array( $wp_list->_um_list, $lists_subscribed ) ) {
			continue;
		}
		if ( $wp_list->_um_status && $wp_list->_um_reg_status ) {
			if ( UM()->Mailchimp()->api()->add_member( $user_id, $wp_list ) ) {
				$lists_subscribed[] = $wp_list->_um_list;
			}
		}
	}
}
add_action( 'um_after_user_status_is_changed', 'um_mc_after_user_status_is_changed', 20 );


/**
 * Update audience contact if Administrator edit user in the admin area.
 *
 * @hook   profile_update
 * @since  2.2.5
 *
 * @global string   $um_mc_old_email  E-mail
 * @param  intager  $user_id
 * @param  WP_User  $old_user_data
 */
function um_mc_profile_update( $user_id, $old_user_data = null ) {
	global $um_mc_old_email;

	if ( is_wp_error( $user_id ) ) {
		return;
	}

	if ( $old_user_data && is_a( $old_user_data, 'WP_User' ) ) {
		$um_mc_old_email = $old_user_data->user_email;
	}
	if ( is_admin() ) {
		um_mc_auto_sync_contact( $user_id, '', (string) $um_mc_old_email );
	}
}
add_action( 'profile_update', 'um_mc_profile_update', 10, 2 );


/**
 * Store old email to determine if email changed
 *
 * @hook   send_email_change_email
 * @since  2.2.10
 *
 * @global string $um_mc_old_email  E-mail
 * @param  bool   $send             Whether to send the email.
 * @param  array  $user             The original user array.
 * @param  array  $userdata         The updated user array.
 * @return bool
 */
function um_mc_profile_update_email_change( $send, $user, $userdata ) {
	global $um_mc_old_email;
	$um_mc_old_email = $user['user_email'];
	return $send;
}
add_filter( 'send_email_change_email', 'um_mc_profile_update_email_change', 20, 3 );


/**
 * Delete user from Mailchimp audiences on delete process
 *
 * @since   2.2.0
 * @version 2.2.4
 *
 * @staticvar array              $deleted_users
 * @param     int|string|WP_User $user
 * @param     string             $action
 * @return    boolean
 */
function um_mc_unsubscribe_user( $user, $action=null ) {
	static $deleted_users = array();

	if ( is_null( $action ) ) {
		$action = UM()->options()->get( 'mailchimp_on_delete' );
	}

	$user_id = UM()->Mailchimp()->api()->get_user_id( $user );
	if ( !empty( $deleted_users[ $user_id ] ) ) {
		return true;
	}

	$my_lists = UM()->Mailchimp()->api()->get_lists_my( $user_id );

	foreach ( $my_lists as $list_id => $subscribed ) {
		switch ( $action ) {
			case 'archive':
				$response = UM()->Mailchimp()->api()->mc_archive_member( $list_id, $user_id );
				break;

			case 'delete-permanent':
				$response = UM()->Mailchimp()->api()->mc_deletep_member( $list_id, $user_id );
				break;

			case 'unsubscribe':
				$response = UM()->Mailchimp()->api()->mc_unsubscribe_member( $list_id, $user_id );
				break;

			default:
				break;
		}
	}

	$deleted_users[ $user_id ] = true;
	return true;
}
add_action( 'delete_user', 'um_mc_unsubscribe_user' );
add_action( 'um_delete_user', 'um_mc_unsubscribe_user' );
add_action( 'um_mc_unsubscribe_user', 'um_mc_unsubscribe_user', 20, 2 );


/**
 * Add a user who was registered from the wp-admin area to audiences with option 'auto_register'
 *
 * @hook    user_register
 * @version 2.2.8
 *
 * @param   $user_id
 */
function um_mc_user_register( $user_id ) {

	if ( is_wp_error( $user_id ) || !is_admin() || defined( 'DOING_AJAX' ) ) {
		return;
	}

	// Don't unsubscribe user on registration
	remove_action( 'um_mc_unsubscribe_user', 'um_mc_unsubscribe_user', 20 );

	return um_mc_auto_sync_contact( $user_id );
}
add_action( 'user_register', 'um_mc_user_register' );