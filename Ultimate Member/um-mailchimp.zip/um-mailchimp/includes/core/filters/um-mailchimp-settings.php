<?php

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Add MailChimp core pages
 * @param  $pages
 * @return mixed
 */
function um_mc_core_pages( $pages ) {
	$pages['mc_unsubscribe'] = array(
		'title' => __( 'Newsletters unsubscribe', 'um-mailchimp' )
	);
	return $pages;
}
add_filter( 'um_core_pages', 'um_mc_core_pages' );


/**
 * Filter settings
 *
 * @param array $defaults
 * @return array
 */
function um_mc_default_settings( $defaults ) {
	$defaults = array_merge( $defaults, $this->setup()->settings_defaults );
	return $defaults;
}
add_filter( 'um_settings_default_values', 'um_mc_default_settings' );


/**
 * Default role settings
 * @since  2.2.4
 *
 * @param  array  $meta
 * @param  int    $user_id
 * @return array
 */
function um_mc_user_role_default_settings( $meta, $user_id ) {

	if ( !isset( $meta['can_manage_mc_groups'] ) ) {
		$meta['can_manage_mc_groups'] = 1;
	}
	if ( !isset( $meta['can_manage_mc_tags'] ) ) {
		$meta['can_manage_mc_tags'] = 1;
	}
	if ( !isset( $meta['can_create_mc_tags'] ) ) {
		$meta['can_create_mc_tags'] = 0;
	}

	return $meta;
}
add_filter( 'um_user_permissions_filter', 'um_mc_user_role_default_settings', 10, 2 );
