<?php
if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Visible fields on Registration page
 *
 * @param string $output
 * @param array $data
 * @return string
 */
function um_mc_edit_field_register( $output, $data ) {

	// audience
	$wp_list = get_post( $data['mailchimp_list'] );
	if ( !$wp_list || !$wp_list->_um_status ) {
		return $output;
	}

	// Don't show a field if assigned user role can't subscribe to the audience
	$form_id = (int) UM()->shortcodes()->form_id;
	$form_data = (array) UM()->query()->post_data( $form_id );
	$custom_fields = maybe_unserialize( $form_data['custom_fields'] );
	if ( !$custom_fields || !UM()->form()->custom_field_roles( $custom_fields ) ) {
		$assigned_role = UM()->form()->assigned_role( $form_id );
		if ( !$wp_list->_um_roles || !is_array( $wp_list->_um_roles ) || !in_array( $assigned_role, $wp_list->_um_roles ) ) {
			return $output . sprintf( '<!-- The role `%s` can not use connection `%s`. -->', $assigned_role, $wp_list->post_title );
		}
	}

	// classes
	if ( !isset( $data['classes'] ) ) {
		$data['classes'] = '';
	}

	// conditions
	$data['conditional'] = '';
	if ( isset( $data['conditions'] ) && is_array( $data['conditions'] ) ) {
		$data['classes'] .= ' um-is-conditional';

		foreach ( $data['conditions'] as $cond_id => $cond ) {
			$data['conditional'] .= ' data-cond-' . $cond_id . '-action="' . $cond[0] . '" data-cond-' . $cond_id . '-field="' . $cond[1] . '" data-cond-' . $cond_id . '-operator="' . $cond[2] . '" data-cond-' . $cond_id . '-value="' . $cond[3] . '"';
		}
	}

	$output .= '<div class="um-field um-field-mailchimp ' . $data['classes'] . '" ' . $data['conditional'] . ' data-key="' . $data['metakey'] . '">';
	$output .= um_mc_field( $data );
	$output .= '</div>';

	return $output;
}
add_filter( 'um_edit_field_register_mailchimp', 'um_mc_edit_field_register', 10, 2 );

/**
 * Default last_login value
 *
 * @param string $value
 * @return string
 */
function um_mc_last_login__filter( $value ) {

	if ( !$value ) {
		$value = um_user( 'user_registered' );
	}
	return $value;
}
add_filter( 'um_profile_last_login_empty__filter', 'um_mc_last_login__filter', 999, 1 );

/**
 * Register field type
 *
 * @do not require a metakey on mailchimp field
 *
 * @param array $array
 * @return array
 */
function um_mc_requires_no_metakey( $array ) {
	$array[] = 'mailchimp';
	return $array;
}
add_filter( 'um_fields_without_metakey', 'um_mc_requires_no_metakey' );


/**
 * Prepare data used in the modal window "Review Registration Details" and email placeholder {submitted_registration}
 *
 * @since     2.2.5        2020-07-26
 *
 * @staticvar boolean      $first_call
 * @param     array|string $submitted
 * @return    array|string
 */
function um_mc_submitted_registration( $submitted ) {
	static $first_call = true;

	$submitted_data = maybe_unserialize( $submitted );

	if ( $first_call && isset( $submitted_data['form_id'] ) ) {

		$user_id = UM()->user()->id;
		$user_mailchimp = get_user_meta( $user_id, 'um-mailchimp', true );
		$mylists = get_user_meta( $user_id, '_mylists', true );

		$fields = UM()->query()->get_attr( 'custom_fields', $submitted_data['form_id'] );
		foreach ( $fields as $key => $field ) {
			if ( isset( $field['mailchimp_list'] ) && $field['type'] === 'mailchimp' ) {

				$wp_list_id = (int) $field['mailchimp_list'];
				$wp_list = get_post( $wp_list_id );
				$list_id = $wp_list->_um_list;

				$value = __( 'No', 'um-mailchimp' );
				if ( $user_mailchimp && isset( $user_mailchimp[$wp_list_id] ) && !empty( $user_mailchimp[$wp_list_id]['enabled'] ) ) {
					$value = __( 'Yes', 'um-mailchimp' );
				} elseif ( $mylists && !empty( $mylists[$list_id] ) ) {
					$value = __( 'Yes', 'um-mailchimp' );
				}

				UM()->user()->profile[$field['metakey']] = $value;
			}
		}
		remove_filter( 'um_fields_without_metakey', 'um_mc_requires_no_metakey' );
		$first_call = false;
	}

	return $submitted;
}
add_filter( "um_profile_submitted__filter", 'um_mc_submitted_registration' );
