<?php
namespace um_ext\um_mailchimp\core;


if ( ! defined( 'ABSPATH' ) ) exit;


/**
 * Class for MailChimp API requests logging
 *
 * @example UM()->classes['um_mailchimp_log']
 * @example UM()->Mailchimp()->log()
 */
class Log {

	/**
	 * A file system pointer
	 * @var resource
	 */
	private $file;

	/**
	 * Path to file
	 * @var string
	 */
	private $file_path;

	/**
	 * Max size of the log file
	 * @var int
	 */
	private $max_filesize = 4 * 1024 * 1024;


	/**
	 * Class constructor
	 */
	public function __construct() {
		$this->file_path = UM()->files()->upload_basedir . 'mailchimp.log';
		$this->archive();
		$this->file = fopen( $this->file_path, 'ab+' );
	}


	/**
	 * Format error as HTML text
	 *
	 * @since   2.2.6
	 * @version 2.2.7
	 *
	 * @param   array|string $error
	 * @return  string
	 */
	public function error_html( $error ) {
		if ( is_string( $error ) ) {
			return trim( $error );
		}

		$error_text = '';
		if ( !empty( $error['title'] ) ) {
			$error_text .= '<strong>' . $error['title'] . '</strong> ';
		}
		if ( !empty( $error['title'] ) && !empty( $error['detail'] ) ) {
			$error_text .= ' - ';
		}
		if ( !empty( $error['detail'] ) ) {
			$error_text .= $error['detail'] . ' ';
		}
		if ( !empty( $error['errors'] ) && is_array( $error['errors'] ) ) {
			$error_text .= '<br><strong>' . __( 'Errors', 'um-mailchimp' ) . ':</strong> ';
			foreach ( $error['errors'] as $error ) {
				if ( isset( $error['field'] ) && isset( $error['message'] ) ) {
					$error_text .= sprintf( "<br>'%s' - %s,", $error['field'], $error['message'] );
				}
			}
		}
		return trim( $error_text, ' ,;' );
	}


	/**
	 * Get log content
	 *
	 * @return string
	 */
	public function get() {
		$size = filesize( $this->file_path );
		$content = $size ? fread( $this->file, $size ) : '';
		return $content;
	}


	/**
	 * Get log content as HTML
	 *
	 * @return string
	 */
	public function get_html() {

		if( !file_exists( $this->file_path ) ) {
			return _e( 'No file "mailchimp.log".', 'um-mailchimp' );
		}

		$log_arr = file( $this->file_path );
		foreach( $log_arr as $key => $value ) {
			if( substr_count( $value, '-> ERROR' ) || substr_count( $value, '-> error' ) ) {
				$log_arr[ $key ] = '<span style="color:darkred;">' . $log_arr[ $key ] . '</span>';
			}
			if( substr_count( $value, '-> SUCCESS' ) || substr_count( $value, '-> success' ) ) {
				$log_arr[ $key ] = '<span style="color:darkgreen;">' . $log_arr[ $key ] . '</span>';
			}
			if( substr_count( $value, '-> WARNING' ) || substr_count( $value, '-> warning' ) ) {
				$log_arr[ $key ] = '<span style="color:darkgoldenrod;">' . $log_arr[ $key ] . '</span>';
			}
		}

		$content = implode( '</br>', $log_arr );

		return $content;
	}


	/**
	 * Add new record to the log
	 *
	 * @param array $data
	 */
	public function add( $data ) {
		$this->update_user_log( $data );

		$status = 'ERROR';
		if ( isset( $data['status'] ) && $data['status'] ) {
			$status = 'SUCCESS';
		} elseif ( isset( $data['response'] ) && isset( $data['response']['title'] ) && 'Resource Not Found' === $data['response']['title'] ) {
			$status = 'WARNING';
		}

		$content = date( 'Y-m-d H:i:s' ) . ' -> ' . $status;

		if ( isset( $data['response'] ) ) {
			if ( isset( $data['response']['detail'] ) ) {
				$content .= ':&nbsp' . $data['response']['detail'];
			} elseif ( isset( $data['response']['title'] ) ) {
				$content .= ':&nbsp' . $data['response']['title'];
			}
		}

		if( !empty( $data[ 'method' ] ) ) {
			$content .= PHP_EOL;
			$content .= ' [' . strtoupper( $data[ 'method' ] ) . ']';
		}

		if( !empty( $data[ 'url' ] ) ) {
			$content .= ' ' . $data[ 'url' ];
		}

		if( !empty( $data[ 'args' ] ) ) {
			$content .= PHP_EOL;
			$content .= 'ARGS: ' . json_encode( $data[ 'args' ], JSON_UNESCAPED_SLASHES );
		}

		/**
		 * @see option "Log all responses"
		 */
		if( 'ERROR' === $status || UM()->options()->get( 'mailchimp_enable_log_response' ) ) {
			if( isset( $data[ 'response' ] ) ) {
				$content .= PHP_EOL;
				$content .= 'RESPONSE: ' . json_encode( $this->remove_links( $data[ 'response' ], JSON_UNESCAPED_SLASHES ) );
			}
			if( ! empty( $data[ 'trace' ] ) ) {
				$content .= PHP_EOL;
				$content .= 'TRACE: ' . $data[ 'trace' ];
			}
		}

		if ( 'WARNING' !== $status && isset( $_SERVER['HTTP_REFERER'] ) ) {
			$content .= PHP_EOL;
			$content .= 'REFERER: ' . $_SERVER['HTTP_REFERER'];
		}

		$content .= PHP_EOL . PHP_EOL;

		fwrite( $this->file, $content );
	}


	/**
	 * Archive log if it is too big
	 */
	public function archive() {
		if ( is_file( $this->file_path ) && filesize( $this->file_path ) > $this->max_filesize ) {
			$dir = dirname( $this->file_path );
			$datetime = date( 'Y-m-d H-i' );
			if ( is_writable( $dir ) && @copy( $this->file_path, "$dir/mailchimp $datetime.log" ) ) {
				$this->clear();
			}
		}
	}


	/**
	 * Clear log file
	 */
	public function clear() {
		if( file_exists( $this->file_path ) ) {
			file_put_contents( $this->file_path, '' );
		}
	}


	/**
	 * Recursive remove links
	 *
	 * @param mixed $arr
	 * @return mixed
	 */
	public function remove_links( $arr ) {
		if( is_array( $arr ) ) {
			foreach( $arr as $k => $v ) {
				if( $k === '_links' ) {
					unset( $arr[ $k ] );
				} else {
					$arr[ $k ] = $this->remove_links( $v );
				}
			}
		}

		return $arr;
	}


	/**
	 * Add new record to the user log
	 *
	 * @since  2.3.1
	 *
	 * @param  array $data  A MailChimp API response
	 */
	public function update_user_log( $data ) {
		$user_id = UM()->Mailchimp()->api()->user_id;
		if ( empty( $user_id ) || 'get' === $data['method'] ) {
			return;
		}

		$log_meta = get_user_meta( $user_id, 'um_mc_log', true );
		if ( empty( $log_meta ) || ! is_array( $log_meta ) ) {
			$log_meta = array();
		}

		$content = date( 'Y-m-d H:i:s' );
		if ( empty( $data['status'] ) ) {
			$content .= ' -> ERROR';
			if ( isset( $data['response'] ) && isset( $data['response']['detail'] ) ) {
				$content .= ':&nbsp' . $data['response']['detail'];
			}
		} else {
			$content .= ' -> SUCCESS';
		}
		$content .= ', [' . strtoupper( $data['method'] ) . ']&nbsp' . $data['url'];
		if ( ! empty( $data['args'] ) ) {
			$content .= ', ARGS:&nbsp' . json_encode( $data['args'], JSON_UNESCAPED_SLASHES );
		}
		if ( isset( $data['response'] ) && ! empty( $data['response']['errors'] ) ) {
			$content .= ', ERRORS:&nbsp' . json_encode( $data['response']['errors'], JSON_UNESCAPED_SLASHES );
		}
		if ( isset( $_SERVER['HTTP_REFERER'] ) ) {
			$content .= ', REFERER:&nbsp' . $_SERVER['HTTP_REFERER'];
		}

		array_unshift( $log_meta, $content );
		$log_meta_ = array_slice( $log_meta, 0, 20 );

		update_user_meta( $user_id, 'um_mc_log', $log_meta_ );
	}

}