<?php

namespace um_ext\um_mailchimp\admin\core;

if ( !defined( 'ABSPATH' ) ) exit;

/**
 * Class for admin side functionality
 *
 * @example UM()->classes['um_mailchimp_dashboard']
 * @example UM()->Mailchimp()->admin()->dashboard()
 */
class Dashboard {

	/**
	 * The count of queries in the batch request
	 */
	const batch_limit = 150;

	/**
	 * The count of contacts updated in the one iteration of the tool Sync Profiles (with details)
	 */
	const sync_count = 4;

	/**
	 * The current connection object
	 * @var WP_Post
	 */
	private $wp_list = null;

	/**
	 * Class constructor
	 */
	public function __construct() {

		add_action( 'admin_menu', [ $this, 'prepare_metabox' ], 20 );

		add_action( 'wp_ajax_um_mailchimp_bulk_subscribe', [ $this, 'ajax_bulk_action' ] );
		add_action( 'wp_ajax_um_mailchimp_bulk_unsubscribe', [ $this, 'ajax_bulk_action' ] );
		add_action( 'wp_ajax_um_mailchimp_scan_now', [ $this, 'ajax_scan_now' ] );
		add_action( 'wp_ajax_um_mailchimp_sync_members', [ $this, 'ajax_sync_members' ] );
		add_action( 'wp_ajax_um_mailchimp_sync_now', [ $this, 'ajax_sync_now' ] );
	}

	/**
	 * Bulk Subscribe & Unubscribe
	 *
	 * @since 2.2.0
	 * @version 2.2.9
	 */
	public function ajax_bulk_action() {
		UM()->admin()->check_ajax_nonce();

		if ( empty( $_POST['action'] ) ) {
			wp_send_json_error( __( 'Empty action in line ', 'um-mailchimp' ) . __LINE__ );
		}
		$action = sanitize_text_field( $_POST['action'] );

		if ( empty( $_POST['key'] ) ) {
			wp_send_json_error( __( 'Empty key in line ', 'um-mailchimp' ) . __LINE__ );
		}
		$action_key = sanitize_text_field( $_POST['key'] );

		if ( empty( $_POST['list_id'] ) ) {
			wp_send_json_error( __( 'Empty connection ID in line ', 'um-mailchimp' ) . __LINE__ );
		} elseif ( is_numeric( $_POST['list_id'] ) ) {
			$this->wp_list = get_post( $_POST['list_id'] );
		} else {
			$this->wp_list = UM()->Mailchimp()->api()->get_wp_list( $_POST['list_id'] );
		}

		if ( empty( $this->wp_list ) ) {
			$message = __( 'Wrong connection in line ', 'um-mailchimp' ) . __LINE__;
			$message .= __( '<br>Please verify the connection settings.', 'um-mailchimp' );
			wp_send_json_error( $message );
		}
		$list_id = $this->wp_list->_um_list;

		if ( empty( $_POST['offset'] ) ) {
			$offset = 0;
		} else {
			$offset = absint( $_POST['offset'] );
		}

		if ( empty( $_POST['length'] ) ) {
			$length = self::batch_limit;
		} else {
			$length = absint( $_POST['length'] );
		}

		$role = sanitize_text_field( $_POST['role'] );
		$status = sanitize_text_field( $_POST['status'] );

		$users_all = $this->get_users( $action_key, $role, $status );
		if ( empty( $users_all ) ) {
			wp_send_json_error( __( 'You don\'t have users that match criteria.', 'um-mailchimp' ) );
		} else {
			$total = count( $users_all );
		}

		$users = array_slice( $users_all, $offset, $length );
		$subtotal = count( $users );

		switch ( $action ) {
			case 'um_mailchimp_bulk_subscribe':
				$batch = $this->bulk_subscribe_process( $list_id, $users, 'subscribed', $action_key, $offset );
				break;
			case 'um_mailchimp_bulk_unsubscribe':
				$batch = $this->bulk_unsubscribe_process( $list_id, $users, 'unsubscribed', $action_key, $offset );
				break;
			default :
				wp_send_json_error( __( 'Unknown action', 'um-mailchimp' ) );
		}

		if ( is_wp_error( $batch ) ) {
			wp_send_json_error( $batch->get_error_message() );
		}

		if ( $subtotal < $length ) {
			$message = __( 'Completed', 'um-mailchimp' );
			UM()->Mailchimp()->api()->delete_temp_files( 1, $action_key );
		} else {
			$message = sprintf( __( 'Processed... %s', 'um-mailchimp' ), round( ($offset + $subtotal) / $total * 100 ) ) . '%';
		}

		$response = [
			'batch'		 => $batch,
			'key'			 => $action_key,
			'list_id'	 => $list_id,
			'message'	 => $message,
			'length'	 => (int) $length,
			'offset'	 => (int) $offset,
			'subtotal' => (int) $subtotal,
			'total'		 => (int) $total
		];

		wp_send_json_success( $response );
	}

	/**
	 * Find mached users
	 *
	 * @version 2.2.9
	 */
	public function ajax_scan_now() {
		UM()->admin()->check_ajax_nonce();

		$action_key = empty( $_POST['key'] ) ? uniqid() : sanitize_text_field( $_POST['key'] );
		$role = sanitize_text_field( $_POST['role'] );
		$status = sanitize_text_field( $_POST['status'] );

		$users = $this->get_users( $action_key, $role, $status );
		$total = count( $users );

		// display the results
		wp_send_json_success( [
			'key'			 => $action_key,
			'message'	 => sprintf( _n( '%d user was selected', '%d users were selected', $total, 'um-mailchimp' ), $total ),
			'total'		 => $total
		] );
	}

	/**
	 * Update audience contacts
	 *
	 * @version 2.2.9
	 */
	public function ajax_sync_members() {
		UM()->admin()->check_ajax_nonce();

		$action_key = empty( $_POST['key'] ) ? uniqid() : sanitize_text_field( $_POST['key'] );

		$state = get_transient( "um_mc:dashboard_sync_state:$action_key" );
		if ( empty( $state ) ) {

			if ( empty( $_POST['list_id'] ) ) {
				wp_send_json_error( __( 'Empty audience ID in line ', 'um-mailchimp' ) . __LINE__ );
			} elseif ( is_numeric( $_POST['list_id'] ) ) {
				$this->wp_list = get_post( $_POST['list_id'] );
			} else {
				$this->wp_list = UM()->Mailchimp()->api()->get_wp_list( $_POST['list_id'] );
			}

			$state = [
				'key'				 => $action_key,
				'list_id'		 => $this->wp_list->_um_list,
				'wp_list_id' => $this->wp_list->ID,
				'count'			 => self::sync_count,
				'offset'		 => 0,
				'subtotal'	 => 0,
				'total'			 => 0
			];
		} elseif ( isset( $state['wp_list_id'] ) ) {
			$this->wp_list = get_post( $state['wp_list_id'] );
		}

		if ( empty( $this->wp_list ) ) {
			$message = __( 'Wrong audience in line ', 'um-mailchimp' ) . __LINE__;
			$message .= __( '<br>Please verify the audience settings.', 'um-mailchimp' );
			wp_send_json_error( $message );
		}
		$list_id = $this->wp_list->_um_list;

		// get contacts from the audience
		$request = "lists/{$list_id}/members";
		$request_data = [
			'count'			 => $state['count'],
			'offset'		 => $state['offset'],
			'sort_field' => 'timestamp_signup',
			'sort_dir'	 => 'ASC'
		];
		$list = UM()->Mailchimp()->api()->call()->get( $request, $request_data );

		$batchlog = [];
		if ( isset( $list['members'] ) && is_array( $list['members'] ) ) {
			$state['subtotal'] = count( $list['members'] );
			$state['total'] = $list['total_items'];

			$data = [
				'wp_list'		 => $this->wp_list,
				'wp_list_id' => $this->wp_list->ID
			];

			foreach ( $list['members'] as $member ) {
				if ( ++$state['offset'] > $state['total'] ) {
					break;
				}

				$hash = md5( strtolower( $member['email_address'] ) );
				$user_id = UM()->Mailchimp()->api()->get_user_id( $member['email_address'] );

				if ( $user_id ) {

					// skip by user role
					um_fetch_user( $user_id );
					if ( $this->wp_list->_um_roles && is_array( $this->wp_list->_um_roles ) && empty( array_intersect( um_user( 'roles' ), $this->wp_list->_um_roles ) ) ) {
						$batchlog[$hash] = [
							'email_address'	 => $member['email_address'],
							'status'				 => __( 'Skip.', 'um-mailchimp' ),
							'error'					 => __( 'Syncing for this user role is not allowed. See the connection setting `Who can subscribe to this audience`.', 'um-mailchimp' )
						];
						continue;
					}

					// update
					$m = UM()->Mailchimp()->api()->mc_update_member( $list_id, $user_id, $data );

					if ( $m ) {
						$batchlog[$hash] = [
							'email_address'	 => $member['email_address'],
							'status'				 => $m['status']
						];
					} else {
						$error = UM()->Mailchimp()->api()->get_last_error();
						$error_text = UM()->Mailchimp()->log()->error_html( $error );
						$batchlog[$hash] = [
							'email_address'	 => $member['email_address'],
							'status'				 => __( 'Sync error.', 'um-mailchimp' ),
							'error'					 => strip_tags( $error_text )
						];
					}
				} else {
					$batchlog[$hash] = [
						'email_address'	 => $member['email_address'],
						'status'				 => __( 'Not found.', 'um-mailchimp' ),
						'error'					 => __( 'This contact does not exist on the site.', 'um-mailchimp' )
					];
				}
			}
		} else {
			wp_send_json_error( __( 'You don\'t have any users', 'um-mailchimp' ) );
		}

		// update state
		if ( $state['offset'] >= $state['total'] ) {
			$message = __( 'Completed', 'um-mailchimp' );
			delete_transient( "um_mc:dashboard_sync_state:$action_key" );
		} else {
			$message = sprintf( __( 'Processed... %d%% (%d/%d)', 'um-mailchimp' ), round( $state['offset'] / $state['total'] * 100 ), $state['offset'], $state['total'] );
			set_transient( "um_mc:dashboard_sync_state:$action_key", $state, 600 );
		}

		$response = [
			'batchlog' => (array) $batchlog,
			'key'			 => (string) $state['key'],
			'length'	 => (int) $state['count'],
			'list_id'	 => (string) $state['list_id'],
			'message'	 => (string) $message,
			'offset'	 => (int) $state['offset'],
			'total'		 => (int) $state['total']
		];

		wp_send_json_success( $response );
	}

	/**
	 * Sync Profiles
	 *
	 * @version 2.2.9
	 */
	public function ajax_sync_now() {
		UM()->admin()->check_ajax_nonce();

		$action_key = empty( $_POST['key'] ) ? uniqid() : sanitize_text_field( $_POST['key'] );

		if ( empty( $_POST['list_id'] ) ) {
			wp_send_json_error( __( 'Empty connection ID in line ', 'um-mailchimp' ) . __LINE__ );
		} elseif ( is_numeric( $_POST['list_id'] ) ) {
			$this->wp_list = get_post( $_POST['list_id'] );
		} else {
			$this->wp_list = UM()->Mailchimp()->api()->get_wp_list( $_POST['list_id'] );
		}

		if ( empty( $this->wp_list ) ) {
			$message = __( 'Wrong connection in line ', 'um-mailchimp' ) . __LINE__;
			$message .= __( '<br>Please verify the connection settings.', 'um-mailchimp' );
			wp_send_json_error( $message );
		}
		$list_id = $this->wp_list->_um_list;

		if ( empty( $_POST['offset'] ) ) {
			$offset = 0;
		} else {
			$offset = absint( $_POST['offset'] );
		}

		if ( empty( $_POST['length'] ) ) {
			$length = self::batch_limit;
		} else {
			$length = absint( $_POST['length'] );
		}


		if ( function_exists( 'set_time_limit' ) && false === strpos( ini_get( 'disable_functions' ), 'set_time_limit' ) && !ini_get( 'safe_mode' ) ) { // phpcs:ignore PHPCompatibility.PHP.DeprecatedIniDirectives.safe_modeDeprecatedRemoved
			@set_time_limit( 0 ); // @codingStandardsIgnoreLine
		}


		$users_all = $this->get_users( $action_key );
		if ( empty( $users_all ) ) {
			wp_send_json_error( __( 'You don\'t have any users', 'um-mailchimp' ) );
		} else {
			$total = count( $users_all );
		}

		$users = array_slice( $users_all, $offset, $length );
		$subtotal = count( $users );

		$mc_emails = $this->get_users_external( $action_key, $list_id, true );

		/* >> prepare $data */
		$groups = UM()->Mailchimp()->api()->prepare_groups( $list_id, $this->wp_list );
		$tags = UM()->Mailchimp()->api()->prepare_tags( $list_id, $this->wp_list->_um_reg_tags );

		$data = [
			'wp_list'		 => $this->wp_list,
			'wp_list_id' => $this->wp_list->ID
		];

		$data_create = [
			'status'		 => 'subscribed',
			'groups'		 => $groups,
			'tags'			 => $this->wp_list->_um_reg_tags,
			'wp_list'		 => $this->wp_list,
			'wp_list_id' => $this->wp_list->ID
		];
		/* << prepare $data */

		$Batch = UM()->Mailchimp()->api()->call()->new_batch();

		foreach ( $users as $user ) {

			// skip by user role
			um_fetch_user( $user->ID );
			if ( $this->wp_list->_um_roles && is_array( $this->wp_list->_um_roles ) && empty( array_intersect( um_user( 'roles' ), $this->wp_list->_um_roles ) ) ) {
				$offset++;
				continue;
			}

			$email_md5 = md5( strtolower( $user->user_email ) );

			$user_lists = get_user_meta( $user->ID, '_mylists', true );
			if ( !is_array( $user_lists ) ) {
				$user_lists = [];
			}

			if ( in_array( $user->user_email, $mc_emails ) && empty( $user_lists[$list_id] ) ) {
				//user only in the audience. Update usermeta.
				UM()->Mailchimp()->api()->update_mylists( $list_id, $user->ID, $this->wp_list->ID );
			} elseif ( !in_array( $user->user_email, $mc_emails ) && !empty( $user_lists[$list_id] ) ) {
				//user only in the site. Add to the audience.
				$request_data = apply_filters( 'um_mailchimp_api_create_member', [
					'email_address'	 => $user->user_email,
					'status'				 => 'subscribed'
					], $list_id, $user->ID, $data );

				$Batch->post( "op_uid:{$user->ID}_list:{$list_id}_key:{$action_key}_o:{$offset}", "lists/{$list_id}/members", $data_create );

				//update tags
				if ( !empty( $tags ) ) {
					$Batch->post( "op_tags_uid:{$user->ID}_list:{$list_id}_key:{$action_key}_o:{$offset}", "lists/{$list_id}/members/{$email_md5}/tags", [ 'tags' => $tags ] );
				}
			} elseif ( in_array( $user->user_email, $mc_emails ) && !empty( $user_lists[$list_id] ) ) {
				//user exists in the audience and in the site. Update contact.
				$request_data = apply_filters( 'um_mailchimp_api_update_member', [
					'email_address'	 => $user->user_email,
					'status'				 => 'subscribed'
					], $list_id, $user->ID, $data );

				$Batch->put( "op_uid:{$user->ID}_list:{$list_id}_key:{$action_key}_o:{$offset}", "lists/{$list_id}/members/{$email_md5}", $request_data );
			}

			$offset++;
		}

		$batch = $Batch->execute();
		if ( is_wp_error( $batch ) ) {
			wp_send_json_error( $batch->get_error_message() );
		}

		if ( $subtotal < $length ) {
			$message = __( 'Completed', 'um-mailchimp' );
			UM()->Mailchimp()->api()->delete_temp_files( 1, $action_key );
		} else {
			$message = sprintf( __( 'Processed... %s%%', 'um-mailchimp' ), round( $offset / $total * 100 ) );
		}

		$response = [
			'batch'		 => $batch,
			'key'			 => $action_key,
			'list_id'	 => $list_id,
			'message'	 => $message,
			'length'	 => (int) $length,
			'offset'	 => (int) $offset,
			'subtotal' => (int) $subtotal,
			'total'		 => (int) $total
		];

		wp_send_json_success( $response );
	}

	/**
	 * "Bulk Subscribe & Unubscribe" tool handler - subscribe
	 *
	 * @param string $list_id
	 * @param array $users
	 * @param string $status
	 * @param string $action_key
	 * @return array|\WP_Error
	 */
	public function bulk_subscribe_process( $list_id, $users, $status = 'subscribed', $action_key = '', $offset = 0 ) {

		if ( empty( $this->wp_list ) ) {
			$this->wp_list = UM()->Mailchimp()->api()->get_wp_list( $list_id );
		}
		if ( empty( $this->wp_list ) ) {
			$message = __( 'Wrong audience in line ', 'um-mailchimp' ) . __LINE__;
			$message .= __( '<br>Please verify the audience settings.', 'um-mailchimp' );
			return new \WP_Error( 'um_mailchimp_wrong_list', $message );
		}

		if ( empty( $users ) ) {
			return new \WP_Error( 'um_mailchimp_wrong_users', __( 'Wrong users in line ', 'um-mailchimp' ) . __LINE__ );
		}

		if ( function_exists( 'set_time_limit' ) && false === strpos( ini_get( 'disable_functions' ), 'set_time_limit' ) && !ini_get( 'safe_mode' ) ) { // phpcs:ignore PHPCompatibility.PHP.DeprecatedIniDirectives.safe_modeDeprecatedRemoved
			@set_time_limit( 0 ); // @codingStandardsIgnoreLine
		}

		/* >> prepare $data */
		$data = [
			'wp_list'		 => $this->wp_list,
			'wp_list_id' => $this->wp_list->ID
		];
		if ( $this->wp_list->_um_reg_status ) {
			$groups = UM()->Mailchimp()->api()->prepare_groups( $list_id, $this->wp_list );
			$tags = UM()->Mailchimp()->api()->prepare_tags( $list_id, $this->wp_list->_um_reg_tags );
			$data = [
				'status'	 => 'subscribed',
				'groups'	 => $groups,
				'tags'		 => $this->wp_list->_um_reg_tags,
				'wp_list'	 => $this->wp_list
			];
		}
		/* << prepare $data */

		$Batch = UM()->Mailchimp()->api()->call()->new_batch();

		foreach ( $users as $user ) {
			$email_md5 = md5( $user->user_email );

			$request_data = apply_filters( 'um_mailchimp_api_update_member', [
				'email_address'	 => $user->user_email,
				'status'				 => $status
				], $list_id, $user->ID, $data );

			$Batch->put( "op_uid:{$user->ID}_list:{$list_id}_key:{$action_key}_o:{$offset}", "lists/{$list_id}/members/{$email_md5}", $request_data );

			//update tags
			if ( !empty( $tags ) ) {
				$Batch->post( "op_tags_uid:{$user->ID}_list:{$list_id}_key:{$action_key}_o:{$offset}", "lists/{$list_id}/members/{$email_md5}/tags", [ 'tags' => $tags ] );
			}

			UM()->Mailchimp()->api()->update_mylists( $list_id, $user->ID, $this->wp_list->ID );
		}

		$batch = $Batch->execute();

		return $batch;
	}

	/**
	 * "Bulk Subscribe & Unubscribe" tool handler - unsubscribe
	 *
	 * @param string $list_id
	 * @param array $users
	 * @param string $status
	 * @param string $action_key
	 * @return array|\WP_Error
	 */
	public function bulk_unsubscribe_process( $list_id, $users, $status = 'unsubscribed', $action_key = '', $offset = 0 ) {

		if ( empty( $this->wp_list ) ) {
			$this->wp_list = UM()->Mailchimp()->api()->get_wp_list( $list_id );
		}
		if ( empty( $this->wp_list ) ) {
			$message = __( 'Wrong audience in line ', 'um-mailchimp' ) . __LINE__;
			$message .= __( '<br>Please verify the audience settings.', 'um-mailchimp' );
			return new \WP_Error( 'um_mailchimp_wrong_list', $message );
		}

		if ( empty( $users ) ) {
			return new \WP_Error( 'um_mailchimp_wrong_users', __( 'Wrong users in line ', 'um-mailchimp' ) . __LINE__ );
		}

		if ( function_exists( 'set_time_limit' ) && false === strpos( ini_get( 'disable_functions' ), 'set_time_limit' ) && !ini_get( 'safe_mode' ) ) { // phpcs:ignore PHPCompatibility.PHP.DeprecatedIniDirectives.safe_modeDeprecatedRemoved
			@set_time_limit( 0 ); // @codingStandardsIgnoreLine
		}

		$Batch = UM()->Mailchimp()->api()->call()->new_batch();

		foreach ( $users as $user ) {
			$email_md5 = md5( $user->user_email );

			$Batch->patch( "op_rem_uid:{$user->ID}_list:{$list_id}_key:{$action_key}_o:{$offset}", "lists/{$list_id}/members/{$email_md5}", [
				'email_address'	 => $user->user_email,
				'status'				 => $status,
			] );

			UM()->Mailchimp()->api()->update_mylists( $list_id, $user->ID, 'remove' );
		}

		$batch = $Batch->execute();

		return $batch;
	}

	/**
	 * Get an array of the subscribed members emails from the audience
	 *
	 * @param string $action_key
	 * @param string $list_id
	 * @param boolean $cache
	 * @return array
	 */
	public function get_users_external( $action_key, $list_id, $cache = true ) {

		//get users list from cache
		$file = UM()->files()->upload_basedir . 'temp/_um_mailchimp_users_external_' . $action_key . '_' . $list_id . '.txt';
		if ( $cache && file_exists( $file ) ) {
			$mc_emails = array_map( 'trim', file( $file ) );
		}

		if ( empty( $mc_emails ) || !is_array( $mc_emails ) ) {
			$mc_emails = [];

			$members = UM()->Mailchimp()->api()->mc_get_members( $list_id );
			if ( is_array( $members ) ) {
				foreach ( $members as $member ) {
					if ( $member['status'] === 'subscribed' ) {
						$mc_emails[] = $member['email_address'];
					}
				}
			}

			//set users list cache
			if ( $cache ) {
				file_put_contents( $file, implode( PHP_EOL, $mc_emails ) );
			}
		}

		return $mc_emails;
	}

	/**
	 * Get users for action
	 *
	 * @param string $action_key
	 * @param string $role
	 * @param string $status
	 * @return array
	 */
	public function get_users( $action_key, $role = '', $status = '' ) {

		//get users list from cache
		$file = UM()->files()->upload_basedir . 'temp/_um_mailchimp_users_' . $action_key . '_' . $role . '_' . $status . '.txt';
		if ( file_exists( $file ) ) {
			$users_json = file( $file );
			$users = array_map( 'json_decode', $users_json );
		}

		if ( empty( $users ) || !is_array( $users ) ) {
			//get all users with selected role and status
			$args = [
				'fields' => [ 'user_email', 'ID' ]
			];

			if ( !empty( $role ) ) {
				$args['role'] = $role;
			}

			if ( !empty( $status ) ) {
				$args['meta_query'][] = [
					'key'			 => 'account_status',
					'value'		 => $status,
					'compare'	 => '=',
				];
			}

			$query_users = new \WP_User_Query( $args );
			$users = $query_users->get_results();

			//set users list cache
			file_put_contents( $file, implode( PHP_EOL, array_map( 'json_encode', $users ) ) );
		}

		return $users;
	}

	/**
	 * Load metabox MailChimp
	 */
	public function load_metabox() {
		add_meta_box(
			'um-metaboxes-mailchimp', __( 'MailChimp', 'um-mailchimp' ), [ &$this, 'metabox_content' ], UM()->Mailchimp()->admin()->pagehook, 'core', 'core'
		);
	}

	/**
	 * Render metabox MailChimp
	 */
	public function metabox_content() {
		$suffix = ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG || defined( 'UM_SCRIPT_DEBUG' ) ) ? '' : '.min';

		wp_enqueue_script( 'um-mailchimp-dashboard', um_mailchimp_url . 'assets/js/um-mailchimp-dashboard' . $suffix . '.js', [ 'jquery', 'wp-util', 'um_admin_global' ], um_mailchimp_version, true );

		wp_localize_script( 'um-mailchimp-dashboard', 'um_mailchimp_data', [
			'current_url'		 => UM()->permalinks()->get_current_url(),
			'internal_lists' => UM()->Mailchimp()->api()->get_wp_lists_array(),
			'role'					 => isset( $_SESSION['_um_mailchimp_selected_role'] ) ? $_SESSION['_um_mailchimp_selected_role'] : '',
			'roles'					 => UM()->roles()->get_roles(),
			'status'				 => isset( $_SESSION['_um_mailchimp_selected_status'] ) ? $_SESSION['_um_mailchimp_selected_status'] : '',
			'status_list'		 => [
				'approved'										 => __( 'Approved', 'um-mailchimp' ),
				'awaiting_admin_review'				 => __( 'Awaiting Admin Review', 'um-mailchimp' ),
				'awaiting_email_confirmation'	 => __( 'Awaiting Email Confirmation', 'um-mailchimp' ),
				'inactive'										 => __( 'Inactive', 'um-mailchimp' ),
				'rejected'										 => __( 'Rejected', 'um-mailchimp' ),
			],
			'labels'				 => [
				'sync_message'									 => __( 'Starting synchronization...', 'um-mailchimp' ),
				'scan_message'									 => __( 'Checking subscription status...', 'um-mailchimp' ),
				'start_bulk_subscribe_process'	 => __( 'Subscribe users... 0%', 'um-mailchimp' ),
				'start_bulk_unsubscribe_process' => __( 'Unsubscribe users... 0%', 'um-mailchimp' ),
				'sync_process'									 => __( 'Syncronization...', 'um-mailchimp' ),
				'processing'										 => __( 'Processing...', 'um-mailchimp' )
			]
		] );

		include_once um_mailchimp_path . 'includes/admin/templates/dashboard.php';
	}

	/**
	 * Add metabox MailChimp
	 */
	public function prepare_metabox() {
		add_action( 'load-' . UM()->Mailchimp()->admin()->pagehook, [ &$this, 'load_metabox' ] );
	}

}
