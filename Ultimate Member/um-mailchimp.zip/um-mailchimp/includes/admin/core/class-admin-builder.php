<?php

namespace um_ext\um_mailchimp\admin\core;

// Exit if accessed directly.
if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class for a form builder functionality
 *
 * @example UM()->classes['um_mailchimp_admin_builder']
 * @example UM()->Mailchimp()->admin()->builder()
 */
class Admin_Builder {

	/**
	 * Class constructor
	 */
	public function __construct() {
		add_action( 'um_admin_field_edit_hook_mailchimp_list', [ $this, 'um_admin_field_edit_hook_mailchimp_list' ] );
		add_action( 'um_admin_field_edit_hook_mailchimp_auto_subscribe', [ $this, 'um_admin_field_edit_hook_mailchimp_auto_subscribe' ] );
		add_action( 'um_admin_field_edit_hook_mailchimp_groups', [ $this, 'um_admin_field_edit_hook_mailchimp_groups' ] );
		add_action( 'um_admin_field_edit_hook_mailchimp_tags', [ $this, 'um_admin_field_edit_hook_mailchimp_tags' ] );

		add_filter( 'um_core_fields_hook', [ $this, 'um_mc_add_field' ] );
	}

	/**
	 * Add field type
	 *
	 * @extend core fields
	 *
	 * @param array $fields
	 * @return array
	 */
	public function um_mc_add_field( $fields ) {

		$fields['mailchimp'] = [
				'name' => __( 'MailChimp', 'um-mailchimp' ),
				'col1' => [ '_title', '_mailchimp_auto_subscribe', '_mailchimp_groups', '_mailchimp_tags' ],
				'col2' => [ '_label', '_mailchimp_list' ],
				'col3' => [],
				'validate' => [
						'_title' => [
								'mode' => 'required',
								'error' => __( 'You must provide a title', 'um-mailchimp' )
						]
				]
		];

		return $fields;
	}

	/**
	 * Field option "Select the connection"
	 *
	 * @param string $val
	 */
	public function um_admin_field_edit_hook_mailchimp_list( $val ) {

		$wp_lists = UM()->Mailchimp()->api()->get_wp_lists();
		if ( !$wp_lists ) {
			return;
		}
		?>

		<p>
		<label for="_mailchimp_list"><?php _e( 'Select the connection', 'um-mailchimp' ); ?> <?php UM()->tooltip( __( 'You can set up the connection to the audience in the menu Ultimate Member > MailChimp', 'um-mailchimp' ) ); ?></label>
		<select name="_mailchimp_list" id="_mailchimp_list" required style="width: 100%">

			<?php foreach ( $wp_lists as $wp_list ) { ?>
				<option value="<?php echo esc_attr( $wp_list->ID ); ?>" <?php selected( $wp_list->ID, $val ); ?>><?php echo $wp_list->post_title; ?></option>
			<?php } ?>

		</select>
		</p>

		<?php
	}

	/**
	 * Field option "Checked by default"
	 *
	 * @param string $val
	 */
	public function um_admin_field_edit_hook_mailchimp_auto_subscribe( $val ) {
		?>
		<p>
		<label for="_mailchimp_auto_subscribe">
			<input type="checkbox" name="_mailchimp_auto_subscribe" id="_mailchimp_auto_subscribe" value="1" <?php checked( $val, '1' ) ?> />
			<?php
			_e( 'Checked by default', 'um-mailchimp' );
			UM()->tooltip( __( 'The user will be subscribed to the audience on form submit if the field is checked. The user can uncheck it manually in the form.', 'um-mailchimp' ) );
			?>
		</label>
		</p>
		<?php
	}

	/**
	 * Field option "Manage groups"
	 *
	 * @since 2.2.5
	 *
	 * @param string $val
	 */
	public function um_admin_field_edit_hook_mailchimp_groups( $val ) {
		?>
		<p>
		<label for="_mailchimp_groups">
			<input type="checkbox" name="_mailchimp_groups" id="_mailchimp_groups" value="1" <?php checked( $val, '1' ) ?> />
			<?php
			_e( 'Manage groups', 'um-mailchimp' );
			UM()->tooltip( __( 'The user can select groups in the form if this option is enabled.', 'um-mailchimp' ) );
			?>
		</label>
		</p>
		<?php
	}

	/**
	 * Field option "Manage tags"
	 *
	 * @since 2.2.5
	 *
	 * @param string $val
	 */
	public function um_admin_field_edit_hook_mailchimp_tags( $val ) {
		?>
		<p>
		<label for="_mailchimp_tags">
			<input type="checkbox" name="_mailchimp_tags" id="_mailchimp_tags" value="1" <?php checked( $val, '1' ) ?> />
			<?php
			_e( 'Manage tags', 'um-mailchimp' );
			UM()->tooltip( __( 'The user can select tags in the form if this option is enabled.', 'um-mailchimp' ) );
			?>
		</label>
		</p>
		<?php
	}

}
