<?php
if ( !defined( 'ABSPATH' ) ) {
	exit;
}

$mailchimp_allow_add_tags = UM()->options()->get( 'mailchimp_allow_add_tags' );
if ( !is_numeric( $mailchimp_allow_add_tags ) ) {
	return;
}

$um_roles = UM()->roles()->get_roles();
if ( empty( $um_roles ) || !is_array( $um_roles ) ) {
	return;
}

foreach ( $um_roles as $slug => $name ) {
	$roledata = UM()->roles()->role_data( $slug );
	if ( empty( $roledata ) ) {
		continue;
	}
	$roledata['can_create_mc_tags'] = $mailchimp_allow_add_tags;
	update_option( "um_role_{$slug}_meta", $roledata );
}