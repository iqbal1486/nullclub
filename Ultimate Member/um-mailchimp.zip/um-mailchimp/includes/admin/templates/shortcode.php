<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>

<div class="um-admin-metabox">
	<p><strong>[ultimatemember_mailchimp_subscribe id="<?php the_ID(); ?>"]</strong></p>
	<p><?php _e( 'You may get more details about this shortcode', 'um-mailchimp' ); ?> <a href="https://docs.ultimatemember.com/article/1583-mailchimp-shortcodes#ultimatemember_mailchimp_subscribe" title="MailChimp shortcodes" target="_blank"><?php _e( 'here', 'um-mailchimp' ); ?></a></p>
</div>