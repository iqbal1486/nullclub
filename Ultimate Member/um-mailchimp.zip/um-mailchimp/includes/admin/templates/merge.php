<?php
/**
 * The content of the metabox 'Merge User Meta'
 */
if ( !defined( 'ABSPATH' ) ) exit;

/**
 * Get the $list_id
 */
if ( empty( $list_id ) && !empty( $post_id ) ) {
	$list_id = get_post_meta( $post_id, '_um_list', true );
}
if ( empty( $list_id ) ) {
	return __( 'Please select an audience', 'um-mailchimp' );
}


/**
 * Get fields relationships
 */
$merged = get_post_meta( $post_id, '_um_merge', true );


/**
 * Get Ultimate Member's fields and split them by types
 */
$options_array = array();
$options_date = array();
$options_string = array();

/* default fields */
$um_fields_def = UM()->builtin()->all_user_fields();
$um_fields = apply_filters( 'um_mailchimp_merge_fields', $um_fields_def, $list_id );

/* special fields-helpers */
$um_fields_special_def = array(
		'role_slug' => array( 'title' => __( 'Role slug', 'um-mailchimp' ) ),
		'role_title' => array( 'title' => __( 'Role title', 'um-mailchimp' ) )
);
$um_fields_special = apply_filters( 'um_mailchimp_merge_fields_special', $um_fields_special_def, $list_id );
if ( $um_fields_special ) {
	$um_fields = array_merge( $um_fields, $um_fields_special );
}

asort( $um_fields );
foreach ( $um_fields as $k => $var ) {
	if ( empty( $var['title'] ) ) {
		continue;
	}
	$o_title = $var['title'] . ' (' . $k . ')';

	$options_string[$k] = $o_title;

	switch ( $k ) {
		case 'gender':
		case 'role_radio':
		case 'role_select':
		case 'role_slug':
		case 'role_title':
			$options_array[$k] = $o_title;
			break;

		case 'user_registered':
			$options_date[$k] = $o_title;
			break;

		default:
			$options_string[$k] = $o_title;
			break;
	}

	$type = UM()->fields()->get_field_type( $k );
	switch ( $type ) {
		case 'radio':
		case 'select':
			$options_array[$k] = $o_title;
			break;

		case 'date':
		case 'time':
			$options_date[$k] = $o_title;
			break;

		default:
			$options_string[$k] = $o_title;
			break;
	}
}


/**
 * Get MailChimp's fields and prepare data to display
 */
$fields = array();

delete_transient( "um_mc_api:lists/{$list_id}/merge-fields" ); // clear cache

$mc_merge_fields = UM()->Mailchimp()->api()->mc_get_merge_fields( $list_id );
foreach ( $mc_merge_fields as $arr ) {

	$_label = $arr['name'];
	$_tooltip = __( 'Tag: ', 'um-mailchimp' ) . esc_html__( $arr['tag'] ) . '<br>'
			. __( 'Type: ', 'um-mailchimp' ) . esc_html__( $arr['type'] );
	$_options = array();
	$_value = isset( $merged[$arr['tag']] ) ? $merged[$arr['tag']] : '';
	$_description = '';

	// Options
	switch ( $arr['type'] ) {
		case 'dropdown':
		case 'radio':
			$_options = $options_array;
			if ( isset( $arr['options'] ) && isset( $arr['options']['choices'] ) && is_array( $arr['options']['choices'] ) ) {
				$choices = array_map( 'stripslashes', array_filter( (array) $arr['options']['choices'] ) );
				$_tooltip .= '<br>' . __( 'Choices: ', 'um-mailchimp' ) . implode( ', ', $choices );

				if ( $_value && empty( $um_fields_special[$_value] ) ) {
					$field_data = UM()->builtin()->get_a_field( $_value );
					$options = isset( $field_data['options'] ) ? array_map( 'stripslashes', array_filter( (array) $field_data['options'] ) ) : array();

					$diff = array_diff( $choices, $options );

					// show warning
					if ( $diff ) {
						$_description_tooltip = '<strong>' . __( 'Difference: ', 'um-mailchimp' ) . '</strong>' . implode( ', ', $diff )
								. '<br><br><strong>' . __( 'MC Choices: ', 'um-mailchimp' ) . '</strong>' . implode( ', ', $choices )
								. '<br><br><strong>' . __( 'UM Choices: ', 'um-mailchimp' ) . '</strong>' . implode( ', ', $options );
						$_description .= __( "Warning! Choices doesn't match", 'um-mailchimp' );
						$_description .= ' <span class="um_tooltip dashicons dashicons-editor-help" title="' . $_description_tooltip . '"></span>';
					}
				}
			}
			break;

		case 'birthday':
		case 'date':
			$_options = $options_date;
			break;

		default:
			$_options = $options_string;
			break;
	}

	// Required
	if ( empty( $arr['required'] ) ) {
		$_options = array_merge( array( '0' => __( '~Ignore this field~', 'um-mailchimp' ) ), $_options );
	} else {
		$_label .= ' <span class="um_tooltip dashicons dashicons-warning" title="' . __( 'This field is required', 'um-mailchimp' ) . '"></span>';
		if ( empty( $_value ) ) {
			$_description .= __( "Warning! This fiels is required", 'um-mailchimp' );
		}
	}

	// Fields
	switch ( $arr['type'] ) {
		case 'address':

			$fields[] = array(
					'id' => $arr['tag'],
					'type' => 'select',
					'size' => 'small',
					'label' => $_label,
					'tooltip' => $_tooltip,
					'options' => [
							'0' => __( 'Off', 'um-mailchimp' ),
							'1' => __( 'On', 'um-mailchimp' )
					],
					'value' => $_value,
					'class' => 'um_mc_address_field'
			);

			foreach ( UM()->Mailchimp()->api()->address_fields() as $afk => $aft ) {
				$_key = $arr['tag'] . '-' . $afk;
				$_value = isset( $merged[$_key] ) ? $merged[$_key] : '';
				$_label = $arr['name'] . ': ' . $aft . ($afk !== 'addr2' ? ' <span class="um_tooltip dashicons dashicons-warning" title="' . __( 'This field is required', 'um-mailchimp' ) . '"></span>' : '');
				$fields[] = array(
						'id' => $_key,
						'type' => 'select',
						'size' => 'long',
						'label' => $_label,
						'options' => apply_filters( 'um_mailchimp_merge_field_options', $_options, $arr, $list_id ),
						'value' => $_value,
						'class' => 'um_mc_address_field_item'
				);
			}
			break;

		default:
			$fields[] = array(
					'id' => $arr['tag'],
					'type' => 'select',
					'size' => 'long',
					'label' => $_label,
					'tooltip' => $_tooltip,
					'options' => apply_filters( 'um_mailchimp_merge_field_options', $_options, $arr, $list_id ),
					'value' => $_value,
					'description' => $_description,
			);
			break;
	}
}
?>

<div class="um-admin-metabox">

	<?php
	UM()->admin_forms( array(
			'class' => 'um-form-mailchimp-merge um-half-column',
			'fields' => $fields,
			'prefix_id' => 'mailchimp[_um_merge]'
	) )->render_form();
	?>

	<div class="um-admin-clear"></div>
	<p><?php _e( 'You may get more details about these settings', 'um-mailchimp' ); ?> <a href="https://docs.ultimatemember.com/article/82-mailchimp-setup#audience_fields" title="Audience fields" target="_blank"><?php _e( 'here', 'um-mailchimp' ); ?></a></p>
</div>