<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div id="UM_mailchimp_view_log" style="display:none">
	<div class="um-admin-modal-head">
		<h3><?php _e( 'MailChimp requests log', 'um-mailchimp' ); ?></h3>
	</div>
	<div class="um-admin-modal-body"></div>
</div>