/*
 Plugin Name: Ultimate Member - MailChimp
 Description: Admin panel scripts
 Version: 2.2.8
 Author: Ultimate Member
 Author URI: http://ultimatemember.com/
 */

/**
 * Globals
 * @type object
 */
var um_admin_scripts;

jQuery( function () {

	/**
	 * Button "Clear log"
	 */
	jQuery( document.body ).on( 'click', '#um_mailchimp_clear_log', function (e) {
		e.preventDefault();
		jQuery.ajax( {
			url: wp.ajax.settings.url,
			type: 'post',
			data: {
				action: 'um_mailchimp_clear_log',
				nonce: um_admin_scripts.nonce
			},
			success: function () {
				window.location.reload();
			}
		} );
	} );
	

	/**
	 * The address field in the tool "Merge User Meta"
	 */
	jQuery( '#um-admin-mailchimp-merge' ).on( 'change', '.um_mc_address_field', function (e) {
		var mainField = e.currentTarget;
		var field_id = mainField.getAttribute( 'data-field_id' );
		var $rows = jQuery( '.um_mc_address_field_item[data-field_id^="' + field_id + '"]' ).closest( 'tr' );
		if ( mainField.value === '1' ) {
			$rows.show();
		} else {
			$rows.hide();
		}
	} ).find( '.um_mc_address_field' ).trigger( 'change' );

} );