/**
 * Global
 * @type object
 */
var um_admin_scripts, um_mailchimp_data;

var um_mc_tools = {
	'umSyncMembers': {
		tmpl: 'um-mailchimp-sync-members-metabox',
		wrapper: '#um-mailchimp-sync-members-metabox-wrapper',
		data: {
			disabled: true,
			selectDisabled: false
		}
	},
	'um_sync_now': {
		tmpl: 'um-mailchimp-sync-metabox',
		wrapper: '#um-mailchimp-sync-metabox-wrapper',
		data: {
			disabled: true,
			selectDisabled: false
		}
	},
	'um_scan_now': {
		tmpl: 'um-mailchimp-subscribe-metabox',
		wrapper: '#um-mailchimp-subscribe-metabox-wrapper',
		data: {
			disabled: false
		}
	}
};

jQuery( function () {

	/* Init templates on page load */
	for ( var um_mc_tool in um_mc_tools ) {
		window[um_mc_tool] = um_mc_create_template( um_mc_tools[um_mc_tool]['tmpl'], jQuery.extend( um_mailchimp_data, um_mc_tools[um_mc_tool]['data'] ) );
		if ( window[um_mc_tool] ) {
			um_mc_render_template( window[um_mc_tool], jQuery( um_mc_tools[um_mc_tool]['wrapper'] ) );
		}
	}

	/* Init actions */
	jQuery( document )
					.on( 'click', '#btn_um_mailchimp_sync_now:not(.disabled)', {
						action: 'um_mailchimp_sync_now',
						key: window.um_sync_now
					}, um_mc_ajax_sync )
					.on( 'click', '#btn_um_mailchimp_sync_members:not(.disabled)', {
						action: 'um_mailchimp_sync_members',
						key: window.umSyncMembers
					}, um_mc_ajax_sync )
					.on( 'click', '#btn_um_mailchimp_sync_members_pause', function(){
						um_mc_ajax_sync_process({pause: true});
					} )
					.on( 'click', '#btn_um_mailchimp_sync_members_play', function(){
						um_mc_ajax_sync_process({pause: false});
					} )
					.on( 'click', '#btn_um_mailchimp_scan_now:not(.disabled)', um_mc_ajax_bulk_scan_now )
					.on( 'click', '#btn_um_mailchimp_bulk_subscribe:not(.disabled)', um_mc_ajax_bulk_action )
					.on( 'click', '#btn_um_mailchimp_bulk_unsubscribe:not(.disabled)', um_mc_ajax_bulk_action )
					.on( 'change', '.um_mailchimp_list', function (e) {
						um_mc_update_template( window.um_scan_now, {
							disabled: false,
							internal_list: e.target.value
						} );
					} )
					.on( 'change', '.um_mailchimp_sync_list', function (e) {
						um_mc_update_template( window.um_sync_now, {
							internal_list: e.target.value,
							disabled: !e.target.value,
							message: ''
						} );
					} )
					.on( 'change', '.um_mailchimp_sync_members', function (e) {
						um_mc_update_template( window.umSyncMembers, {
							internal_list: e.target.value,
							disabled: !e.target.value,
							pause_button: false,
							play_button: false,
							message: '',
							log: null
						} );
					} );
} );

function um_mc_create_template(id, data) {
	if ( !jQuery( '#tmpl-' + id ).length ) {
		return;
	}

	var template = wp.template( id ),
					key = 'um_mc_template_' + (new Date()).getMilliseconds();

	if ( typeof window.um_mc_dashboard_data === 'undefined' ) {
		window.um_mc_dashboard_data = {};
	}

	window.um_mc_dashboard_data[ key ] = {
		template: template,
		data: data
	};
	return key;
};

function um_mc_render_template(key, $object) {
	if ( typeof window.um_mc_dashboard_data[ key ] !== 'undefined' ) {
		var content = window.um_mc_dashboard_data[ key ].template( window.um_mc_dashboard_data[key].data );
		if ( typeof $object !== 'undefined' ) {
			window.um_mc_dashboard_data[key].object = $object;
		}
		window.um_mc_dashboard_data[key].object.html( content );
		return true;
	}
	return false;
};

function um_mc_update_template(key, data) {
	data = data || {};
	if ( typeof window.um_mc_dashboard_data[ key ] !== 'undefined' ) {
		for ( var index in data ) {
			window.um_mc_dashboard_data[ key ]['data'][ index ] = data[ index ];
		}

		return um_mc_render_template( key );
	}
	return false;
};

/**
 * Sync Profiles
 * @param   {object}   e Event
 * @returns {undefined}
 */
function um_mc_ajax_sync(e) {
	e.preventDefault();

	if( typeof e.data === 'undefined' ){
		e.data = {};
	}
	jQuery.extend( e.data, {
		batchlog: {},
		list_id: jQuery( e.target ).closest('.um_mailchimp_metabox').find('select[name="um_mc_list_id"]').val()
	} );

	um_mc_update_template( e.data.key, {
		disabled: true, // disable all progress buttons to prevent conflicts
		selectDisabled: true,
		message: um_mailchimp_data.labels.sync_message || ''
	} );

	um_mc_ajax_sync_process.batchlog = {};
	um_mc_ajax_sync_process( e.data );
}

function um_mc_ajax_sync_process(data) {
	var self = um_mc_ajax_sync_process;
	if( typeof self.batchlog === 'undefined' ){
		self.batchlog = {};
	}
	if( typeof self.data === 'undefined' ){
		self.data = {
			nonce: um_admin_scripts.nonce,
			action: '',
			key: '',
			list_id: 0,
			message: '',
			length: 0,
			offset: 0,
			total: 0,
			pause: false
		};
	}
	if( typeof data === 'object' ){
		jQuery.extend(self.data, data);
	}

	if(self.data.pause){
		um_mc_update_template( self.data.key, {
			pause_button: false,
			play_button: true,
			loading: false
		} );
		return;
	}else{
		um_mc_update_template( self.data.key, {
			pause_button: true,
			play_button: false,
			loading: true
		} );
	}

	jQuery.post( wp.ajax.settings.url, self.data ).done( function (json) {

		if ( json.success ) {
			jQuery.extend( self.data, json.data );
			if ( typeof json.data.batchlog === 'object' ) {
				jQuery.extend( self.batchlog, json.data.batchlog );
			}

			um_mc_update_template( self.data.key, {
				pause_button: true,
				play_button: false,
				log: self.batchlog,
				message: self.data.message
			} );

			if ( self.data.total > self.data.offset ) {
				um_mc_ajax_sync_process( self.data );
			} else {
				setTimeout( function () {
					um_mc_update_template( self.data.key, {
						disabled: true,
						selectDisabled: false,
						pause_button: false,
						play_button: false,
						internal_list: '',
						loading: false,
						log: self.batchlog
					} );
				}, 1000 );
			}

		} else {

			um_mc_update_template( self.data.key, {
				message: json.data,
				loading: false
			} );
			console.error( json );
		}

	} ).fail( function (xhr, status, error) {
		alert( status + ' ' + error );
	} );
}

/**
 * Bulk Subscribe & Unubscribe (Scan Now)
 * @param   {type}     e Event
 * @returns {undefined}
 */
function um_mc_ajax_bulk_scan_now(e) {
	e.preventDefault();

	var role = jQuery( '.um_mailchimp_user_role' ).val(),
					status = jQuery( '.um_mailchimp_user_status' ).val();

	um_mc_update_template( window.um_scan_now, {
		disabled: true, // disable all progress buttons to prevent conflicts
		message: um_mailchimp_data.labels.scan_message,
		loading: true,
		role: role,
		status: status
	} );

	jQuery.post( wp.ajax.settings.url, {
		action: 'um_mailchimp_scan_now',
		role: role,
		status: status,
		nonce: um_admin_scripts.nonce
	}, function (json) {
		if ( json.success ) {
			window.umMcBulcAction = {
				key: json.data.key,
				role: role,
				status: status,
				batches: []
			};
			if ( json.data.total ) {
				um_mc_update_template( window.um_scan_now, {
					disabled: true,
					loading: false,
					message: json.data.message,
					step: 2
				} );
			} else {
				um_mc_update_template( window.um_scan_now, {
					disabled: false,
					loading: false,
					message: json.data.message,
					step: 0
				} );
			}
		} else {
			alert( json.data );
		}
	} ).fail( function (xhr, status, error) {
		alert( status + ' ' + error );
	} );
}

/**
 * Bulk Subscribe & Unubscribe handler
 * @param   {object}   e Event
 * @returns {undefined}
 */
function um_mc_ajax_bulk_action(e) {
	e.preventDefault();

	var list_id = jQuery( '.um_mailchimp_list' ).val();

	var $button = jQuery( e.currentTarget );
	var action = '', message = '';
	if ( $button.attr( 'id' ) === 'btn_um_mailchimp_bulk_subscribe' ) {
		action = 'um_mailchimp_bulk_subscribe';
		message = um_mailchimp_data.labels.start_bulk_subscribe_process;
	}
	if ( $button.attr( 'id' ) === 'btn_um_mailchimp_bulk_unsubscribe' ) {
		action = 'um_mailchimp_bulk_unsubscribe';
		message = um_mailchimp_data.labels.start_bulk_unsubscribe_process;
	}

	um_mc_update_template( window.um_scan_now, {
		disabled: true, // disable all progress buttons to prevent conflicts
		loading: true,
		message: message,
		internal_list: list_id
	} );

	um_mc_ajax_bulk_process( list_id, action );
}

/**
 * Bulk Subscribe & Unubscribe (single iteration)
 * @param   {string} list_id  The audience post ID
 * @param   {string} action   The action slug
 * @returns {object}					jqXHR
 */
function um_mc_ajax_bulk_process(list_id, action) {

	if ( typeof um_mc_ajax_bulk_process.tmpData === 'undefined' ) {
		um_mc_ajax_bulk_process.tmpData = jQuery.extend( window.umMcBulcAction, {
			action: action,
			nonce: um_admin_scripts.nonce,
			list_id: list_id,
			message: '',
			length: 0,
			offset: 0,
			subtotal: 0,
			total: 0
		} );
	}

	um_mc_ajax_bulk_process.tmpData.action = action;
	um_mc_ajax_bulk_process.tmpData.list_id = list_id;

	return jQuery.post( wp.ajax.settings.url, um_mc_ajax_bulk_process.tmpData, function (json) {

		if ( json.success ) {
			var tmpData = jQuery.extend( um_mc_ajax_bulk_process.tmpData, json.data );
			window.umMcBulcAction.batches.push( tmpData.batch );

			um_mc_update_template( window.um_scan_now, {
				message: tmpData.message,
				loading: true
			} );

			if ( (tmpData.total - tmpData.offset) > tmpData.length ) {
				um_mc_ajax_bulk_process.tmpData.offset = tmpData.offset + tmpData.length;
				um_mc_ajax_bulk_process( list_id, action );
			} else {
				setTimeout( function () {
					window.location = um_mailchimp_data.current_url;
				}, 1000 );
			}

		} else {

			um_mc_update_template( window.um_scan_now, {
				message: json.data,
				loading: false
			} );
			console.error( json );
		}

	} ).fail( function (xhr, status, error) {
		alert( status + ' ' + error );
	} );
}