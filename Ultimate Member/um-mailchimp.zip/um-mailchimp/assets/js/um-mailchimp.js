/*
 Plugin Name: Ultimate Member - MailChimp
 Description: Frontend scripts
 Version:     2.2.8
 Author:      Ultimate Member
 Author URI:  http://ultimatemember.com/
 */

if ( typeof (window.UM) !== 'object' ) {
	window.UM = {};
}

window.UM.mailchimp = {
	block: {},
	data: {},
	handler: {
		/**
		 * Disable hidden inputs to exclude from submit
		 * @since   2.2.7
		 * @returns {undefined}
		 */
		disableHiddenFields: function () {
			if ( UM.mailchimp.block.checkboxes.length ) {
				UM.mailchimp.block.checkboxes.each( function (i, item) {
					jQuery( item ).is( ':visible' ) ? jQuery( item ).closest( '.um-account-fieldset, .um-field-type_mailchimp' ).find( 'input,select,textarea' ).prop( 'disabled', false ) : jQuery( item ).closest( '.um-account-fieldset, .um-field-type_mailchimp' ).find( 'input,select,textarea' ).attr( 'disabled', 'disabled' ).prop( 'disabled', true );
				} );
			}
		},
		/**
		 * Show or hide section with groups and tags
		 * @since   2.2.4
		 * @param   {object}    input  The input[type="checkbox"]
		 * @returns {undefined}
		 */
		toggleAudienceSection: function (input) {
			UM.mailchimp.block.section = jQuery( input ).closest( '.um-account-fieldset,fieldset' ).children( '.um-account-fieldset-dropdown,section' );
			if ( UM.mailchimp.block.section.length ) {
				input.checked ? UM.mailchimp.block.section.show( 200 ) : UM.mailchimp.block.section.hide( 200 );
			}
		},
		/**
		 * Change the checkbox icon and class 'active'
		 * @since   2.2.7
		 * @param   {object}    input  The input[type="checkbox"]
		 * @returns {undefined}
		 */
		updateCheckboxIcon: function (input) {
			var $label = jQuery( input ).parents( 'label' );
			input.checked ? $label.addClass( 'active' ).find( 'i' ).removeAttr( 'class' ).addClass( 'um-icon-android-checkbox-outline' ) : $label.removeClass( 'active' ).find( 'i' ).removeAttr( 'class' ).addClass( 'um-icon-android-checkbox-outline-blank' );
		}
	},
	/**
	 * Init handlers for the MailChimp fields
	 * @since   2.2.4
	 * @version 2.2.8
	 * @returns {undefined}
	 */
	setup: function () {
		UM.mailchimp.block.checkboxes = jQuery( '.um-account-fieldset > .um-field-checkbox input[type="checkbox"], .um-field-checkbox-mailchimp input[type="checkbox"]' );
		UM.mailchimp.block.checkboxes.each( function (i, item) {
			UM.mailchimp.handler.toggleAudienceSection( item );
		} ).on( 'change', function (e) {
			UM.mailchimp.handler.toggleAudienceSection( e.target );
			UM.mailchimp.handler.updateCheckboxIcon( e.target );
			e.stopPropagation();
		} ).closest( 'fieldset' ).find( 'input[type="checkbox"]' ).on( 'change', function (e) {
			UM.mailchimp.handler.updateCheckboxIcon( e.target );
		} );

		// Fix for fields hidden by conditional logic
		jQuery( document ).on( 'um_fields_change', UM.mailchimp.handler.disableHiddenFields );
	}
};

jQuery( function () {
	UM.mailchimp.setup();
} );