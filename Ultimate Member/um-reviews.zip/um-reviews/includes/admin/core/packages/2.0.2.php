<?php
if ( ! defined( 'ABSPATH' ) )
	exit; // Exit if accessed directly

UM()->Reviews()->api()->flush_reviews();