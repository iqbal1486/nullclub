<h2>About Us</h2>

<p>WP AllMySMS for WooCommerce help to connect your customers with WooCommerce order notification and do customer engagement.</p>

<p>WP AllMySMS for WooCommerce will automatically send notification to customers and administrator on new orders. SMS can also be send to customer to notify about order status.</p>

<h2>Majors Features:</h2>
	<ul>
		<li>Automate customer experience using AllMySMS.</li>
		<li>Customers get notified on order confirmations.</li>
		<li>Admin get notified when orders are placed.</li>
		<li>Admin can customize the SMS text for every woo status.</li>
		<li>Customizable options for admin.</li>
	</ul>
	

<h2>Manual Upload via WordPress Admin #Manual Upload via WordPress Admin</h2>
	<ul>
		<li>Navigate to Plugins > Add New.</li>
		<li>Click the Upload Plugin button at the top of the screen.</li>
		<li>Select the zip file  from your local filesystem.</li>
		<li>Click the Install Now button.</li>
		<li>When installation is complete, you’ll see “Plugin installed successfully.” Click the Activate Plugin button at the bottom of the page.</li>
		<li>Do required settings</li>
	</ul>