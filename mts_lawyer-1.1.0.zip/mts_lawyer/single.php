<?php
/**
 * The template for displaying all single posts.
 *
 * @package Lawyer
 */

get_header(); ?>

	<?php lawyer_action( 'before_content' ); ?>

	<div id="wrapper" class="<?php lawyer_single_page_class(); ?>">

		<div class="container clearfix">

			<?php
			lawyer_single_featured_image_effect();

			lawyer_single_sections();

			lawyer_action( 'after_content' );

			get_sidebar();
			?>

		</div>

		<?php
		if ( 'full' === lawyer_get_settings( 'related_posts_position' ) ) {
			lawyer_related_posts();
		}
		?>

<?php
get_footer();
