<?php
/**
 * The template for displaying comments
 *
 * The area of the page that contains both current comments
 * and the comment form.
 *
 * @package Lawyer
 */

/*
 * If the current post is protected by a password and
 * the visitor has not yet entered the password we will
 * return early without loading the comments.
 */
if ( post_password_required() ) { ?>
	<p class="nocomments"><?php esc_html_e( 'This post is password protected. Enter the password to view comments.', 'lawyer' ); ?></p>
	<?php
	return;
}

if ( have_comments() ) :
?>
	<div id="comments">

		<div class="comment-title">

			<h4 class="total-comments"><?php comments_number( esc_html__( 'No Responses', 'lawyer' ), esc_html__( 'One Response', 'lawyer' ), esc_html__( '% Comments', 'lawyer' ) ); ?></h4>
		</div>

		<ol class="commentlist clearfix">
			<?php
			// List comments.
			wp_list_comments( 'callback=lawyer_comments' );

			// Comments pagination.
			the_comments_navigation( array(
				'prev_text' => '<i class="fa fa-angle-double-left"></i> ' . esc_html__( 'Older comments', 'lawyer' ),
				'next_text' => esc_html__( 'Newer Comments', 'lawyer' ) . ' <i class="fa fa-angle-double-right"></i>',
			) );
			?>
		</ol>

	</div>
<?php endif; ?>

<?php if ( comments_open() ) : ?>
	<div id="commentsAdd">
		<div id="respond" class="box m-t-6">
			<?php
			// Declare Vars.
			$comment_send     = esc_html__( 'Post Comment', 'lawyer' );
			$comment_reply    = esc_html__( 'Leave a Reply', 'lawyer' );
			$comment_reply_to = esc_html__( 'Reply', 'lawyer' );
			$comment_author   = esc_html__( 'Your Full Name*', 'lawyer' );
			$comment_email    = esc_html__( 'Your E-mail Address*', 'lawyer' );
			$comment_body     = esc_html__( 'Your Message Here...*', 'lawyer' );
			$comment_url      = esc_html__( 'Website', 'lawyer' );
			$comment_cancel   = esc_html__( 'Cancel Reply', 'lawyer' );
			$comments_args    = [
				// Define Fields.
				'fields'               => [
					// Author field.
					'author'  => '<p class="comment-form-author"><input id="author" name="author" aria-required="true" placeholder="' . $comment_author . '"></input></p>',
					// Email Field.
					'email'   => '<p class="comment-form-email"><input id="email" name="email" placeholder="' . $comment_email . '"></input></p>',
					// URL Field.
					'url'     => '<p class="comment-form-url"><input id="url" name="url" placeholder="' . $comment_url . '"></input></p>',
				],
				// Change the title of send button.
				'label_submit'         => $comment_send,
				// Change the title of the reply section.
				'title_reply'          => $comment_reply,
				// Change the title of the reply section.
				'title_reply_to'       => $comment_reply_to,
				// Cancel Reply Text.
				'cancel_reply_link'    => $comment_cancel,
				// Redefine your own textarea (the comment body).
				'comment_field'        => '<p class="comment-form-comment"><textarea id="comment" name="comment" cols="45" rows="6" aria-required="true" placeholder="' . $comment_body . '"></textarea></p>',
				// Message Before Comment.
				'comment_notes_before' => '',
				// Remove "Text or HTML to be displayed after the set of comment fields".
				'comment_notes_after'  => '',
				// Submit Button ID.
				'id_submit'            => 'submit',
			];
			comment_form( $comments_args );
			?>
		</div>

	</div>
<?php
endif;
