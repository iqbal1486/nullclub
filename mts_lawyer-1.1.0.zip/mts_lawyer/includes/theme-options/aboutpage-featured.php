<?php
/**
 * About Page Featured Section
 *
 * @package Lawyer
 */

$menus['aboutpage']['child']['aboutpage-featured'] = array(
	'title' => esc_html__( 'Featured', 'lawyer' ),
	'desc'  => esc_html__( 'From here, you can control the elements of the Featured section.', 'lawyer' ),
);

$sections['aboutpage-featured'] = array(

	array(
		'id'       => 'about_featured_background',
		'type'     => 'background',
		'title'    => esc_html__( 'Featured Section Background', 'lawyer' ),
		'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'lawyer' ),
		'options'  => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'      => array(
			'color'         => '',
			'use'           => 'upload',
			'image_pattern' => 'nobg',
			'image_upload'  => get_template_directory_uri() . '/images/featured2-bg.jpg',
			'repeat'        => 'no-repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
	),

	array(
		'id'       => 'about_featured_icon',
		'type'     => 'icon_select',
		'title'    => esc_html__( 'Icon', 'lawyer' ),
		'sub_desc' => esc_html__( 'Select an icon.', 'lawyer' ),
		'std'      => 'institution',
	),

	array(
		'id'       => 'about_featured_small_text',
		'type'     => 'text',
		'title'    => esc_html__( 'Small Text', 'lawyer' ),
		'sub_desc' => esc_html__( 'Enter small text here.', 'lawyer' ),
		'std'      => 'We recovered',
	),

	array(
		'id'       => 'about_featured_figure',
		'type'     => 'text',
		'title'    => esc_html__( 'Figure', 'lawyer' ),
		'sub_desc' => esc_html__( 'Enter text for featured section.', 'lawyer' ),
		'std'      => '$ 3,250,000',
	),
	array(
		'id'    => 'about_featured_figure_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Figure Font', 'lawyer' ),
		'std'   => array(
			'preview-text'  => 'Figure',
			'preview-color' => 'dark',
			'font-family'   => 'Frank Ruhl Libre',
			'font-weight'   => '400',
			'font-size'     => '88px',
			'line-height'   => '1',
			'color'         => '#ffffff',
			'css-selectors' => '.about-featured-section .figure',
		),
	),

	array(
		'id'       => 'about_featured_title',
		'type'     => 'textarea',
		'title'    => esc_html__( 'Title', 'lawyer' ),
		'sub_desc' => esc_html__( 'Enter title for featured section.', 'lawyer' ),
		'std'      => 'For our clients',
	),
	array(
		'id'    => 'about_featured_title_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Title Font', 'lawyer' ),
		'std'   => array(
			'preview-text'   => 'Title',
			'preview-color'  => 'dark',
			'font-family'    => 'Frank Ruhl Libre',
			'font-weight'    => '400',
			'font-size'      => '24px',
			'line-height'    => '32px',
			'color'          => '#ffffff',
			'additional-css' => 'text-transform: uppercase;',
			'css-selectors'  => '.about-featured-section h2',
		),
	),

	array(
		'id'       => 'about_featured_button_text',
		'type'     => 'text',
		'title'    => esc_html__( 'Button Text', 'lawyer' ),
		'sub_desc' => esc_html__( 'Enter button1 text.', 'lawyer' ),
		'std'      => 'Contact us now',
	),

	array(
		'id'       => 'about_featured_button_url',
		'type'     => 'text',
		'title'    => esc_html__( 'Button URL', 'lawyer' ),
		'sub_desc' => esc_html__( 'Enter button1 URL.', 'lawyer' ),
		'std'      => '#',
	),

	array(
		'id'       => 'about_featured_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Padding', 'lawyer' ),
		'sub_desc' => esc_html__( 'Set featured section padding from here.', 'lawyer' ),
		'std'      => array(
			'top'    => '128px',
			'right'  => '0',
			'bottom' => '128px',
			'left'   => '0',
		),
	),

);
