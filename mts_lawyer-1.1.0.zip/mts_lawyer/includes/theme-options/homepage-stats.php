<?php
/**
 * HomePage Stats Section
 *
 * @package Lawyer
 */

$menus['homepage']['child']['homepage-stats'] = array(
	'title' => esc_html__( 'Stats', 'lawyer' ),
	'desc'  => esc_html__( 'From here, you can control the elements of the stats section.', 'lawyer' ),
);

$sections['homepage-stats'] = array(

	array(
		'id'    => 'stats_top_heading',
		'type'  => 'heading',
		'title' => esc_html__( 'Stats Section', 'lawyer' ),
	),

	array(
		'id'       => 'stats_figure1',
		'type'     => 'text',
		'title'    => esc_html__( 'Stats 1', 'lawyer' ),
		'sub_desc' => esc_html__( 'Enter stats figure1.', 'lawyer' ),
		'std'      => '$ 32500',
	),
	array(
		'id'       => 'stats_text1',
		'type'     => 'text',
		'title'    => esc_html__( 'Stats text 1', 'lawyer' ),
		'sub_desc' => esc_html__( 'Set stats text1.', 'lawyer' ),
		'std'      => 'Recovered to clients',
	),

	array(
		'id'       => 'stats_figure2',
		'type'     => 'text',
		'title'    => esc_html__( 'Stats 2', 'lawyer' ),
		'sub_desc' => esc_html__( 'Enter stats figure2.', 'lawyer' ),
		'std'      => '$ 12500',
	),
	array(
		'id'       => 'stats_text2',
		'type'     => 'text',
		'title'    => esc_html__( 'Stats text 2', 'lawyer' ),
		'sub_desc' => esc_html__( 'Set stats text2.', 'lawyer' ),
		'std'      => 'Recovered this year',
	),

	array(
		'id'       => 'stats_figure3',
		'type'     => 'text',
		'title'    => esc_html__( 'Stats 3', 'lawyer' ),
		'sub_desc' => esc_html__( 'Enter stats figure3.', 'lawyer' ),
		'std'      => '$ 7000',
	),
	array(
		'id'       => 'stats_text3',
		'type'     => 'text',
		'title'    => esc_html__( 'Stats text 3', 'lawyer' ),
		'sub_desc' => esc_html__( 'Set stats text3.', 'lawyer' ),
		'std'      => 'Avg. saved per case',
	),

	array(
		'id'    => 'stats_figure_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Stats Figure Font', 'lawyer' ),
		'std'   => array(
			'preview-text'  => 'Stats Figure',
			'preview-color' => 'dark',
			'font-family'   => 'Frank Ruhl Libre',
			'font-weight'   => '700',
			'font-size'     => '80px',
			'color'         => '#ffffff',
			'line-height'   => '1',
			'css-selectors' => '.stats-section .stats-container .figure',
		),
	),

	array(
		'id'    => 'stats_text_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Stats Text Font', 'lawyer' ),
		'std'   => array(
			'preview-text'   => 'Stats Text',
			'preview-color'  => 'dark',
			'font-family'    => 'Roboto',
			'font-weight'    => '400',
			'font-size'      => '18px',
			'line-height'    => '35px',
			'color'          => '#ffffff',
			'additional-css' => 'text-transform: uppercase;',
			'css-selectors'  => '.stats-section .stats-container p',
		),
	),

	array(
		'id'    => 'stats_bottom_heading',
		'type'  => 'heading',
		'title' => esc_html__( 'List and Video Section', 'lawyer' ),
	),

	array(
		'id'        => 'stats_list',
		'type'      => 'group',
		'title'     => esc_html__( 'Stats List', 'lawyer' ),
		'sub_desc'  => esc_html__( 'Add stats list appearing on the Stats section.', 'lawyer' ),
		'groupname' => esc_html__( 'List', 'lawyer' ),
		'subfields' => array(
			array(
				'id'    => 'stats_list_title',
				'type'  => 'text',
				'title' => esc_html__( 'Title', 'lawyer' ),
			),
			array(
				'id'    => 'stats_list_icon',
				'type'  => 'icon_select',
				'title' => esc_html__( 'Icon', 'lawyer' ),
				'std'   => 'book',
			),
			array(
				'id'    => 'stats_list_text',
				'type'  => 'textarea',
				'title' => esc_html__( 'Text', 'lawyer' ),
			),
		),
		'std'       => array(
			'1' => array(
				'group_sort'       => '1',
				'stats_list_title' => 'Professional Liability',
				'stats_list_icon'  => 'book',
				'stats_list_text'  => 'Our lawyers will also represent you in civil litigation cases such as divorce, child and spouse maintenance.',
			),
			'2' => array(
				'group_sort'       => '2',
				'stats_list_title' => 'Dedication to Our Clients',
				'stats_list_icon'  => 'book',
				'stats_list_text'  => 'Our lawyers will also represent you in civil litigation cases such as divorce, child and spouse maintenance.',
			),
			'3' => array(
				'group_sort'       => '3',
				'stats_list_title' => 'Outstanding Service',
				'stats_list_icon'  => 'book',
				'stats_list_text'  => 'Our lawyers will also represent you in civil litigation cases such as divorce, child and spouse maintenance.',
			),
		),
	),

	array(
		'id'       => 'stats_youtube_id',
		'type'     => 'text',
		'title'    => esc_html__( 'YouTube Video ID', 'lawyer' ),
		'sub_desc' => esc_html__( 'Enter YouTube video ID to appear on the Stats section', 'lawyer' ),
		'std'      => 'hcZGS9SUkeY',
	),

	array(
		'id'    => 'stats_list_title_font',
		'type'  => 'typography',
		'title' => esc_html__( 'List Title Font', 'lawyer' ),
		'std'   => array(
			'preview-text'   => 'List Title',
			'preview-color'  => 'dark',
			'font-family'    => 'Roboto',
			'font-weight'    => '700',
			'font-size'      => '20px',
			'line-height'    => '35px',
			'color'          => '#ffffff',
			'additional-css' => 'text-transform: uppercase;',
			'css-selectors'  => '.stats-section .stats-list h2',
		),
	),

	array(
		'id'    => 'stats_list_text_font',
		'type'  => 'typography',
		'title' => esc_html__( 'List Text Font', 'lawyer' ),
		'std'   => array(
			'preview-text'  => 'List Text',
			'preview-color' => 'dark',
			'font-family'   => 'Roboto',
			'font-weight'   => '400',
			'font-size'     => '16px',
			'line-height'   => '26px',
			'color'         => '#ffffff',
			'css-selectors' => '.stats-section .stats-list p',
		),
	),

	array(
		'id'    => 'stats_general_heading',
		'type'  => 'heading',
		'title' => esc_html__( 'General Settings', 'lawyer' ),
	),

	array(
		'id'       => 'stats_background',
		'type'     => 'background',
		'title'    => esc_html__( 'Section Background', 'lawyer' ),
		'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'lawyer' ),
		'options'  => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'      => array(
			'color'         => '',
			'use'           => 'upload',
			'image_pattern' => 'nobg',
			'image_upload'  => get_template_directory_uri() . '/images/stats-bg.jpg',
			'repeat'        => 'no-repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
	),

	array(
		'id'       => 'stats_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Padding', 'lawyer' ),
		'sub_desc' => esc_html__( 'Set stats section padding from here.', 'lawyer' ),
		'std'      => array(
			'top'    => '160px',
			'right'  => '0',
			'bottom' => '124px',
			'left'   => '0',
		),
	),

);
