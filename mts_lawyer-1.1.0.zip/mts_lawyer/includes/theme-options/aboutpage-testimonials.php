<?php
/**
 * About Page Testimonials Section
 *
 * @package Lawyer
 */

$menus['aboutpage']['child']['aboutpage-testimonials'] = array(
	'title' => esc_html__( 'Testimonials', 'lawyer' ),
	'desc'  => esc_html__( 'From here, you can control the elements of the Testimonials section.', 'lawyer' ),
);

$sections['aboutpage-testimonials'] = array(

	array(
		'id'       => 'about_testimonials_background',
		'type'     => 'background',
		'title'    => esc_html__( 'Section Background', 'lawyer' ),
		'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'lawyer' ),
		'options'  => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'      => array(
			'color'         => '#ffffff',
			'use'           => 'pattern',
			'image_pattern' => 'nobg',
			'image_upload'  => '',
			'repeat'        => 'repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
	),

	array(
		'id'       => 'about_testimonials_icon',
		'type'     => 'icon_select',
		'title'    => esc_html__( 'Icon', 'lawyer' ),
		'sub_desc' => esc_html__( 'Select an icon.', 'lawyer' ),
		'std'      => 'institution',
	),

	array(
		'id'       => 'about_testimonials_title',
		'type'     => 'text',
		'title'    => esc_html__( 'Title', 'lawyer' ),
		'sub_desc' => esc_html__( 'Enter title here.', 'lawyer' ),
		'std'      => 'Toughest Defence Lawyers with Best Results',
	),
	array(
		'id'    => 'about_testimonials_title_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Title Font', 'lawyer' ),
		'std'   => array(
			'preview-text'  => 'Title',
			'preview-color' => 'light',
			'font-family'   => 'Frank Ruhl Libre',
			'font-weight'   => '400',
			'font-size'     => '48px',
			'line-height'   => '56px',
			'color'         => '#2d3349',
			'css-selectors' => '.about-testimonials-section h2',
		),
	),
	array(
		'id'       => 'about_testimonials_text',
		'type'     => 'textarea',
		'title'    => esc_html__( 'Text', 'lawyer' ),
		'sub_desc' => esc_html__( 'Enter text here.', 'lawyer' ),
		'std'      => 'Our lawyers will also represent you in civil litigation cases such as divorce, child and<br>spouse maintenance.',
	),
	array(
		'id'    => 'about_testimonials_text_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Text Font', 'lawyer' ),
		'std'   => array(
			'preview-text'  => 'Text',
			'preview-color' => 'light',
			'font-family'   => 'Roboto',
			'font-weight'   => '400',
			'font-size'     => '20px',
			'line-height'   => '35px',
			'color'         => '#2d3349',
			'css-selectors' => '.about-testimonials-section p',
		),
	),

	array(
		'id'        => 'about_testimonials_group',
		'type'      => 'group',
		'title'     => esc_html__( 'Testimonials', 'lawyer' ),
		'sub_desc'  => esc_html__( 'Add testimonial appearing on the Testimonials section.', 'lawyer' ),
		'groupname' => esc_html__( 'Testimonial', 'lawyer' ),
		'subfields' => array(
			array(
				'id'    => 'about_testimonials_group_author',
				'type'  => 'text',
				'title' => esc_html__( 'Author Name', 'lawyer' ),
			),
			array(
				'id'       => 'about_testimonials_group_image',
				'type'     => 'upload',
				'title'    => esc_html__( 'Upload Image', 'lawyer' ),
				'sub_desc' => esc_html__( 'Select an image file. Recommended size: 100 X 100 in px.', 'lawyer' ),
			),
			array(
				'id'    => 'about_testimonials_group_testimonial',
				'type'  => 'textarea',
				'title' => esc_html__( 'Testimonial', 'lawyer' ),
			),
		),
		'std'       => array(
			'1' => array(
				'group_sort'                           => '1',
				'about_testimonials_group_author'      => 'Edmund Brooke, Paralegal',
				'about_testimonials_group_image'       => get_template_directory_uri() . '/images/testimonial1.png',
				'about_testimonials_group_testimonial' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam iaculis pellentesque erat a venenatis. Nam ullamcorper eu elit non malesuada. Vivamus dignissim vitae sem nec tempor.',
			),
			'2' => array(
				'group_sort'                           => '2',
				'about_testimonials_group_author'      => 'Edmund Brooke, Paralegal',
				'about_testimonials_group_image'       => get_template_directory_uri() . '/images/testimonial1.png',
				'about_testimonials_group_testimonial' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam iaculis pellentesque erat a venenatis. Nam ullamcorper eu elit non malesuada. Vivamus dignissim vitae sem nec tempor.',
			),
			'3' => array(
				'group_sort'                           => '3',
				'about_testimonials_group_author'      => 'Edmund Brooke, Paralegal',
				'about_testimonials_group_image'       => get_template_directory_uri() . '/images/testimonial1.png',
				'about_testimonials_group_testimonial' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam iaculis pellentesque erat a venenatis. Nam ullamcorper eu elit non malesuada. Vivamus dignissim vitae sem nec tempor.',
			),
			'4' => array(
				'group_sort'                           => '4',
				'about_testimonials_group_author'      => 'Edmund Brooke, Paralegal',
				'about_testimonials_group_image'       => get_template_directory_uri() . '/images/testimonial1.png',
				'about_testimonials_group_testimonial' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam iaculis pellentesque erat a venenatis. Nam ullamcorper eu elit non malesuada. Vivamus dignissim vitae sem nec tempor.',
			),
		),
	),

	array(
		'id'    => 'about_testimonials_group_author_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Author Name Font', 'lawyer' ),
		'std'   => array(
			'preview-text'  => 'Author Name',
			'preview-color' => 'light',
			'font-family'   => 'Frank Ruhl Libre',
			'font-weight'   => '400',
			'font-size'     => '32px',
			'line-height'   => '56px',
			'color'         => '#2d3349',
			'css-selectors' => '.testimonial-wrap h3',
		),
	),
	array(
		'id'    => 'about_testimonials_group_testimonial_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Testimonial Font', 'lawyer' ),
		'std'   => array(
			'preview-text'   => 'Testimonial',
			'preview-color'  => 'light',
			'font-family'    => 'Roboto',
			'font-weight'    => '400',
			'font-size'      => '18px',
			'color'          => '#2d3349',
			'additional-css' => 'opacity: 0.5;',
			'css-selectors'  => '.testimonial-wrap p',
		),
	),

	array(
		'id'       => 'about_testimonials_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Padding', 'lawyer' ),
		'sub_desc' => esc_html__( 'Set testimonials section padding from here.', 'lawyer' ),
		'std'      => array(
			'top'    => '126px',
			'right'  => '0',
			'bottom' => '126px',
			'left'   => '0',
		),
	),

);
