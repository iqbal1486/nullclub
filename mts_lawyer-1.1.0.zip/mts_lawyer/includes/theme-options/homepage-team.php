<?php
/**
 * HomePage Team Section
 *
 * @package Lawyer
 */

$menus['homepage']['child']['homepage-team'] = array(
	'title' => esc_html__( 'Team', 'lawyer' ),
	'desc'  => esc_html__( 'From here, you can control the elements of the Team section.', 'lawyer' ),
);

$sections['homepage-team'] = array(

	array(
		'id'       => 'team_background',
		'type'     => 'background',
		'title'    => esc_html__( 'Section Background', 'lawyer' ),
		'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'lawyer' ),
		'options'  => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'      => array(
			'color'         => '#ffffff',
			'use'           => 'pattern',
			'image_pattern' => 'nobg',
			'image_upload'  => '',
			'repeat'        => 'repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
	),

	array(
		'id'       => 'team_icon',
		'type'     => 'icon_select',
		'title'    => esc_html__( 'Icon', 'lawyer' ),
		'sub_desc' => esc_html__( 'Select an icon.', 'lawyer' ),
		'std'      => 'institution',
	),

	array(
		'id'       => 'team_title',
		'type'     => 'text',
		'title'    => esc_html__( 'Title', 'lawyer' ),
		'sub_desc' => esc_html__( 'Enter title here.', 'lawyer' ),
		'std'      => 'Toughest Defense Lawyers for Your Money',
	),
	array(
		'id'    => 'team_title_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Title Font', 'lawyer' ),
		'std'   => array(
			'preview-text'  => 'Title',
			'preview-color' => 'light',
			'font-family'   => 'Frank Ruhl Libre',
			'font-weight'   => '400',
			'font-size'     => '48px',
			'line-height'   => '56px',
			'color'         => '#2d3349',
			'css-selectors' => '.team-section h2',
		),
	),
	array(
		'id'       => 'team_text',
		'type'     => 'textarea',
		'title'    => esc_html__( 'Text', 'lawyer' ),
		'sub_desc' => esc_html__( 'Enter text here.', 'lawyer' ),
		'std'      => 'Our lawyers will also represent you in civil litigation cases such as divorce, child and<br>spouse maintenance.',
	),
	array(
		'id'    => 'team_text_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Text Font', 'lawyer' ),
		'std'   => array(
			'preview-text'  => 'Text',
			'preview-color' => 'light',
			'font-family'   => 'Roboto',
			'font-weight'   => '400',
			'font-size'     => '20px',
			'line-height'   => '35px',
			'color'         => '#2d3349',
			'css-selectors' => '.team-section p',
		),
	),

	array(
		'id'        => 'team_group',
		'type'      => 'group',
		'title'     => esc_html__( 'Team', 'lawyer' ),
		'sub_desc'  => esc_html__( 'Add services grid appearing on the Team section.', 'lawyer' ),
		'groupname' => esc_html__( 'Services', 'lawyer' ),
		'subfields' => array(
			array(
				'id'    => 'team_group_title',
				'type'  => 'text',
				'title' => esc_html__( 'Title', 'lawyer' ),
			),
			array(
				'id'    => 'team_group_url',
				'type'  => 'text',
				'title' => esc_html__( 'URL', 'lawyer' ),
			),
			array(
				'id'       => 'team_group_image',
				'type'     => 'upload',
				'title'    => esc_html__( 'Upload Image', 'lawyer' ),
				'sub_desc' => esc_html__( 'Select an image file. Recommended size: 255 X 275', 'lawyer' ),
			),
			array(
				'id'    => 'team_group_text',
				'type'  => 'text',
				'title' => esc_html__( 'Text', 'lawyer' ),
			),
			array(
				'id'    => 'team_group_hover_text',
				'type'  => 'text',
				'title' => esc_html__( 'Hover Text', 'lawyer' ),
			),
			array(
				'id'    => 'team_group_hover_color',
				'type'  => 'color',
				'title' => esc_html__( 'Hover Color', 'lawyer' ),
				'args'  => array( 'opacity' => true ),
			),
		),
		'std'       => array(
			'1' => array(
				'group_sort'             => '1',
				'team_group_title'       => 'John Appleseed',
				'team_group_url'         => '#',
				'team_group_image'       => get_template_directory_uri() . '/images/team1.jpg',
				'team_group_text'        => 'External Relations',
				'team_group_hover_text'  => 'See sucess rates',
				'team_group_hover_color' => 'rgba(207,167,85,0.5)',
			),
			'2' => array(
				'group_sort'             => '2',
				'team_group_title'       => 'Rose Johnson',
				'team_group_url'         => '#',
				'team_group_image'       => get_template_directory_uri() . '/images/team2.jpg',
				'team_group_text'        => 'External Relations',
				'team_group_hover_text'  => 'See sucess rates',
				'team_group_hover_color' => 'rgba(207,167,85,0.5)',
			),
			'3' => array(
				'group_sort'             => '3',
				'team_group_title'       => 'John Appleseed',
				'team_group_url'         => '#',
				'team_group_image'       => get_template_directory_uri() . '/images/team3.jpg',
				'team_group_text'        => 'External Relations',
				'team_group_hover_text'  => 'See sucess rates',
				'team_group_hover_color' => 'rgba(207,167,85,0.5)',
			),
			'4' => array(
				'group_sort'             => '4',
				'team_group_title'       => 'Rose Johnson',
				'team_group_url'         => '#',
				'team_group_image'       => get_template_directory_uri() . '/images/team4.jpg',
				'team_group_text'        => 'External Relations',
				'team_group_hover_text'  => 'See sucess rates',
				'team_group_hover_color' => 'rgba(207,167,85,0.5)',
			),
		),
	),

	array(
		'id'    => 'team_group_title_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Team Title Font', 'lawyer' ),
		'std'   => array(
			'preview-text'   => 'Team Title',
			'preview-color'  => 'light',
			'font-family'    => 'Roboto',
			'font-weight'    => '700',
			'font-size'      => '16px',
			'color'          => '#2d3349',
			'additional-css' => 'text-transform: uppercase;',
			'css-selectors'  => '.team-container h3',
		),
	),
	array(
		'id'    => 'team_group_text_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Team Text Font', 'lawyer' ),
		'std'   => array(
			'preview-text'   => 'Team Text',
			'preview-color'  => 'light',
			'font-family'    => 'Roboto',
			'font-weight'    => '400',
			'font-size'      => '12px',
			'line-height'    => '1',
			'color'          => '#abadb3',
			'additional-css' => 'text-transform: uppercase;',
			'css-selectors'  => '.team-container p',
		),
	),
	array(
		'id'    => 'team_group_hover_text_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Team Hover Text Font', 'lawyer' ),
		'std'   => array(
			'preview-text'   => 'Team Hover Text',
			'preview-color'  => 'dark',
			'font-family'    => 'Roboto',
			'font-weight'    => '700',
			'font-size'      => '16px',
			'color'          => '#ffffff',
			'additional-css' => 'text-transform: uppercase;',
			'css-selectors'  => '.team-container .hover-text',
		),
	),

	array(
		'id'       => 'team_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Padding', 'lawyer' ),
		'sub_desc' => esc_html__( 'Set padding from here.', 'lawyer' ),
		'std'      => array(
			'top'    => '126px',
			'right'  => '0',
			'bottom' => '95px',
			'left'   => '0',
		),
	),

);
