<?php
/**
 * Brands
 *
 * @package Lawyer
 */

$menus['footer']['child']['footer-brands'] = array(
	'title' => esc_html__( 'Brands Section', 'lawyer' ),
	'desc'  => esc_html__( 'From here, you can control the Brands Section.', 'lawyer' ),
);

$sections['footer-brands'] = array(

	array(
		'id'       => 'footer_brands_section',
		'type'     => 'switch',
		'title'    => esc_html__( 'Brands Section', 'lawyer' ),
		'sub_desc' => esc_html__( 'Enable or disable Brands Section with this option.', 'lawyer' ),
		'std'      => '0',
	),

	array(
		'id'         => 'footer_brands_alignment',
		'type'       => 'button_set',
		'title'      => esc_html__( 'Brands Section Alignment', 'lawyer' ),
		'sub_desc'   => esc_html__( 'Choose alignment of Brands Section.', 'lawyer' ),
		'options'    => array(
			'left'   => esc_html__( 'Left', 'lawyer' ),
			'center' => esc_html__( 'Center', 'lawyer' ),
			'right'  => esc_html__( 'Right', 'lawyer' ),
		),
		'std'        => 'center',
		'class'      => 'green',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_brands_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'brands_section_title',
		'type'       => 'text',
		'title'      => esc_html__( 'Brands Title', 'lawyer' ),
		'sub_desc'   => esc_html__( 'Enter brands title here.', 'lawyer' ),
		'std'        => esc_html__( 'Our Brands:', 'lawyer' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_brands_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),

	),

	array(
		'id'         => 'footer_brands_items',
		'type'       => 'group',
		'title'      => esc_html__( 'Brands', 'lawyer' ),
		'groupname'  => esc_html__( 'Brand', 'lawyer' ), // Group name.
		'subfields'  => array(
			array(
				'id'       => 'brand_title',
				'type'     => 'text',
				'title'    => esc_html__( 'Title', 'lawyer' ),
				'sub_desc' => esc_html__( 'The title will not be shown.', 'lawyer' ),
			),
			array(
				'id'       => 'brand_image',
				'type'     => 'upload',
				'title'    => esc_html__( 'Image', 'lawyer' ),
				'sub_desc' => esc_html__( 'Upload or select an image for brand', 'lawyer' ),
			),
			array(
				'id'       => 'brand_url',
				'type'     => 'text',
				'title'    => esc_html__( 'Link', 'lawyer' ),
				'sub_desc' => esc_html__( 'Insert a link URL of brand', 'lawyer' ),
				'std'      => '#',
			),
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_brands_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'brands_margin',
		'type'       => 'margin',
		'title'      => esc_html__( 'Margin', 'lawyer' ),
		'sub_desc'   => esc_html__( 'Brands Section margin.', 'lawyer' ),
		'std'        => array(
			'top'    => '0',
			'right'  => '0',
			'bottom' => '0',
			'left'   => '0',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_brands_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'brands_padding',
		'type'       => 'margin',
		'title'      => esc_html__( 'Padding', 'lawyer' ),
		'sub_desc'   => esc_html__( 'Brands Section padding.', 'lawyer' ),
		'std'        => array(
			'top'    => '40px',
			'right'  => '0',
			'bottom' => '27px',
			'left'   => '0',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_brands_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'brands_border',
		'type'       => 'border',
		'title'      => esc_html__( 'Border', 'lawyer' ),
		'sub_desc'   => esc_html__( 'Select border', 'lawyer' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_brands_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
);
