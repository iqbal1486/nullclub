<?php
/**
 * HomePage Services Grid 2 Section
 *
 * @package Lawyer
 */

$menus['homepage']['child']['homepage-services-grid2'] = array(
	'title' => esc_html__( 'Services Grid 2', 'lawyer' ),
	'desc'  => esc_html__( 'From here, you can control the elements of the Services Grid 2 section.', 'lawyer' ),
);

$default_text = 'Our lawyers will also represent you in civil litigation cases such as divorce, child and spouse maintenance.';

$sections['homepage-services-grid2'] = array(

	array(
		'id'       => 'services_grid2_background',
		'type'     => 'background',
		'title'    => esc_html__( 'Section Background', 'lawyer' ),
		'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'lawyer' ),
		'options'  => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'      => array(
			'color'         => '',
			'use'           => 'upload',
			'image_pattern' => 'nobg',
			'image_upload'  => get_template_directory_uri() . '/images/services-grid2-bg.jpg',
			'repeat'        => 'no-repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
	),

	array(
		'id'        => 'services_grid2_group',
		'type'      => 'group',
		'title'     => esc_html__( 'Services Grid 2', 'lawyer' ),
		'sub_desc'  => esc_html__( 'Add services appearing on the Services Grid 2 section.', 'lawyer' ),
		'groupname' => esc_html__( 'Services', 'lawyer' ),
		'subfields' => array(
			array(
				'id'    => 'services_grid2_group_title',
				'type'  => 'text',
				'title' => esc_html__( 'Title', 'lawyer' ),
			),
			array(
				'id'    => 'services_grid2_group_text',
				'type'  => 'textarea',
				'title' => esc_html__( 'Text', 'lawyer' ),
			),
			array(
				'id'    => 'services_grid2_group_icon',
				'type'  => 'icon_select',
				'title' => esc_html__( 'Select Icon', 'lawyer' ),
			),
		),
		'std'       => array(
			'1' => array(
				'group_sort'                 => '1',
				'services_grid2_group_title' => 'Procurement',
				'services_grid2_group_text'  => $default_text,
				'services_grid2_group_icon'  => 'book',
			),
			'2' => array(
				'group_sort'                 => '2',
				'services_grid2_group_title' => 'Maintenance',
				'services_grid2_group_text'  => $default_text,
				'services_grid2_group_icon'  => 'cog',
			),
			'3' => array(
				'group_sort'                 => '3',
				'services_grid2_group_title' => 'Family Law',
				'services_grid2_group_text'  => $default_text,
				'services_grid2_group_icon'  => 'adjust',
			),
			'4' => array(
				'group_sort'                 => '4',
				'services_grid2_group_title' => 'Criminal Law',
				'services_grid2_group_text'  => $default_text,
				'services_grid2_group_icon'  => 'user-secret',
			),
			'5' => array(
				'group_sort'                 => '5',
				'services_grid2_group_title' => 'Estate Planning',
				'services_grid2_group_text'  => $default_text,
				'services_grid2_group_icon'  => 'institution',
			),
			'6' => array(
				'group_sort'                 => '6',
				'services_grid2_group_title' => 'Intelectual Property',
				'services_grid2_group_text'  => $default_text,
				'services_grid2_group_icon'  => 'houzz',
			),
			'7' => array(
				'group_sort'                 => '7',
				'services_grid2_group_title' => 'Capital Market',
				'services_grid2_group_text'  => $default_text,
				'services_grid2_group_icon'  => 'hospital-o',
			),
			'8' => array(
				'group_sort'                 => '8',
				'services_grid2_group_title' => 'Malpractice',
				'services_grid2_group_text'  => $default_text,
				'services_grid2_group_icon'  => 'hand-spock-o',
			),
			'9' => array(
				'group_sort'                 => '9',
				'services_grid2_group_title' => 'Privatization',
				'services_grid2_group_text'  => $default_text,
				'services_grid2_group_icon'  => 'folder',
			),
		),
	),

	array(
		'id'    => 'services_grid2_title_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Title Font', 'lawyer' ),
		'std'   => array(
			'preview-text'   => 'Title',
			'preview-color'  => 'light',
			'font-family'    => 'Roboto',
			'font-weight'    => '700',
			'font-size'      => '20px',
			'color'          => '#2d3349',
			'additional-css' => 'text-transform: uppercase;',
			'css-selectors'  => '.services-grid2-container h3',
		),
	),
	array(
		'id'    => 'services_grid2_text_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Text Font', 'lawyer' ),
		'std'   => array(
			'preview-text'  => 'Text',
			'preview-color' => 'light',
			'font-family'   => 'Roboto',
			'font-weight'   => '400',
			'font-size'     => '16px',
			'line-height'   => '26px',
			'color'         => '#2d3849',
			'css-selectors' => '.services-grid2-container p',
		),
	),

	array(
		'id'       => 'services_grid2_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Padding', 'lawyer' ),
		'sub_desc' => esc_html__( 'Set padding from here.', 'lawyer' ),
		'std'      => array(
			'top'    => '131px',
			'right'  => '0',
			'bottom' => '92px',
			'left'   => '0',
		),
	),

);
