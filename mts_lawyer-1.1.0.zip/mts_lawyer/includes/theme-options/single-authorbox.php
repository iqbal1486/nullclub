<?php
/**
 * Single Subscribe
 *
 * @package Lawyer
 */

$menus['single-authorbox'] = array(
	'title' => esc_html__( 'Author Box', 'lawyer' ),
	'desc'  => esc_html__( 'From here, you can control the appearance and functionality of Author box in single posts page.', 'lawyer' ),
);

$mts_patterns = array(
	'nobg' => array( 'img' => $uri . 'bg-patterns/nobg.png' ),
);
for ( $i = 0; $i <= 52; $i++ ) {
	$mts_patterns[ 'pattern' . $i ] = array( 'img' => $uri . 'bg-patterns/pattern' . $i . '.png' );
}

for ( $i = 1; $i <= 29; $i++ ) {
	$mts_patterns[ 'hbg' . $i ] = array( 'img' => $uri . 'bg-patterns/hbg' . $i . '.png' );
}

$sections['single-authorbox'] = array(

	array(
		'id'    => 'single_authorbox_heading',
		'type'  => 'heading',
		'title' => esc_html__( 'Author box Settings', 'lawyer' ),
	),
	array(
		'id'       => 'single_authorbox_background',
		'type'     => 'background',
		'title'    => esc_html__( 'Author box Background', 'lawyer' ),
		'sub_desc' => esc_html__( 'Set background color, pattern and image for subscribe box from here.', 'lawyer' ),
		'options'  => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'      => array(
			'color'         => '',
			'use'           => 'pattern',
			'image_pattern' => 'nobg',
			'image_upload'  => '',
			'repeat'        => 'repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
	),
	array(
		'id'       => 'author_box_title',
		'type'     => 'text',
		'title'    => esc_html__( 'Author Box Title', 'lawyer' ),
		'sub_desc' => esc_html__( 'Enter author box title.', 'lawyer' ),
		'std'      => '',
	),
	array(
		'id'       => 'single_authorbox_margin',
		'type'     => 'margin',
		'title'    => esc_html__( 'Margin', 'lawyer' ),
		'sub_desc' => esc_html__( 'Set Author box margin from here.', 'lawyer' ),
		'std'      => array(
			'top'    => '30px',
			'right'  => '0',
			'bottom' => '0',
			'left'   => '0',
		),
	),
	array(
		'id'       => 'single_authorbox_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Padding', 'lawyer' ),
		'sub_desc' => esc_html__( 'Set Author box padding from here.', 'lawyer' ),
		'std'      => array(
			'top'    => '40px',
			'right'  => '0',
			'bottom' => '0',
			'left'   => '0',
		),
	),
	array(
		'id'       => 'single_authorbox_border',
		'type'     => 'border',
		'title'    => esc_html__( 'Border', 'magnus' ),
		'sub_desc' => esc_html__( 'Select border', 'magnus' ),
		'std'      => array(
			'direction' => 'top',
			'size'      => '1',
			'style'     => 'solid',
			'color'     => '#e0e1e4',
		),
	),
	array(
		'id'       => 'single_authorbox_border_radius',
		'type'     => 'text',
		'class'    => 'small-text',
		'title'    => esc_html__( 'Border Radius', 'lawyer' ),
		'sub_desc' => esc_html__( 'Author box border radius.', 'lawyer' ),
		'std'      => '0',
		'args'     => array( 'type' => 'number' ),
	),

	array(
		'id'    => 'single_authorbox_title_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Author Box Title Font', 'lawyer' ),
		'std'   => array(
			'preview-text'   => 'Author Box Title Font',
			'preview-color'  => 'light',
			'font-family'    => 'Roboto',
			'font-weight'    => '700',
			'font-size'      => '13px',
			'line-height'    => '24px',
			'letter-spacing' => '1px',
			'color'          => '#2d3849',
			'additional-css' => 'text-transform: uppercase;',
			'css-selectors'  => '.postauthor h4',
		),
	),
	array(
		'id'    => 'single_authorbox_author_name_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Author Box Name Font', 'lawyer' ),
		'std'   => array(
			'preview-text'   => 'Author Box Name Font',
			'preview-color'  => 'light',
			'font-family'    => 'Roboto',
			'font-weight'    => '700',
			'font-size'      => '16px',
			'line-height'    => '24px',
			'letter-spacing' => '1px',
			'color'          => '#cfa755',
			'margin-top'     => '3px',
			'additional-css' => 'text-transform: uppercase;',
			'css-selectors'  => '.postauthor h5, .postauthor h5 a',
		),
	),
	array(
		'id'    => 'single_authorbox_text_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Author Box Text Font', 'lawyer' ),
		'std'   => array(
			'preview-text'  => 'Author Box Text Font',
			'preview-color' => 'light',
			'font-family'   => 'Roboto',
			'font-weight'   => '400',
			'font-size'     => '15px',
			'line-height'   => '26px',
			'color'         => '#2d3849',
			'css-selectors' => '.postauthor p',
		),
	),

	array(
		'id'    => 'single_author_img_heading',
		'type'  => 'heading',
		'title' => esc_html__( 'Author Image Settings', 'lawyer' ),
	),
	array(
		'id'       => 'single_author_image_margin',
		'type'     => 'margin',
		'title'    => esc_html__( 'Margin', 'lawyer' ),
		'sub_desc' => esc_html__( 'Set Author image margin from here.', 'lawyer' ),
		'std'      => array(
			'top'    => '0',
			'right'  => '32px',
			'bottom' => '0',
			'left'   => '0',
		),
	),
	array(
		'id'       => 'single_author_image_border_radius',
		'type'     => 'text',
		'class'    => 'small-text',
		'title'    => esc_html__( 'Border Radius', 'lawyer' ),
		'sub_desc' => esc_html__( 'Author image border radius.', 'lawyer' ),
		'std'      => '100',
		'args'     => array( 'type' => 'number' ),
	),

);
