<?php
/**
 * HomePage Heading
 *
 * @package Lawyer
 */

$menus['blog']['child']['blog-heading'] = array(
	'title' => esc_html__( 'Heading Section', 'lawyer' ),
	'desc'  => esc_html__( 'From here, you can control the elements of Blog Heading Section.', 'lawyer' ),
);

// Dependency check that blog heading option is enable.
$blog_heading_dependency = array(
	'relation' => 'and',
	array(
		'field'      => 'blog_heading_section',
		'value'      => '1',
		'comparison' => '==',
	),
);

$sections['blog-heading'] = array(

	array(
		'id'       => 'blog_heading_section',
		'type'     => 'switch',
		'title'    => esc_html__( 'Heading Section', 'lawyer' ),
		'sub_desc' => esc_html__( 'Enable or disable header section with this option.', 'lawyer' ),
		'std'      => '1',
	),

	array(
		'id'         => 'blog_heading_bg',
		'type'       => 'background',
		'title'      => esc_html__( 'Heading Background', 'lawyer' ),
		'sub_desc'   => esc_html__( 'Set background color, pattern and image from here.', 'lawyer' ),
		'options'    => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'        => array(
			'color'         => '',
			'use'           => 'upload',
			'image_pattern' => 'nobg',
			'image_upload'  => get_template_directory_uri() . '/images/blog-heading-bg.jpg',
			'repeat'        => 'no-repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
		'dependency' => $blog_heading_dependency,
	),

	array(
		'id'         => 'blog_heading',
		'type'       => 'text',
		'title'      => esc_html__( 'Blog Heading', 'lawyer' ),
		'sub_desc'   => esc_html__( 'Update blog heading from here.', 'lawyer' ),
		'std'        => 'Blog',
		'dependency' => $blog_heading_dependency,
	),
	array(
		'id'         => 'blog_subheading',
		'type'       => 'text',
		'title'      => esc_html__( 'Blog SubHeading', 'lawyer' ),
		'sub_desc'   => esc_html__( 'Update blog sub-heading from here.', 'lawyer' ),
		'std'        => 'Latest Updates and News',
		'dependency' => $blog_heading_dependency,
	),
	array(
		'id'         => 'mts_breadcrumb',
		'type'       => 'switch',
		'title'      => esc_html__( 'Breadcrumbs', 'lawyer' ),
		'sub_desc'   => esc_html__( 'Breadcrumbs are a great way to make your site more user-friendly. You can enable them by checking this box.', 'lawyer' ),
		'std'        => '1',
		'dependency' => $blog_heading_dependency,
	),

	array(
		'id'         => 'breadcrumb_icon',
		'type'       => 'icon_select',
		'title'      => esc_html__( 'Icon', 'lawyer' ),
		'sub_desc'   => esc_html__( 'Select divider icons from here.', 'lawyer' ),
		'std'        => 'angle-right',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'blog_heading_section',
				'value'      => '1',
				'comparison' => '==',
			),
			array(
				'field'      => 'mts_breadcrumb',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'breadcrumb_font',
		'type'       => 'typography',
		'title'      => esc_html__( 'Breadcrumbs Font', 'lawyer' ),
		'std'        => array(
			'preview-text'   => 'Breadcrumbs',
			'preview-color'  => 'light',
			'font-family'    => 'Roboto',
			'font-weight'    => '700',
			'font-size'      => '16px',
			'color'          => '#a4a6aa',
			'additional-css' => 'text-transform: uppercase;',
			'css-selectors'  => '.breadcrumb, .blog-heading-section .rank-math-breadcrumb p',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'blog_heading_section',
				'value'      => '1',
				'comparison' => '==',
			),
			array(
				'field'      => 'mts_breadcrumb',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'blog_breadcrumb_url',
		'type'       => 'text',
		'title'      => esc_html__( 'Blog Breadcrumb URL', 'lawyer' ),
		'sub_desc'   => esc_html__( 'Update blog URL from here. This option is only for Blog Page.', 'lawyer' ),
		'std'        => 'blog',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'blog_heading_section',
				'value'      => '1',
				'comparison' => '==',
			),
			array(
				'field'      => 'mts_breadcrumb',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'blog_heading_margin',
		'type'       => 'margin',
		'title'      => esc_html__( 'Margin', 'lawyer' ),
		'sub_desc'   => esc_html__( 'Set margin from here.', 'lawyer' ),
		'std'        => array(
			'top'    => '0',
			'right'  => '0',
			'bottom' => '50px',
			'left'   => '0',
		),
		'dependency' => $blog_heading_dependency,
	),
	array(
		'id'         => 'blog_heading_padding',
		'type'       => 'margin',
		'title'      => esc_html__( 'Padding', 'lawyer' ),
		'sub_desc'   => esc_html__( 'Set padding from here.', 'lawyer' ),
		'std'        => array(
			'top'    => '72px',
			'right'  => '0',
			'bottom' => '70px',
			'left'   => '0',
		),
		'dependency' => $blog_heading_dependency,
	),

	array(
		'id'         => 'blog_heading_font',
		'type'       => 'typography',
		'title'      => esc_html__( 'Blog Heading Font', 'lawyer' ),
		'std'        => array(
			'preview-text'  => 'Blog Heading',
			'preview-color' => 'light',
			'font-family'   => 'Frank Ruhl Libre',
			'font-weight'   => '400',
			'font-size'     => '48px',
			'line-height'   => '1',
			'color'         => '#2d3849',
			'css-selectors' => '.blog-heading-section h2',
		),
		'dependency' => $blog_heading_dependency,
	),

	array(
		'id'         => 'blog_subheading_font',
		'type'       => 'typography',
		'title'      => esc_html__( 'Blog SubHeading Font', 'lawyer' ),
		'std'        => array(
			'preview-text'  => 'Blog SubHeading',
			'preview-color' => 'light',
			'font-family'   => 'Roboto',
			'font-weight'   => '400',
			'font-size'     => '20px',
			'line-height'   => '35px',
			'color'         => '#2d3849',
			'css-selectors' => '.blog-heading-section p',
		),
		'dependency' => $blog_heading_dependency,
	),

);
