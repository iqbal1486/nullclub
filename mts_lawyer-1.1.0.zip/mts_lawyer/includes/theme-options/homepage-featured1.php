<?php
/**
 * HomePage Featured1 Section
 *
 * @package Lawyer
 */

$menus['homepage']['child']['homepage-featured1'] = array(
	'title' => esc_html__( 'Featured 1', 'lawyer' ),
	'desc'  => esc_html__( 'From here, you can control the elements of the Featured 1 section.', 'lawyer' ),
);

$sections['homepage-featured1'] = array(

	array(
		'id'       => 'featured1_background',
		'type'     => 'background',
		'title'    => esc_html__( 'Featured 1 Section Background', 'lawyer' ),
		'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'lawyer' ),
		'options'  => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'      => array(
			'color'         => '',
			'use'           => 'upload',
			'image_pattern' => 'nobg',
			'image_upload'  => get_template_directory_uri() . '/images/featured1-bg.jpg',
			'repeat'        => 'no-repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
	),

	array(
		'id'       => 'featured1_title',
		'type'     => 'textarea',
		'title'    => esc_html__( 'Title', 'lawyer' ),
		'sub_desc' => esc_html__( 'Enter title for featured1 section.', 'lawyer' ),
		'std'      => 'You Deserve the Best<br>Defence Lawyers.',
	),
	array(
		'id'    => 'featured1_title_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Title Font', 'lawyer' ),
		'std'   => array(
			'preview-text'  => 'Title',
			'preview-color' => 'light',
			'font-family'   => 'Frank Ruhl Libre',
			'font-weight'   => '400',
			'font-size'     => '80px',
			'line-height'   => '80px',
			'color'         => '#2d3849',
			'css-selectors' => '.featured1-section h2',
		),
	),

	array(
		'id'       => 'featured1_text',
		'type'     => 'textarea',
		'title'    => esc_html__( 'Text', 'lawyer' ),
		'sub_desc' => esc_html__( 'Enter text for featured1 section.', 'lawyer' ),
		'std'      => 'Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Donec lacinia ligula orci, ut pharetra nunc rutrum sed.',
	),
	array(
		'id'    => 'featured1_text_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Text Font', 'lawyer' ),
		'std'   => array(
			'preview-text'  => 'Text',
			'preview-color' => 'light',
			'font-family'   => 'Roboto',
			'font-weight'   => '400',
			'font-size'     => '20px',
			'line-height'   => '35px',
			'color'         => '#2d3849',
			'css-selectors' => '.featured1-section p',
		),
	),

	array(
		'id'       => 'featured1_button_text',
		'type'     => 'text',
		'title'    => esc_html__( 'Button Text', 'lawyer' ),
		'sub_desc' => esc_html__( 'Enter button text.', 'lawyer' ),
		'std'      => 'Contact us now',
	),

	array(
		'id'       => 'featured1_button_url',
		'type'     => 'text',
		'title'    => esc_html__( 'Button URL', 'lawyer' ),
		'sub_desc' => esc_html__( 'Enter button URL.', 'lawyer' ),
		'std'      => '#',
	),

	array(
		'id'       => 'featured1_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Padding', 'lawyer' ),
		'sub_desc' => esc_html__( 'Set featured1 section padding from here.', 'lawyer' ),
		'std'      => array(
			'top'    => '164px',
			'right'  => '0',
			'bottom' => '134px',
			'left'   => '0',
		),
	),

);
