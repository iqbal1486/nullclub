<?php
/**
 * HomePage Tab
 *
 * @package Lawyer
 */

$menus['homepage'] = array(
	'icon'  => 'fa-home',
	'title' => esc_html__( 'Homepage', 'lawyer' ),
);

$menus['homepage']['child']['homepage-sections'] = array(
	'title' => esc_html__( 'Homepage Sections', 'lawyer' ),
	'desc'  => esc_html__( 'From here, you can control the elements of the Homepage Sections.', 'lawyer' ),
);

$sections['homepage-sections'] = array(

	array(
		'id'       => 'homepage_layout',
		'type'     => 'layout',
		'title'    => esc_html__( 'Homepage Section Manager', 'lawyer' ),
		'sub_desc' => esc_html__( 'Organize how you want the sections to appear on the homepage', 'lawyer' ),
		'options'  => array(
			'enabled'  => array(
				'featured2'      => esc_html__( 'Featured 2', 'lawyer' ),
				'icon-grid'      => esc_html__( 'Icon Grid', 'lawyer' ),
				'services-grid'  => esc_html__( 'Services Grid', 'lawyer' ),
				'cta'            => esc_html__( 'Call to Action', 'lawyer' ),
				'services-list'  => esc_html__( 'Services List', 'lawyer' ),
				'stats'          => esc_html__( 'Stats', 'lawyer' ),
				'stats2'         => esc_html__( 'Stats 2', 'lawyer' ),
				'team'           => esc_html__( 'Team', 'lawyer' ),
				'services-grid2' => esc_html__( 'Services Grid 2', 'lawyer' ),
				'blog'           => esc_html__( 'Blog Section', 'lawyer' ),
				'featured-on'    => esc_html__( 'Featured On', 'lawyer' ),
				'featured3'      => esc_html__( 'Featured 3', 'lawyer' ),
				'why-us'         => esc_html__( 'Why Us', 'lawyer' ),
				'faqs'           => esc_html__( 'FAQs', 'lawyer' ),
			),
			'disabled' => array(
				'featured1' => esc_html__( 'Featured 1', 'lawyer' ),
			),
		),
		'std'      => array(
			'enabled'  => array(
				'featured2'      => esc_html__( 'Featured 2', 'lawyer' ),
				'icon-grid'      => esc_html__( 'Icon Grid', 'lawyer' ),
				'services-grid'  => esc_html__( 'Services Grid', 'lawyer' ),
				'cta'            => esc_html__( 'Call to Action', 'lawyer' ),
				'services-list'  => esc_html__( 'Services List', 'lawyer' ),
				'stats'          => esc_html__( 'Stats', 'lawyer' ),
				'stats2'         => esc_html__( 'Stats 2', 'lawyer' ),
				'team'           => esc_html__( 'Team', 'lawyer' ),
				'services-grid2' => esc_html__( 'Services Grid 2', 'lawyer' ),
				'blog'           => esc_html__( 'Blog Section', 'lawyer' ),
				'featured-on'    => esc_html__( 'Featured On', 'lawyer' ),
				'featured3'      => esc_html__( 'Featured 3', 'lawyer' ),
				'why-us'         => esc_html__( 'Why Us', 'lawyer' ),
				'faqs'           => esc_html__( 'FAQs', 'lawyer' ),
			),
			'disabled' => array(
				'featured1' => esc_html__( 'Featured 1', 'lawyer' ),
			),
		),
	),
);
