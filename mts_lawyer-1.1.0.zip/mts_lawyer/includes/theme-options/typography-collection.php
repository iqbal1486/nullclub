<?php
/**
 * Typography tab
 *
 * @package Lawyer
 */

$menus['typography-collection'] = array(
	'icon'       => 'fa-text-width',
	'title'      => esc_html__( 'Typography', 'lawyer' ),
	'hide_title' => true,
);

$sections['typography-collection'] = array(

	array(
		'id'    => 'typography-collections',
		'type'  => 'typography_collections',
		'title' => esc_html__( 'Theme Typography', 'lawyer' ),
		'desc'  => esc_html__( 'From here, you can control the fonts used on your site. You can choose from 17 standard font sets, or from the Google Fonts Library containing 800+ fonts.', 'lawyer' ),
	),

	array(
		'id'    => 'lawyer_logo',
		'type'  => 'typography',
		'title' => esc_html__( 'Logo Font', 'lawyer' ),
		'std'   => array(
			'preview-text'   => 'Logo',
			'preview-color'  => 'dark',
			'font-family'    => 'Frank Ruhl Libre',
			'font-weight'    => '700',
			'font-size'      => '34px',
			'color'          => '#ffffff',
			'additional-css' => 'text-transform: uppercase;',
			'css-selectors'  => '#logo a',
		),
	),

	array(
		'id'    => 'secondary_navigation_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Secondary Navigation', 'lawyer' ),
		'std'   => array(
			'preview-text'   => 'Secondary Navigation Font',
			'preview-color'  => 'dark',
			'font-family'    => 'Roboto',
			'font-weight'    => '700',
			'font-size'      => '14px',
			'color'          => '#ffffff',
			'additional-css' => 'text-transform: uppercase;',
			'css-selectors'  => '#secondary-navigation li',
		),
	),

	array(
		'id'    => 'home_title_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Archive Article Titles', 'lawyer' ),
		'std'   => array(
			'preview-text'  => 'Archive Article Title',
			'preview-color' => 'light',
			'font-family'   => 'Frank Ruhl Libre',
			'font-weight'   => '700',
			'font-size'     => '40px',
			'line-height'   => '46px',
			'color'         => '#2e2f36',
			'css-selectors' => '.latestPost .title a',
		),
	),

	array(
		'id'    => 'content_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Content Font', 'lawyer' ),
		'std'   => array(
			'preview-text'  => 'Content Font',
			'preview-color' => 'light',
			'font-family'   => 'Roboto',
			'font-weight'   => '400',
			'font-size'     => '16px',
			'line-height'   => '30px',
			'color'         => '#2d3849',
			'css-selectors' => 'body',
		),
	),

	array(
		'id'    => 'sidebar_title_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Sidebar Widget Title', 'lawyer' ),
		'std'   => array(
			'preview-text'   => 'Sidebar Title Font',
			'preview-color'  => 'light',
			'font-family'    => 'Roboto',
			'font-weight'    => '700',
			'font-size'      => '13px',
			'letter-spacing' => '1px',
			'color'          => '#2d3849',
			'additional-css' => 'text-transform: uppercase;',
			'css-selectors'  => '#sidebar .widget h3.widget-title, #sidebar .widget h3.widget-title a, #sidebar .widget #wp-subscribe .title',
		),
	),

	array(
		'id'    => 'mts_widget_links',
		'type'  => 'typography',
		'title' => esc_html__( 'MTS Widgets Links', 'lawyer' ),
		'std'   => array(
			'preview-text'   => 'Sidebar Links',
			'preview-color'  => 'light',
			'font-family'    => 'Frank Ruhl Libre',
			'font-weight'    => '400',
			'font-size'      => '16px',
			'line-height'    => '20px',
			'color'          => '#2d3349',
			'additional-css' => 'text-transform: none;',
			'css-selectors'  => '#sidebar .widget li.horizontal-small a, #sidebar .widget li.horizontal-small, #sidebar .widget .wpt_widget_content .entry-title a, #sidebar .widget .wp_review_tab_widget_content .entry-title a',
		),
	),

	array(
		'id'    => 'default_widget_links',
		'type'  => 'typography',
		'title' => esc_html__( 'Default Widgets Link', 'lawyer' ),
		'std'   => array(
			'preview-text'   => 'Default Widgets',
			'preview-color'  => 'light',
			'font-family'    => 'Roboto',
			'font-weight'    => '400',
			'font-size'      => '13px',
			'line-height'    => '30px',
			'color'          => '#2d3849',
			'additional-css' => 'text-transform: uppercase;',
			'css-selectors'  => '#sidebar .widget li a, #sidebar .widget.widget_categories li a, #sidebar .widget.widget_archive li a, #sidebar .widget.widget_pages li a, #sidebar .widget.widget_meta li a, #sidebar .widget.widget_recent_comments li a, #sidebar .widget.widget_recent_entries li a, #sidebar .widget.widget_rss, #sidebar .widget.widget_nav_menu li a',
		),
	),

	array(
		'id'    => 'sidebar_url_bigthumb',
		'type'  => 'typography',
		'title' => esc_html__( 'Sidebar Links on Big Thumb', 'lawyer' ),
		'std'   => array(
			'preview-text'  => 'Sidebar Links Big Thumb',
			'preview-color' => 'light',
			'font-family'   => 'Frank Ruhl Libre',
			'font-weight'   => '400',
			'font-size'     => '20px',
			'line-height'   => '24px',
			'color'         => '#2d3349',
			'css-selectors' => '#sidebar .widget .vertical-small a, #sidebar .widget li.vertical-small, #sidebar .widget .review_thumb_large .entry-title a, .f-widget .widget .vertical-small a, .f-widget .widget .vertical-small li, .f-widget .widget .review_thumb_large .entry-title a',
		),
	),

	array(
		'id'    => 'sidebar_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Sidebar Font', 'lawyer' ),
		'std'   => array(
			'preview-text'  => 'Sidebar Font',
			'preview-color' => 'light',
			'font-family'   => 'Roboto',
			'font-weight'   => '400',
			'font-size'     => '14px',
			'line-height'   => '30px',
			'color'         => '#2d3849',
			'css-selectors' => '#sidebar .widget p, #sidebar .widget .post-excerpt, #sidebar .widget #wp-subscribe p.text, #sidebar .wp-subscribe-wrap .wps-consent-wrapper label, #sidebar .wp-subscribe-wrap p.footer-text',
		),
	),

	array(
		'id'    => 'sidebar_font_bigthumb',
		'type'  => 'typography',
		'title' => esc_html__( 'Sidebar Font bigthumb', 'lawyer' ),
		'std'   => array(
			'preview-text'  => 'Sidebar Font bigthumb',
			'preview-color' => 'light',
			'font-family'   => 'Roboto',
			'font-weight'   => '400',
			'font-size'     => '16px',
			'line-height'   => '24px',
			'color'         => '#2d3849',
			'css-selectors' => '#sidebar .widget .vertical-small p, #sidebar .widget .vertical-small .post-excerpt, .f-widget .widget .vertical-small p, .f-widget .widget .vertical-small .post-excerpt',
		),
	),

	array(
		'id'    => 'sidebar_postinfo_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Sidebar Postinfo Font', 'lawyer' ),
		'std'   => array(
			'preview-text'   => 'Sidebar Postinfo Font',
			'preview-color'  => 'light',
			'font-family'    => 'Roboto',
			'font-weight'    => '700',
			'font-size'      => '11px',
			'line-height'    => '14px',
			'color'          => '#abaeb3',
			'additional-css' => 'text-transform: uppercase;',
			'css-selectors'  => '#sidebar .widget .post-info, #sidebar .widget .post-info a, #sidebar .wpt_widget_content .wpt-postmeta',
		),
	),

	array(
		'id'    => 'sidebar_postinfo_font_bigthumb',
		'type'  => 'typography',
		'title' => esc_html__( 'Sidebar Postinfo Font bigthumb', 'lawyer' ),
		'std'   => array(
			'preview-text'   => 'Sidebar Postinfo Font bigthumb',
			'preview-color'  => 'light',
			'font-family'    => 'Roboto',
			'font-weight'    => '700',
			'font-size'      => '11px',
			'line-height'    => '14px',
			'color'          => '#abaeb3',
			'additional-css' => 'text-transform: uppercase;',
			'css-selectors'  => '#sidebar .widget .vertical-small .post-info, #sidebar .widget .vertical-small .post-info a, .f-widget .widget .vertical-small .post-info, .f-widget .widget .vertical-small .post-info a, .widget .wp_review_tab_widget_content .review_thumb_large .wp-review-tab-postmeta, .wpt_comment_content, .wpt_excerpt',
		),
	),

	array(
		'id'    => 'tabs_title_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Tabs Title', 'lawyer' ),
		'std'   => array(
			'preview-text'   => 'Tabs Title Font',
			'preview-color'  => 'light',
			'font-family'    => 'Frank Ruhl Libre',
			'font-weight'    => '500',
			'font-size'      => '15px',
			'color'          => '#9298a1',
			'additional-css' => 'text-transform: uppercase;',
			'css-selectors'  => '#sidebar .widget .wp_review_tab_widget_content .tab_title a, #sidebar .widget .wpt_widget_content .tab_title a, .f-widget .widget .wp_review_tab_widget_content .tab_title a, .f-widget .widget .wpt_widget_content .tab_title a',
		),
	),

	array(
		'id'    => 'top_footer_title_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Footer Widget Title', 'lawyer' ),
		'std'   => array(
			'preview-text'   => 'Footer Title Font',
			'preview-color'  => 'dark',
			'font-family'    => 'Roboto',
			'font-weight'    => '700',
			'font-size'      => '16px',
			'margin-bottom'  => '30px',
			'color'          => lawyer_get_settings( 'primary_color_scheme' ),
			'additional-css' => 'text-transform: uppercase;',
			'css-selectors'  => '.footer-widgets h3, #site-footer .widget #wp-subscribe .title, .brands-title',
		),
	),

	array(
		'id'    => 'top_footer_link_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Footer Link', 'lawyer' ),
		'std'   => array(
			'preview-text'   => 'Footer Links',
			'preview-color'  => 'dark',
			'font-family'    => 'Roboto',
			'font-weight'    => '400',
			'font-size'      => '16px',
			'line-height'    => '24px',
			'color'          => '#ffffff',
			'additional-css' => 'text-transform: uppercase;',
			'css-selectors'  => '.f-widget a, footer .wpt_widget_content a, footer .wp_review_tab_widget_content a, footer .wpt_tab_widget_content a, footer .widget .wp_review_tab_widget_content a',
		),
	),

	array(
		'id'    => 'top_footer_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Footer font', 'lawyer' ),
		'std'   => array(
			'preview-text'   => 'Footer Font',
			'preview-color'  => 'dark',
			'font-family'    => 'Roboto',
			'font-weight'    => '400',
			'font-size'      => '14px',
			'line-height'    => '26px',
			'color'          => '#ffffff',
			'additional-css' => 'opacity: 0.8;',
			'css-selectors'  => '.footer-widgets, .f-widget .top-posts .comment_num, footer .meta, footer .twitter_time, footer .widget .wpt_widget_content .wpt-postmeta, footer .widget .wpt_comment_content, footer .widget .wpt_excerpt, footer .wp_review_tab_widget_content .wp-review-tab-postmeta, footer .advanced-recent-posts p, footer .popular-posts p, footer .category-posts p, footer .widget .post-info',
		),
	),

	array(
		'id'    => 'copyrights_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Copyrights Section', 'lawyer' ),
		'std'   => array(
			'preview-text'   => 'Copyrights Font',
			'preview-color'  => 'dark',
			'font-family'    => 'Roboto',
			'font-weight'    => '700',
			'font-size'      => '14px',
			'color'          => '#ffffff',
			'additional-css' => 'text-transform: uppercase;',
			'css-selectors'  => '#copyright-note',
		),
	),

	array(
		'id'    => 'h1_headline',
		'type'  => 'typography',
		'title' => esc_html__( 'H1 Heading in Content', 'lawyer' ),
		'std'   => array(
			'preview-text'  => 'H1 Headline',
			'preview-color' => 'light',
			'font-family'   => 'Frank Ruhl Libre',
			'font-weight'   => '700',
			'font-size'     => '36px',
			'color'         => '#2d3849',
			'css-selectors' => 'h1',
		),
	),

	array(
		'id'    => 'h2_headline',
		'type'  => 'typography',
		'title' => esc_html__( 'H2 Heading in Content', 'lawyer' ),
		'std'   => array(
			'preview-text'  => 'H2 Headline',
			'preview-color' => 'light',
			'font-family'   => 'Frank Ruhl Libre',
			'font-weight'   => '700',
			'font-size'     => '34px',
			'color'         => '#2d3849',
			'css-selectors' => 'h2',
		),
	),

	array(
		'id'    => 'h3_headline',
		'type'  => 'typography',
		'title' => esc_html__( 'H3 Heading in Content', 'lawyer' ),
		'std'   => array(
			'preview-text'  => 'H3 Headline',
			'preview-color' => 'light',
			'font-family'   => 'Frank Ruhl Libre',
			'font-weight'   => '700',
			'font-size'     => '32px',
			'color'         => '#2d3849',
			'css-selectors' => 'h3',
		),
	),

	array(
		'id'    => 'h4_headline',
		'type'  => 'typography',
		'title' => esc_html__( 'H4 Heading in Content', 'lawyer' ),
		'std'   => array(
			'preview-text'  => 'H4 Headline',
			'preview-color' => 'light',
			'font-family'   => 'Frank Ruhl Libre',
			'font-weight'   => '700',
			'font-size'     => '30px',
			'color'         => '#2d3849',
			'css-selectors' => 'h4',
		),
	),

	array(
		'id'    => 'h5_headline',
		'type'  => 'typography',
		'title' => esc_html__( 'H5 Heading in Content', 'lawyer' ),
		'std'   => array(
			'preview-text'  => 'H5 Headline',
			'preview-color' => 'light',
			'font-family'   => 'Frank Ruhl Libre',
			'font-weight'   => '700',
			'font-size'     => '28px',
			'color'         => '#2d3849',
			'css-selectors' => 'h5',
		),
	),

	array(
		'id'    => 'h6_headline',
		'type'  => 'typography',
		'title' => esc_html__( 'H6 Heading in Content', 'lawyer' ),
		'std'   => array(
			'preview-text'  => 'H6 Headline',
			'preview-color' => 'light',
			'font-family'   => 'Frank Ruhl Libre',
			'font-weight'   => '700',
			'font-size'     => '24px',
			'color'         => '#2d3849',
			'css-selectors' => 'h6, blockquote',
		),
	),

	array(
		'id'       => 'typography-subsets',
		'type'     => 'multi_checkbox',
		'title'    => esc_html__( 'Character sets', 'lawyer' ),
		'sub_desc' => esc_html__( 'Choose the character sets you wish to include. Please note that not all sets are available for all fonts.', 'lawyer' ),
		'options'  => array(
			'latin'        => esc_html__( 'Latin', 'lawyer' ),
			'latin-ext'    => esc_html__( 'Latin Extended', 'lawyer' ),
			'cyrillic'     => esc_html__( 'Cyrillic', 'lawyer' ),
			'cyrillic-ext' => esc_html__( 'Cyrillic Extended', 'lawyer' ),
			'greek'        => esc_html__( 'Greek', 'lawyer' ),
			'greek-ext'    => esc_html__( 'Greek Extended', 'lawyer' ),
			'vietnamese'   => esc_html__( 'Vietnamese', 'lawyer' ),
			'khmer'        => esc_html__( 'Khmer', 'lawyer' ),
			'devanagari'   => esc_html__( 'Devanagari', 'lawyer' ),
		),
		'std'      => array( 'latin' ),
	),
);
