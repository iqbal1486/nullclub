<?php
/**
 * HomePage Stats 2 Section
 *
 * @package Lawyer
 */

$menus['homepage']['child']['homepage-stats2'] = array(
	'title' => esc_html__( 'Stats 2', 'lawyer' ),
	'desc'  => esc_html__( 'From here, you can control the elements of the stats section.', 'lawyer' ),
);

$sections['homepage-stats2'] = array(

	// Left section.
	array(
		'id'    => 'stats2_left_heading',
		'type'  => 'heading',
		'title' => esc_html__( 'Left Section', 'lawyer' ),
	),

	array(
		'id'       => 'stats2_left_icon',
		'type'     => 'icon_select',
		'title'    => esc_html__( 'Icon', 'lawyer' ),
		'sub_desc' => esc_html__( 'Select an icon for left section.', 'lawyer' ),
		'std'      => 'institution',
	),

	array(
		'id'       => 'stats2_left_figure',
		'type'     => 'text',
		'title'    => esc_html__( 'Stats 2', 'lawyer' ),
		'sub_desc' => esc_html__( 'Enter stats figure 2.', 'lawyer' ),
		'std'      => '$325,000',
	),
	array(
		'id'       => 'stats2_left_title',
		'type'     => 'text',
		'title'    => esc_html__( 'Stats Title', 'lawyer' ),
		'sub_desc' => esc_html__( 'Set stats title.', 'lawyer' ),
		'std'      => 'Recovered to clients',
	),
	array(
		'id'       => 'stats2_left_text',
		'type'     => 'textarea',
		'title'    => esc_html__( 'Stats Text', 'lawyer' ),
		'sub_desc' => esc_html__( 'Set stats text.', 'lawyer' ),
		'std'      => 'Our lawyers will also represent you in civil litigation cases such as divorce, child and spouse maintenance.',
	),

	array(
		'id'    => 'stats2_left_figure_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Stats Figure Font', 'lawyer' ),
		'std'   => array(
			'preview-text'  => 'Stats Figure',
			'preview-color' => 'dark',
			'font-family'   => 'Frank Ruhl Libre',
			'font-weight'   => '400',
			'font-size'     => '80px',
			'color'         => '#ffffff',
			'line-height'   => '1',
			'css-selectors' => '.stats2-section .left .figure',
		),
	),
	array(
		'id'    => 'stats2_left_title_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Stats Title Font', 'lawyer' ),
		'std'   => array(
			'preview-text'   => 'Stats Title',
			'preview-color'  => 'dark',
			'font-family'    => 'Roboto',
			'font-weight'    => '400',
			'font-size'      => '18px',
			'line-height'    => '35px',
			'color'          => '#ffffff',
			'additional-css' => 'text-transform: uppercase;',
			'css-selectors'  => '.stats2-section .left h2',
		),
	),
	array(
		'id'    => 'stats2_left_text_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Stats Text Font', 'lawyer' ),
		'std'   => array(
			'preview-text'  => 'Stats Text',
			'preview-color' => 'dark',
			'font-family'   => 'Roboto',
			'font-weight'   => '400',
			'font-size'     => '16px',
			'line-height'   => '26px',
			'color'         => '#ffffff',
			'css-selectors' => '.stats2-section .left p',
		),
	),

	array(
		'id'       => 'stats2_left_button_text',
		'type'     => 'text',
		'title'    => esc_html__( 'Button Text', 'lawyer' ),
		'sub_desc' => esc_html__( 'Enter button text.', 'lawyer' ),
		'std'      => 'Contact us now',
	),

	array(
		'id'       => 'stats2_left_button_url',
		'type'     => 'text',
		'title'    => esc_html__( 'Button URL', 'lawyer' ),
		'sub_desc' => esc_html__( 'Enter button URL.', 'lawyer' ),
		'std'      => '#',
	),

	array(
		'id'       => 'stats2_left_background',
		'type'     => 'background',
		'title'    => esc_html__( 'Section Background', 'lawyer' ),
		'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'lawyer' ),
		'options'  => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'      => array(
			'color'         => '',
			'use'           => 'upload',
			'image_pattern' => 'nobg',
			'image_upload'  => get_template_directory_uri() . '/images/stats2-left-bg.jpg',
			'repeat'        => 'no-repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
	),

	array(
		'id'       => 'stats2_left_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Padding', 'lawyer' ),
		'sub_desc' => esc_html__( 'Set stats section padding from here.', 'lawyer' ),
		'std'      => array(
			'top'    => '74px',
			'right'  => '110px',
			'bottom' => '74px',
			'left'   => '150px',
		),
	),

	// Right section.
	array(
		'id'    => 'stats2_right_heading',
		'type'  => 'heading',
		'title' => esc_html__( 'Left Section', 'lawyer' ),
	),

	array(
		'id'       => 'stats2_right_icon',
		'type'     => 'icon_select',
		'title'    => esc_html__( 'Icon', 'lawyer' ),
		'sub_desc' => esc_html__( 'Select an icon for left section.', 'lawyer' ),
		'std'      => 'institution',
	),

	array(
		'id'       => 'stats2_right_figure',
		'type'     => 'text',
		'title'    => esc_html__( 'Stats 2', 'lawyer' ),
		'sub_desc' => esc_html__( 'Enter stats figure 2.', 'lawyer' ),
		'std'      => '$125,000',
	),
	array(
		'id'       => 'stats2_right_title',
		'type'     => 'text',
		'title'    => esc_html__( 'Stats Title', 'lawyer' ),
		'sub_desc' => esc_html__( 'Set stats title.', 'lawyer' ),
		'std'      => 'Recovered to clients',
	),
	array(
		'id'       => 'stats2_right_text',
		'type'     => 'textarea',
		'title'    => esc_html__( 'Stats Text', 'lawyer' ),
		'sub_desc' => esc_html__( 'Set stats text.', 'lawyer' ),
		'std'      => 'Our lawyers will also represent you in civil litigation cases such as divorce, child and spouse maintenance.',
	),

	array(
		'id'    => 'stats2_right_figure_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Stats Figure Font', 'lawyer' ),
		'std'   => array(
			'preview-text'  => 'Stats Figure',
			'preview-color' => 'light',
			'font-family'   => 'Frank Ruhl Libre',
			'font-weight'   => '400',
			'font-size'     => '80px',
			'color'         => '#2d3849',
			'line-height'   => '1',
			'css-selectors' => '.stats2-section .right .figure',
		),
	),
	array(
		'id'    => 'stats2_right_title_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Stats Title Font', 'lawyer' ),
		'std'   => array(
			'preview-text'   => 'Stats Title',
			'preview-color'  => 'light',
			'font-family'    => 'Roboto',
			'font-weight'    => '400',
			'font-size'      => '18px',
			'line-height'    => '35px',
			'color'          => '#2d3849',
			'additional-css' => 'text-transform: uppercase;',
			'css-selectors'  => '.stats2-section .right h2',
		),
	),
	array(
		'id'    => 'stats2_right_text_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Stats Text Font', 'lawyer' ),
		'std'   => array(
			'preview-text'  => 'Stats Text',
			'preview-color' => 'light',
			'font-family'   => 'Roboto',
			'font-weight'   => '400',
			'font-size'     => '16px',
			'line-height'   => '26px',
			'color'         => '#2d3849',
			'css-selectors' => '.stats2-section .right p',
		),
	),

	array(
		'id'       => 'stats2_right_button_text',
		'type'     => 'text',
		'title'    => esc_html__( 'Button Text', 'lawyer' ),
		'sub_desc' => esc_html__( 'Enter button text.', 'lawyer' ),
		'std'      => 'Contact us now',
	),

	array(
		'id'       => 'stats2_right_button_url',
		'type'     => 'text',
		'title'    => esc_html__( 'Button URL', 'lawyer' ),
		'sub_desc' => esc_html__( 'Enter button URL.', 'lawyer' ),
		'std'      => '#',
	),

	array(
		'id'       => 'stats2_right_background',
		'type'     => 'background',
		'title'    => esc_html__( 'Section Background', 'lawyer' ),
		'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'lawyer' ),
		'options'  => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'      => array(
			'color'         => '',
			'use'           => 'upload',
			'image_pattern' => 'nobg',
			'image_upload'  => get_template_directory_uri() . '/images/stats2-right-bg.jpg',
			'repeat'        => 'no-repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
	),

	array(
		'id'       => 'stats2_right_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Padding', 'lawyer' ),
		'sub_desc' => esc_html__( 'Set padding from here.', 'lawyer' ),
		'std'      => array(
			'top'    => '74px',
			'right'  => '150px',
			'bottom' => '74px',
			'left'   => '110px',
		),
	),

);
