<?php
/**
 * Social Tab
 *
 * @package Lawyer
 */

$menus['social'] = array(
	'icon'  => 'fa-users',
	'title' => esc_html__( 'Social Share', 'lawyer' ),
	'desc'  => esc_html__( 'Enable or disable social sharing buttons on single posts using these buttons.', 'lawyer' ),
);

$menus['social']['child']['social-general'] = array(
	'title' => esc_html__( 'General', 'lawyer' ),
	'desc'  => esc_html__( 'From here, you can control the elements of social sharing buttons.', 'lawyer' ),
);

$sections['social-general'] = array(

	array(
		'id'       => 'social_button_layout',
		'type'     => 'radio_img',
		'title'    => esc_html__( 'Social Sharing Buttons Layout', 'lawyer' ),
		'sub_desc' => wp_kses( __( 'Choose default <strong>social sharing buttons</strong> layout or modern <strong>social sharing buttons</strong> layout for your site. ', 'lawyer' ), array( 'strong' => array() ) ),
		'options'  => array(
			'default'  => array( 'img' => $uri . 'social/default.jpg' ),
			'standard' => array( 'img' => $uri . 'social/standard.jpg' ),
			'circular' => array( 'img' => $uri . 'social/circular.jpg' ),
		),
		'std'      => 'standard',
	),

	array(
		'id'       => 'mts_social_button_position',
		'type'     => 'button_set',
		'title'    => esc_html__( 'Social Sharing Buttons Position', 'lawyer' ),
		'options'  => array(
			'top'      => esc_html__( 'Above Content', 'lawyer' ),
			'bottom'   => esc_html__( 'Below Content', 'lawyer' ),
			'floating' => esc_html__( 'Floating', 'lawyer' ),
		),
		'sub_desc' => esc_html__( 'Choose position for Social Sharing Buttons.', 'lawyer' ),
		'std'      => 'bottom',
		'class'    => 'green',
	),

	array(
		'id'       => 'mts_social_buttons_on_pages',
		'type'     => 'button_set',
		'title'    => esc_html__( 'Social Sharing Buttons on Pages', 'lawyer' ),
		'options'  => array(
			'0' => esc_html__( 'Off', 'lawyer' ),
			'1' => esc_html__( 'On', 'lawyer' ),
		),
		'sub_desc' => esc_html__( 'Enable the sharing buttons for pages too, not just posts.', 'lawyer' ),
		'std'      => '0',
	),

	array(
		'id'       => 'mts_social_buttons',
		'type'     => 'layout',
		'title'    => esc_html__( 'Social Media Buttons', 'lawyer' ),
		'sub_desc' => esc_html__( 'Organize how you want the social sharing buttons to appear on single posts', 'lawyer' ),
		'options'  => array(
			'enabled'  => array(
				'facebookshare' => esc_html__( 'Facebook Share', 'lawyer' ),
				'twitter'       => esc_html__( 'Twitter', 'lawyer' ),
				'pinterest'     => esc_html__( 'Pinterest', 'lawyer' ),
				'reddit'        => esc_html__( 'Reddit', 'lawyer' ),
			),
			'disabled' => array(
				'facebook' => esc_html__( 'Facebook Like', 'lawyer' ),
				'linkedin' => esc_html__( 'LinkedIn', 'lawyer' ),
				'stumble'  => esc_html__( 'StumbleUpon', 'lawyer' ),
			),
		),
		'std'      => array(
			'enabled'  => array(
				'facebookshare' => esc_html__( 'Facebook Share', 'lawyer' ),
				'twitter'       => esc_html__( 'Twitter', 'lawyer' ),
				'pinterest'     => esc_html__( 'Pinterest', 'lawyer' ),
				'reddit'        => esc_html__( 'Reddit', 'lawyer' ),
			),
			'disabled' => array(
				'facebook' => esc_html__( 'Facebook Like', 'lawyer' ),
				'linkedin' => esc_html__( 'LinkedIn', 'lawyer' ),
				'stumble'  => esc_html__( 'StumbleUpon', 'lawyer' ),
			),
		),
	),

);
