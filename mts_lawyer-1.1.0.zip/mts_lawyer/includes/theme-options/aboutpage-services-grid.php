<?php
/**
 * About Page Services Grid Section
 *
 * @package Lawyer
 */

$menus['aboutpage']['child']['aboutpage-services-grid'] = array(
	'title' => esc_html__( 'Services Grid', 'lawyer' ),
	'desc'  => esc_html__( 'From here, you can control the elements of the About Services Grid section.', 'lawyer' ),
);

$sections['aboutpage-services-grid'] = array(

	array(
		'id'       => 'about_services_grid_background',
		'type'     => 'background',
		'title'    => esc_html__( 'Section Background', 'lawyer' ),
		'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'lawyer' ),
		'options'  => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'      => array(
			'color'         => '#ffffff',
			'use'           => 'pattern',
			'image_pattern' => 'nobg',
			'image_upload'  => '',
			'repeat'        => 'repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
	),

	array(
		'id'        => 'about_services_group',
		'type'      => 'group',
		'title'     => esc_html__( 'About Services Grid', 'lawyer' ),
		'sub_desc'  => esc_html__( 'Add grids appearing on the About Services Grid section.', 'lawyer' ),
		'groupname' => esc_html__( 'Service', 'lawyer' ),
		'subfields' => array(
			array(
				'id'    => 'about_services_group_title',
				'type'  => 'text',
				'title' => esc_html__( 'Title', 'lawyer' ),
			),
			array(
				'id'       => 'about_services_group_image',
				'type'     => 'upload',
				'title'    => esc_html__( 'Upload Image', 'lawyer' ),
				'sub_desc' => esc_html__( 'Select an image file. Recommended size: 255 X 275', 'lawyer' ),
			),
			array(
				'id'    => 'about_services_group_icon',
				'type'  => 'icon_select',
				'title' => esc_html__( 'Select Icon', 'lawyer' ),
			),
			array(
				'id'    => 'about_services_group_text',
				'type'  => 'text',
				'title' => esc_html__( 'Text', 'lawyer' ),
			),
			array(
				'id'    => 'about_services_group_url',
				'type'  => 'text',
				'title' => esc_html__( 'URL', 'lawyer' ),
			),
		),
		'std'       => array(
			'1' => array(
				'group_sort'                 => '1',
				'about_services_group_title' => 'In the court of law',
				'about_services_group_image' => get_template_directory_uri() . '/images/services-grid1.jpg',
				'about_services_group_icon'  => 'book',
				'about_services_group_text'  => 'Criminal law',
				'about_services_group_url'   => '#',
			),
			'2' => array(
				'group_sort'                 => '2',
				'about_services_group_title' => 'Medical Negligence',
				'about_services_group_image' => get_template_directory_uri() . '/images/services-grid2.jpg',
				'about_services_group_icon'  => 'book',
				'about_services_group_text'  => 'Medical Malpractice',
				'about_services_group_url'   => '#',
			),
			'3' => array(
				'group_sort'                 => '3',
				'about_services_group_title' => 'Family law',
				'about_services_group_image' => get_template_directory_uri() . '/images/services-grid3.jpg',
				'about_services_group_icon'  => 'book',
				'about_services_group_text'  => 'Insurance law',
				'about_services_group_url'   => '#',
			),
			'4' => array(
				'group_sort'                 => '4',
				'about_services_group_title' => 'Forclosure law',
				'about_services_group_image' => get_template_directory_uri() . '/images/services-grid4.jpg',
				'about_services_group_icon'  => 'book',
				'about_services_group_text'  => 'Real estate law',
				'about_services_group_url'   => '#',
			),
		),
	),

	array(
		'id'    => 'about_services_group_title_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Grid Title Font', 'lawyer' ),
		'std'   => array(
			'preview-text'   => 'Grid Title',
			'preview-color'  => 'light',
			'font-family'    => 'Roboto',
			'font-weight'    => '700',
			'font-size'      => '16px',
			'color'          => '#2d3349',
			'additional-css' => 'text-transform: uppercase;',
			'css-selectors'  => '.about-services-grid-container h3',
		),
	),
	array(
		'id'    => 'about_services_group_text_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Grid Text Font', 'lawyer' ),
		'std'   => array(
			'preview-text'   => 'Grid Text',
			'preview-color'  => 'light',
			'font-family'    => 'Roboto',
			'font-weight'    => '400',
			'font-size'      => '12px',
			'color'          => '#abadb3',
			'additional-css' => 'text-transform: uppercase;',
			'css-selectors'  => '.about-services-grid-container p',
		),
	),

	array(
		'id'       => 'about_services_grid_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Padding', 'lawyer' ),
		'sub_desc' => esc_html__( 'Set services grid section padding from here.', 'lawyer' ),
		'std'      => array(
			'top'    => '124px',
			'right'  => '0',
			'bottom' => '94px',
			'left'   => '0',
		),
	),

);
