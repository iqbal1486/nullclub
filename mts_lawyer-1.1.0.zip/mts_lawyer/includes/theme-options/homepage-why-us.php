<?php
/**
 * HomePage Why Us Section
 *
 * @package Lawyer
 */

$menus['homepage']['child']['homepage-why-us'] = array(
	'title' => esc_html__( 'Why Us', 'lawyer' ),
	'desc'  => esc_html__( 'From here, you can control the elements of the Why Us section.', 'lawyer' ),
);

$why_us_text = 'Our lawyers will also represent you in civil litigation cases.';

$sections['homepage-why-us'] = array(

	array(
		'id'       => 'why_us_background',
		'type'     => 'background',
		'title'    => esc_html__( 'Why Us Section Background', 'lawyer' ),
		'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'lawyer' ),
		'options'  => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'      => array(
			'color'         => '#ffffff',
			'use'           => 'pattern',
			'image_pattern' => 'nobg',
			'image_upload'  => '',
			'repeat'        => 'repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
	),

	array(
		'id'       => 'why_us_icon',
		'type'     => 'icon_select',
		'title'    => esc_html__( 'Icon', 'lawyer' ),
		'sub_desc' => esc_html__( 'Select an icon.', 'lawyer' ),
		'std'      => 'institution',
	),

	array(
		'id'       => 'why_us_title',
		'type'     => 'text',
		'title'    => esc_html__( 'Title', 'lawyer' ),
		'sub_desc' => esc_html__( 'Enter title for why us section.', 'lawyer' ),
		'std'      => 'Why Choose Us?',
	),
	array(
		'id'    => 'why_us_title_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Title Font', 'lawyer' ),
		'std'   => array(
			'preview-text'  => 'Title',
			'preview-color' => 'light',
			'font-family'   => 'Frank Ruhl Libre',
			'font-weight'   => '400',
			'font-size'     => '48px',
			'line-height'   => '56px',
			'color'         => '#2d3349',
			'css-selectors' => '.why-us-section h2',
		),
	),

	array(
		'id'       => 'why_us_text',
		'type'     => 'textarea',
		'title'    => esc_html__( 'Text', 'lawyer' ),
		'sub_desc' => esc_html__( 'Enter text for why us section.', 'lawyer' ),
		'std'      => 'Our Company offers only legal help and we act only in accordance with widely recognized moral priciples.',
	),
	array(
		'id'    => 'why_us_text_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Text Font', 'lawyer' ),
		'std'   => array(
			'preview-text'  => 'Text',
			'preview-color' => 'light',
			'font-family'   => 'Roboto',
			'font-weight'   => '400',
			'font-size'     => '20px',
			'line-height'   => '35px',
			'color'         => '#2d3349',
			'css-selectors' => '.why-us-section p',
		),
	),

	array(
		'id'        => 'why_us_left_items',
		'type'      => 'group',
		'title'     => esc_html__( 'Left List', 'lawyer' ),
		'sub_desc'  => esc_html__( 'Add list items appearing on the why us left section.', 'lawyer' ),
		'groupname' => esc_html__( 'List', 'lawyer' ),
		'subfields' => array(
			array(
				'id'    => 'why_us_left_title',
				'type'  => 'text',
				'title' => esc_html__( 'Title', 'lawyer' ),
			),
			array(
				'id'    => 'why_us_left_text',
				'type'  => 'textarea',
				'title' => esc_html__( 'Text', 'lawyer' ),
			),
			array(
				'id'    => 'why_us_left_icon',
				'type'  => 'icon_select',
				'title' => esc_html__( 'Select Icon', 'lawyer' ),
			),
		),
		'std'       => array(
			'1' => array(
				'group_sort'        => '1',
				'why_us_left_title' => 'Great Discount',
				'why_us_left_text'  => $why_us_text,
				'why_us_left_icon'  => 'get-pocket',
			),
			'2' => array(
				'group_sort'        => '2',
				'why_us_left_title' => 'Community Service',
				'why_us_left_text'  => $why_us_text,
				'why_us_left_icon'  => 'futbol-o',
			),
		),
	),

	array(
		'id'       => 'why_us_img',
		'type'     => 'upload',
		'title'    => esc_html__( 'Middle Image', 'lawyer' ),
		'sub_desc' => esc_html__( 'Select an image file. Recommended size: 276 X 266', 'lawyer' ),
		'return'   => 'url',
		'std'      => get_template_directory_uri() . '/images/justice-scale.jpg',
	),

	array(
		'id'        => 'why_us_right_items',
		'type'      => 'group',
		'title'     => esc_html__( 'Right List', 'lawyer' ),
		'sub_desc'  => esc_html__( 'Add list items appearing on the why us right section.', 'lawyer' ),
		'groupname' => esc_html__( 'List', 'lawyer' ),
		'subfields' => array(
			array(
				'id'    => 'why_us_right_title',
				'type'  => 'text',
				'title' => esc_html__( 'Title', 'lawyer' ),
			),
			array(
				'id'    => 'why_us_right_text',
				'type'  => 'textarea',
				'title' => esc_html__( 'Text', 'lawyer' ),
			),
			array(
				'id'    => 'why_us_right_icon',
				'type'  => 'icon_select',
				'title' => esc_html__( 'Select Icon', 'lawyer' ),
			),
		),
		'std'       => array(
			'1' => array(
				'group_sort'         => '1',
				'why_us_right_title' => 'Get Legal Advise',
				'why_us_right_text'  => $why_us_text,
				'why_us_right_icon'  => 'universal-access',
			),
			'2' => array(
				'group_sort'         => '2',
				'why_us_right_title' => 'Expert Lawyers',
				'why_us_right_text'  => $why_us_text,
				'why_us_right_icon'  => 'mortar-board',
			),
		),
	),

	array(
		'id'    => 'why_us_list_title_font',
		'type'  => 'typography',
		'title' => esc_html__( 'List Title Font', 'lawyer' ),
		'std'   => array(
			'preview-text'   => 'List Title',
			'preview-color'  => 'light',
			'font-family'    => 'Roboto',
			'font-weight'    => '700',
			'font-size'      => '20px',
			'color'          => '#2d3349',
			'additional-css' => 'text-transform: uppercase;',
			'css-selectors'  => '.why-us-section .list h3',
		),
	),
	array(
		'id'    => 'why_us_list_text_font',
		'type'  => 'typography',
		'title' => esc_html__( 'List Text Font', 'lawyer' ),
		'std'   => array(
			'preview-text'  => 'List Text',
			'preview-color' => 'light',
			'font-family'   => 'Roboto',
			'font-weight'   => '400',
			'font-size'     => '16px',
			'line-height'   => '26px',
			'color'         => '#2d3349',
			'css-selectors' => '.why-us-section .list p',
		),
	),

	array(
		'id'       => 'why_us_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Padding', 'lawyer' ),
		'sub_desc' => esc_html__( 'Set why us section padding from here.', 'lawyer' ),
		'std'      => array(
			'top'    => '125px',
			'right'  => '0',
			'bottom' => '94px',
			'left'   => '0',
		),
	),

);
