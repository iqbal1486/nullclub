<?php
/**
 * HomePage Blog Section
 *
 * @package Lawyer
 */

$menus['homepage']['child']['homepage-blog'] = array(
	'title' => esc_html__( 'Blog', 'lawyer' ),
	'desc'  => esc_html__( 'From here, you can control the elements of the Blog section.', 'lawyer' ),
);

$sections['homepage-blog'] = array(

	array(
		'id'    => 'blog_section_left_heading',
		'type'  => 'heading',
		'title' => esc_html__( 'Left Section Settings', 'lawyer' ),
	),

	array(
		'id'       => 'blog_section_title',
		'type'     => 'text',
		'title'    => esc_html__( 'Title', 'lawyer' ),
		'sub_desc' => esc_html__( 'Enter title here.', 'lawyer' ),
		'std'      => 'Read Our Blog or Follow Us on Social Media.',
	),
	array(
		'id'    => 'blog_section_title_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Title Font', 'lawyer' ),
		'std'   => array(
			'preview-text'  => 'Title',
			'preview-color' => 'dark',
			'font-family'   => 'Frank Ruhl Libre',
			'font-weight'   => '400',
			'font-size'     => '48px',
			'line-height'   => '56px',
			'color'         => '#ffffff',
			'css-selectors' => '.blog-section h2',
		),
	),
	array(
		'id'       => 'blog_section_text',
		'type'     => 'textarea',
		'title'    => esc_html__( 'Text', 'lawyer' ),
		'sub_desc' => esc_html__( 'Enter text here.', 'lawyer' ),
		'std'      => 'Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Donec lacinia ligula orci, ut pharetra nunc rutrum sed. Ut molestie, lacus sed commodo molestie.',
	),
	array(
		'id'    => 'blog_section_text_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Text Font', 'lawyer' ),
		'std'   => array(
			'preview-text'  => 'Text',
			'preview-color' => 'dark',
			'font-family'   => 'Roboto',
			'font-weight'   => '400',
			'font-size'     => '20px',
			'line-height'   => '35px',
			'color'         => '#ffffff',
			'css-selectors' => '.blog-section p',
		),
	),

	array(
		'id'       => 'blog_section_button_text',
		'type'     => 'text',
		'title'    => esc_html__( 'Button Text', 'lawyer' ),
		'sub_desc' => esc_html__( 'Enter button text.', 'lawyer' ),
		'std'      => 'Contact us now',
	),

	array(
		'id'       => 'blog_section_button_url',
		'type'     => 'text',
		'title'    => esc_html__( 'Button URL', 'lawyer' ),
		'sub_desc' => esc_html__( 'Enter button URL.', 'lawyer' ),
		'std'      => '#',
	),

	array(
		'id'        => 'blog_social_icons',
		'title'     => esc_html__( 'Blog Social Icons', 'lawyer' ),
		'sub_desc'  => esc_html__( 'Add Social Media icons in blog section.', 'lawyer' ),
		'type'      => 'group',
		'groupname' => esc_html__( 'Blog Icons', 'lawyer' ), // Group name.
		'subfields' => array(
			array(
				'id'    => 'blog_social_title',
				'type'  => 'text',
				'title' => esc_html__( 'Title', 'lawyer' ),
			),
			array(
				'id'    => 'blog_social_icon',
				'type'  => 'icon_select',
				'title' => esc_html__( 'Icon', 'lawyer' ),
			),
			array(
				'id'    => 'blog_social_link',
				'type'  => 'text',
				'title' => esc_html__( 'URL', 'lawyer' ),
			),
			array(
				'id'    => 'blog_social_bgcolor',
				'type'  => 'color',
				'title' => esc_html__( 'Blog icon background color', 'lawyer' ),
			),
			array(
				'id'    => 'blog_social_hover_bgcolor',
				'type'  => 'color',
				'title' => esc_html__( 'Blog icon background hover color', 'lawyer' ),
			),
			array(
				'id'    => 'blog_social_color',
				'type'  => 'color',
				'title' => esc_html__( 'Blog icon color', 'lawyer' ),
			),
			array(
				'id'    => 'blog_social_hover_color',
				'type'  => 'color',
				'title' => esc_html__( 'Blog icon hover color', 'lawyer' ),
			),
			array(
				'id'    => 'blog_social_margin',
				'type'  => 'margin',
				'title' => esc_html__( 'Blog icon Margin', 'lawyer' ),
			),
			array(
				'id'    => 'blog_social_padding',
				'type'  => 'margin',
				'title' => esc_html__( 'Blog icon Padding', 'lawyer' ),
			),
			array(
				'id'       => 'blog_social_border',
				'type'     => 'border',
				'title'    => esc_html__( 'Border', 'lawyer' ),
				'sub_desc' => esc_html__( 'Select border.', 'lawyer' ),
			),
			array(
				'id'    => 'blog_social_border_radius',
				'type'  => 'text',
				'class' => 'small-text',
				'title' => esc_html__( 'Blog icon border radius', 'lawyer' ),
				'args'  => array( 'type' => 'number' ),
			),
		),
		'std'       => array(
			'facebook'  => array(
				'group_title'               => 'Facebook',
				'group_sort'                => '1',
				'blog_social_title'         => 'Facebook',
				'blog_social_icon'          => 'facebook-official',
				'blog_social_link'          => '#',
				'blog_social_bgcolor'       => '',
				'blog_social_hover_bgcolor' => '',
				'blog_social_color'         => '#ffffff',
				'blog_social_hover_color'   => lawyer_get_settings( 'primary_color_scheme' ),
				'blog_social_margin'        => array(
					'top'    => '0',
					'right'  => '0',
					'bottom' => '0',
					'left'   => '0',
				),
				'blog_social_padding'       => array(
					'top'    => '6px',
					'right'  => '24px',
					'bottom' => '6px',
					'left'   => '0',
				),
				'blog_social_border_radius' => '0',
				'blog_social_border'        => array(
					'direction' => 'right',
					'size'      => '1',
					'style'     => 'solid',
					'color'     => '#5e6a74',
				),
			),
			'twitter'   => array(
				'group_title'               => 'Twitter',
				'group_sort'                => '2',
				'blog_social_title'         => 'Twitter',
				'blog_social_icon'          => 'twitter',
				'blog_social_link'          => '#',
				'blog_social_bgcolor'       => '',
				'blog_social_hover_bgcolor' => '',
				'blog_social_color'         => '#ffffff',
				'blog_social_hover_color'   => lawyer_get_settings( 'primary_color_scheme' ),
				'blog_social_margin'        => array(
					'top'    => '0',
					'right'  => '0',
					'bottom' => '0',
					'left'   => '0',
				),
				'blog_social_padding'       => array(
					'top'    => '6px',
					'right'  => '24px',
					'bottom' => '6px',
					'left'   => '24px',
				),
				'blog_social_border_radius' => '0',
				'blog_social_border'        => array(
					'direction' => 'right',
					'size'      => '1',
					'style'     => 'solid',
					'color'     => '#5e6a74',
				),
			),
			'instagram' => array(
				'group_title'               => 'Instagram',
				'group_sort'                => '2',
				'blog_social_title'         => 'Instagram',
				'blog_social_icon'          => 'instagram',
				'blog_social_link'          => '#',
				'blog_social_bgcolor'       => '',
				'blog_social_hover_bgcolor' => '',
				'blog_social_color'         => '#ffffff',
				'blog_social_hover_color'   => lawyer_get_settings( 'primary_color_scheme' ),
				'blog_social_margin'        => array(
					'top'    => '0',
					'right'  => '0',
					'bottom' => '0',
					'left'   => '0',
				),
				'blog_social_padding'       => array(
					'top'    => '6px',
					'right'  => '24px',
					'bottom' => '6px',
					'left'   => '24px',
				),
				'blog_social_border_radius' => '0',
				'blog_social_border'        => array(
					'direction' => 'right',
					'size'      => '1',
					'style'     => 'solid',
					'color'     => '#5e6a74',
				),
			),
			'pinterest' => array(
				'group_title'               => 'Pinterest',
				'group_sort'                => '2',
				'blog_social_title'         => 'Pinterest',
				'blog_social_icon'          => 'pinterest',
				'blog_social_link'          => '#',
				'blog_social_bgcolor'       => '',
				'blog_social_hover_bgcolor' => '',
				'blog_social_color'         => '#ffffff',
				'blog_social_hover_color'   => lawyer_get_settings( 'primary_color_scheme' ),
				'blog_social_margin'        => array(
					'top'    => '0',
					'right'  => '0',
					'bottom' => '0',
					'left'   => '0',
				),
				'blog_social_padding'       => array(
					'top'    => '6px',
					'right'  => '0',
					'bottom' => '6px',
					'left'   => '24px',
				),
				'blog_social_border_radius' => '0',
			),
		),
	),

	array(
		'id'    => 'blog_section_right_heading',
		'type'  => 'heading',
		'title' => esc_html__( 'Right Settings', 'lawyer' ),
	),
	array(
		'id'       => 'blog_section_postnum',
		'type'     => 'text',
		'title'    => esc_html__( 'Blog Posts Number', 'lawyer' ),
		'sub_desc' => esc_html__( 'Enter the total number of posts which you want to show on Blog Section.', 'lawyer' ),
		'validate' => 'numeric',
		'std'      => '3',
		'class'    => 'small-text',
	),
	array(
		'id'       => 'blog_post_background',
		'type'     => 'background',
		'title'    => esc_html__( 'Blog Post Background', 'lawyer' ),
		'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'lawyer' ),
		'options'  => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'      => array(
			'color'         => '#ffffff',
			'use'           => 'pattern',
			'image_pattern' => 'nobg',
			'image_upload'  => '',
			'repeat'        => 'repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
	),
	array(
		'id'    => 'blog_post_title_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Post Title Font', 'lawyer' ),
		'std'   => array(
			'preview-text'  => 'Post Title',
			'preview-color' => 'light',
			'font-family'   => 'Roboto',
			'font-weight'   => '700',
			'font-size'     => '22px',
			'line-height'   => '30px',
			'color'         => '#2d3349',
			'css-selectors' => '.blog-section .right h2',
		),
	),
	array(
		'id'    => 'blog_post_meta_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Post Meta Font', 'lawyer' ),
		'std'   => array(
			'preview-text'   => 'Post Meta',
			'preview-color'  => 'light',
			'font-family'    => 'Roboto',
			'font-weight'    => '700',
			'font-size'      => '12px',
			'line-height'    => '16px',
			'color'          => '#2d3349',
			'additional-css' => 'text-transform: uppercase;',
			'css-selectors'  => '.blog-section .post-meta',
		),
	),

	array(
		'id'    => 'blog_section_settings_heading',
		'type'  => 'heading',
		'title' => esc_html__( 'General Settings', 'lawyer' ),
	),

	array(
		'id'       => 'blog_section_background',
		'type'     => 'background',
		'title'    => esc_html__( 'Section Background', 'lawyer' ),
		'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'lawyer' ),
		'options'  => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'      => array(
			'color'         => '',
			'use'           => 'upload',
			'image_pattern' => 'nobg',
			'image_upload'  => get_template_directory_uri() . '/images/blog-section-bg.jpg',
			'repeat'        => 'no-repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
	),

	array(
		'id'       => 'blog_section_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Padding', 'lawyer' ),
		'sub_desc' => esc_html__( 'Set blog section padding from here.', 'lawyer' ),
		'std'      => array(
			'top'    => '112px',
			'right'  => '0',
			'bottom' => '102px',
			'left'   => '0',
		),
	),

);
