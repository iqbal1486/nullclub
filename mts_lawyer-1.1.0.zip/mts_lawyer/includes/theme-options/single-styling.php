<?php
/**
 * Single Styling
 *
 * @package Lawyer
 */

$menus['single-styling'] = array(
	'title' => esc_html__( 'Single Styling', 'lawyer' ),
	'desc'  => esc_html__( 'From here, you can control the appearance and functionality of your single posts page.', 'lawyer' ),
);

$sections['single-styling'] = array(

	array(
		'id'    => 'single_title_heading',
		'type'  => 'heading',
		'title' => esc_html__( 'Single Titles Styling', 'lawyer' ),
	),

	array(
		'id'       => 'single_title_alignment',
		'type'     => 'button_set',
		'title'    => esc_html__( 'Single Page Title Alignment', 'lawyer' ),
		'sub_desc' => esc_html__( 'Choose the single page title alignment', 'lawyer' ),
		'options'  => array(
			'left'   => esc_html__( 'Left', 'lawyer' ),
			'center' => esc_html__( 'Center', 'lawyer' ),
			'right'  => esc_html__( 'Right', 'lawyer' ),
		),
		'std'      => 'left',
	),

	array(
		'id'       => 'single_title_background',
		'type'     => 'background',
		'title'    => esc_html__( 'Single Page Title Background Color', 'lawyer' ),
		'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'lawyer' ),
		'options'  => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'      => array(
			'color'         => '',
			'use'           => 'pattern',
			'image_pattern' => 'nobg',
			'image_upload'  => '',
			'repeat'        => 'repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
	),
	array(
		'id'       => 'single_title_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Single Page Title Padding', 'lawyer' ),
		'sub_desc' => esc_html__( 'Set single page title padding from here.', 'lawyer' ),
		'std'      => array(
			'top'    => '0',
			'right'  => '0',
			'bottom' => '0',
			'left'   => '0',
		),
	),
	array(
		'id'       => 'single_title_border',
		'type'     => 'border',
		'title'    => esc_html__( 'Border', 'lawyer' ),
		'sub_desc' => esc_html__( 'Select border', 'lawyer' ),
	),
	array(
		'id'    => 'single_page_titles_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Comment Section Title', 'lawyer' ),
		'std'   => array(
			'preview-text'   => 'Title Font',
			'preview-color'  => 'light',
			'font-family'    => 'Roboto',
			'font-weight'    => '700',
			'font-size'      => '13px',
			'line-height'    => '30px',
			'letter-spacing' => '1px',
			'color'          => '#2d3849',
			'additional-css' => 'text-transform: uppercase;',
			'css-selectors'  => '#respond h3, #respond h4, .total-comments',
		),
	),

	array(
		'id'    => 'mts_single_styling_heading',
		'type'  => 'heading',
		'title' => esc_html__( 'Single Styling', 'lawyer' ),
	),

	array(
		'id'       => 'single_background',
		'type'     => 'background',
		'title'    => esc_html__( 'Background', 'lawyer' ),
		'sub_desc' => esc_html__( 'Set background color, pattern and image of Single, Page, Archive, Search, Category and 404 Page from here.', 'lawyer' ),
		'options'  => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'      => array(
			'color'         => '',
			'use'           => 'pattern',
			'image_pattern' => 'nobg',
			'image_upload'  => '',
			'repeat'        => 'repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
	),

	array(
		'id'       => 'mts_single_styling_margin',
		'type'     => 'margin',
		'title'    => esc_html__( 'Single Margin', 'lawyer' ),
		'sub_desc' => esc_html__( 'Set single post margin from here.', 'lawyer' ),
		'left'     => false,
		'right'    => false,
		'std'      => array(
			'top'    => '0',
			'bottom' => '35px',
		),
	),
	array(
		'id'       => 'mts_single_styling_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Single Padding', 'lawyer' ),
		'sub_desc' => esc_html__( 'Set single post padding from here.', 'lawyer' ),
		'std'      => array(
			'top'    => '0',
			'right'  => '0',
			'bottom' => '0',
			'left'   => '0',
		),
	),
	array(
		'id'       => 'single_styling_border',
		'type'     => 'border',
		'title'    => esc_html__( 'Border', 'lawyer' ),
		'sub_desc' => esc_html__( 'Select border', 'lawyer' ),
	),
	array(
		'id'    => 'single_title_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Single Post Title', 'lawyer' ),
		'std'   => array(
			'preview-text'  => 'Single Article Title',
			'preview-color' => 'light',
			'font-family'   => 'Frank Ruhl Libre',
			'font-weight'   => '400',
			'font-size'     => '36px',
			'line-height'   => '46px',
			'color'         => '#2d3349',
			'css-selectors' => '.single-title',
		),
	),
	array(
		'id'    => 'mts_single_meta_info_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Single Meta Info Font', 'lawyer' ),
		'std'   => array(
			'preview-text'   => 'Post Meta Info Font',
			'preview-color'  => 'light',
			'font-family'    => 'Roboto',
			'font-weight'    => '700',
			'font-size'      => '13px',
			'color'          => '#2d3849',
			'letter-spacing' => '1px',
			'additional-css' => 'text-transform: uppercase;',
			'css-selectors'  => '.single_post .post-info.bottom, .single_post .post-info.bottom a, .single-full-header .post-info, .single-full-header .post-info.bottom a, .reply, #comments .ago',
		),
	),

);
