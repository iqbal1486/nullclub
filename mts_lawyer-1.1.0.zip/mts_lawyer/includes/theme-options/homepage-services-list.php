<?php
/**
 * HomePage Services List Section
 *
 * @package Lawyer
 */

$menus['homepage']['child']['homepage-services-list'] = array(
	'title' => esc_html__( 'Services List', 'lawyer' ),
	'desc'  => esc_html__( 'From here, you can control the elements of the services list section.', 'lawyer' ),
);

$service_list = join(
	PHP_EOL,
	[
		'-  Domestic Violence',
		'-  Drug Crimes',
		'-  DUI Defense',
		'-  Expungements',
		'-  Federal Appeals',
		'-  Federal Crimes',
		'-  Gang Crimes',
		'-  Misdemeanor Crimes',
		'-  Probation Violations',
		'-  Sex Crimes',
		'-  Theft Crimes',
		'-  Warrants',
		'-  White Collar Crimes',
	]
);

$sections['homepage-services-list'] = array(

	array(
		'id'       => 'services_list_background',
		'type'     => 'background',
		'title'    => esc_html__( 'Section Background', 'lawyer' ),
		'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'lawyer' ),
		'options'  => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'      => array(
			'color'         => '',
			'use'           => 'upload',
			'image_pattern' => 'nobg',
			'image_upload'  => get_template_directory_uri() . '/images/services-list-bg.jpg',
			'repeat'        => 'no-repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
	),

	array(
		'id'       => 'services_list_title1',
		'type'     => 'text',
		'title'    => esc_html__( 'Title1', 'lawyer' ),
		'sub_desc' => esc_html__( 'Enter 1st title for services list section.', 'lawyer' ),
		'std'      => 'Criminal Charges',
	),
	array(
		'id'       => 'services_list_text1',
		'type'     => 'textarea',
		'title'    => esc_html__( 'Services List', 'lawyer' ),
		'sub_desc' => esc_html__( 'Set 1st services list. One item per line.', 'lawyer' ),
		'std'      => $service_list,
	),

	array(
		'id'       => 'services_list_title2',
		'type'     => 'text',
		'title'    => esc_html__( 'Title1', 'lawyer' ),
		'sub_desc' => esc_html__( 'Enter 2nd title for services list section.', 'lawyer' ),
		'std'      => 'Estate Planning',
	),
	array(
		'id'       => 'services_list_text2',
		'type'     => 'textarea',
		'title'    => esc_html__( 'Services List', 'lawyer' ),
		'sub_desc' => esc_html__( 'Set 2nd services list. One item per line.', 'lawyer' ),
		'std'      => $service_list,
	),

	array(
		'id'       => 'services_list_title3',
		'type'     => 'text',
		'title'    => esc_html__( 'Title1', 'lawyer' ),
		'sub_desc' => esc_html__( 'Enter 3rd title for services list section.', 'lawyer' ),
		'std'      => 'Capital Market',
	),
	array(
		'id'       => 'services_list_text3',
		'type'     => 'textarea',
		'title'    => esc_html__( 'Services List', 'lawyer' ),
		'sub_desc' => esc_html__( 'Set 3rd services list. One item per line.', 'lawyer' ),
		'std'      => $service_list,
	),

	array(
		'id'       => 'services_list_title4',
		'type'     => 'text',
		'title'    => esc_html__( 'Title1', 'lawyer' ),
		'sub_desc' => esc_html__( 'Enter 4th title for services list section.', 'lawyer' ),
		'std'      => 'Personal Injury',
	),
	array(
		'id'       => 'services_list_text4',
		'type'     => 'textarea',
		'title'    => esc_html__( 'Services List', 'lawyer' ),
		'sub_desc' => esc_html__( 'Set 4th services list. One item per line.', 'lawyer' ),
		'std'      => $service_list,
	),

	array(
		'id'    => 'services_list_title_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Title Font', 'lawyer' ),
		'std'   => array(
			'preview-text'   => 'Title',
			'preview-color'  => 'light',
			'font-family'    => 'Roboto',
			'font-weight'    => '700',
			'font-size'      => '20px',
			'line-height'    => '42px',
			'color'          => lawyer_get_settings( 'primary_color_scheme' ),
			'additional-css' => 'text-transform: uppercase;',
			'css-selectors'  => '.services-list-section h2',
		),
	),

	array(
		'id'       => 'services_list_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Padding', 'lawyer' ),
		'sub_desc' => esc_html__( 'Set services list section padding from here.', 'lawyer' ),
		'std'      => array(
			'top'    => '155px',
			'right'  => '0',
			'bottom' => '152px',
			'left'   => '0',
		),
	),

);
