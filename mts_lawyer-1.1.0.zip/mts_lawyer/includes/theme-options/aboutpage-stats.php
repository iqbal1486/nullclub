<?php
/**
 * About Page Stats Section
 *
 * @package Lawyer
 */

$menus['aboutpage']['child']['aboutpage-stats'] = array(
	'title' => esc_html__( 'Stats', 'lawyer' ),
	'desc'  => esc_html__( 'From here, you can control the elements of the Stats section.', 'lawyer' ),
);

$sections['aboutpage-stats'] = array(

	array(
		'id'       => 'about_stats_background',
		'type'     => 'background',
		'title'    => esc_html__( 'Section Background', 'lawyer' ),
		'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'lawyer' ),
		'options'  => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'      => array(
			'color'         => '',
			'use'           => 'upload',
			'image_pattern' => 'nobg',
			'image_upload'  => get_template_directory_uri() . '/images/about-stats-bg.jpg',
			'repeat'        => 'no-repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
	),

	array(
		'id'       => 'about_stats_icon',
		'type'     => 'icon_select',
		'title'    => esc_html__( 'Icon', 'lawyer' ),
		'sub_desc' => esc_html__( 'Select an icon.', 'lawyer' ),
		'std'      => 'institution',
	),

	array(
		'id'       => 'about_stats_title',
		'type'     => 'text',
		'title'    => esc_html__( 'Title', 'lawyer' ),
		'sub_desc' => esc_html__( 'Enter title here.', 'lawyer' ),
		'std'      => 'Proven Credentials',
	),
	array(
		'id'    => 'about_stats_title_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Title Font', 'lawyer' ),
		'std'   => array(
			'preview-text'  => 'Title',
			'preview-color' => 'dark',
			'font-family'   => 'Frank Ruhl Libre',
			'font-weight'   => '400',
			'font-size'     => '48px',
			'line-height'   => '56px',
			'color'         => '#ffffff',
			'css-selectors' => '.about-stats-section h2',
		),
	),
	array(
		'id'       => 'about_stats_text',
		'type'     => 'textarea',
		'title'    => esc_html__( 'Text', 'lawyer' ),
		'sub_desc' => esc_html__( 'Enter text here.', 'lawyer' ),
		'std'      => 'Our lawyers will also represent you in civil litigation cases such as divorce, child and spouse maintenance.',
	),
	array(
		'id'    => 'about_stats_text_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Text Font', 'lawyer' ),
		'std'   => array(
			'preview-text'  => 'Text',
			'preview-color' => 'dark',
			'font-family'   => 'Roboto',
			'font-weight'   => '400',
			'font-size'     => '20px',
			'line-height'   => '35px',
			'color'         => '#ffffff',
			'css-selectors' => '.about-stats-section p',
		),
	),

	array(
		'id'        => 'about_stats_group',
		'type'      => 'group',
		'title'     => esc_html__( 'Stats', 'lawyer' ),
		'sub_desc'  => esc_html__( 'Add stats appearing on the Stats section.', 'lawyer' ),
		'groupname' => esc_html__( 'Stats', 'lawyer' ),
		'subfields' => array(
			array(
				'id'    => 'about_stats_group_title',
				'type'  => 'text',
				'title' => esc_html__( 'Graph Title', 'lawyer' ),
			),
			array(
				'id'       => 'about_stats_group_percentage',
				'type'     => 'text',
				'title'    => esc_html__( 'Percentage (%)', 'lawyer' ),
				'validate' => 'numeric',
				'class'    => 'small-text',
			),
		),
		'std'       => array(
			'1' => array(
				'group_sort'                   => '1',
				'about_stats_group_title'      => 'Immigration law',
				'about_stats_group_percentage' => '60',
			),
			'2' => array(
				'group_sort'                   => '2',
				'about_stats_group_title'      => 'Malpractice',
				'about_stats_group_percentage' => '75',
			),
			'3' => array(
				'group_sort'                   => '3',
				'about_stats_group_title'      => 'Products Liability',
				'about_stats_group_percentage' => '90',
			),
		),
	),

	array(
		'id'    => 'about_stats_group_title_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Graph Title Font', 'lawyer' ),
		'std'   => array(
			'preview-text'   => 'Graph Title',
			'preview-color'  => 'dark',
			'font-family'    => 'Roboto',
			'font-weight'    => '700',
			'font-size'      => '20px',
			'line-height'    => '35px',
			'color'          => '#ffffff',
			'additional-css' => 'text-transform: uppercase;',
			'css-selectors'  => '.about-stats-container .left',
		),
	),
	array(
		'id'    => 'about_stats_group_percentage_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Percentage Font', 'lawyer' ),
		'std'   => array(
			'preview-text'   => 'Percentage',
			'preview-color'  => 'dark',
			'font-family'    => 'Roboto',
			'font-weight'    => '700',
			'font-size'      => '15px',
			'line-height'    => '36px',
			'color'          => '#ffffff',
			'additional-css' => 'text-transform: uppercase;',
			'css-selectors'  => '.about-stats-container .bar-fill',
		),
	),

	array(
		'id'       => 'about_stats_button_text',
		'type'     => 'text',
		'title'    => esc_html__( 'Button Text', 'lawyer' ),
		'sub_desc' => esc_html__( 'Enter button1 text.', 'lawyer' ),
		'std'      => 'Contact us now',
	),

	array(
		'id'       => 'about_stats_button_url',
		'type'     => 'text',
		'title'    => esc_html__( 'Button URL', 'lawyer' ),
		'sub_desc' => esc_html__( 'Enter button1 URL.', 'lawyer' ),
		'std'      => '#',
	),

	array(
		'id'       => 'about_stats_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Padding', 'lawyer' ),
		'sub_desc' => esc_html__( 'Set stats section padding from here.', 'lawyer' ),
		'std'      => array(
			'top'    => '63px',
			'right'  => '0',
			'bottom' => '63px',
			'left'   => '0',
		),
	),

);
