<?php
/**
 * About Page Tab
 *
 * @package Lawyer
 */

$menus['aboutpage'] = array(
	'icon'  => 'fa-address-book-o',
	'title' => esc_html__( 'About Page', 'lawyer' ),
);

$menus['aboutpage']['child']['aboutpage-sections'] = array(
	'title' => esc_html__( 'About Page Sections', 'lawyer' ),
	'desc'  => esc_html__( 'From here, you can control the elements of the About Page Sections.', 'lawyer' ),
);

$sections['aboutpage-sections'] = array(

	array(
		'id'       => 'aboutpage_layout',
		'type'     => 'layout',
		'title'    => esc_html__( 'About Page Section Manager', 'lawyer' ),
		'sub_desc' => esc_html__( 'Organize how you want the sections to appear on the aboutpage', 'lawyer' ),
		'options'  => array(
			'enabled'  => array(
				'featured'      => esc_html__( 'Featured', 'lawyer' ),
				'services-grid' => esc_html__( 'Services Grid', 'lawyer' ),
				'video'         => esc_html__( 'Video', 'lawyer' ),
				'testimonials'  => esc_html__( 'Testimonials', 'lawyer' ),
				'stats'         => esc_html__( 'Stats', 'lawyer' ),
				'featured-on'   => esc_html__( 'Featured On', 'lawyer' ),
				'services-list' => esc_html__( 'Services List', 'lawyer' ),
			),
			'disabled' => array(),
		),
		'std'      => array(
			'enabled'  => array(
				'featured'      => esc_html__( 'Featured', 'lawyer' ),
				'services-grid' => esc_html__( 'Services Grid', 'lawyer' ),
				'video'         => esc_html__( 'Video', 'lawyer' ),
				'testimonials'  => esc_html__( 'Testimonials', 'lawyer' ),
				'stats'         => esc_html__( 'Stats', 'lawyer' ),
				'featured-on'   => esc_html__( 'Featured On', 'lawyer' ),
				'services-list' => esc_html__( 'Services List', 'lawyer' ),
			),
			'disabled' => array(),
		),
	),

);
