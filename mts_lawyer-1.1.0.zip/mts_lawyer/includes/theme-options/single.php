<?php
/**
 * Single Tab
 *
 * @package Lawyer
 */

$menus['single-general'] = array(
	'title' => esc_html__( 'General', 'lawyer' ),
	'desc'  => esc_html__( 'From here, you can control the appearance and functionality of your single posts page.', 'lawyer' ),
);

$sections['single-general'] = array(

	array(
		'id'       => 'show_single_featured',
		'type'     => 'switch',
		'title'    => esc_html__( 'Show Featured image', 'lawyer' ),
		'sub_desc' => esc_html__( 'Enable/Disable the Featured images in the single post.', 'lawyer' ),
		'std'      => '1',
	),

	array(
		'id'       => 'mts_single_post_layout',
		'type'     => 'layout2',
		'title'    => esc_html__( 'Single Post Layout', 'lawyer' ),
		'sub_desc' => esc_html__( 'Customize the look of single posts', 'lawyer' ),
		'options'  => array(
			'enabled'  => array(
				'content' => array(
					'label'     => esc_html__( 'Post Content', 'lawyer' ),
					'subfields' => array(),
				),
				'tags'    => array(
					'label'     => esc_html__( 'Tags', 'lawyer' ),
					'subfields' => array(),
				),
				'author'  => array(
					'label'     => esc_html__( 'Author Box', 'lawyer' ),
					'subfields' => array(),
				),
				'related' => array(
					'label'     => esc_html__( 'Related Posts', 'lawyer' ),
					'subfields' => array(
						array(
							'id'       => 'related_post_title',
							'type'     => 'text',
							'title'    => esc_html__( 'Related Posts Title', 'lawyer' ),
							'sub_desc' => esc_html__( 'Enter the title text to show in the related posts section.', 'lawyer' ),
							'std'      => 'See More Posts',
						),
						array(
							'id'       => 'mts_related_posts_taxonomy',
							'type'     => 'switch',
							'title'    => esc_html__( 'Related Posts Taxonomy', 'lawyer' ),
							'options'  => array(
								'tags'       => esc_html__( 'Tags', 'lawyer' ),
								'categories' => esc_html__( 'Categories', 'lawyer' ),
							),
							'class'    => 'green',
							'sub_desc' => esc_html__( 'Related Posts based on tags or categories.', 'lawyer' ),
							'std'      => 'categories',
						),
					),
				),
			),
			'disabled' => array(
				'subscribe' => array(
					'label'     => esc_html__( 'Subscribe Box', 'lawyer' ),
					'subfields' => array(),
				),
			),
		),
	),

	array(
		'id'       => 'mts_single_headline_meta_info',
		'type'     => 'layout2',
		'title'    => esc_html__( 'Single Meta Info', 'lawyer' ),
		'sub_desc' => esc_html__( 'Organize how you want the post meta info to appear on single page', 'lawyer' ),
		'options'  => array(
			'enabled'  => array(
				'author'   => array(
					'label'     => esc_html__( 'Author Name', 'lawyer' ),
					'subfields' => array(
						array(
							'id'    => 'mts_single_meta_info_author_icon',
							'type'  => 'icon_select',
							'title' => esc_html__( 'Select Icon', 'lawyer' ),
						),
					),
				),
				'category' => array(
					'label'     => esc_html__( 'Categories', 'lawyer' ),
					'subfields' => array(
						array(
							'id'    => 'mts_single_meta_info_category_icon',
							'type'  => 'icon_select',
							'title' => esc_html__( 'Select Icon', 'lawyer' ),
						),
					),
				),
				'date'     => array(
					'label'     => esc_html__( 'Date', 'lawyer' ),
					'subfields' => array(
						array(
							'id'    => 'mts_single_meta_info_date_icon',
							'type'  => 'icon_select',
							'title' => esc_html__( 'Select Icon', 'lawyer' ),
						),
					),
				),
			),
			'disabled' => array(
				'comment' => array(
					'label'     => esc_html__( 'Comment Count', 'lawyer' ),
					'subfields' => array(
						array(
							'id'    => 'mts_single_meta_info_comment_icon',
							'type'  => 'icon_select',
							'title' => esc_html__( 'Select Icon', 'lawyer' ),
						),
					),
				),
			),
		),
	),

	array(
		'id'       => 'mts_author_comment',
		'type'     => 'switch',
		'title'    => esc_html__( 'Highlight Author Comment', 'lawyer' ),
		'sub_desc' => esc_html__( 'Use this button to highlight author comments.', 'lawyer' ),
		'std'      => '1',
	),

	array(
		'id'       => 'mts_comment_date',
		'type'     => 'switch',
		'title'    => esc_html__( 'Date in Comments', 'lawyer' ),
		'sub_desc' => esc_html__( 'Use this button to show the date for comments.', 'lawyer' ),
		'std'      => '1',
	),
);
