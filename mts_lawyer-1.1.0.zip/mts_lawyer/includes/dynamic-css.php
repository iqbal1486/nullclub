<?php
/**
 * Dynamic CSS for the frontend.
 *
 * @package Lawyer
 */

defined( 'WPINC' ) || exit;

/**
 * Helper function.
 * Merge and combine the CSS elements.
 *
 * @param  string|array $elements An array of our elements.
 *                                If we use a string then it is directly returned.
 * @return string
 */
function lawyer_implode( $elements = array() ) {

	if ( ! is_array( $elements ) ) {
		return $elements;
	}

	// Make sure our values are unique.
	$elements = array_unique( $elements );

	// Sort elements alphabetically.
	// This way all duplicate items will be merged in the final CSS array.
	sort( $elements );

	// Implode items and return the value.
	return implode( ',', $elements );

}

/**
 * Maps elements from dynamic css to the selector.
 *
 * @param  array  $elements The elements.
 * @param  string $selector The selector.
 * @return array
 */
function lawyer_map_selector( $elements, $selector ) {
	$array = array();

	foreach ( $elements as $element ) {
		$array[] = $element . $selector;
	}

	return $array;
}

/**
 * Map CSS selectors from values.
 *
 * @param array $css    Array of dynamic CSS.
 * @param array $values Array of values.
 */
function lawyer_map_css_selectors( &$css, $values ) {
	if ( isset( $values['css-selectors'] ) ) {
		$elements = $values['css-selectors'];
		unset( $values['css-selectors'] );

		$css[ $elements ] = $values;
	}
}

/**
 * Merge CSS values.
 *
 * @param array $css    Array of dynamic CSS.
 * @param array $values Array of values.
 */
function lawyer_merge_value( &$css, $values ) {
	foreach ( $values as $id => $val ) {
		$css[ $id ] = $val;
	}
}

/**
 * Format of the $css array:
 * $css['media-query']['element']['property'] = value
 *
 * If no media query is required then set it to 'global'
 *
 * If we want to add multiple values for the same property then we have to make it an array like this:
 * $css[media-query][element]['property'][] = value1
 * $css[media-query][element]['property'][] = value2
 *
 * Multiple values defined as an array above will be parsed separately.
 */
function lawyer_dynamic_css_array() {

	global $wp_version;

	$css       = array();
	$c_page_id = lawyer()->get_page_id();

	// Site Background.
	$css['global']['html body'] = Lawyer_Sanitize::background( lawyer_get_settings( 'mts_background' ) );

	// Top bar Background.
	$css['global']['.top-bar, .header-search.active #s'] = Lawyer_Sanitize::background( lawyer_get_settings( 'top_bar_background' ) );

	// Nav Background.
	$css['global']['#header, .navigation ul ul, .navigation ul li li'] = Lawyer_Sanitize::background( lawyer_get_settings( 'nav_background' ) );

	// Content Font.
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'content_font' ) ) );
	// Logo Font.
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'lawyer_logo' ) ) );
	// Secondary Navigation font.
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'secondary_navigation_font' ) ) );
	// Blog heading font.
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'blog_heading_font' ) ) );
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'blog_subheading_font' ) ) );
	// Homepage post title font.
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'home_title_font' ) ) );
	// Pagination.
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'pagination_font' ) ) );
	// Breadcrumbs font.
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'breadcrumb_font' ) ) );
	// Single post title font.
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'single_title_font' ) ) );
	// Single Page titles font.
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'single_page_titles_font' ) ) );
	// Related Posts Section title font.
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'related_post_title_font' ) ) );
	// Single subscribe box.
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'single_subscribe_title_font' ) ) );
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'single_subscribe_text_font' ) ) );
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'single_subscribe_input_font' ) ) );
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'single_subscribe_submit_font' ) ) );
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'single_subscribe_small_text_font' ) ) );
	// Author Box.
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'single_authorbox_title_font' ) ) );
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'single_authorbox_author_name_font' ) ) );
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'single_authorbox_text_font' ) ) );
	// Footer Nav.
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'footer_nav_font' ) ) );
	// Sidebar widget title font.
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'sidebar_title_font' ) ) );
	// Sidebar widget font.
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'mts_widget_links' ) ) );
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'default_widget_links' ) ) );
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'sidebar_url_bigthumb' ) ) );
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'sidebar_font' ) ) );
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'sidebar_font_bigthumb' ) ) );
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'sidebar_postinfo_font' ) ) );
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'sidebar_postinfo_font_bigthumb' ) ) );
	// Tab widget title font.
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'tabs_title_font' ) ) );
	// Footer widget title font.
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'footer_lawyer_logo' ) ) );
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'top_footer_title_font' ) ) );
	// Footer link font.
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'top_footer_link_font' ) ) );
	// Footer widget font.
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'top_footer_font' ) ) );
	// Copyrights section font.
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'copyrights_font' ) ) );
	// H1 title in the content.
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'h1_headline' ) ) );
	// H2 title in the content.
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'h2_headline' ) ) );
	// H3 title in the content.
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'h3_headline' ) ) );
	// H4 title in the content.
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'h4_headline' ) ) );
	// H5 title in the content.
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'h5_headline' ) ) );
	// H6 title in the content.
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'h6_headline' ) ) );

	lawyer_dynamic_css_skin( $css );
	lawyer_sidebar_position( $css );
	lawyer_header( $css );
	lawyer_sidebar_styling( $css );
	lawyer_home_sections( $css );
	lawyer_about_sections( $css );
	lawyer_post_layouts( $css );
	lawyer_post_pagination( $css );
	lawyer_footer( $css );
	lawyer_copyrights( $css );
	lawyer_single( $css );
	lawyer_single_social_buttons( $css );
	lawyer_misc_css( $css );

	return apply_filters( 'lawyer_dynamic_css_array', $css );
}

/**
 * Skin CSS
 *
 * @param array $css Array of dynamic CSS.
 */
function lawyer_dynamic_css_skin( &$css ) {

	// Primary Color.
	$primary_color_scheme = Lawyer_Sanitize::color( lawyer_get_settings( 'primary_color_scheme' ) );

	// Text Color.
	$elements = array(
		'a',
		'body a:hover',
		'.breadcrumb a',
		'.single_post .thecontent a',
		'.reply a',
		'.featured-content a.title:hover',
		'.latestPost .title a:hover',
		'.related-posts .title a:hover',
		'.layout-default .latestPost .title a:hover',
		'.layout-2 .latestPost .title a:hover',
		'.layout-3 .latestPost .title a:hover',
		'.layout-4 .latestPost .title a:hover',
		'.woocommerce ul.products li.product .price',
		'.product_list_widget .amount',
		'.woocommerce div.product p.price, .woocommerce div.product span.price',
		'.shareit-circular.standard .fa:hover',
		'.textwidget a',
		'#wp-calendar td#today',
		'.pnavigation2 a',
		'footer .widget li a:hover',
		'#sidebar .widget li a:hover',
		'.title a:hover',
		'.post-info > span a',
		'#tabber .inside li a:hover',
		'.fn a',
		'.widget .wp_review_tab_widget_content a',
		'.sidebar .wpt_widget_content a',
		'.related-posts .title a:hover',
		'.layout-subscribe .widget #wp-subscribe .title span',
		'.footer-nav li a:hover',
		'blockquote:after',
		'article ul li::before',
		'.single .pagination a .current:hover',
		'#secondary-navigation li:hover',
		'.nav-button .button.border',
		'.featured2-section .small-container .button.border',
		'.featured2-navigation a::after',
		'.featured2-section .small-container .featured2-navigation a:hover',
		'.featured2-section .featured-2-icon',
		'.cta-section .button',
		'.blog-section .button.border',
		'.post-wrapper a:hover h2',
		'.about-stats-section .button.border',
		'.about-stats-section .icon',
		'.about-services-list-container .button.border',
		'.about-featured-section .icon',
		'.about-testimonials-section .icon',
		'.about-services-list-section .icon',
		'.services-grid-section .icon',
		'.stats-list li i',
		'.stats2-section .icon',
		'.team-section .icon',
		'.services-grid2-section i',
		'.featured3-section .icon',
		'.why-us-section .icon',
		'.faqs-section .question span',
	);

	$css['global'][ lawyer_implode( $elements ) ]['color'] = $primary_color_scheme;
	$css['global']['#sidebar .widget a:hover']['color']    = $primary_color_scheme;

	// Text Color Important.
	$elements = array(
		'.social-profile-icons ul li a:hover',
		'.layout-1 .latestPost a:hover',
		'#sidebar .widget .wpt_widget_content .tab_title.selected a',
		'#sidebar .widget .wp_review_tab_widget_content .tab_title.selected a',
		'.widget .review_thumb_large .review-result',
		'.widget .review_thumb_large .review-total-only.large-thumb',
		'footer .widget .wpt_widget_content .tab_title.selected a',
		'footer .widget .wp_review_tab_widget_content .tab_title.selected a',
	);
	$css['global'][ lawyer_implode( $elements ) ]['color'] = $primary_color_scheme . '!important';

	// Background Color.
	$elements = array(
		'.error404 .article .sbutton',
		'.search .article .sbutton',
		'.pace .pace-progress',
		'#mobile-menu-wrapper ul li a:hover',
		'.pagination a:hover',
		'.single .pagination a:hover .current',
		'a#pull',
		'#commentform input#submit',
		'#mtscontact_submit',
		'.navigation #wpmm-megamenu .wpmm-pagination a',
		'.wpmm-megamenu-showing.wpmm-light-scheme',
		'.mts-subscribe input[type="submit"]',
		'.f-widget .widget .wp-subscribe-wrap input.submit',
		'.widget_product_search button[type="submit"]',
		'#move-to-top:hover',
		'#tabber ul.tabs li a.selected',
		'.navigation ul .sfHover a',
		'.widget-slider .slide-caption',
		'.owl-prev:hover, .owl-next:hover',
		'.widget .wp-subscribe-wrap h4.title span.decor:after',
		'.woocommerce a.button',
		'.woocommerce-page a.button',
		'.woocommerce button.button',
		'.woocommerce-page button.button',
		'.woocommerce input.button',
		'.woocommerce-page input.button',
		'.woocommerce #respond input#submit',
		'.woocommerce-page #respond input#submit',
		'.woocommerce #content input.button',
		'.woocommerce-page #content input.button',
		'.woocommerce .bypostauthor:after',
		'.woocommerce nav.woocommerce-pagination ul li span.current',
		'.woocommerce-page nav.woocommerce-pagination ul li span.current',
		'.woocommerce #content nav.woocommerce-pagination ul li span.current',
		'.woocommerce-page #content nav.woocommerce-pagination ul li span.current',
		'.woocommerce nav.woocommerce-pagination ul li a:hover',
		'.woocommerce-page nav.woocommerce-pagination ul li a:hover',
		'.woocommerce #content nav.woocommerce-pagination ul li a:hover',
		'.woocommerce-page #content nav.woocommerce-pagination ul li a:hover',
		'.woocommerce nav.woocommerce-pagination ul li a:focus',
		'.woocommerce-page nav.woocommerce-pagination ul li a:focus',
		'.woocommerce #content nav.woocommerce-pagination ul li a:focus',
		'.woocommerce-page #content nav.woocommerce-pagination ul li a:focus',
		'.woocommerce a.button',
		'.woocommerce-page a.button',
		'.woocommerce button.button',
		'.woocommerce-page button.button',
		'.woocommerce input.button',
		'.woocommerce-page input.button',
		'.woocommerce #respond input#submit',
		'.woocommerce-page #respond input#submit',
		'.woocommerce #content input.button',
		'.woocommerce-page #content input.button',
		'.woocommerce #respond input#submit.alt.disabled',
		'.woocommerce #respond input#submit.alt.disabled:hover',
		'.woocommerce #respond input#submit.alt:disabled',
		'.woocommerce #respond input#submit.alt:disabled:hover',
		'.woocommerce #respond input#submit.alt:disabled[disabled]',
		'.woocommerce #respond input#submit.alt:disabled[disabled]:hover',
		'.woocommerce a.button.alt.disabled, .woocommerce a.button.alt.disabled:hover',
		'.woocommerce a.button.alt:disabled',
		'.woocommerce a.button.alt:disabled:hover',
		'.woocommerce a.button.alt:disabled[disabled]',
		'.woocommerce a.button.alt:disabled[disabled]:hover',
		'.woocommerce button.button.alt.disabled',
		'.woocommerce button.button.alt.disabled:hover',
		'.woocommerce button.button.alt:disabled',
		'.woocommerce button.button.alt:disabled:hover',
		'.woocommerce button.button.alt:disabled[disabled]',
		'.woocommerce button.button.alt:disabled[disabled]:hover',
		'.woocommerce input.button.alt.disabled',
		'.woocommerce input.button.alt.disabled:hover',
		'.woocommerce input.button.alt:disabled',
		'.woocommerce input.button.alt:disabled:hover',
		'.woocommerce input.button.alt:disabled[disabled]',
		'.woocommerce input.button.alt:disabled[disabled]:hover',
		'#wpmm-megamenu .review-total-only',
		'#searchsubmit',
		'.widget .wpt_widget_content #tags-tab-content ul li a',
		'#add_payment_method .wc-proceed-to-checkout a.checkout-button',
		'.woocommerce-cart .wc-proceed-to-checkout a.checkout-button',
		'.woocommerce-checkout .wc-proceed-to-checkout a.checkout-button',
		'.woocommerce #respond input#submit.alt',
		'.woocommerce a.button.alt',
		'.woocommerce button.button.alt',
		'.woocommerce input.button.alt',
		'.woocommerce-account .woocommerce-MyAccount-navigation li.is-active',
		'.widget #wp-subscribe form::after',
		'.button',
		'.instagram-button a',
		'.woocommerce .woocommerce-widget-layered-nav-dropdown__submit',
		'.layout-subscribe form:after',
		'.f-widget .widget #wp-subscribe form:after',
		'.widget .sbutton',
		'.owl-prev:hover, .owl-next:hover',
		'.woocommerce .widget_price_filter .ui-slider .ui-slider-handle',
		'.woocommerce .widget_price_filter .ui-slider .ui-slider-range',
		'.latestPost-review-wrapper',
		'.latestPost .review-type-circle.latestPost-review-wrapper',
		'.woocommerce span.onsale',
		'.widget .widget_wp_review_tab .review-total-only.large-thumb',
		'.widget #wp-subscribe input.submit',
		'#sidebar .widget h3::before',
		'#sidebar .widget #wp-subscribe .title::before',
		'.f-widget .widget #wp-subscribe input.submit',
		'.prev-next .prev a:hover',
		'.prev-next .next a:hover',
		'.pagination .nav-previous a',
		'.pagination .nav-next a',
		'.tags a:hover',
		'.nav-button .button.border:hover',
		'.featured2-section .small-container .button.border:hover',
		'.text-wrapper span',
		'.stats-container .stats-wrap::before',
		'.blog-section .post-wrapper .arrow',
		'.blog-section .button.border:hover',
		'.about-video-section .fa-play',
		'.about-testimonials-section .owl-controls .owl-dot:hover span:hover',
		'.about-testimonials-section .owl-controls .owl-dot.active span',
		'.about-stats-section .bar .bar-fill',
		'.about-stats-section .button.border:hover',
		'.about-services-list-container .button.border:hover',
	);

	$css['global'][ lawyer_implode( $elements ) ]['background-color'] = $primary_color_scheme;

	// Background Color Important.
	$elements = array(
		'.tagcloud a:hover, #sidebar .widget .tagcloud a:hover',
		'.widget .wpt_widget_content #tags-tab-content ul li a:hover ',
	);
	$css['global'][ lawyer_implode( $elements ) ]['background-color'] = $primary_color_scheme . '!important';

	// Border Color.
	$elements = array(
		'.flex-control-thumbs .flex-active',
		'#secondary-navigation .navigation ul .current-menu-item',
		'#header .button.border',
		'.featured2-section .small-container .button.border',
		'.f-widget .widget #wp-subscribe input.name-field',
		'.f-widget .widget #wp-subscribe input.email-field',
		'.blog-section .button.border',
		'.about-stats-section .button.border',
		'.about-services-list-section .about-services-list-container .button.border',
	);

	$css['global'][ lawyer_implode( $elements ) ]['border-color'] = $primary_color_scheme;

}

/**
 * Sidebar Position
 *
 * @param array $css Array of dynamic CSS.
 */
function lawyer_sidebar_position( &$css ) {

	// Sidebar position.
	$sidebar_position = lawyer_get_settings( 'mts_layout' );

	$sidebar_metabox_location = '';
	if ( is_page() || is_single() ) {
		$sidebar_metabox_location = get_post_meta( get_the_ID(), '_mts_sidebar_location', true );
	}

	if ( 'right' !== $sidebar_metabox_location && ( 'sclayout' === $sidebar_position || 'left' === $sidebar_metabox_location ) ) {

		$css['global']['.article']['float']                = 'right';
		$css['global']['.sidebar.c-4-12']['float']         = 'left';
		$css['global']['.sidebar.c-4-12']['padding-right'] = 0;

		if ( null !== lawyer_get_settings( 'mts_social_button_position' ) && 'floating' === lawyer_get_settings( 'mts_social_button_position' ) ) {
			$css['global']['.shareit.floating']['margin']                = '0 760px 0';
			$css['global']['.shareit.floating']['border-left']           = '0';
			$css['global']['.shareit.shareit-circular.floating']['left'] = '95%';

		}
	}
}

/**
 * Header
 *
 * @param array $css Array of dynamic CSS.
 */
function lawyer_header( &$css ) {

	// Top Bar.
	$header_class = array(
		'.top-bar',
	);
	lawyer_merge_value( $css['global'][ lawyer_implode( $header_class ) ], Lawyer_Sanitize::margin( lawyer_get_settings( 'top_bar_margin' ) ) );
	lawyer_merge_value( $css['global'][ lawyer_implode( $header_class ) ], Lawyer_Sanitize::padding( lawyer_get_settings( 'top_bar_padding' ) ) );

	// Maine Nav.
	$header_class = array(
		'#header',
	);
	lawyer_merge_value( $css['global'][ lawyer_implode( $header_class ) ], Lawyer_Sanitize::margin( lawyer_get_settings( 'main_nav_margin' ) ) );
	lawyer_merge_value( $css['global'][ lawyer_implode( $header_class ) ], Lawyer_Sanitize::padding( lawyer_get_settings( 'main_nav_padding' ) ) );
	// Header Border.
	$header_border = Lawyer_Sanitize::border( lawyer_get_settings( 'mts_header_border' ) );
	$css['global'][ lawyer_implode( $header_class ) ][ $header_border['direction'] ] = $header_border ['value'];

	// Main Nav.
	$main_nav_classes = array(
		'#secondary-navigation .navigation ul ul a',
		'#secondary-navigation .navigation ul ul a:link',
		'#secondary-navigation .navigation ul ul a:visited',
	);
	$css['global'][ lawyer_implode( $main_nav_classes ) ]['color']             = Lawyer_Sanitize::color( lawyer_get_settings( 'main_navigation_dropdown_color' ) );
	$css['global']['#secondary-navigation .navigation ul ul a:hover']['color'] = Lawyer_Sanitize::color( lawyer_get_settings( 'main_navigation_dropdown_hover_color' ) );

	// Single color.
	$css['global']['.single_post .post-single-content a, .single_post ul li::before']['color'] = Lawyer_Sanitize::color( lawyer_get_settings( 'main_navigation_dropdown_hover_color' ) );

	// Contact info.
	if ( ! empty( lawyer_get_settings( 'contact_info' ) ) && is_array( lawyer_get_settings( 'contact_info' ) ) ) :

		$i            = 0;
		$contect_info = lawyer_get_settings( 'contact_info' );

		foreach ( $contect_info as $info ) :

			++$i;

			$css['global'][ '.info-' . $i . ' .contact-info-icon' ]['color'] = Lawyer_Sanitize::color( $info['contact_info_icon_color'] );

			$css['global'][ '.info-' . $i . ' p.small-text' ]['color'] = Lawyer_Sanitize::color( $info['contact_info_small_text_color'] );

			$css['global'][ '.info-' . $i . ' p.large-text' ]['color'] = Lawyer_Sanitize::color( $info['contact_info_text_color'] );

			$contect_info_border = Lawyer_Sanitize::border( $info['contact_info_border'] );
			$css['global'][ '.info-' . $i ][ $contect_info_border['direction'] ] = $contect_info_border ['value'];

			lawyer_merge_value( $css['global'][ '.info-' . $i ], Lawyer_Sanitize::margin( $info['contact_info_margin'] ) );
			lawyer_merge_value( $css['global'][ '.info-' . $i ], Lawyer_Sanitize::padding( $info['contact_info_padding'] ) );

		endforeach;

	endif;

	// Social icons.
	if ( ! empty( lawyer_get_settings( 'header_social_icons' ) ) && is_array( lawyer_get_settings( 'header_social_icons' ) ) ) :
		$header_icons = lawyer_get_settings( 'header_social_icons' );
		foreach ( $header_icons as $header_icon ) :

			$css['global'][ '.header-social-icons a.header-' . $header_icon['header_icon'] ]['background-color'] = Lawyer_Sanitize::color( $header_icon['header_icon_bgcolor'] );

			$css['global'][ '.header-social-icons a.header-' . $header_icon['header_icon'] . ':hover' ]['background-color'] = Lawyer_Sanitize::color( $header_icon['header_icon_hover_bgcolor'] );

			$css['global'][ '.header-social-icons a.header-' . $header_icon['header_icon'] ]['color'] = Lawyer_Sanitize::color( $header_icon['header_icon_color'] );

			$css['global'][ '.header-social-icons a.header-' . $header_icon['header_icon'] . ':hover' ]['color'] = Lawyer_Sanitize::color( $header_icon['header_icon_hover_color'] );

			lawyer_merge_value( $css['global'][ '.header-social-icons a.header-' . $header_icon['header_icon'] ], Lawyer_Sanitize::margin( $header_icon['header_icon_margin'] ) );

			lawyer_merge_value( $css['global'][ '.header-social-icons a.header-' . $header_icon['header_icon'] ], Lawyer_Sanitize::padding( $header_icon['header_icon_padding'] ) );

			$header_icon_border = Lawyer_Sanitize::border( $header_icon['header_icon_border'] );
			$css['global'][ '.header-social-icons a.header-' . $header_icon['header_icon'] ][ $header_icon_border['direction'] ] = $header_icon_border ['value'];

			$css['global'][ '.header-social-icons a.header-' . $header_icon['header_icon'] ]['border-radius'] = Lawyer_Sanitize::size( $header_icon['header_icon_border_radius'] . 'px' );

		endforeach;
	endif;

	// Header Ad.
	lawyer_merge_value( $css['global']['.widget-header, .small-header .widget-header'], Lawyer_Sanitize::margin( lawyer_get_settings( 'mts_header_adcode_margin' ) ) );

	// Ad-Blocker.
	$css['global']['.navigation-banner']['background'] = Lawyer_Sanitize::color( lawyer_get_settings( 'navigation_ad_background' ) );
}

/**
 * Social Share Styling
 *
 * @param array $css Array of dynamic CSS.
 */
function lawyer_single_social_buttons( &$css ) {

	$social_shadow = lawyer_get_settings( 'social_styling_box_shadow' );

	// Social share.
	$css['global']['.shareit.floating'] = Lawyer_Sanitize::background( lawyer_get_settings( 'social_styling_background' ) );
	lawyer_merge_value( $css['global']['.shareit.floating'], Lawyer_Sanitize::margin( lawyer_get_settings( 'social_styling_margin' ) ) );

	// Social share border.
	$social_border = Lawyer_Sanitize::border( lawyer_get_settings( 'social_styling_border' ) );
	$css['global']['.shareit.floating'][ $social_border ['direction'] ] = $social_border ['value'];

	if ( 0 === $social_shadow ) {
		$css['global']['.shareit.floating']['box-shadow'] = 'none';
	}
	$social_button_layout   = lawyer_get_settings( 'social_button_layout' );
	$social_button_position = lawyer_get_settings( 'social_floating_button_position' );
	if ( 'default' === $social_button_layout ) {
		$share_class = '.shareit.shareit-' . $social_button_layout . '.floating';
	} else {
		$share_class = '.shareit.' . $social_button_layout . '.floating';
	}
	if ( ! empty( $social_button_position ) && is_array( $social_button_position ) ) {
		foreach ( $social_button_position as $key => $position ) {
			$css['global'][ $share_class ][ $key ] = $position;
		}
	}
}

/**
 * Sidebar styling
 *
 * @param array $css Array of dynamic CSS.
 */
function lawyer_sidebar_styling( &$css ) {

	// Sidebar.
	lawyer_merge_value( $css['global']['#sidebar .widget'], Lawyer_Sanitize::background( lawyer_get_settings( 'mts_sidebar_styling_background' ) ) );
	lawyer_merge_value( $css['global']['#sidebar .widget'], Lawyer_Sanitize::margin( lawyer_get_settings( 'mts_sidebar_styling_margin' ) ) );
	lawyer_merge_value( $css['global']['#sidebar .widget'], Lawyer_Sanitize::padding( lawyer_get_settings( 'mts_sidebar_styling_padding' ) ) );
	// Sidebar border.
	$sidebar_border = Lawyer_Sanitize::border( lawyer_get_settings( 'sidebar_styling_border' ) );
	$css['global']['#sidebar .widget'][ $sidebar_border['direction'] ] = $sidebar_border['value'];

	// Sidebar title.
	$sidebar_title                   = '#sidebar .widget h3, #sidebar .widget #wp-subscribe .title';
	$css['global'][ $sidebar_title ] = Lawyer_Sanitize::background( lawyer_get_settings( 'mts_sidebar_title_styling_background' ) );
	lawyer_merge_value( $css['global'][ $sidebar_title ], Lawyer_Sanitize::padding( lawyer_get_settings( 'mts_sidebar_title_styling_padding' ) ) );
	lawyer_merge_value( $css['global'][ $sidebar_title ], Lawyer_Sanitize::margin( lawyer_get_settings( 'mts_sidebar_title_styling_margin' ) ) );
	// Sidebar Title border.
	$sidebar_title_border = Lawyer_Sanitize::border( lawyer_get_settings( 'widget_title_border' ) );
	$css['global'][ $sidebar_title ][ $sidebar_title_border['direction'] ] = $sidebar_title_border['value'];
}

/**
 * HomePage sections CSS
 *
 * @param array $css Array of dynamic CSS.
 */
function lawyer_home_sections( &$css ) {

	/**
	 * Featured 1 Section.
	 *
	 */
	$css['global']['.featured1-section'] = Lawyer_Sanitize::background( lawyer_get_settings( 'featured1_background' ) );

	lawyer_merge_value( $css['global']['.featured1-section'], Lawyer_Sanitize::padding( lawyer_get_settings( 'featured1_padding' ) ) );

	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'featured1_title_font' ) ) );
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'featured1_text_font' ) ) );

	/**
	 * Featured 2 Section.
	 *
	 */
	$css['global']['.featured2-section'] = Lawyer_Sanitize::background( lawyer_get_settings( 'featured2_background' ) );

	lawyer_merge_value( $css['global']['.featured2-section'], Lawyer_Sanitize::padding( lawyer_get_settings( 'featured2_padding' ) ) );

	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'featured2_title_font' ) ) );
	// Featured 2 nav.
	$featured2_nav_border = Lawyer_Sanitize::border( lawyer_get_settings( 'featured2_nav_border' ) );
	$css['global']['.featured2-navigation'][ $featured2_nav_border ['direction'] ] = $featured2_nav_border ['value'];

	lawyer_merge_value( $css['global']['.featured2-navigation'], Lawyer_Sanitize::margin( lawyer_get_settings( 'featured2_nav_margin' ) ) );
	lawyer_merge_value( $css['global']['.featured2-navigation'], Lawyer_Sanitize::padding( lawyer_get_settings( 'featured2_nav_padding' ) ) );

	/**
	 * Icon Grid Section.
	 *
	 */
	$css['global']['.icon-grid-section'] = Lawyer_Sanitize::background( lawyer_get_settings( 'icon_grid_background' ) );

	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'icon_grid_title_font' ) ) );
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'icon_grid_text_font' ) ) );

	lawyer_merge_value( $css['global']['.icon-grid-section'], Lawyer_Sanitize::padding( lawyer_get_settings( 'icon_grid_padding' ) ) );

	/**
	 * Services Grid Section.
	 *
	 */
	$css['global']['.services-grid-section'] = Lawyer_Sanitize::background( lawyer_get_settings( 'services_grid_background' ) );

	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'services_grid_title_font' ) ) );
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'services_grid_text_font' ) ) );
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'services_group_title_font' ) ) );
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'services_group_text_font' ) ) );

	lawyer_merge_value( $css['global']['.services-grid-section'], Lawyer_Sanitize::padding( lawyer_get_settings( 'services_grid_padding' ) ) );

	/**
	 * CTA Section.
	 *
	 */
	$css['global']['.cta-section'] = Lawyer_Sanitize::background( lawyer_get_settings( 'cta_background' ) );

	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'cta_title_font' ) ) );

	lawyer_merge_value( $css['global']['.cta-section'], Lawyer_Sanitize::padding( lawyer_get_settings( 'cta_padding' ) ) );

	/**
	 * Services List Section.
	 *
	 */
	$css['global']['.services-list-section'] = Lawyer_Sanitize::background( lawyer_get_settings( 'services_list_background' ) );

	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'services_list_title_font' ) ) );

	lawyer_merge_value( $css['global']['.services-list-section'], Lawyer_Sanitize::padding( lawyer_get_settings( 'services_list_padding' ) ) );

	/**
	 * Stats Section.
	 *
	 */
	$css['global']['.stats-section'] = Lawyer_Sanitize::background( lawyer_get_settings( 'stats_background' ) );

	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'stats_figure_font' ) ) );
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'stats_text_font' ) ) );
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'stats_list_title_font' ) ) );
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'stats_list_text_font' ) ) );

	lawyer_merge_value( $css['global']['.stats-section'], Lawyer_Sanitize::padding( lawyer_get_settings( 'stats_padding' ) ) );

	/**
	 * Stats 2 Section.
	 *
	 */
	$css['global']['.stats2-section .left']  = Lawyer_Sanitize::background( lawyer_get_settings( 'stats2_left_background' ) );
	$css['global']['.stats2-section .right'] = Lawyer_Sanitize::background( lawyer_get_settings( 'stats2_right_background' ) );

	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'stats2_left_figure_font' ) ) );
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'stats2_left_title_font' ) ) );
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'stats2_left_text_font' ) ) );

	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'stats2_right_figure_font' ) ) );
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'stats2_right_title_font' ) ) );
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'stats2_right_text_font' ) ) );

	lawyer_merge_value( $css['global']['.stats2-section .left'], Lawyer_Sanitize::padding( lawyer_get_settings( 'stats2_left_padding' ) ) );
	lawyer_merge_value( $css['global']['.stats2-section .right'], Lawyer_Sanitize::padding( lawyer_get_settings( 'stats2_right_padding' ) ) );

	/**
	 * Team Section.
	 *
	 */
	$css['global']['.team-section'] = Lawyer_Sanitize::background( lawyer_get_settings( 'team_background' ) );

	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'team_title_font' ) ) );
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'team_text_font' ) ) );
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'team_group_title_font' ) ) );
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'team_group_text_font' ) ) );
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'team_group_hover_text_font' ) ) );

	lawyer_merge_value( $css['global']['.team-section'], Lawyer_Sanitize::padding( lawyer_get_settings( 'team_padding' ) ) );

	$team_grids = lawyer_get_settings( 'team_group' );
	if ( ! empty( $team_grids ) && is_array( $team_grids ) ) {
		foreach ( $team_grids as $team_grid ) {
			$css['global']['.team-section .team-container .img:hover::after']['background-color'] = Lawyer_Sanitize::color( $team_grid['team_group_hover_color'] );
		}
	}

	/**
	 * Services Grid 2 Section.
	 *
	 */
	$css['global']['.services-grid2-section'] = Lawyer_Sanitize::background( lawyer_get_settings( 'services_grid2_background' ) );

	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'services_grid2_title_font' ) ) );
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'services_grid2_text_font' ) ) );

	lawyer_merge_value( $css['global']['.services-grid2-section'], Lawyer_Sanitize::padding( lawyer_get_settings( 'services_grid2_padding' ) ) );

	/**
	 * Blog Section.
	 *
	 */
	$css['global']['.blog-section']    = Lawyer_Sanitize::background( lawyer_get_settings( 'blog_section_background' ) );
	$css['global']['.post-wrapper li'] = Lawyer_Sanitize::background( lawyer_get_settings( 'blog_post_background' ) );

	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'blog_section_title_font' ) ) );
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'blog_section_text_font' ) ) );
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'blog_post_title_font' ) ) );
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'blog_post_meta_font' ) ) );

	lawyer_merge_value( $css['global']['.blog-section'], Lawyer_Sanitize::padding( lawyer_get_settings( 'blog_section_padding' ) ) );

	// Social icons.
	$blog_social_icons = lawyer_get_settings( 'blog_social_icons' );
	if ( ! empty( $blog_social_icons ) && is_array( $blog_social_icons ) ) :
		foreach ( $blog_social_icons as $blog_social_icon ) :

			$css['global'][ '.blog-social-icons a.blog-social-' . $blog_social_icon['blog_social_icon'] ]['background-color'] = Lawyer_Sanitize::color( $blog_social_icon['blog_social_bgcolor'] );

			$css['global'][ '.blog-social-icons a.blog-social-' . $blog_social_icon['blog_social_icon'] . ':hover' ]['background-color'] = Lawyer_Sanitize::color( $blog_social_icon['blog_social_hover_bgcolor'] );

			$css['global'][ '.blog-social-icons a.blog-social-' . $blog_social_icon['blog_social_icon'] ]['color'] = Lawyer_Sanitize::color( $blog_social_icon['blog_social_color'] );

			$css['global'][ '.blog-social-icons a.blog-social-' . $blog_social_icon['blog_social_icon'] . ':hover' ]['color'] = Lawyer_Sanitize::color( $blog_social_icon['blog_social_hover_color'] );

			lawyer_merge_value( $css['global'][ '.blog-social-icons a.blog-social-' . $blog_social_icon['blog_social_icon'] ], Lawyer_Sanitize::margin( $blog_social_icon['blog_social_margin'] ) );

			lawyer_merge_value( $css['global'][ '.blog-social-icons a.blog-social-' . $blog_social_icon['blog_social_icon'] ], Lawyer_Sanitize::padding( $blog_social_icon['blog_social_padding'] ) );

			if ( ! empty( $blog_social_icon['blog_social_border'] ) ) {
				$blog_social_icon_border = Lawyer_Sanitize::border( $blog_social_icon['blog_social_border'] );
				$css['global'][ '.blog-social-icons a.blog-social-' . $blog_social_icon['blog_social_icon'] ][ $blog_social_icon_border['direction'] ] = $blog_social_icon_border ['value'];
			}

			$css['global'][ '.blog-social-icons a.blog-social-' . $blog_social_icon['blog_social_icon'] ]['border-radius'] = Lawyer_Sanitize::size( $blog_social_icon['blog_social_border_radius'] . 'px' );

		endforeach;
	endif;

	/**
	 * Featured On Section.
	 *
	 */
	$css['global']['.featured-on-section'] = Lawyer_Sanitize::background( lawyer_get_settings( 'featured_on_background' ) );

	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'featured_on_title_font' ) ) );
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'featured_on_text_font' ) ) );

	lawyer_merge_value( $css['global']['.featured-on-section'], Lawyer_Sanitize::padding( lawyer_get_settings( 'featured_on_padding' ) ) );

	/**
	 * Featured 3 Section.
	 *
	 */
	$css['global']['.featured3-section'] = Lawyer_Sanitize::background( lawyer_get_settings( 'featured3_background' ) );

	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'featured3_title_font' ) ) );
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'featured3_text_font' ) ) );
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'featured3_info_text_font' ) ) );
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'featured3_info_small_text_font' ) ) );

	lawyer_merge_value( $css['global']['.featured3-section'], Lawyer_Sanitize::padding( lawyer_get_settings( 'featured3_padding' ) ) );

	/**
	 * Why Us Section.
	 *
	 */
	$css['global']['.why-us-section'] = Lawyer_Sanitize::background( lawyer_get_settings( 'why_us_background' ) );

	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'why_us_title_font' ) ) );
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'why_us_text_font' ) ) );
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'why_us_list_title_font' ) ) );
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'why_us_list_text_font' ) ) );

	lawyer_merge_value( $css['global']['.why-us-section'], Lawyer_Sanitize::padding( lawyer_get_settings( 'why_us_padding' ) ) );

	/**
	 * FAQs Section.
	 *
	 */
	$css['global']['.faqs-section'] = Lawyer_Sanitize::background( lawyer_get_settings( 'faqs_background' ) );

	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'faqs_question_font' ) ) );
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'faqs_answer_font' ) ) );

	lawyer_merge_value( $css['global']['.faqs-section'], Lawyer_Sanitize::padding( lawyer_get_settings( 'faqs_padding' ) ) );
}

/**
 * About Page Layout CSS
 *
 * @param array $css Array of dynamic CSS.
 */
function lawyer_about_sections( &$css ) {

	/**
	 * Featured Section.
	 *
	 */
	$css['global']['.about-featured-section'] = Lawyer_Sanitize::background( lawyer_get_settings( 'about_featured_background' ) );

	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'about_featured_figure_font' ) ) );
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'about_featured_title_font' ) ) );

	lawyer_merge_value( $css['global']['.about-featured-section'], Lawyer_Sanitize::padding( lawyer_get_settings( 'about_featured_padding' ) ) );

	/**
	 * Services Grid Section.
	 *
	 */
	$css['global']['.about-services-grid-section'] = Lawyer_Sanitize::background( lawyer_get_settings( 'about_services_grid_background' ) );

	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'about_services_group_title_font' ) ) );
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'about_services_group_text_font' ) ) );

	lawyer_merge_value( $css['global']['.about-services-grid-section'], Lawyer_Sanitize::padding( lawyer_get_settings( 'about_services_grid_padding' ) ) );

	/**
	 * Video Section.
	 *
	 */
	$css['global']['.about-video-section .video-img']['background-image'] = 'url(' . lawyer_get_settings( 'about_video_image' ) . ')';

	lawyer_merge_value( $css['global']['.about-video-section'], Lawyer_Sanitize::padding( lawyer_get_settings( 'about_video_padding' ) ) );

	/**
	 * Testimonials Section.
	 *
	 */
	$css['global']['.about-testimonials-section'] = Lawyer_Sanitize::background( lawyer_get_settings( 'about_testimonials_background' ) );

	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'about_testimonials_title_font' ) ) );
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'about_testimonials_text_font' ) ) );
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'about_testimonials_group_author_font' ) ) );
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'about_testimonials_group_testimonial_font' ) ) );

	lawyer_merge_value( $css['global']['.about-testimonials-section'], Lawyer_Sanitize::padding( lawyer_get_settings( 'about_services_grid_padding' ) ) );

	/**
	 * Stats Section.
	 *
	 */
	$css['global']['.about-stats-section'] = Lawyer_Sanitize::background( lawyer_get_settings( 'about_stats_background' ) );

	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'about_stats_title_font' ) ) );
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'about_stats_text_font' ) ) );
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'about_stats_group_title_font' ) ) );
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'about_stats_group_percentage_font' ) ) );

	lawyer_merge_value( $css['global']['.about-stats-section'], Lawyer_Sanitize::padding( lawyer_get_settings( 'about_stats_padding' ) ) );

	/**
	 * Featured On Section.
	 *
	 */
	$css['global']['.about-featured-on-section'] = Lawyer_Sanitize::background( lawyer_get_settings( 'about_featured_on_background' ) );

	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'about_featured_on_title_font' ) ) );
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'about_featured_on_text_font' ) ) );

	lawyer_merge_value( $css['global']['.about-featured-on-section'], Lawyer_Sanitize::padding( lawyer_get_settings( 'about_featured_on_padding' ) ) );

	/**
	 * Services List Section.
	 *
	 */
	$css['global']['.about-services-list-section'] = Lawyer_Sanitize::background( lawyer_get_settings( 'about_services_list_background' ) );

	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'about_services_list_group_title_font' ) ) );
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'about_services_list_group_text_font' ) ) );

	lawyer_merge_value( $css['global']['.about-services-list-section'], Lawyer_Sanitize::margin( lawyer_get_settings( 'about_services_list_margin' ) ) );
	lawyer_merge_value( $css['global']['.about-services-list-section'], Lawyer_Sanitize::padding( lawyer_get_settings( 'about_services_list_padding' ) ) );

}

/**
 * Layout CSS
 *
 * @param array $css Array of dynamic CSS.
 */
function lawyer_post_layouts( &$css ) {

	// Heading Section.
	$css['global']['.blog-heading-section'] = Lawyer_Sanitize::background( lawyer_get_settings( 'blog_heading_bg' ) );

	lawyer_merge_value( $css['global']['.blog-heading-section'], Lawyer_Sanitize::margin( lawyer_get_settings( 'blog_heading_margin' ) ) );

	lawyer_merge_value( $css['global']['.blog-heading-section'], Lawyer_Sanitize::padding( lawyer_get_settings( 'blog_heading_padding' ) ) );

	// Post Layouts.
	$features = lawyer_get_settings( 'mts_featured_categories' );
	foreach ( $features as $feature ) :

		if ( ! isset( $feature['unique_id'] ) ) {
			continue;
		}

		$category     = $feature['mts_featured_category'];
		$posts_layout = 'layout-default';
		$unique_id    = $feature['unique_id'];

		if ( 'layout-default' === $posts_layout ) :
			$posts_layout = 'default';
		endif;

		// Container Class.
		if ( ! in_array( $posts_layout, array( 'default' ) ) ) :
			$container_class                                     = array(
				'.layout-' . $unique_id,
			);
			$css['global'][ lawyer_implode( $container_class ) ] = array(
				'width'    => '100%',
				'float'    => 'none',
				'overflow' => 'visible',
				'position' => 'relative',
			);
		endif;
		if ( ! in_array( $posts_layout, array( 'default' ) ) ) :
			$all_class                                     = array(
				'.layout-' . $unique_id . ' .latestPost .title',
			);
			$css['global'][ lawyer_implode( $all_class ) ] = array(
				'line-height' => '1',
				'font-size'   => 'inherit',
			);
		endif;

		// Section title align.
		$post_title_align = lawyer_get_settings( 'mts_post_title_alignment_' . $unique_id );

		// Post area.
		$cat_class = 'cat-latest';
		if ( 'latest' !== $category ) {
			$category  = get_term_by( 'slug', $category, 'category' );
			$cat_class = sanitize_key( $category->name );
		}

		$title_class = '.title-container.title-id-' . $unique_id . ' h3';

		$css['global'][ $title_class ] = Lawyer_Sanitize::background( lawyer_get_settings( 'mts_featured_category_title_background_' . $unique_id ) );
		lawyer_merge_value( $css['global'][ $title_class ], Lawyer_Sanitize::margin( lawyer_get_settings( 'mts_featured_category_title_margin_' . $unique_id ) ) );
		lawyer_merge_value( $css['global'][ $title_class ], Lawyer_Sanitize::padding( lawyer_get_settings( 'mts_featured_category_title_padding_' . $unique_id ) ) );
		// Section title border.
		$post_title_border = Lawyer_Sanitize::border( lawyer_get_settings( 'post_title_border_' . $unique_id ) );
		$css['global'][ $title_class ][ $post_title_border['direction'] ] = $post_title_border['value'];

		// Title alignment.
		$align_class = '.title-container.title-id-' . $unique_id;
		if ( 'center' === $post_title_align ) :
			$css['global'][ $align_class ]['text-align'] = 'center';
		elseif ( 'right' === $post_title_align ) :
			$css['global'][ $align_class ]['text-align'] = 'right';
		elseif ( 'full' === $post_title_align ) :
			$css['global'][ $title_class ]['width'] = '100%';
		endif;

		lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'mts_featured_category_title_font_' . $unique_id ) ) );

		$post_class = '.layout-' . $unique_id . '.default-container';

		// Post border.
		$post_border = Lawyer_Sanitize::border( lawyer_get_settings( 'post_border_' . $unique_id ) );
		$css['global'][ $post_class ][ $post_border['direction'] ] = $post_border['value'];

		lawyer_merge_value( $css['global'][ $post_class ], Lawyer_Sanitize::margin( lawyer_get_settings( 'post_margin_' . $unique_id ) ) );
		lawyer_merge_value( $css['global'][ $post_class ], Lawyer_Sanitize::padding( lawyer_get_settings( 'post_padding_' . $unique_id ) ) );

		/**
		 * Meta info
		 */

		lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'meta_info_font_' . $unique_id ) ) );

		lawyer_merge_value( $css['global'][ '.layout-' . $unique_id . ' .latestPost .post-info' ], Lawyer_Sanitize::margin( lawyer_get_settings( 'mts_meta_info_margin_' . $unique_id ) ) );

		lawyer_merge_value( $css['global'][ '.layout-' . $unique_id . ' .latestPost .post-info' ], Lawyer_Sanitize::padding( lawyer_get_settings( 'mts_meta_info_padding_' . $unique_id ) ) );

		lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'post_title_font_' . $unique_id ) ) );

		lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'post_excerpt_font_' . $unique_id ) ) );

		// Border.
		$meta_info_border = Lawyer_Sanitize::border( lawyer_get_settings( 'meta_info_border_' . $unique_id ) );
		$css['global'][ '.layout-' . $unique_id . ' .latestPost .post-info' ][ $meta_info_border['direction'] ] = $meta_info_border['value'];

	endforeach;
}

/**
 * Pagination
 *
 * @param array $css Array of dynamic CSS.
 */
function lawyer_post_pagination( &$css ) {

	// Pagination Active class.
	$pagination_class_active = array(
		'.pace .pace-progress',
		'.page-numbers.current',
		'#mobile-menu-wrapper ul li a:hover',
		'.pagination a:hover',
	);
	$pagination_class        = array(
		'.pagination a',
		'.single .pagination > .current .currenttext',
		'.pagination .page-numbers.dots',
	);
	lawyer_merge_value( $css['global'][ lawyer_implode( array_merge( $pagination_class_active, $pagination_class ) ) ], Lawyer_Sanitize::margin( lawyer_get_settings( 'mts_pagenavigation_margin' ) ) );
	if ( '2' !== lawyer_get_settings( 'mts_pagenavigation_type' ) ) {
		$css['global'][ lawyer_implode( $pagination_class ) ]['background-color'] = Lawyer_Sanitize::color( lawyer_get_settings( 'mts_pagenavigation_bgcolor' ) );

		$css['global'][ lawyer_implode( $pagination_class_active ) ]['background-color'] = Lawyer_Sanitize::color( lawyer_get_settings( 'mts_pagenavigation_hover_bgcolor' ) );

		$css['global'][ lawyer_implode( $pagination_class ) ]['color'] = Lawyer_Sanitize::color( lawyer_get_settings( 'mts_pagenavigation_color' ) );

		$css['global'][ lawyer_implode( $pagination_class_active ) ]['color'] = Lawyer_Sanitize::color( lawyer_get_settings( 'mts_pagenavigation_hover_color' ) );

		lawyer_merge_value( $css['global'][ lawyer_implode( array_merge( $pagination_class_active, $pagination_class ) ) ], Lawyer_Sanitize::padding( lawyer_get_settings( 'mts_pagenavigation_padding' ) ) );
	} else {
		$css['global']['#load-posts a']['background-color'] = Lawyer_Sanitize::color( lawyer_get_settings( 'load_more_bgcolor' ) );

		$css['global']['#load-posts a:hover']['background-color'] = Lawyer_Sanitize::color( lawyer_get_settings( 'load_more_hover_bgcolor' ) );

		$css['global']['#load-posts a']['color'] = Lawyer_Sanitize::color( lawyer_get_settings( 'load_more_color' ) );

		$css['global']['#load-posts a:hover']['color'] = Lawyer_Sanitize::color( lawyer_get_settings( 'load_more_hover_color' ) );

		lawyer_merge_value( $css['global']['#load-posts a'], Lawyer_Sanitize::padding( lawyer_get_settings( 'load_more_padding' ) ) );
	}
	$css['global'][ lawyer_implode( $pagination_class ) ]['border-radius']        = Lawyer_Sanitize::size( lawyer_get_settings( 'mts_pagenavigation_border_radius' ) . 'px' );
	$css['global'][ lawyer_implode( $pagination_class_active ) ]['border-radius'] = Lawyer_Sanitize::size( lawyer_get_settings( 'mts_pagenavigation_border_radius' ) . 'px' );

	// Pagination border.
	$pagination_border = Lawyer_Sanitize::border( lawyer_get_settings( 'pagenavigation_border' ) );
	$css['global']['.pagination'][ $pagination_border ['direction'] ] = $pagination_border ['value'];

	// Load more Alignment.
	$load_more_align = lawyer_get_settings( 'load_more_alignment' );
	if ( 'left' === $load_more_align ) :
		$css['global']['#load-posts']['text-align'] = 'left';
	elseif ( 'right' === $load_more_align ) :
		$css['global']['#load-posts']['text-align'] = 'right';
	elseif ( 'full' === $load_more_align ) :
		$css['global']['#load-posts a']['width'] = '100%';
	endif;
}

/**
 * Single
 *
 * @param array $css Array of dynamic CSS.
 */
function lawyer_single( &$css ) {

	// Single, Page, Archive, Search, Category and 404 Page Background.
	$page_classes = array(
		'.single .article',
		'.page .article',
		'.search .article',
		'.archive .article',
		'.error404 .article',
	);

	$css['global'][ lawyer_implode( $page_classes ) ] = Lawyer_Sanitize::background( lawyer_get_settings( 'single_background' ) );

	// Margin, Padding, Border and Box Shadow.
	lawyer_merge_value( $css['global'][ lawyer_implode( $page_classes ) ], Lawyer_Sanitize::margin( lawyer_get_settings( 'mts_single_styling_margin' ) ) );
	lawyer_merge_value( $css['global'][ lawyer_implode( $page_classes ) ], Lawyer_Sanitize::padding( lawyer_get_settings( 'mts_single_styling_padding' ) ) );

	// Single border.
	$single_border = Lawyer_Sanitize::border( lawyer_get_settings( 'single_styling_border' ) );
	$css['global']['.article'][ $single_border ['direction'] ] = $single_border ['value'];

	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'mts_single_meta_info_font' ) ) );

	// Related Posts.
	$css['global']['.related-posts'] = Lawyer_Sanitize::background( lawyer_get_settings( 'related_posts_background' ) );
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'related_posts_font' ) ) );
	lawyer_map_css_selectors( $css['global'], Lawyer_Sanitize::typography( lawyer_get_settings( 'related_posts_meta_font' ) ) );
	lawyer_merge_value( $css['global']['.related-posts'], Lawyer_Sanitize::margin( lawyer_get_settings( 'related_posts_margin' ) ) );
	lawyer_merge_value( $css['global']['.related-posts'], Lawyer_Sanitize::padding( lawyer_get_settings( 'related_posts_padding' ) ) );

	$related_posts_border = Lawyer_Sanitize::border( lawyer_get_settings( 'related_posts_border' ) );
	$css['global']['.related-posts'][ $related_posts_border ['direction'] ] = $related_posts_border ['value'];

	// Related Posts articles.
	$css['global']['.related-posts article'] = Lawyer_Sanitize::background( lawyer_get_settings( 'related_article_background' ) );
	lawyer_merge_value( $css['global']['.related-posts article'], Lawyer_Sanitize::padding( lawyer_get_settings( 'related_article_padding' ) ) );
	lawyer_merge_value( $css['global']['.related-posts article header'], Lawyer_Sanitize::padding( lawyer_get_settings( 'related_article_text_padding' ) ) );

	// Subscribe Box.
	$css['global']['.single-subscribe .widget #wp-subscribe'] = Lawyer_Sanitize::background( lawyer_get_settings( 'single_subscribe_background' ) );
	lawyer_merge_value( $css['global']['.single-subscribe .widget #wp-subscribe'], Lawyer_Sanitize::margin( lawyer_get_settings( 'single_subscribe_margin' ) ) );
	lawyer_merge_value( $css['global']['.single-subscribe .widget #wp-subscribe'], Lawyer_Sanitize::padding( lawyer_get_settings( 'single_subscribe_padding' ) ) );
	$css['global']['.single-subscribe .widget #wp-subscribe']['border-radius'] = Lawyer_Sanitize::size( lawyer_get_settings( 'single_subscribe_border_radius' ) . 'px' );

	// Subscribe Box Input fields.
	$subscribe_input_class = array(
		'.single-subscribe #wp-subscribe input.email-field',
		'.single-subscribe #wp-subscribe input.name-field',
	);
	$css['global'][ lawyer_implode( $subscribe_input_class ) ]['background-color'] = Lawyer_Sanitize::color( lawyer_get_settings( 'single_subscribe_input_background' ) );

	$css['global'][ lawyer_implode( $subscribe_input_class ) ]['height'] = Lawyer_Sanitize::size( lawyer_get_settings( 'single_subscribe_input_height' ) . 'px' );

	$css['global']['.single-subscribe .widget #wp-subscribe input.submit']['height'] = Lawyer_Sanitize::size( lawyer_get_settings( 'single_subscribe_input_height' ) . 'px' );

	$css['global'][ lawyer_implode( $subscribe_input_class ) ]['border-radius'] = Lawyer_Sanitize::size( lawyer_get_settings( 'single_subscribe_input_border_radius' ) . 'px' );

	// Subscribe Box Input border.
	$subscribe_box_input_border = Lawyer_Sanitize::border( lawyer_get_settings( 'single_subscribe_input_border' ) );
	$css['global'][ lawyer_implode( $subscribe_input_class ) ][ $subscribe_box_input_border ['direction'] ] = $subscribe_box_input_border ['value'];

	// Subscribe Box Submit button.
	$css['global']['.single-subscribe .widget #wp-subscribe input.submit']['background']    = Lawyer_Sanitize::color( lawyer_get_settings( 'single_subscribe_submit_backgroud' ) );
	$css['global']['.single-subscribe .widget #wp-subscribe input.submit']['border-radius'] = Lawyer_Sanitize::size( lawyer_get_settings( 'single_subscribe_submit_border_radius' ) . 'px' );

	// Subscribe Box Submit border.
	$subscribe_box_submit_border = Lawyer_Sanitize::border( lawyer_get_settings( 'single_subscribe_submit_border' ) );
	$css['global']['.single-subscribe .widget #wp-subscribe input.submit'][ $subscribe_box_submit_border ['direction'] ] = $subscribe_box_submit_border ['value'];

	lawyer_merge_value( $css['global']['.single-subscribe .widget #wp-subscribe input.submit'], Lawyer_Sanitize::padding( lawyer_get_settings( 'single_subscribe_submit_padding' ) ) );

	// Author Box.
	$css['global']['.postauthor'] = Lawyer_Sanitize::background( lawyer_get_settings( 'single_authorbox_background' ) );

	lawyer_merge_value( $css['global']['.postauthor'], Lawyer_Sanitize::margin( lawyer_get_settings( 'single_authorbox_margin' ) ) );

	lawyer_merge_value( $css['global']['.postauthor'], Lawyer_Sanitize::padding( lawyer_get_settings( 'single_authorbox_padding' ) ) );

	$css['global']['.postauthor']['border-radius'] = Lawyer_Sanitize::size( lawyer_get_settings( 'single_authorbox_border_radius' ) . 'px' );

	$single_authorbox_border = Lawyer_Sanitize::border( lawyer_get_settings( 'single_authorbox_border' ) );
	$css['global']['.postauthor'][ $single_authorbox_border ['direction'] ] = $single_authorbox_border ['value'];

	// Author image.
	lawyer_merge_value( $css['global']['.postauthor img'], Lawyer_Sanitize::margin( lawyer_get_settings( 'single_author_image_margin' ) ) );

	$css['global']['.postauthor img']['border-radius'] = Lawyer_Sanitize::size( lawyer_get_settings( 'single_author_image_border_radius' ) . 'px' );

	// Single Page titles Styling.
	$titles_align = lawyer_get_settings( 'single_title_alignment' );

	$titles_align_class = array(
		'.comment-title',
		'#respond',
		'.related-posts-title',
	);
	$titles_class       = array(
		'#respond h4',
		'.total-comments',
		'.related-posts h4',
	);

	$css['global'][ lawyer_implode( $titles_class ) ] = Lawyer_Sanitize::background( lawyer_get_settings( 'single_title_background' ) );
	lawyer_merge_value( $css['global'][ lawyer_implode( $titles_class ) ], Lawyer_Sanitize::padding( lawyer_get_settings( 'single_title_padding' ) ) );
	// Single title border.
	$single_titles_border = Lawyer_Sanitize::border( lawyer_get_settings( 'single_title_border' ) );
	$css['global'][ lawyer_implode( $titles_class ) ][ $single_titles_border ['direction'] ] = $single_titles_border ['value'];

	if ( 'left' === $titles_align ) :
		$css['global'][ lawyer_implode( $titles_class ) ]['display'] = 'inline-block';
	elseif ( 'center' === $titles_align ) :
		$css['global'][ lawyer_implode( $titles_align_class ) ]['text-align'] = 'center';
		$css['global'][ lawyer_implode( $titles_class ) ]['display']          = 'inline-block';
	elseif ( 'right' === $titles_align ) :
		$css['global'][ lawyer_implode( $titles_align_class ) ]['text-align'] = 'right';
		$css['global'][ lawyer_implode( $titles_class ) ]['display']          = 'inline-block';
	endif;

}

/**
 * Copyrights
 *
 * @param array $css Array of dynamic CSS.
 */
function lawyer_copyrights( &$css ) {

	// Copyrights background.
	$css['global']['.copyrights'] = Lawyer_Sanitize::background( lawyer_get_settings( 'mts_copyrights_background' ) );

	// copyrights border.
	$copyrights_border = Lawyer_Sanitize::border( lawyer_get_settings( 'copyrights_border' ) );
	$css['global']['.copyrights'][ $copyrights_border ['direction'] ] = $copyrights_border ['value'];

}

/**
 * Footer
 *
 * @param array $css Array of dynamic CSS.
 */
function lawyer_footer( &$css ) {

	// Footer background.
	$css['global']['#site-footer'] = Lawyer_Sanitize::background( lawyer_get_settings( 'mts_footer_background' ) );

	// Footer.
	lawyer_merge_value( $css['global']['#site-footer'], Lawyer_Sanitize::margin( lawyer_get_settings( 'mts_top_footer_margin' ) ) );
	lawyer_merge_value( $css['global']['#site-footer'], Lawyer_Sanitize::padding( lawyer_get_settings( 'mts_top_footer_padding' ) ) );

	// Footer widgets.
	if ( 1 === lawyer_get_settings( 'mts_top_footer' ) && 1 === lawyer_get_settings( 'mts_top_footer_num' ) ) :
		$css['global']['.footer-widgets']['display']                = 'flex';
		$css['global']['.footer-widgets']['justify-content']        = 'center';
		$css['global']['.footer-widgets .f-widget']['width']        = '38.7387388%';
		$css['global']['.footer-widgets .f-widget']['text-align']   = 'center';
		$css['global']['.footer-widgets .f-widget']['margin-right'] = '0px';
	endif;

	// Footer Navigation Section.
	lawyer_merge_value( $css['global']['.footer-nav-section'], Lawyer_Sanitize::margin( lawyer_get_settings( 'footer_nav_margin' ) ) );
	lawyer_merge_value( $css['global']['.footer-nav-section'], Lawyer_Sanitize::padding( lawyer_get_settings( 'footer_nav_padding' ) ) );

	// footer Nav border.
	$footer_nav_border = Lawyer_Sanitize::border( lawyer_get_settings( 'footer_nav_border' ) );
	$css['global']['.footer-nav-section'][ $footer_nav_border ['direction'] ] = $footer_nav_border ['value'];

	// footer Nav position.
	$footer_sections_position = lawyer_get_settings( 'footer_sections_position' );
	if ( 1 === lawyer_get_settings( 'footer_nav_section' ) || 1 === lawyer_get_settings( 'footer_brands_section' ) ) :
		if ( 'left' === $footer_sections_position || 'right' === $footer_sections_position ) :
			$css['global']['#site-footer .container']['display']   = 'flex';
			$css['global']['#site-footer .container']['flex-flow'] = 'row wrap';
			$css['global']['.footer-sections']['flex-basis']       = 'calc(25% - 20px )';
			$css['global']['.footer-sections']['padding-right']    = '20px';
			$css['global']['.footer-widgets']['flex-basis']        = '75%';
			$css['global']['.brands-container']['display']         = 'block';
			$css['global']['.brands-items li']['max-width']        = '100%';
			$css['global']['.brands-items li']['flex-basis']       = '60%';
		endif;
		if ( 'right' === $footer_sections_position ) :
			$css['global']['#site-footer .container']['flex-direction'] = 'row-reverse';
			$css['global']['.footer-sections']['padding-right']         = '0';
			$css['global']['.footer-sections']['padding-left']          = '20px';
			$css['global']['.brands-container']['text-align']           = 'right';
			$css['global']['.brands-items']['justify-content']          = 'flex-end';
		endif;
	endif;

	// footer Nav alignment.
	$footer_nav_align = lawyer_get_settings( 'footer_nav_alignment' );
	if ( 'left' === $footer_nav_align ) :
		$css['global']['.footer-nav-section']['text-align'] = 'left';
	elseif ( 'center' === $footer_nav_align ) :
		$css['global']['.footer-nav-section']['text-align'] = 'center';
	elseif ( 'right' === $footer_nav_align ) :
		$css['global']['.footer-nav-section']['text-align'] = 'right';
	endif;

	// footer Nav menu item.
	lawyer_merge_value( $css['global']['.footer-nav-container li a'], Lawyer_Sanitize::margin( lawyer_get_settings( 'footer_menu_item_margin' ) ) );

	// footer Nav separator.
	lawyer_merge_value( $css['global']['.footer-nav-container .footer-separator'], Lawyer_Sanitize::margin( lawyer_get_settings( 'footer_nav_separator_margin' ) ) );
	$css['global']['.footer-nav-container .footer-separator']['color'] = Lawyer_Sanitize::color( lawyer_get_settings( 'footer_nav_separator_color' ) );

	// Footer Logo Social icons.
	if ( 1 === lawyer_get_settings( 'footer_logo_social_icons' ) && ! empty( lawyer_get_settings( 'footer_logo_social' ) ) && is_array( lawyer_get_settings( 'footer_logo_social' ) ) ) :
		$footer_nav_icons = lawyer_get_settings( 'footer_logo_social' );
		foreach ( $footer_nav_icons as $footer_nav_icon ) :
			$footer_icons[]               = $footer_nav_icon['footer_logo_social_icon'];
			$footer_nav_icon_border_size  = $footer_nav_icon['footer_logo_social_border_size'];
			$footer_nav_icon_border_style = $footer_nav_icon['footer_logo_social_border_style'];
			$footer_nav_icon_border_color = $footer_nav_icon['footer_logo_social_border_color'];
			$footer_nav_icon_border       = $footer_nav_icon_border_size . 'px ' . $footer_nav_icon_border_style . ' ' . $footer_nav_icon_border_color;
			$css['global'][ '.footer-logo-social-icons a.footer-logo-' . $footer_nav_icon['footer_logo_social_icon'] ]['background-color']            = Lawyer_Sanitize::color( $footer_nav_icon['footer_logo_social_bgcolor'] );
			$css['global'][ '.footer-logo-social-icons a.footer-logo-' . $footer_nav_icon['footer_logo_social_icon'] . ':hover' ]['background-color'] = Lawyer_Sanitize::color( $footer_nav_icon['footer_logo_social_hover_bgcolor'] );
			$css['global'][ '.footer-logo-social-icons a.footer-logo-' . $footer_nav_icon['footer_logo_social_icon'] ]['color']                       = Lawyer_Sanitize::color( $footer_nav_icon['footer_logo_social_color'] );
			$css['global'][ '.footer-logo-social-icons a.footer-logo-' . $footer_nav_icon['footer_logo_social_icon'] . ':hover' ]['color']            = Lawyer_Sanitize::color( $footer_nav_icon['footer_logo_social_hover_color'] );
			lawyer_merge_value( $css['global'][ '.footer-logo-social-icons a.footer-logo-' . $footer_nav_icon['footer_logo_social_icon'] ], Lawyer_Sanitize::margin( $footer_nav_icon['footer_logo_social_margin'] ) );
			lawyer_merge_value( $css['global'][ '.footer-logo-social-icons a.footer-logo-' . $footer_nav_icon['footer_logo_social_icon'] ], Lawyer_Sanitize::padding( $footer_nav_icon['footer_logo_social_padding'] ) );
			$css['global'][ '.footer-logo-social-icons a.footer-logo-' . $footer_nav_icon['footer_logo_social_icon'] ]['border-radius'] = Lawyer_Sanitize::size( $footer_nav_icon['footer_logo_social_border_radius'] . 'px' );
			$css['global'][ '.footer-logo-social-icons a.footer-logo-' . $footer_nav_icon['footer_logo_social_icon'] ]['border']        = $footer_nav_icon_border;
		endforeach;
	endif;

	// Footer Nav Social icons font size.
	if ( ! empty( $footer_icons ) && is_array( $footer_icons ) ) :
		foreach ( $footer_icons as $footer_icon ) :
			$css['global'][ '.footer-logo-social-icons a.footer-logo-' . $footer_icon ]['font-size'] = Lawyer_Sanitize::size( lawyer_get_settings( 'footer_logo_social_font_size' ) . 'px' );
		endforeach;
	endif;

	// Footer Brands Sections.
	$brands_border = Lawyer_Sanitize::border( lawyer_get_settings( 'brands_border' ) );
	$css['global']['.brands-container'][ $brands_border ['direction'] ] = $brands_border ['value'];

	// footer brands alignment.
	$footer_brands_align = lawyer_get_settings( 'footer_brands_alignment' );
	if ( 'center' === $footer_brands_align ) :
		$css['global']['.brands-container']['justify-content'] = 'center';
	elseif ( 'right' === $footer_brands_align ) :
		$css['global']['.brands-container']['justify-content'] = 'flex-end';
	endif;

	// brand container.
	lawyer_merge_value( $css['global']['.brands-container'], Lawyer_Sanitize::margin( lawyer_get_settings( 'brands_margin' ) ) );
	lawyer_merge_value( $css['global']['.brands-container'], Lawyer_Sanitize::padding( lawyer_get_settings( 'brands_padding' ) ) );

}

/**
 * Misc
 *
 * @param array $css Array of dynamic CSS.
 */
function lawyer_misc_css( &$css ) {

	// Show Logo.
	$show_logo = lawyer_get_settings( 'mts_header_section2' );

	if ( 0 === $show_logo ) {
		$css['global']['.logo-wrap']['display'] = 'none';
	}

	// Back to top.
	// Border.
	$top_button_border = Lawyer_Sanitize::border( lawyer_get_settings( 'top_button_border' ) );
	$css['global']['#move-to-top'][ $top_button_border ['direction'] ] = $top_button_border ['value'];
	// Font-size, Padding and Position.
	$css['global']['#move-to-top .fa']['font-size'] = Lawyer_Sanitize::size( lawyer_get_settings( 'top_button_font_size' ) . 'px' );
	lawyer_merge_value( $css['global']['#move-to-top'], Lawyer_Sanitize::padding( lawyer_get_settings( 'top_button_padding' ) ) );
	$top_button_position = lawyer_get_settings( 'top_button_position' );
	foreach ( $top_button_position as $key => $position ) {
		$css['global']['#move-to-top'][ $key ] = $position;
	}
	// Border-radius.
	$css['global']['#move-to-top']['border-radius'] = Lawyer_Sanitize::size( lawyer_get_settings( 'top_button_border_radius' ) . 'px' );
	// Colors.
	$css['global']['#move-to-top']['color']            = Lawyer_Sanitize::color( lawyer_get_settings( 'top_button_color' ) );
	$css['global']['#move-to-top:hover']['color']      = Lawyer_Sanitize::color( lawyer_get_settings( 'top_button_color_hover' ) );
	$css['global']['#move-to-top']['background']       = Lawyer_Sanitize::color( lawyer_get_settings( 'top_button_background' ) );
	$css['global']['#move-to-top:hover']['background'] = Lawyer_Sanitize::color( lawyer_get_settings( 'top_button_background_hover' ) );
}
