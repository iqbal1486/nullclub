<?php
/**
 * Homepage Section - Stats
 *
 * @package Lawyer
 */

$about_image      = lawyer_get_settings( 'about_video_image' );
$about_youtube_id = lawyer_get_settings( 'about_video_youtube_id' );

?>

<section class="about-video-section clearfix">

	<?php

	if ( ! empty( $about_image ) && ! empty( $about_youtube_id ) ) {
		global $wp_embed;
		$url = 'http://www.youtube.com/watch?v=' . $about_youtube_id;
		printf(
			'<a class="youtube-popup" href="%s"><div class="video-img"><i class="fa fa-play"></i></div></a>',
			$url
		);
	}

	?>
</section>
