<?php
/**
 * About Page Section - Testimonials
 *
 * @package Lawyer
 */

$icon         = lawyer_get_settings( 'about_testimonials_icon' );
$title        = lawyer_get_settings( 'about_testimonials_title' );
$text         = lawyer_get_settings( 'about_testimonials_text' );
$testimonials = lawyer_get_settings( 'about_testimonials_group' );

if ( empty( $icon ) && empty( $title ) && empty( $text ) && empty( $testimonials ) && ! is_array( $testimonials ) ) {
	return;
}
?>

<section class="about-testimonials-section clearfix">

		<?php
		echo '<div class="container">';

		if ( $icon ) {
			echo '<i class="icon fa fa-' . $icon . '"></i>';
		}
		if ( $title ) {
			echo '<h2>' . $title . '</h2>';
		}
		if ( $text ) {
			echo '<p>' . $text . '</p>';
		}

		echo '</div>';

		// Services grids.
		if ( ! empty( $testimonials ) && is_array( $testimonials ) ) {

			if ( empty( $testimonials ) ) {
				return;
			}

			echo '<div class="about-testimonial-slider owl-carousel owl-theme owl-loaded">';

			foreach ( $testimonials as $testimonial ) {
				printf(
					'<div class="testimonial-wrap"><div class="author-img"><img src="%1$s"></div><div class="testimonial-content"><h3>%2$s</h3><p>%3$s</p></div></div>',
					$testimonial['about_testimonials_group_image'],
					$testimonial['about_testimonials_group_author'],
					$testimonial['about_testimonials_group_testimonial']
				);
			}

			echo '</div>';

		}
		?>

</section>
