<?php
/**
 * About Page Section - Featured
 *
 * @package Lawyer
 */

$icon       = lawyer_get_settings( 'about_featured_icon' );
$small_text = lawyer_get_settings( 'about_featured_small_text' );
$figure     = lawyer_get_settings( 'about_featured_figure' );
$title      = lawyer_get_settings( 'about_featured_title' );

$button_text = lawyer_get_settings( 'about_featured_button_text' );
$button_url  = lawyer_get_settings( 'about_featured_button_url' );

if ( empty( $icon ) && empty( $small_text ) && empty( $figure ) && empty( $title ) && empty( $button_text ) && empty( $button_url ) ) {
	return;
}
?>

<section class="about-featured-section clearfix">

	<div class="container">

		<?php
		if ( $icon ) {
			echo '<i class="icon fa fa-' . $icon . '"></i>';
		}
		if ( $small_text ) {
			echo '<p class="small-text">' . $small_text . '</p>';
		}
		if ( $small_text ) {
			echo '<div class="figure">' . $figure . '</div>';
		}
		if ( $title ) {
			echo '<h2>' . $title . '</h2>';
		}
		if ( $button_text && ! empty( $button_url ) ) {
			printf(
				'<a class="button" href="%1$s">%2$s</a>',
				$button_url,
				$button_text
			);
		}
		?>

	</div><!-- .container -->

</section>
