<?php
/**
 * About Page Section - Services List
 *
 * @package Lawyer
 */

$services_lists = lawyer_get_settings( 'about_services_list_group' );

if ( empty( $services_lists ) ) {
	return;
}
?>

<section class="about-services-list-section clearfix">

	<div class="container">

		<?php

		// Services grids2.
		if ( ! empty( $services_lists ) && is_array( $services_lists ) ) {

			echo '<ul class="about-services-list-container">';

			foreach ( $services_lists as $services_list ) {
				printf(
					'<li><span class="icon"><i class="fa fa-%1$s"></i></span><div class="text"><h3>%2$s</h3><p>%3$s</p></div><div class="button-wrap"><a class="button border" href="%4$s">%5$s</a></div></li>',
					$services_list['about_services_list_group_icon'],
					$services_list['about_services_list_group_title'],
					$services_list['about_services_list_group_text'],
					$services_list['about_services_list_group_button_url'],
					$services_list['about_services_list_group_button_text']
				);
			}

			echo '</ul>';

		}
		?>

	</div><!-- .container -->

</section>
