<?php
/**
 * Posts Layout - default
 *
 * @package Lawyer
 */

$featured = lawyer()->featured_layouts;
?>

<div class="container clear <?php $featured->get_post_container_class(); ?>">

	<?php $featured->get_section_title(); ?>

	<div class="<?php lawyer_article_class(); ?>">

		<div id="content_box">

			<?php lawyer_action( 'start_content_box' ); ?>

			<section id="latest-posts" class="layout-default clearfix">
				<?php
				while ( have_posts() ) :
					the_post();
					$post_meta_info = lawyer_get_settings( 'home_meta_info_' . $featured->current['unique_id'] );
				?>
				<article class="latestPost excerpt">

					<?php $featured->get_post_thumbnail(); ?>

					<div class="wrapper">

						<?php $featured->get_post_title(); ?>

						<?php $featured->get_post_content(); ?>

					</div>

				</article>
				<?php
				endwhile;

				$featured->get_post_pagination();
				?>
			</section><!--#latest-posts-->

		</div>

	</div>

	<?php get_sidebar(); ?>

</div>
