<?php if ( lawyer_get_settings( 'navigation_ad' ) && lawyer_get_settings( 'navigation_adcode' ) ) { ?>
	<div class="navigation-banner">
		<div class="container">
			<div style="<?php ad_size_value( lawyer_get_settings( 'navigation_ad_size' ) ); ?>">
				<?php echo lawyer_get_settings( 'navigation_adcode' ); ?>
			</div>
		</div>
	</div>
<?php } ?>
