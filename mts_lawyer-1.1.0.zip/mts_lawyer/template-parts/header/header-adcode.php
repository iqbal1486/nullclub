<?php
/**
 * Header adcode
 *
 */

$ad_show_on = lawyer_get_settings( 'header_adcode_show' );
$layouts    = lawyer_get_settings( 'header_styles' );

if ( ! empty( lawyer_get_settings( 'mts_header_adcode' ) ) ) {
	echo ( 'header-default' !== $layouts ) ? '<div class="container small-header">' : '';

	if ( 'all' === $ad_show_on ) {
		if ( ! empty( lawyer_get_settings( 'mts_header_adcode' ) ) ) {
			if ( 0 !== lawyer_get_settings( 'header_ad_size' ) ) {
				$style = 'max-width: 100%;';
			}
			?>
			<div class="widget-header">
				<div style="<?php ad_size_value( lawyer_get_settings( 'header_ad_size' ) ); ?> <?php echo isset( $style ) ? $style : ''; ?>">
					<?php echo lawyer_get_settings( 'mts_header_adcode' ); ?>
				</div>
			</div>
		<?php
		}
	}
	if ( 'home' === $ad_show_on ) {
		if ( is_home() || is_front_page() ) {
			if ( ! empty( lawyer_get_settings( 'mts_header_adcode' ) ) ) {
				if ( 0 !== lawyer_get_settings( 'header_ad_size' ) ) {
					$style = 'max-width: 100%;';
				}
				?>
				<div class="widget-header">
					<div style="<?php ad_size_value( lawyer_get_settings( 'header_ad_size' ) ); ?> <?php echo isset( $style ) ? $style : ''; ?>">
						<?php echo lawyer_get_settings( 'mts_header_adcode' ); ?>
					</div>
				</div>
			<?php
			}
		}
	}
	if ( 'single' === $ad_show_on ) {
		if ( is_single() ) {
			if ( ! empty( lawyer_get_settings( 'mts_header_adcode' ) ) ) {
				if ( 0 !== lawyer_get_settings( 'header_ad_size' ) ) {
					$style = 'max-width: 100%;';
				}
				?>
				<div class="widget-header">
					<div style="<?php ad_size_value( lawyer_get_settings( 'header_ad_size' ) ); ?> <?php echo isset( $style ) ? $style : ''; ?>">
						<?php echo lawyer_get_settings( 'mts_header_adcode' ); ?>
					</div>
				</div>
			<?php
			}
		}
	}
	if ( 'page' === $ad_show_on ) {
		if ( is_page() ) {
			if ( ! empty( lawyer_get_settings( 'mts_header_adcode' ) ) ) {
				if ( 0 !== lawyer_get_settings( 'header_ad_size' ) ) {
					$style = 'max-width: 100%;';
				}
				?>
				<div class="widget-header">
					<div style="<?php ad_size_value( lawyer_get_settings( 'header_ad_size' ) ); ?> <?php echo isset( $style ) ? $style : ''; ?>">
						<?php echo lawyer_get_settings( 'mts_header_adcode' ); ?>
					</div>
				</div>
			<?php
			}
		}
	}

	echo ( 'header-default' !== $layouts ) ? '</div>' : '';
}
