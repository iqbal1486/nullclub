<?php
/**
 * Header Layout 3
 *
 * @package Lawyer
 */

?>

<header id="site-header" class="main-header <?php echo esc_attr( lawyer_get_settings( 'header_styles' ) ); ?> clearfix" role="banner" itemscope itemtype="http://schema.org/WPHeader">

	<?php if ( lawyer_get_settings( 'mts_sticky_nav' ) ) { ?>
	<div class="clear" id="catcher"></div>
	<div id="header" class="sticky-navigation">
	<?php } else { ?>
	<div id="header">
	<?php } ?>
		<div class="container">

			<div class="logo-wrap">
				<?php lawyer_logo(); ?>
			</div>

			<div id="secondary-navigation" class="secondary-navigation" role="navigation" itemscope itemtype="http://schema.org/SiteNavigationElement">
				<a href="#" id="pull" class="toggle-mobile-menu"><?php _e( 'Menu', 'lawyer' ); ?></a>
				<?php if ( has_nav_menu( 'mobile' ) ) { ?>

					<nav class="navigation clearfix">
						<?php
						// Secondary Navigation.
						if ( has_nav_menu( 'secondary-menu' ) ) {
							wp_nav_menu( array(
								'theme_location' => 'secondary-menu',
								'menu_class'     => 'menu clearfix',
								'container'      => '',
								'walker'         => new lawyer_menu_walker(),
							));
						}
						?>
					</nav>
					<nav class="navigation mobile-only clearfix mobile-menu-wrapper">
						<?php
						// Mobile Menu.
						if ( has_nav_menu( 'mobile' ) ) {
							wp_nav_menu( array(
								'theme_location' => 'mobile',
								'menu_class'     => 'menu clearfix',
								'container'      => '',
								'walker'         => new lawyer_menu_walker(),
							));
						}
						?>
					</nav>

				<?php } else { ?>

					<nav class="navigation clearfix mobile-menu-wrapper">
						<?php
						// Secondary Navigation.
						if ( has_nav_menu( 'secondary-menu' ) ) {
							wp_nav_menu( array(
								'theme_location' => 'secondary-menu',
								'menu_class'     => 'menu clearfix',
								'container'      => '',
								'walker'         => new lawyer_menu_walker(),
							));
						}
						?>
					</nav>

				<?php } ?>
			</div>

			<?php
			// Nav Button.
			if ( lawyer_get_settings( 'nav_button' ) && ! empty( lawyer_get_settings( 'nav_button_url' ) ) ) {
				printf( '<div class="nav-button"><a href="%1$s" class="button border">%2$s</a></div>', lawyer_get_settings( 'nav_button_url' ), lawyer_get_settings( 'nav_button_text' ) );
			}
			?>

		</div><!--.container-->

	</div><!-- #header -->

	<?php get_template_part( 'template-parts/header/header', 'nav-adcode' ); ?>

</header>

<?php get_template_part( 'template-parts/header/header', 'adcode' ); ?>
