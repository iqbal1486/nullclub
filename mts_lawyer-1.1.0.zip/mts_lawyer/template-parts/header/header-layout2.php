<?php
/**
 * Header Layout 2
 *
 * @package Lawyer
 */
?>

<header id="site-header" class="main-header <?php echo esc_attr( lawyer_get_settings( 'header_styles' ) ); ?> clearfix" role="banner" itemscope itemtype="http://schema.org/WPHeader">

	<?php if ( lawyer_get_settings( 'mts_sticky_nav' ) ) { ?>
	<div class="clear" id="catcher"></div>
	<div id="header" class="sticky-navigation">
	<?php } else { ?>
	<div id="header">
	<?php } ?>
		<div class="container">

			<div id="secondary-navigation" class="secondary-navigation" role="navigation" itemscope itemtype="http://schema.org/SiteNavigationElement">
				<a href="#" id="pull" class="toggle-mobile-menu"><?php _e( 'Menu', 'lawyer' ); ?></a>
				<?php if ( has_nav_menu( 'mobile' ) ) { ?>

					<nav class="navigation clearfix">
						<?php
						// Secondary Navigation.
						if ( has_nav_menu( 'secondary-menu' ) ) {
							wp_nav_menu( array(
								'theme_location' => 'secondary-menu',
								'menu_class'     => 'menu clearfix',
								'container'      => '',
								'walker'         => new lawyer_menu_walker(),
							));
						}
						?>
					</nav>
					<nav class="navigation mobile-only clearfix mobile-menu-wrapper">
						<?php
						// Mobile Menu.
						if ( has_nav_menu( 'mobile' ) ) {
							wp_nav_menu( array(
								'theme_location' => 'mobile',
								'menu_class'     => 'menu clearfix',
								'container'      => '',
								'walker'         => new lawyer_menu_walker(),
							));
						}
						?>
					</nav>

				<?php } else { ?>

					<nav class="navigation clearfix mobile-menu-wrapper">
						<?php
						// Secondary Navigation.
						if ( has_nav_menu( 'secondary-menu' ) ) {
							wp_nav_menu( array(
								'theme_location' => 'secondary-menu',
								'menu_class'     => 'menu clearfix',
								'container'      => '',
								'walker'         => new lawyer_menu_walker(),
							));
						}
						?>
					</nav>

				<?php } ?>
			</div>

			<?php
			// Nav Button.
			if ( lawyer_get_settings( 'nav_button' ) && ! empty( lawyer_get_settings( 'nav_button_url' ) ) ) {
				printf( '<div class="nav-button"><a href="%1$s" class="button border">%2$s</a></div>', lawyer_get_settings( 'nav_button_url' ), lawyer_get_settings( 'nav_button_text' ) );
			}
			?>

		</div><!--.container-->

	</div><!--#header-->

	<div class="top-bar">

		<?php
		// Header Search Box.
		if ( lawyer_get_settings( 'header_search_box' ) ) {
			?>
			<div class="header-search header-field">
				<?php $ajax_search = ! empty( lawyer_get_settings( 'mts_ajax_search' ) ) ? ' autocomplete="off"' : ''; ?>

				<form method="get" id="searchform" class="search-form" action="<?php echo esc_attr( home_url() ); ?>" _lpchecked="1">
					<fieldset>
						<input type="text" name="s" id="s" value="<?php the_search_query(); ?>" placeholder="<?php esc_html_e( 'Search here...', 'lawyer' ); ?>" <?php echo $ajax_search; ?>>
					</fieldset>
				</form>
			</div><!-- END .header-search -->
		<?php
		}
		?>

		<div class="container">

			<div class="logo-wrap">
				<?php lawyer_logo(); ?>
			</div>

			<?php
			// Header Search icon.
			if ( lawyer_get_settings( 'header_search_box' ) ) {
				?>
				<div class="header-search">
					<button id="search-image" class="sbutton icon" type="submit" value="">
						<i class="fa fa-search fa-flip-horizontal"></i>
					</button>
					<button class="sbutton open">
						<i class="fa fa-close"></i>
					</button>
				</div><!-- END .header-search -->
			<?php
			}

			// Header Social Icons.
			if ( ! empty( lawyer_get_settings( 'header_social_icons' ) ) && is_array( lawyer_get_settings( 'header_social_icons' ) ) ) {
				$header_icons = lawyer_get_settings( 'header_social_icons' );
				lawyer_social_icons( $header_icons, true );
			}

			// Contact info.
			if ( ! empty( lawyer_get_settings( 'contact_info' ) ) && is_array( lawyer_get_settings( 'contact_info' ) ) ) {
				$contact_info = lawyer_get_settings( 'contact_info' );
				lawyer_contact_info( $contact_info, true );
			}
			?>

		</div><!-- .container -->

	</div><!-- .top-bar -->

	<?php get_template_part( 'template-parts/header/header', 'nav-adcode' ); ?>

</header>

<?php get_template_part( 'template-parts/header/header', 'adcode' ); ?>
