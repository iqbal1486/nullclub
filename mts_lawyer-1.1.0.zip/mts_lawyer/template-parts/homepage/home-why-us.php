<?php
/**
 * Homepage Section - Why Us
 *
 * @package Lawyer
 */

$icon        = lawyer_get_settings( 'why_us_icon' );
$title       = lawyer_get_settings( 'why_us_title' );
$text        = lawyer_get_settings( 'why_us_text' );
$img         = lawyer_get_settings( 'why_us_img' );
$left_items  = lawyer_get_settings( 'why_us_left_items' );
$right_items = lawyer_get_settings( 'why_us_right_items' );

if ( empty( $icon ) && empty( $title ) && empty( $text ) && empty( $img ) && empty( $left_items ) && ! is_array( $left_items ) && empty( $right_items ) && ! is_array( $right_items ) ) {
	return;
}
?>

<section class="why-us-section clearfix">

	<div class="container">

		<?php
		if ( $icon ) {
			echo '<i class="icon fa fa-' . $icon . '"></i>';
		}
		if ( $title ) {
			echo '<h2>' . $title . '</h2>';
		}
		if ( $text ) {
			echo '<p>' . $text . '</p>';
		}
		// Left items.
		if ( $left_items && is_array( $left_items ) ) {

			echo '<div class="left">';
			echo '<ul class="list">';
			foreach ( $left_items as $left_item ) {
				printf(
					'<li><div class="text"><h3>%2$s</h3><p>%3$s</p></div><span class="icon"><i class="fa fa-%1$s"></i></span></li>',
					$left_item['why_us_left_icon'],
					$left_item['why_us_left_title'],
					$left_item['why_us_left_text']
				);
			}

			echo '</ul>';
			echo '</div>';

		}
		if ( ! empty( $img ) ) {
			printf(
				'<div class="middle"><img src="%s"></div>',
				$img
			);
		}
		// Right items.
		if ( ! empty( $right_items ) && is_array( $right_items ) ) {

			echo '<div class="right">';
			echo '<ul class="list">';
			foreach ( $right_items as $right_item ) {
				printf(
					'<li><span class="icon"><i class="fa fa-%1$s"></i></span><div class="text"><h3>%2$s</h3><p>%3$s</p></div></li>',
					$right_item['why_us_right_icon'],
					$right_item['why_us_right_title'],
					$right_item['why_us_right_text']
				);
			}

			echo '</ul>';
			echo '</div>';

		}
		?>

	</div><!-- .container -->

</section>
