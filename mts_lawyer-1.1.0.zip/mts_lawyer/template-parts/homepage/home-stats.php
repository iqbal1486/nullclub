<?php
/**
 * Homepage Section - Stats
 *
 * @package Lawyer
 */

$stats_figure1 = lawyer_get_settings( 'stats_figure1' );
$stats_figure2 = lawyer_get_settings( 'stats_figure2' );
$stats_figure3 = lawyer_get_settings( 'stats_figure3' );
$stats_text1   = lawyer_get_settings( 'stats_text1' );
$stats_text2   = lawyer_get_settings( 'stats_text2' );
$stats_text3   = lawyer_get_settings( 'stats_text3' );

$stats_lists      = lawyer_get_settings( 'stats_list' );
$stats_youtube_id = lawyer_get_settings( 'stats_youtube_id' );

?>

<section class="stats-section clearfix">

	<div class="container">

		<?php
		if ( ! empty( $stats_figure1 ) && ! empty( $stats_text1 ) && ! empty( $stats_figure2 ) && ! empty( $stats_text2 ) && ! empty( $stats_figure3 ) && ! empty( $stats_text3 ) ) {
		?>
			<div class="stats-container">

				<?php
				if ( ! empty( $stats_figure1 ) && ! empty( $stats_text1 ) ) {
					printf(
						'<div class="stats-wrap"><div class="figure">%1$s</div><p>%2$s</p></div>',
						$stats_figure1,
						$stats_text1
					);
				}
				if ( ! empty( $stats_figure2 ) && ! empty( $stats_text2 ) ) {
					printf(
						'<div class="stats-wrap"><div class="figure">%1$s</div><p>%2$s</p></div>',
						$stats_figure2,
						$stats_text2
					);
				}
				if ( ! empty( $stats_figure3 ) && ! empty( $stats_text3 ) ) {
					printf(
						'<div class="stats-wrap"><div class="figure">%1$s</div><p>%2$s</p></div>',
						$stats_figure3,
						$stats_text3
					);
				}
				?>

			</div><!-- .stats-container -->
		<?php
		}
		?>

		<?php
		if ( ! empty( $stats_lists ) && is_array( $stats_lists ) && ! empty( $stats_youtube_id ) ) {
		?>
			<div class="stats-list">

				<?php
				// Stats list.
				if ( ! empty( $stats_lists ) && is_array( $stats_lists ) ) {

					echo '<div class="left"><ul class="stats-list-container">';
					foreach ( $stats_lists as $stats_list ) {
						printf(
							'<li><i class="fa fa-%1$s"></i><div><h2>%2$s</h2><p>%3$s</p></div></li>',
							$stats_list['stats_list_icon'],
							$stats_list['stats_list_title'],
							$stats_list['stats_list_text']
						);
					}

					echo '</ul></div>';

				}
				if ( ! empty( $stats_youtube_id ) ) {
					global $wp_embed;
					$url   = 'http://www.youtube.com/watch?v=' . $stats_youtube_id;
					$embed = $wp_embed->run_shortcode( '[embed width="540" height="300"]' . $url . '[/embed]' );
					printf(
						'<div class="right"><div class="video-wrapper">%s</div></div>',
						$embed
					);
				}
				?>

			</div><!-- .stats-list -->
		<?php
		}
		?>

	</div><!-- .container -->

</section>
