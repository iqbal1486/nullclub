<?php
/**
 * Homepage Section - Stats 2
 *
 * @package Lawyer
 */

$left_icon        = lawyer_get_settings( 'stats2_left_icon' );
$left_figure      = lawyer_get_settings( 'stats2_left_figure' );
$left_title       = lawyer_get_settings( 'stats2_left_title' );
$left_text        = lawyer_get_settings( 'stats2_left_text' );
$left_button_text = lawyer_get_settings( 'stats2_left_button_text' );
$left_button_url  = lawyer_get_settings( 'stats2_left_button_url' );

$right_icon        = lawyer_get_settings( 'stats2_right_icon' );
$right_figure      = lawyer_get_settings( 'stats2_right_figure' );
$right_title       = lawyer_get_settings( 'stats2_right_title' );
$right_text        = lawyer_get_settings( 'stats2_right_text' );
$right_button_text = lawyer_get_settings( 'stats2_right_button_text' );
$right_button_url  = lawyer_get_settings( 'stats2_right_button_url' );

if ( empty( $left_icon ) && empty( $left_figure ) && empty( $left_title ) && empty( $left_text ) && empty( $right_icon ) && empty( $right_figure ) && empty( $right_title ) && empty( $right_text ) ) {
	return;
}
?>

<section class="stats2-section clearfix">

		<div class="left">

			<?php
			if ( $left_icon ) {
				printf(
					'<div class="icon"><i class="fa fa-%s"></i></div>',
					$left_icon
				);
			}
			if ( $left_figure ) {
				printf(
					'<div class="figure">%s</div>',
					$left_figure
				);
			}
			if ( $left_title ) {
				printf(
					'<h2>%s</h2>',
					$left_title
				);
			}
			if ( $left_text ) {
				printf(
					'<p>%s</p>',
					$left_text
				);
			}
			if ( $left_text ) {
				printf(
					'<a href="%1$s" class="button border">%2$s</a>',
					$left_button_url,
					$left_button_text
				);
			}
			?>

		</div><!-- .left -->

		<div class="right">

			<?php
			if ( $right_icon ) {
				printf(
					'<div class="icon"><i class="fa fa-%s"></i></div>',
					$right_icon
				);
			}
			if ( $right_figure ) {
				printf(
					'<div class="figure">%s</div>',
					$right_figure
				);
			}
			if ( $right_title ) {
				printf(
					'<h2>%s</h2>',
					$right_title
				);
			}
			if ( $right_text ) {
				printf(
					'<p>%s</p>',
					$right_text
				);
			}
			if ( $right_text ) {
				printf(
					'<a href="%1$s" class="button border">%2$s</a>',
					$right_button_url,
					$right_button_text
				);
			}
			?>

		</div><!-- .right -->

</section>
