<?php
/**
 * Homepage Section - CTA
 *
 * @package Lawyer
 */

$title       = lawyer_get_settings( 'cta_title' );
$button_text = lawyer_get_settings( 'cta_button_text' );
$button_url  = lawyer_get_settings( 'cta_button_url' );

if ( empty( $title ) && empty( $button_text ) && empty( $button_url ) ) {
	return;
}
?>

<section class="cta-section clearfix">

	<div class="container">

		<div class="small-container">

			<?php
			if ( ! empty( $title ) ) {
				printf( '<div class="left"><h2>%s</h2></div>', $title );
			}
			if ( ! empty( $button_text ) && ! empty( $button_url ) ) {
				printf(
					'<div class="right"><a class="button" href="%1$s">%2$s</a></div>',
					$button_url,
					$button_text
				);
			}
			?>

		</div><!-- .small-container -->

	</div><!-- .container -->

</section>
