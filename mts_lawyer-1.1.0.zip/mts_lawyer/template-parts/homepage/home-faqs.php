<?php
/**
 * Homepage Section - FAQs
 *
 * @package Lawyer
 */

$faqs = lawyer_get_settings( 'faqs_items' );

if ( empty( $faqs ) && ! is_array( $faqs ) ) {
	return;
}
?>

<section class="faqs-section clearfix">

	<div class="container">

		<div class="small-container">

			<?php
			// Left items.
			if ( ! empty( $faqs ) && is_array( $faqs ) ) {

				echo '<div class="accordion">';
				echo '<ul class="list">';
				foreach ( $faqs as $faq ) {
					printf(
						'<div class="wrap"><li class="question"><span class="faq-arrow fa fa-angle-right"></span>%1$s</li>
						<li class="answer">%2$s</li></div>',
						$faq['faqs_question'],
						$faq['faqs_answer']
					);
				}

				echo '</ul>';
				echo '</div>';

			}
			?>

		</div><!-- .small-container -->

	</div><!-- .container -->

</section>
