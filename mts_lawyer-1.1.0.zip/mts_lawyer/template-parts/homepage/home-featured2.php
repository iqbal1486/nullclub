<?php
/**
 * Homepage Section - Featured 2
 *
 * @package Lawyer
 */

$icon  = lawyer_get_settings( 'featured2_icon' );
$title = lawyer_get_settings( 'featured2_title' );

$small_text = lawyer_get_settings( 'featured2_small_text' );

$button_text1 = lawyer_get_settings( 'featured2_button_text1' );
$button_url1  = lawyer_get_settings( 'featured2_button_url1' );
$button_text2 = lawyer_get_settings( 'featured2_button_text2' );
$button_url2  = lawyer_get_settings( 'featured2_button_url2' );

if ( empty( $icon ) && empty( $title ) && ! lawyer_get_settings( 'featured2_nav_section' ) && empty( $small_text ) && empty( $button_text1 ) && empty( $button_url1 ) && empty( $button_text2 ) && empty( $button_url2 ) ) {
	return;
}
?>

<section class="featured2-section clearfix">

	<div class="container">

		<div class="small-container">

			<?php
			if ( $icon ) {
				echo '<i class="featured-2-icon fa fa-' . $icon . '"></i>';
			}
			if ( $small_text ) {
				echo '<p class="small-text">' . $small_text . '</p>';
			}
			if ( $title ) {
				echo '<h2>' . $title . '</h2>';
			}
			if ( lawyer_get_settings( 'featured2_nav_section' ) ) {
			?>
			<div id="featured2-navigation" class="featured2-navigation" role="navigation" itemscope itemtype="http://schema.org/SiteNavigationElement">
				<nav class="nav clearfix">
					<?php
					// Featured 2 Navigation.
					if ( has_nav_menu( 'featured2-menu' ) ) {
						wp_nav_menu( array(
							'theme_location' => 'featured2-menu',
							'menu_class'     => 'menu clearfix',
							'container'      => '',
							'walker'         => new lawyer_menu_walker(),
						));
					}
					?>
				</nav>
			</div>
			<?php
			}
			if ( $button_text1 && $button_url1 ) {
				echo '<a class="button border" href="' . $button_url1 . '">' . $button_text1 . '</a>';
			}
			if ( $button_text2 && $button_url2 ) {
				echo '<a class="button" href="' . $button_url2 . '">' . $button_text2 . '</a>';
			}
			?>

		</div>

	</div><!-- .container -->

</section>
