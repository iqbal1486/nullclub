<?php
/**
 * Homepage Section - Services Grid 2
 *
 * @package Lawyer
 */

$services_grids = lawyer_get_settings( 'services_grid2_group' );

if ( empty( $services_grids ) ) {
	return;
}
?>

<section class="services-grid2-section clearfix">

	<div class="container">

		<?php

		// Services grids2.
		if ( ! empty( $services_grids ) && is_array( $services_grids ) ) {

			echo '<ul class="services-grid2-container">';

			foreach ( $services_grids as $services_grid ) {
				printf(
					'<li><span class="icon"><i class="fa fa-%1$s"></i></span><div class="text"><h3>%2$s</h3><p>%3$s</p></div></li>',
					$services_grid['services_grid2_group_icon'],
					$services_grid['services_grid2_group_title'],
					$services_grid['services_grid2_group_text']
				);
			}

			echo '</ul>';

		}
		?>

	</div><!-- .container -->

</section>
