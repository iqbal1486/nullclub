<?php
/**
 * Template Name: About Page
 *
 * @package Lawyer
 */

get_header();

?>

<div id="wrapper" class="clearfix">

	<?php

	lawyer_aboutpage_sections();

	get_footer();
