<?php
/********************************************************************
 * Copyright (C) 2020 Darko Gjorgjijoski (https://codeverve.com)
 *
 * This file is part of Video Uploads for Vimeo
 *
 * Video Uploads for Vimeo is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * Video Uploads for Vimeo is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Video Uploads for Vimeo. If not, see <https://www.gnu.org/licenses/>.
 **********************************************************************/

/**
 * Class WP_DGV_Public
 *
 * The public facing functionality of the plugin
 *
 * @license GPLv2
 * @copyright Darko Gjorgjijoski <info@codeverve.com>
 * @since 1.0.0
 */
class WP_DGV_Public {

	private $db_helper;

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string $plugin_name The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string $version The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @param string $plugin_name The name of the plugin.
	 * @param string $version The version of this plugin.
	 *
	 * @since    1.0.0
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version     = $version;
		$this->db_helper   = new WP_DGV_Db_Helper();

	}

	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {
		wp_register_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/wp-vimeo-videos-public.css', array(), $this->version, 'all' );
	}

	/**
	 * Register the JavaScript for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {
		wp_register_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/wp-vimeo-videos-public.js', array( 'jquery' ), $this->version, false );
	}

	/**
	 * The video shortcode
	 *
	 * @param $atts
	 *
	 * @return false|string
	 */
	public function shortcode_video( $atts ) {
		$a = shortcode_atts( array( 'id' => '', ), $atts );
		$content  = '';
		$video_id = isset( $a['id'] ) ? $a['id'] : null;
		if ( ! empty( $video_id ) ) {
			wp_enqueue_style( $this->plugin_name );
			$content = wvv_get_view( 'public/partials/video', array(
				'vimeo_id' => $video_id
			) );
		}
		return apply_filters('dgv_shortcode_output', $content, $video_id);
	}

	/**
	 * The video page content
	 *
	 * @param $content
	 *
	 * @return mixed|string|void
	 */
	public function video_contents( $content ) {
		if ( is_singular( WP_DGV_Db_Helper::POST_TYPE_UPLOADS ) ) {
			global $post;
			$theme_path       = get_stylesheet_directory();
			$plugin_file_path = trailingslashit( WP_VIMEO_VIDEOS_PATH ) . '/public/partials/single-content.php';
			$theme_file_path  = trailingslashit( $theme_path ) . '/wp-vimeo-videos/single-content.php';
			ob_start();
			if ( file_exists( $theme_file_path ) ) {
				include $theme_file_path;
			} else {
				include $plugin_file_path;
			}
			$content = ob_get_clean();
		}

		return $content;
	}

}
