<div id="admin-secondary-mbox-dv-<?php echo $sidebar_box_id; ?>" class="admin-primary-mbox-dv">

    <h4 class="admin-secondary-mbox-h4"><?php echo isset($sidebar_h4_title) ? $sidebar_h4_title : ''; ?></h4>

    <p><?php echo isset($sidebar_description) ? $sidebar_description : ''; ?>

        <?php echo $sidebar_content; ?>
</div> <!-- end #admin-secondary-mbox-dv -->