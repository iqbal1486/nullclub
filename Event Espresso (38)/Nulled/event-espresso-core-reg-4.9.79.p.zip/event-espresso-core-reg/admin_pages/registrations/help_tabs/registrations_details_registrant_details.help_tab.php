<p><strong><?php _e('Contact Details', 'event_espresso'); ?></strong></p>
<p>
<?php _e('Shows the contact details for this registrant.', 'event_espresso'); ?><br />
</p>
<p>
<ul>
<li>
<strong><?php _e('Name', 'event_espresso'); ?></strong><br />
<?php _e('Shows the name of the contact.', 'event_espresso'); ?>
</li>
<li>
<strong><?php _e('Email', 'event_espresso'); ?></strong><br />
<?php _e('Shows the email for the contact.', 'event_espresso'); ?>
</li>
<li>
<strong><?php _e('Phone #', 'event_espresso'); ?></strong><br />
<?php _e('Shows the phone number for contact.', 'event_espresso'); ?>
</li>
<li>
<strong><?php _e('Address', 'event_espresso'); ?></strong><br />
<?php _e('Shows the address for the contact.', 'event_espresso'); ?>
</li>
</ul>
</p>
<p>
<?php _e('You can edit contact information this Contact by clicking on the View / Edit this Contact link.', 'event_espresso'); ?><br />
</p>