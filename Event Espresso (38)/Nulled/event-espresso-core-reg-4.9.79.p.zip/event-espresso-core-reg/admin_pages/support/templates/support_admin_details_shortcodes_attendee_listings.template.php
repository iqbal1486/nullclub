<div class="padding">
	<ul>
			<li>[LISTATTENDEES]</li>
			<li>[LISTATTENDEES limit=30] //Number of events to show on the page</li>
			<li>[LISTATTENDEES show_expired=true] //Show expired events</li>
			<li>[LISTATTENDEES show_deleted=true] //Show deleted events</li>
			<li>[LISTATTENDEES show_secondary=true] //Show secondary/backup events</li>
			<li>[LISTATTENDEES show_gravatar=true] //Show a Gravatar f the attendee</li>
			<li>[LISTATTENDEES event_identifier=your_event_identifier"] //Show a single event using the event identifier</li>
			<li>[LISTATTENDEES category_identifier=your_category_identifier] //Show a group of events in a category using the category identifier</li>
			<li>[LISTATTENDEES staff_id=staff_id_number] //Show a list of events that are assigned to a staff member</li>
		</ul>
</div>
