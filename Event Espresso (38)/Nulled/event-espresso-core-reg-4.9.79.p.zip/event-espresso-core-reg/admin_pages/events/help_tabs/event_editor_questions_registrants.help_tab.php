<p><strong><?php _e('Questions for Primary Registrant', 'event_espresso'); ?></strong></p>
<p>
<?php _e('Questions groups are a pre-populated group of questions. The personal information question group is required for all events. You can request additional information from a primary registrant by placing a checkmark in the checkbox for that question group.', 'event_espresso'); ?>
</p>
<p><strong><?php _e('Questions for Additional Registrants', 'event_espresso'); ?></strong></p>
<p>
<?php _e('Remember that questions groups are a pre-populated group of questions. You can request additional information from a additional registrants by placing a checkmark in the checkbox for that question group. This process can be repeated to request multiple question groups from registrants.', 'event_espresso'); ?>
</p>