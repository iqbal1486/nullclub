<p><strong><?php _e('Default Event Settings', 'event_espresso'); ?></strong></p>
<p>
<?php _e('Customize the default settings for your events.', 'event_espresso'); ?>
</p>
<p>
<strong><?php _e('Recommendations', 'event_espresso'); ?></strong><br />
<?php _e('Want to see a tour of this screen? Click on the Default Settings Tour button which appears on the right side of the page.', 'event_espresso'); ?>
</p>
<p>
<strong><?php _e('Screen Options', 'event_espresso'); ?></strong><br />
<?php _e('You can customize the information that is shown on this page by toggling the Screen Options tab. Then you can add or remove checkmarks to hide or show certain content.', 'event_espresso'); ?>
</p>