<?php
/** There are no droids here.  */
