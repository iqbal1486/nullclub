<?php esc_html_e(
    'Mijireh is an off-site payment method for accepting payments online through over 80+ payment gateways. An existing account with Mijireh is required to accept payments.',
    'event_espresso'
);
