<?php echo $dtt_edit_row; ?>
<?php echo $dtt_attached_tickets_row; ?>
<?php
/**
 * template vars used in template
 *
 * $dtt_row
 * $dtt_edit_row
 * $dtt_attached_tickets_row
 */
