<div class="padding">
    <p><?php
        printf(
            esc_html__('Check out the %1$sroadmap for Event Espresso%2$s.', 'event_espresso'),
            '<a href="https://trello.com/b/zg9DCIpe/event-espresso-public-roadmap" target="_blank">',
            '</a>'
        ); ?></p>
</div>