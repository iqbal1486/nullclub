<div class="import-area">
    <div class="important-notice">
        <?php _e(
            'The import feature has been disabled because of bugs. It is expected to be put back in place soon.',
            'event_espresso'
        ); ?>
    </div>
    <?php // echo $form?>
</div>
