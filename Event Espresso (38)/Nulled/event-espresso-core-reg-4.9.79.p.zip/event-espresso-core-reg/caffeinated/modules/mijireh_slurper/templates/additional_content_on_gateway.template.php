<tr>
    <th><?php _e("Mijireh Checkout Page Design", 'event_espresso'); ?><?php
        echo EEH_Template::get_help_tab_link(
            'ee_mijireh_help_tab'
        ); ?></th>
    <td>
        <a href="?mijireh_edit_slurp_page=true"><?php _e("Edit Slurp Page", 'event_espresso'); ?></a>
    </td>
</tr>