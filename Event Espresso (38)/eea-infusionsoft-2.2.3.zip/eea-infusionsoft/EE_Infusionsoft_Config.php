<?php

/**
 *
 * Class EE_Infusionsoft_Config
 *
 * Description
 *
 * @package               Event Espresso
 * @subpackage            core
 * @author                Brent Christensen
 * @since                 2.0.0.p
 *
 */
class EE_Infusionsoft_Config extends EE_Config_Base
{
    /**
     *
     * @var EE_Infusionsoft_Config_Private_Key
     */
    public $private_key;

    /**
     *
     * @var EE_Infusionsoft_Config_Application_Name
     */
    public $application_name;

    public function __construct()
    {
        $this->private_key = '';
        $this->application_name = '';
    }
}
