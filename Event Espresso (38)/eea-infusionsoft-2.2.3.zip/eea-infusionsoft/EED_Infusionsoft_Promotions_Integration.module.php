<?php
/*
 * Class  EED_Infusionsoft_Promotions_Integration
 * For promotions-addon specific integration between Infusionsoft and Promotions addon.
 * We COULD have just riddled this logic throughout the Infusionsoft addon, but
 * it seems nicer to me to segregate it into a specific module. (Plus there was discussion
 * at one point of requiring a whole other addon for integration between specific addons,
 * but that seemed like overkill and would have a worse integration
 *
 *
 * @package         Event Espresso
 * @subpackage      espresso-new-addon
 * @author              Brent Christensen
 *
 * ------------------------------------------------------------------------
 */
class EED_Infusionsoft_Promotions_Integration extends EED_Module
{

    

     /**
      *     set_hooks - for hooking into EE Core, other modules, etc
      *
      *  @access    public
      *  @return    void
      */
    public static function set_hooks()
    {
        self::set_hooks_for_both();
    }
     
    public static function set_hooks_admin()
    {
        self::set_hooks_for_both();
    }

     /**
      * hooks in actions and filters used on both frontend and backend
      */
    protected static function set_hooks_for_both()
    {
        add_filter('FHEE__EEE_Infusionsoft_Line_Item__create_IS_product__ProductName', array( __CLASS__, 'customize_promotion_product_name' ), 10, 2);
        add_filter('FHEE__EEE_Infusionsoft_Line_Item__create_IS_product__description', array( __CLASS__, 'customize_promotion_long_description' ), 10, 2);
        add_filter('FHEE__EEE_Infusionsoft_Line_Item__create_IS_product__short_description', array( __CLASS__, 'customize_promotion_short_description' ), 10, 2);
    }
     
    public static function customize_promotion_product_name($name, $line_item)
    {
        if ($line_item instanceof EE_Line_Item && class_exists('EE_Promotion')) {
            $obj = $line_item->get_object();
            if ($obj instanceof EE_Promotion) {
                return sprintf(
                    __('%1$s Promotion %2$s', 'event_espresso'),
                    $obj->is_percent() ? __('Percent', 'event_espresso') : __('Dollar', 'event_espresso'),
                    $obj->name()
                );
            }
        }
        return $name;
    }
     
     /**
      * Customize the short description (join lines with \r\n)
      * @param string $description
      * @param EE_Line_Item $line_item
      * @return string
      */
    public static function customize_promotion_short_description($description, $line_item)
    {
        return substr(
            self::customize_promotion_product_description($description, $line_item, "\r\n"),
            0,
            250
        );
    }
     
     /**
      * Customize the long description (join with br tags)
      * @param string $description
      * @param EE_Line_Item $line_item
      * @return string
      */
    public static function customize_promotion_long_description($description, $line_item)
    {
        return self::customize_promotion_product_description($description, $line_item, '<br>');
    }

    public static function customize_promotion_product_description($description, $line_item, $line_glue = "\r\n")
    {
        if ($line_item instanceof EE_Line_Item && class_exists('EE_Promotion')) {
            $obj = $line_item->get_object();
            if ($obj instanceof EE_Promotion) {
                $limit = 10;
                $scope_objects = $obj->promotion_objects(array( 'limit' => $limit ));
                $scope_object_names = array();
                foreach ($scope_objects as $scope_obj) {
                    if ($scope_obj instanceof EE_Promotion_Object) {
                        $object_promotion_applies_to = $scope_obj->object();
                        if ($object_promotion_applies_to instanceof EE_Base_Class) {
                            $scope_object_names[] = $object_promotion_applies_to->name();
                        }
                    }
                }
                if (count($scope_object_names) >= $limit) {
                    $scope_object_names[] = __('...and others...', 'event_espresso');
                }
                $description_data = array(
                   __('Name', 'event_espresso') => $obj->name(),
                   __('Code', 'event_espresso') => $obj->code(),
                   __('Type', 'event_espresso') => $obj->is_percent() ? __('Percent', 'event_espresso') : __('Dollar', 'event_espresso'),
                   __('Amount', 'event_espresso') => $obj->amount(),
                   __('Scope (applied to)', 'event_espresso') => $obj->scope(),
                   __('Promo is Exclusive', 'event_espresso') => $obj->get_pretty('PRO_exclusive'),
                   __('Number of Uses', 'event_espresso') => $obj->uses(),
                   __('Valid From', 'event_espresso') => $obj->start(),
                   __('Valid Until', 'event_espresso') => $obj->end(),
                   __('Promotion applies to...', 'event_espresso') => implode(', ', $scope_object_names),
                );
                $description = '';
                foreach ($description_data as $key => $val) {
                    $description .= sprintf(__('%1$s: %2$s', 'event_espresso'), $key, $val) . $line_glue;
                }
            }
        }
        return $description;
    }

     /**
      *    run - initial module setup
      *
      * @access    public
      * @param  WP $WP
      * @return    void
      */
    public function run($WP)
    {
        // add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ));
    }
}
