<?php
/**
 * Infusionsoft_Admin_Page
 * This contains the logic for setting up the Infusionsoft Addon Admin related pages.  Any methods without PHP doc comments have inline docs with parent class.
 * @package               Infusionsoft_Admin_Page (infusionsoft addon)
 * @subpackage            admin/Infusionsoft_Admin_Page.core.php
 * @author                Darren Ethier, Brent Christensen
 * ------------------------------------------------------------------------
 */
class Infusionsoft_Admin_Page extends EE_Admin_Page
{

    /**
     * Form for passing between pre-headers function and post-headers function
     * (mostly only useful for POST requests where the form was somehow invalid
     * and so we want to display the invalid form with validation errors)
     * @var EE_Form_Section_Proper
     */
    protected $_form;


    protected function _init_page_props()
    {
        $this->page_slug = INFUSIONSOFT_PG_SLUG;
        $this->page_label = INFUSIONSOFT_LABEL;
        $this->_admin_base_url = EE_INFUSIONSOFT_ADMIN_URL;
        $this->_admin_base_path = EE_INFUSIONSOFT_ADMIN;
    }



    protected function _ajax_hooks()
    {
    }



    protected function _define_page_props()
    {
        $this->_admin_page_title = INFUSIONSOFT_LABEL;
        $this->_labels = array(
            'publishbox' => esc_html__('Update Settings', 'event_espresso'),
        );
    }



    protected function _set_page_routes()
    {
        $this->_page_routes = array(
            'default'          => '_basic_settings',
            'update_settings'  => array(
                'func'     => '_update_settings',
                'noheader' => true,
            ),
            'usage'            => '_usage',
            'question_mapping' => array(
                'func'       => '_question_mapping',
                'capability' => 'manage_options',
            ),
            'update_question_mapping' =>  array(
                'func'               => '_update_question_mapping',
                'noheader'           => true,
                'headers_sent_route' => 'question_mapping',
                'capability'         => 'manage_options',
            ),
            'conditional_tagging' => array(
                'func' => '_conditional_tagging',
                'capability' => 'manage_options'
            ),
            'update_conditional_tagging' => array(
                'func' => '_update_conditional_tagging',
                'noheader' => true,
                'headers_sent_route' => 'conditional_tagging',
                'capability' => 'manage_options'
            )
        );
    }



    protected function _set_page_config()
    {

        $this->_page_config = array(
            'default' => array(
                'nav'           => array(
                    'label' => esc_html__('Settings', 'event_espresso'),
                    'order' => 10,
                ),
                'metaboxes'     => array_merge($this->_default_espresso_metaboxes, array('_publish_post_box')),
                'require_nonce' => false,
            ),
            'question_mapping' => array(
                'nav'           => array(
                    'label' => esc_html__("Custom Fields Setup", "event_espresso"),
                    'order' => 30,
                ),
                'require_nonce' => false,
            ),
            'conditional_tagging' => array(
                'nav' => array(
                    'label' => esc_html__('Conditional Tagging Setup', 'event_espresso'),
                    'order' => 40
                )
            ),
            'usage'   => array(
                'nav'           => array(
                    'label' => esc_html__('Infusionsoft Usage', 'event_espresso'),
                    'order' => 100,
                ),
                'require_nonce' => false,
            ),

        );
    }


    protected function _add_screen_options()
    {
    }



    protected function _add_screen_options_default()
    {
    }



    protected function _add_feature_pointers()
    {
    }



    public function load_scripts_styles()
    {
        wp_register_script(
            'espresso_infusionsoft_admin',
            EE_INFUSIONSOFT_ADMIN_ASSETS_URL . 'espresso_infusionsoft_admin.js',
            array(
                'espresso_core'
            ),
            EE_INFUSIONSOFT_VERSION,
            true
        );
        wp_enqueue_script('espresso_infusionsoft_admin');
        EE_Registry::$i18n_js_strings['confirm_reset'] = __(
            'Are you sure you want to reset ALL your Event Espresso Infusionsoft Information? This cannot be undone.',
            'event_espresso'
        );
        wp_localize_script('espresso_infusionsoft_admin', 'eei18n', EE_Registry::$i18n_js_strings);
    }



    /**
     * Gets the form and loads it JS (if any) and saves the form so
     * we don't need to do it again later during conditional_tagging()
     */
    public function load_scripts_styles_conditional_tagging()
    {
        try {
            $this->_form = $this->_get_conditional_tagging_form();
            $this->_form->enqueue_js();
        } catch (Exception $e) {
            // fail silently for now, we'll show the error later during the request
            EE_Error::add_error(
                $e->getMessage(),
                __FILE__,
                __FUNCTION__,
                __LINE__
            );
        }
    }


    public function admin_init()
    {
    }



    public function admin_notices()
    {
    }



    public function admin_footer_scripts()
    {
    }



    protected function _basic_settings()
    {
        $this->_settings_page('infusionsoft_basic_settings.template.php');
    }



    /**
     * _settings_page
     *
     * @param $template
     */
    protected function _settings_page($template)
    {
        EE_Registry::instance()->load_helper('Form_Fields');
        $this->_template_args['config'] = EE_Registry::instance()->addons->EE_Infusionsoft->config();
        add_filter('FHEE__EEH_Form_Fields__label_html', '__return_empty_string');
        $this->_template_args['yes_no_values'] = array(
            EE_Question_Option::new_instance(array('QSO_value' => 0, 'QSO_desc' => esc_html__('No', 'event_espresso'))),
            EE_Question_Option::new_instance(array('QSO_value' => 1, 'QSO_desc' => esc_html__('Yes', 'event_espresso'))),
        );
        $this->_template_args['return_action'] = $this->_req_action;
        $this->_template_args['reset_url'] = EE_Admin_Page::add_query_args_and_nonce(
            array(
                'action' => 'reset_settings',
                'return_action' => $this->_req_action
            ),
            EE_INFUSIONSOFT_ADMIN_URL
        );
        $this->_set_add_edit_form_tags('update_settings');
        $this->_set_publish_post_box_vars(null, false, false, null, false);
        $this->_template_args['admin_page_content'] = EEH_Template::display_template(
            EE_INFUSIONSOFT_ADMIN_TEMPLATE_PATH . $template,
            $this->_template_args,
            true
        );
        $this->display_admin_page_with_sidebar();
    }



    protected function _usage()
    {
        $this->_template_args['admin_page_content'] = EEH_Template::display_template(
            EE_INFUSIONSOFT_ADMIN_TEMPLATE_PATH . 'infusionsoft_usage_info.template.php',
            array(),
            true
        );
        $this->display_admin_page_with_no_sidebar();
    }



    protected function _update_settings()
    {
        EE_Registry::instance()->load_helper('Class_Tools');
        if (isset($_POST['reset_infusionsoft']) && $_POST['reset_infusionsoft'] == '1') {
            $config = new EE_Infusionsoft_Config();
            $count = 1;
        } else {
            $config = EE_Registry::instance()->addons->EE_Infusionsoft->config();
            $count = 0;
            // otherwise we assume you want to allow full html
            foreach ($this->_req_data as $key => $value) {
                if (EEH_Class_Tools::has_property($config, $key) && $value != $config->$key) {
                    $config->$key = $this->_sanitize_config_input($key, null, $value);
                    $count++;
                }
            }
        }
        EE_Config::instance()->update_config('addons', 'EE_Infusionsoft', $config);
        // now test out those crednetials, if they've provided any
        if (! empty($config->application_name) && ! empty($config->private_key)) {
            try {
                EED_Infusionsoft::infusionsoft_connection(true);
            } catch (Exception $e) {
                EE_Error::add_error(
                    sprintf(
                        esc_html__(
                            'Error connecting to Infusionsoft: %s. Please double-check your application name and private key',
                            'event_espresso'
                        ),
                        $e->getMessage()
                    ),
                    __FILE__,
                    __FUNCTION__,
                    __LINE__
                );
            }
        }
        $this->_redirect_after_action($count, 'Settings', 'updated', array('action' => $this->_req_data['return_action']));
    }

    /**
     * resets the infusionsoft data and redirects to where they came from
     */
    //  protected function _reset_settings(){
    //      EE_Config::instance()->addons['infusionsoft'] = new EE_Infusionsoft_Config();
    //      EE_Config::instance()->update_espresso_config();
    //      $this->_redirect_after_action(1, 'Settings', 'reset', array('action' => $this->_req_data['return_action']));
    //  }
    private function _sanitize_config_input($top_level_key, $second_level_key, $value)
    {
        $sanitization_methods = array(
            'private_key'      => 'plaintext',
            'application_name' => 'plaintext',
        );
        $sanitization_method = null;
        if (isset($sanitization_methods[ $top_level_key ])
            && $second_level_key === null
            && ! is_array($sanitization_methods[ $top_level_key ])) {
            $sanitization_method = $sanitization_methods[ $top_level_key ];
        } elseif (is_array($sanitization_methods[ $top_level_key ])
            && isset($sanitization_methods[ $top_level_key ][ $second_level_key ])
        ) {
            $sanitization_method = $sanitization_methods[ $top_level_key ][ $second_level_key ];
        }
        //      echo "$top_level_key [$second_level_key] with value $value will be sanitized as a $sanitization_method<br>";
        switch ($sanitization_method) {
            case 'bool':
                return (boolean) intval($value);
            case 'plaintext':
                return wp_strip_all_tags($value);
            case 'int':
                return intval($value);
            case 'html':
                return $value;
            default:
                $input_name = $second_level_key == null ? $top_level_key : $top_level_key . "[" . $second_level_key . "]";
                EE_Error::add_error(
                    sprintf(
                        esc_html__(
                            "Could not sanitize input '%s' because it has no entry in our sanitization methods array",
                            "event_espresso"
                        ),
                        $input_name
                    ),
                    __FILE__,
                    __FUNCTION__,
                    __LINE__
                );
                return null;
        }
    }



    /**
     * Shows the page that allows event managers to change custom questions.
     * @todo: some questions have finite options, which we don't take into account here
     */
    protected function _question_mapping()
    {

        // get tall IS custom fields
        try {
            $form = $this->_generate_question_mapping_form();
            $this->_template_args['admin_page_content'] = $form->form_open(
                EE_Admin_Page::add_query_args_and_nonce(
                    array(
                            'action' => 'update_question_mapping'
                        ),
                    EE_INFUSIONSOFT_ADMIN_URL
                )
            )
                                                          . $form->get_html_and_js()
                                                          . $form->form_close();
        } catch (Exception $e) {
            $this->_template_args['admin_page_content'] = $e->getMessage();
        }
        $this->display_admin_page_with_no_sidebar();
    }



    /**
     * Gets the question mapping form or throws an exception
     * @return EE_Form_Section_Proper
     * @throws EE_Error
     */
    protected function _generate_question_mapping_form()
    {
        $isdk = EED_Infusionsoft::infusionsoft_connection();
        $custom_is_fields = $isdk->dsQuery(
            'DataFormField',
            1000,
            0,
            new stdClass(),
            array(
                'Id',
                'Name',
                'Label'
            )
        );
        if (EED_Infusionsoft::is_IS_error($custom_is_fields)) {
            throw new EE_Error(
                sprintf(
                    esc_html__(
                        'Could not retrieve list of Infusionsoft custom fields. The error was %1$s',
                        'event_espresso'
                    ),
                    (string) $custom_is_fields
                )
            );
        }
        $question_options = array(
            '' => '-',
        );
        /**
         * @var $custom_is_fields array
         */
        foreach ($custom_is_fields as $custom_is_field) {
            $question_options[ $custom_is_field['Name'] ] = $custom_is_field['Label'];
        }
        // get all custom questions
        $question_type_categories = EEM_Question::instance()->question_type_categories();
        if (!isset($question_type_categories['multi-answer-enum'])) {
            throw new EE_Error(
                esc_html__('Could not generate form of Infusionsoft custom fields.', 'event_espresso')
            );
        }
        $questions = EEM_Question::instance()->get_all(
            array(
                array(
                    // exclude system questions, because they're already mapped
                    'QST_system' => '',
                    // exclude multi-answer questions too, because IS doesn't handle that
                    'QST_type' => array(
                        'NOT_IN',
                        $question_type_categories['multi-answer-enum']
                    )
                )
            )
        );
        $form = new EE_Form_Section_Proper(
            array(
                'name' => 'is_mapping',
            )
        );
        $question_subsections = array();
        foreach ($questions as $question) {
            $question_subsections[ $question->ID() ] = new EE_Select_Input(
                $question_options,
                array(
                    'html_label_text' => $question->display_text()
                        . '['
                        . $question->admin_label()
                        . ']',
                    'default' => $question->get_IS_field_name()
                )
            );
        }
        $form->add_subsections(
            array(
                'header' => new EE_Form_Section_HTML(
                    EEH_HTML::h1(
                        esc_html__('Custom Fields Setup', 'event_espresso')
                    )
                ),
                'description' => new EE_Form_Section_HTML(
                    EEH_HTML::p(
                        sprintf(
                            esc_html__(
                                'Select which %1$scustom questions%2$s are for which Infusionsoft custom fields.',
                                'event_espresso'
                            ),
                            '<a href="' . REGISTRATION_FORM_ADMIN_URL . '">',
                            '</a>'
                        )
                        . EEH_HTML::br()
                        // @codingStandardsIgnoreStart
                        . esc_html__('Note: custom questions with multiple answers (e.g. checkbox or multi-select inputs) cannot be mapped to Infusionsoft custom fields because Infusionsoft does not support custom fields with multiple answers.', 'event_espresso')
                    // @codingStandardsIgnoreEnd
                    )
                ),
                'questions' => new EE_Form_Section_Proper(
                    array(
                        'subsections' => $question_subsections
                    )
                ),
                'submit' => new EE_Submit_Input(
                    array(
                        'html_label_text' => '',
                        'default' => esc_html__('Save', 'event_espresso')
                    )
                )
            )
        );
        return $form;
    }



    /**
     * Updates what IS custom fields each EE custom question maps to
     */
    protected function _update_question_mapping()
    {
        $form = $this->_generate_question_mapping_form();
        if ($form->was_submitted($_POST)) {
            $form->receive_form_submission($_POST);
            if ($form->is_valid()) {
                $question_subsection_form = $form->get_subsection('questions');
                if ($question_subsection_form === null) {
                    throw new EE_Error(
                        esc_html__(
                            'Could not process form because it is missing the questions section. Please contact support.',
                            'event_espresso'
                        )
                    );
                }
                // right on. Let's save them all
                $successes = 0;
                foreach ($question_subsection_form->input_values() as $question_id => $custom_field_name) {
                    $question = EEM_Question::instance()->get_one_by_ID($question_id);
                    if ($question instanceof EE_Question) {
                        $success = $question->update_extra_meta(
                            EEE_Infusionsoft_Question::extra_meta_IS_field_name,
                            $custom_field_name
                        );
                        if ((int) $success > 0) {
                            $successes++;
                        }
                    }
                }
                return $this->redirect_after_action(
                    $successes,
                    esc_html(
                        _n(
                            'question',
                            'questions',
                            $successes,
                            'event_espresso'
                        )
                    ),
                    esc_html__('saved', 'event_espresso'),
                    array(
                        'action' => 'question_mapping'
                    )
                );
            }
        }
    }



    /**
     * Shows the page that allows event managers to change what IS tags to assign to contacts
     * based on their answers to multiple choice questions
     */
    protected function _conditional_tagging()
    {
        // get tall IS custom fields
        try {
            $form = $this->_get_conditional_tagging_form();
            $this->_template_args['admin_page_content'] = $form->form_open(
                EE_Admin_Page::add_query_args_and_nonce(
                    array(
                            'action' => 'update_conditional_tagging'
                        ),
                    EE_INFUSIONSOFT_ADMIN_URL
                )
            )
                                                          . $form->get_html()
                                                          . $form->form_close();
        } catch (Exception $e) {
            $this->_template_args['admin_page_content'] = $e->getMessage();
        }
        $this->display_admin_page_with_no_sidebar();
    }



    /**
     * Gets the conditional tagging form if already created and stored on this object
     * or creates it and stores it and returns it.
     * @return EE_Form_Section_Proper
     */
    protected function _get_conditional_tagging_form()
    {
        if (! $this->_form instanceof EE_Form_Section_Proper
            || $this->_form->name() !== 'is_conditional_tagging'
        ) {
            $this->_form = $this->_generate_conditional_tagging_form();
        }
        return $this->_form;
    }



    /**
     * Gets the question mapping form or throws an exception
     * @return EE_Form_Section_Proper
     * @throws EE_Error
     */
    protected function _generate_conditional_tagging_form()
    {
        $isdk = EED_Infusionsoft::infusionsoft_connection();
        $tags = $isdk->dsQuery(
            'ContactGroup',
            1000,
            0,
            new stdClass(),
            array(
                'Id',
                'GroupName',
            )
        );
        if (EED_Infusionsoft::is_IS_error($tags)) {
            throw new EE_Error(
                sprintf(
                    esc_html__(
                        'Could not retrieve list of Infusionsoft tags. The error was %1$s',
                        'event_espresso'
                    ),
                    (string) $tags
                )
            );
        }
        $input_options = array();
        /**
         * @var $tags array
         */
        foreach ($tags as $custom_is_field) {
            $input_options[ $custom_is_field['Id'] ] = $custom_is_field['GroupName'];
        }
        $questions = EEM_Question::instance()->get_all(
            array(
                array(
                    // only select questions with options
                    'QST_type' => array(
                        'NOT_IN',
                        EEM_Question::instance()->question_types_in_category('text')
                    )
                )
            )
        );
        $form = new EE_Form_Section_Proper(
            array(
                'name' => 'is_conditional_tagging',
            )
        );
        $question_subsections = array();
        foreach ($questions as $question) {
            $question_option_subsections = array();
            foreach ($question->options() as $question_option_id => $question_option) {
                $question_option_subsections[ $question_option->ID() ] = new EE_Select_Multiple_Input(
                    $input_options,
                    array(
                        'html_label_text' => $question_option->value(),
                        // uses magic method added by EEE_Infusionsoft_Question_Option
                        'default' => $question_option->get_IS_tag_IDs(),
                    )
                );
                $question_subsections[ $question->ID() ] = new EE_Form_Section_Proper(
                    array(
                        'subsections' => array(
                            'question_text' => new EE_Form_Section_HTML(
                                EEH_HTML::h3(
                                    sprintf(
                                        esc_html__('Question: %1$s', 'event_espresso'),
                                        $question->display_text()
                                    )
                                )
                            ),
                            'options' => new EE_Form_Section_Proper(
                                array(
                                    'subsections' => $question_option_subsections
                                )
                            )
                        )
                    )
                );
            }
        }
        $form->add_subsections(
            array(
                'header' => new EE_Form_Section_HTML(
                    EEH_HTML::h1(
                        esc_html__('Conditional Tagging Setup', 'event_espresso')
                    )
                ),
                'description' => new EE_Form_Section_HTML(
                    EEH_HTML::p(
                        sprintf(
                            esc_html__(
                                'Select which multi-choice %1$scustom questions%2$s are for which Infusionsoft custom tags.',
                                'event_espresso'
                            ),
                            '<a href="' . REGISTRATION_FORM_ADMIN_URL . '">',
                            '</a>'
                        )
                        . EEH_HTML::br()
                        // @codingStandardsIgnoreStart
                        . esc_html__('Note: only multi-choice custom questions (like radio, checkbox, and dropdown select) are used for custom tagging.', 'event_espresso')
                        // @codingStandardsIgnoreEnd
                    )
                ),
                'questions' => new EE_Form_Section_Proper(
                    array(
                        'subsections' => $question_subsections
                    )
                ),
                'submit' => new EE_Submit_Input(
                    array(
                        'html_label_text' => '',
                        'default' => esc_html__('Save', 'event_espresso')
                    )
                )
            )
        );
        return $form;
    }



    /**
     * Updates what IS custom fields each EE custom question maps to
     */
    protected function _update_conditional_tagging()
    {
        $form = $this->_get_conditional_tagging_form();
        if ($form->was_submitted($_POST)) {
            $form->receive_form_submission($_POST);
            if ($form->is_valid()) {
                // right on. Let's save them all
                $successes = 0;
                $question_subsection_form = $form->get_proper_subsection('questions');
                // no need to check return value because we would have had an exception if it were missing
                foreach ($question_subsection_form->subsections() as $question_id => $question_form) {
                    $question_options_form = $question_form->get_proper_subsection('options');
                    // no need to check return value because we would have had an exception if it were missing
                    foreach ($question_options_form->input_values() as $question_option_id => $chosen_tags) {
                        $question_option = EEM_Question_Option::instance()->get_one_by_ID($question_option_id);
                        if ($question_option instanceof EE_Question_Option) {
                            $question_option->set_IS_tag_IDs($chosen_tags);
                            $successes++;
                        }
                    }
                }
                return $this->redirect_after_action(
                    $successes,
                    esc_html(
                        _n(
                            'question option',
                            'question options',
                            $successes,
                            'event_espresso'
                        )
                    ),
                    esc_html__('saved', 'event_espresso'),
                    array(
                        'action' => 'conditional_tagging'
                    )
                );
            }
        }
    }
}
