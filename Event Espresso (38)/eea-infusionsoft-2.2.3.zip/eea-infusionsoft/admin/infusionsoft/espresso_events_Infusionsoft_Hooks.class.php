<?php

use EventEspresso\core\exceptions\InvalidDataTypeException;
use EventEspresso\core\exceptions\InvalidInterfaceException;

/**
 * espresso_events_Registration_Form_Hooks_Extend
 * Hooks various messages logic so that it runs on indicated Events Admin Pages.
 * Commenting/docs common to all children classes is found in the EE_Admin_Hooks parent.
 *
 * @package         espresso_events_Registration_Form_Hooks_Extend
 * @subpackage      includes/core/admin/messages/espresso_events_Registration_Form_Hooks_Extend.class.php
 * @author          Mike Nelson
 * ------------------------------------------------------------------------
 */
class espresso_events_Infusionsoft_Hooks extends EE_Admin_Hooks
{

    /**
     * @var $form EE_Form_Section_Proper
     */
    protected $form;



    protected function _set_hooks_properties()
    {
        $this->_name = 'infusionsoft';
        add_filter(
            'FHEE__Events_Admin_Page___insert_update_cpt_item__event_update_callbacks',
            array($this,'modifyCallbacks')
        );
    }



    /**
     * extending the properties set in espresso_events_Registration_From_Hooks
     *
     * @access protected
     * @return void
     */
    protected function _extend_properties()
    {
        $this->_metaboxes = array_merge(
            $this->_metaboxes,
            array(
                1 => array(
                    'page_route' => array('create_new', 'edit'),
                    'func'       => 'infusionsoftTags',
                    'label'      => esc_html__('Infusionsoft Tags', 'event_espresso'),
                    'priority'   => 'default',
                    'context'    => 'side',
                ),
            )
        );
    }



    /**
     * @param Callable[] $callbacks
     * @return array
     */
    public function modifyCallbacks($callbacks)
    {
        $callbacks[] = array($this, 'updateInfusionsoftTags');
        return $callbacks;
    }



    /**
     * Gets the form, possibly fetching one that was already generating this requested
     * @param EE_Event $event
     * @return EE_Form_Section_Proper|void
     */
    protected function getForm(EE_Event $event)
    {
        if (! $this->form instanceof EE_Form_Section_Proper) {
            $this->form = $this->generateForm($event);
        }
        return $this->form;
    }



    /**
     * Creates the form for setting the IS tags for the event
     * @param EE_Event $event
     * @throws EE_Error
     */
    protected function generateForm(EE_Event $event)
    {
        $isdk = EED_Infusionsoft::infusionsoft_connection();
        $tags = $isdk->dsQuery(
            'ContactGroup',
            1000,
            0,
            new stdClass(),
            array(
                'Id',
                'GroupName',
            )
        );
        if (EED_Infusionsoft::is_IS_error($tags)) {
            throw new EE_Error(
                sprintf(
                    esc_html__(
                        'Could not retrieve list of Infusionsoft tags. The error was %1$s',
                        'event_espresso'
                    ),
                    (string) $tags
                )
            );
        }

        $input_options = array(
            '' => ''
        );
        /**
         * @var $tags array
         */
        foreach ($tags as $custom_is_field) {
            $input_options[ $custom_is_field['Id'] ] = $custom_is_field['GroupName'];
        }
        return new EE_Form_Section_Proper(
            array(
                'name'            => 'infusionsoft_tags',
                'layout_strategy' => new EE_Admin_One_Column_Layout(),
                'subsections'     => array(
                    'desc'    => new EE_Form_Section_HTML(
                        EEH_HTML::p(
                            esc_html__(
                                // @codingStandardsIgnoreStart
                                'The following Infusionsoft tags will be assigned to all contacts who register for this event.',
                                // @codingStandardsIgnoreEnd
                                'event_espresso'
                            )
                        )
                    ),
                    'IS_tags' => new EE_Select_Multiple_Input(
                        $input_options,
                        array(
                            'html_label_text' => '',
                            // uses magic method added by EEE_Infusionsoft_Question_Option
                            'default'         => $event->get_IS_tag_IDs(),
                        )
                    )
                )
            )
        );
    }



    /**
     * @param $post_id
     * @param $post
     * @throws EE_Error
     * @throws InvalidArgumentException
     * @throws InvalidDataTypeException
     * @throws InvalidInterfaceException
     */
    public function infusionsoftTags(
        $post
    ) {
        try {
            $event = EEM_Event::instance()->get_one_by_ID($post->ID);
            if ($event instanceof EE_Event) {
                $form = $this->getForm($event);
                echo $form->get_html_and_js();
            } else {
                esc_html__('Event does not exist, cannot create Infusionsoft tags form.', 'event_espresso');
            }
        } catch (Exception $e) {
            echo $e->getMessage();
        }
    }



    /**
     * Saves event's tags
     *
     * @param EE_Event $event
     * @param $data
     * @return bool
     */
    public function updateInfusionsoftTags(
        EE_Event $event,
        $data
    ) {
        try {
            $form = $this->getForm($event);
            $form->receive_form_submission($data);
            if ($form->is_valid()) {
                $event->set_IS_tag_IDs($form->get_input_value('IS_tags'));
                return true;
            }
            return false;
        } catch (Exception $e) {
            EE_Error::add_error(
                $e->getMessage(),
                __FILE__,
                __FUNCTION__,
                __LINE__
            );
        }
    }
}
