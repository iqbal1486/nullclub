<div class="padding">
    <ul>
        <li>
            <strong>
                <?php _e('Online Documentation:', 'event_espresso'); ?>
            </strong>
            <p><?php printf(esc_html__('Please refer to our %1$sonline documentation%2$s for how to integrate Event Espresso with Infusionsoft', 'event_espresso'), "<a href='https://eventespresso.com/wiki/infusionsoft-integration/' target='_blank'>", "</a>");?></p>

        </li>

    </ul>
</div>
<!-- / .padding -->