<?php
/* @var $config EE_Infusionsoft_Config */
?>
<div class="padding">
    <h4>
        <?php esc_html_e('Infusionsoft Settings', 'event_espresso'); ?>
    </h4>
    <table class="form-table">
        <tbody>

            <tr>
                <th>
                    <label for="application_name">
                        <?php esc_html_e('Application Name', 'event_espresso'); ?>
                    </label>
                </th>
                <td>
                    <input class="regular-text" type="text" name="application_name" value="<?php echo $config->application_name; ?>" />
                    <p class="description">
                        <?php echo esc_html__('Your Infusionsoft Application Name or ID.', 'event_espresso'); ?>
                    </p>
                </td>
            </tr>

            <tr>
                <th>
                    <label for="private_key">
                        <?php esc_html_e('Encrypted Key', 'event_espresso'); ?>
                    </label>
                </th>
                <td>
                    <input class="regular-text" type="text" name="private_key" value="<?php echo $config->private_key; ?>" />
                    <p class="description">
                        <?php echo esc_html__('Your Infusionsoft Encrypted Key.', 'event_espresso'); ?>
                    </p>
                </td>
            </tr>

            <tr>
                <th><?php esc_html_e("Reset Infusionsoft Settings?", 'event_espresso');?></th>
                <td>
                    <?php echo EEH_Form_Fields::select(esc_html__('Reset Infusionsoft Settings?', 'event_espresso'), 0, $yes_no_values, 'reset_infusionsoft', 'reset_infusionsoft'); ?><br/>
                    <span class="description">
                        <?php _e('Set to \'Yes\' and then click \'Save\' to confirm reset all basic and advanced Event Espresso Infusionsoft settings to their plugin defaults.', 'event_espresso'); ?>
                    </span>
                </td>
            </tr>

        </tbody>
    </table>

</div>

<input type='hidden' name="return_action" value="<?php echo $return_action?>">

