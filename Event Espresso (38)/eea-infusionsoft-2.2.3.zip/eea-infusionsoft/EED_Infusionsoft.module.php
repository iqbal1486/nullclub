<?php
/**
 * Class  EED_Infusionsoft
 *
 * @package               Event Espresso
 * @subpackage            espresso-new-addon
 * @author                Brent Christensen
 * ------------------------------------------------------------------------
 */
class EED_Infusionsoft extends EED_Module
{

    /**
     * Date format to be used when sending dates to Infusionsoft.
     * Eg  date(EED_Infusionsoft::IS_datetime_format, time())
     */
    const IS_datetime_format = "Ymd\TH:i:s";

    /**
     * Whenever IS sends an error response, they send a string starting with this
     */
    const IS_error_response_prefix = 'ERROR:';

    /**
     * @var array where keys are model 'names', eg 'Event', 'Registration', 'Ticket', etc
     */
    private static $_models_synced_to_IS = array(
        'Answer',// just so we know to re-trigger sync'ing the registration and its attendee
        'Attendee',// sync to IS contacts
        'Transaction',// sync to IS Invoices
        'Registration',// assigns IS contacts to groups
        'Ticket',// sync to IS products
        'Event',// just so that a change to an event name will force resyncing of its tickets
        'Datetime_Ticket',// helps trigger syncing of Tickets to IS products
        'Line_Item', // syncs to IS InvoiceItems/OrderItems
        'Payment', // syncs payments
    );

    /**
     * Stores all the model objects we want to sycn to infusionsoft.
     * It's nice doing this at the end because the data should be complete; whereas
     * if we did it as the data was saved, data is oftne temporarily in an incomplete state
     * (eg: we need to save a transaction before registrations, but a transaction without registrations
     * is incomplete; also when we save a registration none of its answers have been saved which is also
     * incomplete)
     *
     * @var array top-level keys ar emodel names, next level are model objects indexed by their IDs
     */
    private static $_model_objs_to_sync = array();

    /**
     * Stores all the model objects that have been sync'ed on this request.
     * (Because some model objects may trigger others to be sync'ed so it's nice to have a central place
     * where we know they've all been sync'ed)
     *
     * @var array top-level keys ar emodel names, next level are model objects indexed by their IDs
     */
    private static $_model_objs_synced_this_request = array();

    /**
     * @var EE_iSDK
     */
    protected static $infusionsoft_connection = null;



    /**
     * @return EED_Infusionsoft
     */
    public static function instance()
    {
        return parent::get_instance(__CLASS__);
    }



    public static function reset()
    {
        self::$_model_objs_to_sync = array();
        self::$_model_objs_synced_this_request = array();
    }



    /**
     * Gets an arrya naming each model that is synced to IS
     *
     * @return array where keys are model 'names', eg 'Event', 'Registration', 'Ticket', etc
     */
    public static function models_synced_to_IS()
    {
        return apply_filters('FHEE__EED_Infusionsoft__models_synced_to_IS', self::$_models_synced_to_IS);
    }



    /**
     *    set_hooks - for hooking into EE Core, other modules, etc
     *
     * @access    public
     * @return    void
     */
    public static function set_hooks()
    {
        // EE_Config::register_route( 'infusionsoft', 'EED_Infusionsoft', 'run' );
        self::set_hooks_for_both();
        add_action('AHEE__EE_Front_Controller__get_request__complete', array('EED_Infusionsoft', 'set_affiliate_cookie'));
    }



    /**
     * hooks in actions and filters used on both frontend and backend
     */
    protected static function set_hooks_for_both()
    {
        // hook into when a row is inserted by directly using an EEM_Base child
        add_action('AHEE__EEM_Base__insert__end', array('EED_Infusionsoft', 'sync_insert_item'), 10, 3);
        // before an update query is executed, make sure we have the model objects stored in the entity map
        // BEFORE the update query is issued. This way the model object's will start with the old values
        // CAHNGED MIND. This means the model objects will have their values from BEFORE the update query.
        // the proper fix should be on ticket 6351 where we should ensure updated rows are model objects BEFORE a query
        // and we should manually updated each object too during the query (when using the model directly)
        //       add_filter( 'FHEE__EEM_Base__update__fields_n_values', array( 'EED_Infusionsoft', 'store_affected_in_entity_map'), 10, 3);
        // hook into when a row is updated by directly using an EEM_Base child
        add_action('AHEE__EEM_Base__update__end', array('EED_Infusionsoft', 'sync_update_items'), 10, 4);
        // hook into when a model object is saved
        add_action('AHEE__EE_Base_Class__save__end', array('EED_Infusionsoft', 'sync_saved_item'), 10, 2);
        add_action('shutdown', array('EED_Infusionsoft', 'sync_to_infusionsoft_now'));
    }



    /**
     * Checks if this is for something we sync to infusionsoft
     *
     * @param EEM_Base   $model
     * @param array      $fields_n_values
     * @param int|string $new_id
     */
    public static function sync_insert_item($model, $fields_n_values, $new_id)
    {
        if ($model->get_assumption_concerning_values_already_prepared_by_model_object()) {
            // items already prepared by model object. So let's allow the model object hook to do this work instead
            return;
        }
        if (in_array($model->get_this_model_name(), self::models_synced_to_IS())) {
            $item = $model->get_one_by_ID($new_id);
            if ($item instanceof EE_Base_Class) {
                self::$_model_objs_to_sync[ $item->get_model()->get_this_model_name() ][ $item->ID() ] = $item;
            }
        }
    }


    //   public static function store_affected_in_entity_map( $fields_n_values, )



    /**
     * @param EEM_Base $model
     * @param array    $fields_n_values keys are model field names, values are their updated values
     * @param array    $query_params    @see EEM_Base::get_all()
     * @param int      $num_rows_affected
     */
    public static function sync_update_items($model, $fields_n_values, $query_params, $num_rows_affected)
    {
        // was the job of sync'ing already handled when the model object saved it?
        // or is this a model that IS doesn't care about?
        if ($model->get_assumption_concerning_values_already_prepared_by_model_object()
            || ! in_array($model->get_this_model_name(), self::models_synced_to_IS(), true)
        ) {
            // items already prepared by model object. So let's allow the model object hook to do this work instead
            return;
        }
        $items_just_updated = $model->get_all($query_params);
        foreach ($items_just_updated as $item_just_updated) {
            self::sync_insert_item($model, $item_just_updated->model_field_array(), $item_just_updated->ID());
        }
    }



    /**
     * @param EE_Base_Class $model_obj
     * @param type          $save_result
     * @return boolean
     */
    public static function sync_saved_item($model_obj, $save_result)
    {
        // sync to IS even if the save failed
        // becaue it's possible THIS thing may not be changed,
        // but related data was
        if ($model_obj instanceof EE_Base_Class
            && in_array($model_obj->get_model()->get_this_model_name(), self::models_synced_to_IS())) {
            // enqueue it for saving to IS
            self::$_model_objs_to_sync[ $model_obj->get_model()->get_this_model_name() ][ $model_obj->ID() ] = $model_obj;
        }
    }



    /**
     * Called on shutdown to perform the actual sync'ing
     */
    public static function sync_to_infusionsoft_now()
    {
        // define last-synchronized model object, in case there is an exception before we actually start to process any of them
        $model_objs_to_sync = self::$_model_objs_to_sync;
        $model_obj = null;
        try {
            foreach (self::$_model_objs_to_sync as $model_name => $model_objs) {
                foreach ($model_objs as $id => $model_obj) {
                    // use the special function added by the model class extensions
                    $model_obj->sync_to_infusionsoft();
                }
            }
        } catch (\Exception $e) {
            error_log(
                sprintf(
                    __(
                        'An exception occurred while the EE4 Infusionsoft Add-on was synchronizing to Infusionsoft. The exception was "%1$s" and had trace %2$s. The model objects being synchronized were %3$s, and the one with the exception was a "%4$s" with ID "%5$s"',
                        'event_espresso'
                    ),
                    $e->getMessage(),
                    $e->getTraceAsString(),
                    print_r(
                        array_reduce(
                            $model_objs_to_sync,
                            function ($carry_array, $model_objs) {
                                foreach ($model_objs as $model_obj) {
                                    if ($model_obj instanceof EE_Base_Class) {
                                        $carry_array[ $model_obj->get_model()->get_this_model_name() ][] = $model_obj->model_field_array();
                                    }
                                }
                                return $carry_array;
                            },
                            array()
                        ),
                        true
                    ),
                    is_object($model_obj) ? get_class($model_obj) : __('Not an object', 'event_espresso'),
                    $model_obj instanceof EE_Base_Class ? $model_obj->ID() : __('Not an EE model object', 'event_espresso')
                )
            );
        }
    }



    /**
     * Records that we've sync'ed this model object to infusionsoft on this request
     * so we can avoid repeating it later
     *
     * @param EE_Base_Class $model_obj
     */
    public static function mark_model_obj_synced($model_obj)
    {
        if ($model_obj instanceof EE_Base_Class) {
            self::$_model_objs_synced_this_request[ $model_obj->get_model()->get_this_model_name() ][ $model_obj->ID() ] = $model_obj;
        } else {
            EE_Error::add_error(
                sprintf(__('EED_Infusionsoft::mark_model_obj_synced called on a non-model object of type %s', 'event_espresso')),
                gettype($model_obj),
                __FILE__,
                __FUNCTION__,
                __LINE__
            );
        }
    }



    /**
     * Indicates whether or not we've already sync'ed this model object
     * on this request (useful for knowing if we ought to sync it or not)
     *
     * @param EE_Base_Class $model_obj
     * @return boolean
     */
    public static function synced_on_this_request($model_obj)
    {
        if ($model_obj instanceof EE_Base_Class) {
            return isset(self::$_model_objs_synced_this_request[ $model_obj->get_model()->get_this_model_name() ][ $model_obj->ID() ]);
        } else {
            EE_Error::add_error(sprintf(__('EED_Infusionsoft::synced called on a non-model object of type %s', 'event_espresso')), gettype($model_obj), __FILE__, __FUNCTION__, __LINE__);
        }
    }



    /**
     *    set_hooks_admin - for hooking into EE Admin Core, other modules, etc
     *
     * @access    public
     * @return    void
     */
    public static function set_hooks_admin()
    {
        // some of the Thank You page hooks get called via AJAX, so these need to be called via the admin
        self::set_hooks_for_both();
        // ajax hooks
        add_action('wp_ajax_get_infusionsoft', array('EED_Infusionsoft', '_get_infusionsoft'));
        add_action('wp_ajax_nopriv_get_infusionsoft', array('EED_Infusionsoft', '_get_infusionsoft'));
    }



    /**
     *    config
     *
     * @return EE_Infusionsoft_Config
     */
    public function config()
    {
        // config settings are setup up individually for EED_Modules via the EE_Configurable class that all modules inherit from, so
        // $this->config();  can be used anywhere to retrieve it's config, and:
        // $this->_update_config( $EE_Config_Base_object ); can be used to supply an updated instance of it's config object
        // to piggy back off of the config setup for the base EE_Infusionsoft class, just use the following (note: updates would have to occur from within that class)
        return EE_Registry::instance()->addons->EE_Infusionsoft->config();
    }



    /**
     * Checks for a REQUEST parameter which indicates which affiliate to set a cookie for.
     * If there is a reqeust parameter of 'ref' then sets the 'EE_IS_AffName' cookie (which
     * looks up the affiliate in IS using its "AffCode"),
     * if 'affiliate' then it sets the 'EE_IS_AffId' cookie (which looks up the affiliate
     * in IS using its "Id"). @see https://developer.infusionsoft.com/docs/read/Table_Documentation
     *
     * @return void
     */
    public static function set_affiliate_cookie()
    {
        try {
            $req = EE_Registry::instance()->REQ;
            $url_param_for_affiliate_code = apply_filters('FHEE__EED_Infusionsoft__set_affiliate_cookie__url_param_for_affiliate_code', 'ref');
            $url_param_for_affiliate_id = apply_filters('FHEE__EED_Infusionsoft__set_affiliate_cookie__url_param_for_affiliate_id', 'affiliate');
            $affiliate_code = $req->is_set($url_param_for_affiliate_code) ? sanitize_text_field($req->get($url_param_for_affiliate_code)) : null;
            $affiliate_id = $req->is_set($url_param_for_affiliate_id) ? sanitize_text_field($req->get($url_param_for_affiliate_id)) : null;
            if ($affiliate_code || $affiliate_id) {
                // if they passed an affiliate code/name, try looking it up
                if ($affiliate_code) {
                    $qry = array('AffCode' => $affiliate_code);
                    $rets = array('Id');
                    $ee_infusionsoft = EED_Infusionsoft::infusionsoft_connection();
                    $affiliate_query_results = $ee_infusionsoft->dsQuery('Affiliate', 1, 0, $qry, $rets);
                    if (! empty($affiliate_query_results)) {
                        if (WP_DEBUG && is_string($affiliate_query_results)) {
                            EE_Error::add_error(sprintf(__('Infusionsoft Error while retrieiving affiliate ID: "%s"', 'event_espresso'), $affiliate_query_results), __FILE__, __FUNCTION__, __LINE__);
                        }
                        $affiliate_id = $affiliate_query_results[0]['Id'];
                    } elseif (WP_DEBUG) {
                        // they passed an IS referral code but none exists by that code
                        EE_Error::add_error(
                            sprintf(__('Error finding Infusionsoft Affiliate for Referral Code "%s". Please ensure there is such an affiliate', 'event_espresso'), $affiliate_code),
                            __FILE__,
                            __FUNCTION__,
                            __LINE__
                        );
                    }
                }
                // ok at this point we either have an affiliate ID or we don't
                if ($affiliate_id) {
                    /**
                     * defines how long the IS affiliate cookie should exist for
                     *
                     * @param int $seconds_from_now
                     */
                    $cookie_life = time() + apply_filters('FHEE__EED_Infusionsoft__set_affiliate_cookie__cookie_life', 60 * 60 * 24 * 30);
                    /**
                     * defines the path that should be used for this cookie
                     *
                     * @param string $path (defaults to '/')
                     */
                    $cookie_path = apply_filters('FHEE__EED_Infusionsoft__set_affiliate_cookie__path', '/');
                    /**
                     * just before we've set the affiliate cookie this is called with the affiliate ID
                     *
                     * @param int $affiliate_id
                     */
                    do_action('AHEE__EED_Infusionsoft__set_affiliate_cookie__success', $affiliate_id);
                    EED_Infusionsoft::set_cookie('EE_IS_AffId', $affiliate_id, $cookie_life, $cookie_path);
                }
            }
        } catch (Exception $e) {
            $message = sprintf(__('Could not set affiliate code because %s', 'event_espresso'), $e->getMessage());
            if (WP_DEBUG) {
                EE_Error::add_error($message, __FILE__, __FUNCTION__, __LINE__);
            }
            error_log($message . $e->getTraceAsString());
        }
    }



    /**
     * wrapper for setcookie, which has a filter which can be used to
     *
     * @see setcookie documentation
     * @param string $name
     * @param string $value
     * @param int    $expire
     * @param string $path
     * @return boolean
     */
    public static function set_cookie($name, $value = null, $expire = null, $path = null)
    {
        $override = apply_filters('FHEE__EED_Infusionsoft__set_cookie__override', null, $name, $value, $expire, $path);
        if ($override !== null) {
            return $override;
        } else {
            return setcookie($name, $value, $expire, $path);
        }
    }



    /**
     *    run - initial module setup
     *
     * @access    public
     * @param  WP $WP
     * @return    void
     */
    public function run($WP)
    {
        // add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ));
    }



    /**
     *    enqueue_scripts - Load the scripts and css
     *
     * @access    public
     * @return    void
     */
    public function enqueue_scripts()
    {
    }



    /**
     * Gets the current connection to Infusionsoft
     * using the connection settings in the EE_Infusionsoft_Config
     *
     * @param boolean $reset whether to force reconnecting. default is to just re-use the old one
     * @return EE_iSDK
     * @throws EE_Error, Exception when we cannot connect to infusionsoft
     */
    public static function infusionsoft_connection($reset = false)
    {
        if ($reset || ! self::$infusionsoft_connection) {
            if (! class_exists('EE_iSDK')) {
                require_once("isdk.php");
            }
            // Get the Event Espresso Infusionsoft settings
            $config = EE_Registry::instance()->addons->EE_Infusionsoft->config();
            if (! empty($config->application_name) && ! empty($config->private_key)) {
                if (apply_filters('FHEE__EED_Infusionsoft__infusionsoft_connection__use_mock', false)) {
                    self::$infusionsoft_connection = new EE_iSDK_Mock();
                } else {
                    self::$infusionsoft_connection = new EE_iSDK;
                }
                if (! function_exists('xmlrpc_encode_entitites')) {
                    include("xmlrpc-3.0/lib/xmlrpc.inc");
                }
                self::$infusionsoft_connection->cfgCon($config->application_name, $config->private_key);
            } else {
                throw new Exception(sprintf(__('Could not establish a connection to Infusionsoft because Event Espresso Infusionsoft settings have not been set', 'event_espresso')));
            }
        }
        return self::$infusionsoft_connection;
    }



    /**
     * Returns whether or not this isdk response is an error or not
     *
     * @param string $response
     * @return boolean
     */
    public static function is_IS_error($response)
    {
        return (is_string($response) && strpos($response, EED_Infusionsoft::IS_error_response_prefix) === 0)
               || $response === '';
    }



    /**
     * Verifies the product with this ID actually exists in Infusionsoft
     *
     * @param int $product_id
     * @return boolean
     */
    public static function IS_product_exists($product_id)
    {
        $isdk = self::infusionsoft_connection();
        $response = $isdk->dsLoad('Product', $product_id, array('Id'));
        if (self::is_IS_error($response) || ! $response) {
            return false;
        } else {
            return true;
        }
    }



    /**
     * Same purpose as the IS RPC's addWithDupCheck except also verifies the first name
     * is a match; IS's RPC only checks the last name and email
     *
     * @param $contact_data
     * @return int Infusionsoft contact ID (regardless of whether it was newly inserted or existed previously)
     * @throws \EE_Error in any error in communication or usage
     */
    public static function addWithDupCheck($contact_data)
    {
        $isdk = EED_Infusionsoft::infusionsoft_connection();
        $query = array_intersect_key(
            $contact_data,
            array(
                'FirstName' => true,
                'LastName'  => true,
                'Email'     => true
            )
        );
        if (empty($query)) {
            throw new EE_Error(
                // @codingStandardsIgnoreStart
                esc_html__('Cannot search for a contact because no data provided, expected search data should contain FirstName, LastName, and Email. It was empty.', 'event_espresso')
                // @codingStandardsIgnoreEnd
            );
        }
        $matching_contacts = $isdk->dsQuery(
            'Contact',
            1,
            0,
            $query,
            array(
                'Id'
            )
        );
        if (EED_Infusionsoft::is_IS_error($matching_contacts)) {
            throw new EE_Error(
                sprintf(
                    // @codingStandardsIgnoreStart
                    esc_html__('Error encountered searching for a contact with data %1$s, the error was "%2$s"', 'event_espresso'),
                    // @codingStandardsIgnoreEnd
                    wp_json_encode($query),
                    $matching_contacts
                )
            );
        }
        if (! empty($matching_contacts)) {
            $first_contact = array_shift($matching_contacts);
            if (! isset($first_contact['Id'])) {
                throw new EE_Error(
                    sprintf(
                        // @codingStandardsIgnoreStart
                        esc_html__('The Infusionsoft Contact query was missing the contact\'s Id, the contact query repsonse was: %1$s', 'event_espresso'),
                        // @codingStandardsIgnoreEnd
                        wp_json_encode($matching_contacts)
                    )
                );
            }
            return (int) $first_contact['Id'];
        }
        // no existing contact, so let's add it
        $id = $isdk->addCon(
            $contact_data
        );
        if (EED_Infusionsoft::is_IS_error($matching_contacts)) {
            throw new EE_Error(
                sprintf(
                    // @codingStandardsIgnoreStart
                    esc_html__('Error encountered inserting a contact with data %1$s, the error was "%2$s"', 'event_espresso'),
                    // @codingStandardsIgnoreEnd
                    wp_json_encode($contact_data),
                    $id
                )
            );
        }
        return (int) $id;
    }
}
