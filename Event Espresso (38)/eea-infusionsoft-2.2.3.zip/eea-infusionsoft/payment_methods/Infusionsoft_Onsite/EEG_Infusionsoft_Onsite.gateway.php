<?php

/**
 * ----------------------------------------------
 *
 * Class  EEG_Infusionsoft_Onsite
 *
 * @package         Event Espresso
 * @subpackage      eea-infusionsoft-payments
 * @author          Event Espresso
 *
 *
 * ----------------------------------------------
 */
class EEG_Infusionsoft_Onsite extends EE_Onsite_Gateway
{

    /**
     * Infusionsoft Merchant Account ID.
     *  @var string
     */
    protected $_account_id = null;

    /**
     * All the currencies supported by this gateway.
     *  @var array
     */
    protected $_currencies_supported = EE_Gateway::all_currencies_supported;


    /**
     * Process the payment.
     *
     * @param EEI_Payment $payment
     * @param array  $billing_info
     * @return EE_Payment|EEI_Payment
     */
    public function do_direct_payment($payment, $billing_info = null)
    {
        $this->_log_clean_request($billing_info, $payment, 'Infusionsoft Billing Info');
        // Payment OK?
        if (! ($payment instanceof EEI_Payment)) {
            $payment->set_gateway_response(__('Error. No associated payment was found.', 'event_espresso'));
            $payment->set_status($this->_pay_model->failed_status());
            return $payment;
        }
        // Transaction OK?
        $transaction = $payment->transaction();
        if (! ($transaction instanceof EEI_Transaction)) {
            $payment->set_gateway_response(__('Could not process this payment because it has no associated transaction.', 'event_espresso'));
            $payment->set_status($this->_pay_model->failed_status());
            return $payment;
        }
        // Primary attendee OK?
        $primary_registration = $transaction->primary_registration();
        $primary_attendee = ( $primary_registration instanceof EEI_Registration ) ? $primary_registration->attendee() : false;
        if (! ($primary_attendee instanceof EE_Attendee)) {
            $payment->set_gateway_response(__('Could not process this payment because it has no associated Attendee.', 'event_espresso'));
            $payment->set_status($this->_pay_model->failed_status());
            return $payment;
        }

        // Get Infusionsoft connection.
        $eeg_infusionsoft = EED_Infusionsoft::infusionsoft_connection();

        // Allow the sync to IS.
        add_filter(
            'FHEE__EEE_Infusionsoft_Transaction__sync_to_infusionsoft__transaction_stati_to_sync_to_IS',
            array($this, 'allow_to_sync_to_IS'),
            10,
            2
        );

        // To make sure all the products (tickets) etc. are there.
        EED_Infusionsoft::sync_to_infusionsoft_now();

        // Add/update a contact.
        $contact_id = $primary_attendee->get_IS_contact_ID();
        if (! $contact_id) {
            $primary_attendee->sync_to_infusionsoft();
            $contact_id = $primary_attendee->get_IS_contact_ID();
        }
        // Was the contact created?
        if (EED_Infusionsoft::is_IS_error($contact_id) || ! is_numeric($contact_id)) {
            $this->_log_clean_request($contact_id, $payment, 'No Contact created');
            $payment->set_gateway_response(__('Could not create an Infusionsoft Contact.', 'event_espresso'));
            $payment->set_status($this->_pay_model->failed_status());
            return $payment;
        }

        // Retrieve the affiliate ID from the cookies, if it was ever set.
        if (isset($_COOKIE['EE_IS_AffId'])) {
            $af_id = $_COOKIE['EE_IS_AffId'];
        } else {
            $af_id = 0;
        }

        // Is this a payment retry for already created invoice (the same unfinished payment)?
        // Lats start with getting all payments for this transaction, if any.
        $new_invoice = true;
        $pmnts_args = array( 'order_by' => array( 'PAY_timestamp' => 'DESC' ) );
        $txn_payments = $transaction->payments($pmnts_args);
        if (is_array($txn_payments) && count($txn_payments) > 1) {
            // Trying to find a previously failed payment, if any.
            list($last_payment) = array_slice($txn_payments, 1, 1);
            if ($last_payment instanceof EEI_Payment) {
                $txn_inv_id = $last_payment->txn_id_chq_nmbr();
                if (isset($txn_inv_id) && ! empty($txn_inv_id)) {
                    $inv_amt_owned = $eeg_infusionsoft->amtOwed($txn_inv_id);
                    // If the AMTs match then this is the same unpaid invoice for sure.
                    // We don't want to create new invoices for each payment retry.
                    if (! EED_Infusionsoft::is_IS_error($inv_amt_owned) && is_numeric($inv_amt_owned) && EEH_Money::compare_floats($inv_amt_owned, $payment->amount(), '==')) {
                        $invoice_id = $txn_inv_id;
                        $new_invoice = false;
                    }
                }
            }
        }

        // New/first payment ?
        if ($new_invoice) {
            $order_description = htmlentities(wp_strip_all_tags($primary_registration->event()->name())) . ' [' . $primary_registration->event()->slug() . '][' . $primary_registration->reg_code().']';
            $invoice_id = $transaction->get_IS_invoice_ID();
            if (! $invoice_id) {
                $transaction->sync_to_infusionsoft();
                $invoice_id = $transaction->get_IS_invoice_ID();
            }
            // Was the invoice created?
            if (EED_Infusionsoft::is_IS_error($invoice_id) || ! is_numeric($invoice_id)) {
                $this->_log_clean_request($invoice_id, $payment, 'No Invoice created');
                $payment->set_gateway_response(__('Could not create an Infusionsoft invoice for this payment.', 'event_espresso'));
                $payment->set_status($this->_pay_model->failed_status());
                return $payment;
            }
            $payment->set_txn_id_chq_nmbr($invoice_id);
        }

        // Card already in Infusionsoft ? If not - add it.
        $cc_id = null;
        $Is_card = $eeg_infusionsoft->locateCard($contact_id, substr($billing_info['credit_card'], -4));
        if ($Is_card) {
            $cc_id = is_array($Is_card) ? $Is_card[0]['Id'] : $Is_card;
        }
        // Did we get a proper card id ?
        // If, by any chance, the id is not what we expect - try to process the payment as with a new card.
        $card_financial_data = array(
            'ContactId' => $contact_id,
            'CardType' => $billing_info['card_type'],
            'CardNumber' => $billing_info['credit_card'],
            'ExpirationMonth' => $billing_info['exp_month'],
            'ExpirationYear' => $billing_info['exp_year'],
            'CVV2' => $billing_info['card_cvv'],
            'NameOnCard' => $billing_info['name_on_card']
        );
        $card_address_data = array(
            'BillName'=> $billing_info['first_name'] . ' ' . $billing_info['last_name'],
            'BillAddress1'=> $billing_info['address'],
            'BillCity'=> $billing_info['city'],
            'BillState'=> $billing_info['state'],
            'BillCountry'=> $billing_info['country'],
            'BillZip'=> $billing_info['zip'],
            'FirstName'=> $billing_info['first_name'],
            'LastName'=> $billing_info['last_name'],
            'PhoneNumber' => $billing_info['phone']
        );
        $card_data = array_merge($card_financial_data, $card_address_data);
        if ($cc_id && is_numeric($cc_id)) {
            // IS has the card saved. Validate it.
            if ($this->_card_invalid_and_payment_updated($cc_id, $payment)) {
                return $payment;
            }
            // attempt to update the ticket
            $update_result = $eeg_infusionsoft->dsUpdate(
                'CreditCard',
                $cc_id,
                $card_data
            );
            if (EED_Infusionsoft::is_IS_error($update_result) || empty($update_result)) {
                $this->_log_clean_request(
                    array(
                        'credit_card_data' => $card_data,
                        'infusionsoft_credit_card_id' => $cc_id,
                        'infusionsoft_update_request_response' => $update_result
                    ),
                    $payment,
                    'Could not update infusionsoft credit card data'
                );
            }
        } else {
            // Validate this new card.
            if ($this->_card_invalid_and_payment_updated($card_financial_data, $payment)) {
                return $payment;
            }
            // Add the card to IS.
            $cc_id = $eeg_infusionsoft->dsAdd('CreditCard', $card_data);
        }

        // Charge the Invoice.
        $charge_cc = $eeg_infusionsoft->chargeInvoice(
            intval($invoice_id),
            sprintf(__('Payment of %s for %s', 'event_espresso'), $payment->amount(), $primary_registration->reg_code()),
            $cc_id,
            $this->_account_id,
            false   // Whether this payment should count towards affiliate commissions. Defaults to false.
        );
        // Charge Successful ?
        if (is_array($charge_cc) && $charge_cc['Successful'] && strtolower($charge_cc['Code']) == 'approved') {
            // Approved.
            $payment->set_status($this->_pay_model->approved_status());
            $payment->set_gateway_response($charge_cc['Code']);
            $payment->set_txn_id_chq_nmbr($charge_cc['RefNum']);
            $payment->set_details($billing_info);
            // Prevent a manual order creation.
            $payment->synced_to_infusionsoft();
        } elseif ($charge_cc['Code'] == 'DECLINED') {
            $this->_log_clean_request($charge_cc, $payment, 'Card Charge Declined');
            $payment->set_status($this->_pay_model->declined_status());
            $payment->set_gateway_response($charge_cc['Message']);
        } elseif ($charge_cc['Code'] == 'ERROR') {
            $this->_log_clean_request($charge_cc, $payment, 'Card Charge Error');
            $payment->set_status($this->_pay_model->failed_status());
            $payment->set_gateway_response($charge_cc['Message']);
        } elseif (is_array($charge_cc) && isset($charge_cc['Code'])) {
            $this->_log_clean_request($charge_cc, $payment, 'Card validation Error');
            $payment->set_status($this->_pay_model->declined_status());
            if (isset($charge_cc['Message'])) {
                $payment->set_gateway_response($charge_cc['Message']);
            }
        } else {
            $this->_log_clean_request($charge_cc, $payment, 'Card Charge unrecognized Error');
            $payment->set_status($this->_pay_model->failed_status());
            $payment->set_gateway_response(__('Card Charge request resulted in an unrecognized Error.', 'event_espresso'));
        }

        remove_filter('FHEE__EEE_Infusionsoft_Transaction__sync_to_infusionsoft__transaction_stati_to_sync_to_IS', array($this, 'allow_to_sync_to_IS'));

        return $payment;
    }



    /**
     * Checks with infusionsoft to see if the credit card data or ID is still valid.
     * If it isn't, logs it and updates the payment as failed
     * @param array|int $credit_card_data
     * @param EEI_Payment $payment
     * @return bool
     */
    protected function _card_invalid_and_payment_updated($credit_card_data, EEI_Payment $payment)
    {
        $eeg_infusionsoft = EED_Infusionsoft::infusionsoft_connection();
        $new_cc_valid = $eeg_infusionsoft->validateCard($credit_card_data);
        if (! is_array($new_cc_valid) || $new_cc_valid['Valid'] != true) {
            $this->_log_clean_request($new_cc_valid, $payment, 'Card Authorization/Validation Error');
            $payment->set_gateway_response(__('Card validation failed !', 'event_espresso'));
            $payment->set_status($this->_pay_model->declined_status());
            return true;
        }
        return false;
    }

    /**
     * Allow to sync to IS on an abandoned txn. status.
     *
     * @param array $transaction_status
     * @param EEI_Transaction $transaction
     * @return array
     */
    public function allow_to_sync_to_IS($transaction_status, $transaction)
    {
        array_push($transaction_status, EEM_Transaction::abandoned_status_code);
        return $transaction_status;
    }


    /**
     * CLeans out sensitive data and then logs it.
     *
     * @param array $data
     * @param EEI_Payment $payment
     * @param string $data_info
     * @return void
     */
    private function _log_clean_request($data, $payment, $data_info)
    {
        // The data has to be an array to be cleaned.
        if (is_array($data) && ! empty($data)) {
            $clean_data = $this->arrayCleanData($data);
        } else {
            $clean_data = $data;
        }
        $this->log(array($data_info => $clean_data), $payment);
    }


    /**
     * Clear out the provided sensitive data.
     *
     * @param array $data Data to be logged
     * @return array
     */
    private function arrayCleanData($data)
    {
        // Data keys to be removed.
        $sensitive_data = array(
            'credit_card',
            'exp_month',
            'exp_year',
            'card_cvv',
            'CardNumber',
            'ExpirationMonth',
            'ExpirationYear',
            'CVV2',
            'NameOnCard'
        );
        foreach ($data as $key => $value) {
            if (in_array($key, $sensitive_data)) {
                unset($data[ $key ]);
            } elseif (is_array($value) && ! empty($value)) {
                $data[ $key ] = $this->arrayCleanData($value);
            }
        }
        return $data;
    }
}
