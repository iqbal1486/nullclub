<?php
/**
 * ----------------------------------------------
 *
 * Class  EE_PMT_Infusionsoft_Onsite
 *
 * @package         Event Espresso
 * @subpackage      eea-infusionsoft-payments
 * @author          Event Espresso
 *
 *
 * ----------------------------------------------
 */
class EE_PMT_Infusionsoft_Onsite extends EE_PMT_Base
{

    /**
     * Class constructor.
     */
    public function __construct($pm_instance = null)
    {
        require_once(EE_INFUSIONSOFT_PATH . 'payment_methods' . DS . 'Infusionsoft_Onsite' . DS . 'EEG_Infusionsoft_Onsite.gateway.php');
        $this->_gateway = new EEG_Infusionsoft_Onsite();

        $this->_pretty_name = __('Infusionsoft', 'event_espresso');
        $this->_template_path = EE_INFUSIONSOFT_PATH . 'payment_methods' . DS . 'Infusionsoft_Onsite' . DS . 'templates' . DS;
        $this->_requires_https = true;

        parent::__construct($pm_instance);
    }


    /**
     * Adds the help tab.
     *
     * @see EE_PMT_Base::help_tabs_config()
     * @return array
     */
    public function help_tabs_config()
    {
        return array(
            $this->get_help_tab_name() => array(
                'title' => __('Infusionsoft Payments Settings', 'event_espresso'),
                'filename' => 'payment_methods_infusionsoft'
            )
        );
    }


    /**
     * Gets the form for all the settings related to this payment method.
     *
     * @return EE_Payment_Method_Form
     */
    public function generate_new_settings_form()
    {
        EE_Registry::instance()->load_helper('Template');

        $form = new EE_Infusionsoft_PM_Form($this);
        return $form;
    }


    /**
     *  Creates a billing form for this payment method type.
     *
     *  @param \EE_Transaction $transaction
     *  @return \EE_Billing_Info_Form
     */
    public function generate_new_billing_form(EE_Transaction $transaction = null)
    {
        $allowed_types = $this->_pm_instance->get_extra_meta('credit_card_types', true);
        // If allowed types is a string or empty array or null.
        if (empty($allowed_types)) {
            $allowed_types = array();
        }

        $form = new EE_Billing_Attendee_Info_Form(
            $this->_pm_instance,
            array(
                'name' => 'Infusionsoft_Payment_Info_Form',
                'subsections' => array(
                    'card_type' => new EE_Select_Input(
                        array_intersect_key(EE_PMT_Infusionsoft_Onsite::card_types_supported(), array_flip($allowed_types)),
                        array(
                            'html_class' => 'eea-infusionsoft-billing-form-card-cvv',
                            'html_label_text' => __('Card Type', 'event_espresso'),
                            'required' => true
                        )
                    ),
                    'name_on_card' => new EE_Text_Input(array(
                        'html_class' => 'eea-infusionsoft-billing-form-name-on-card',
                        'html_label_text' => __('Name On Card', 'event_espresso'),
                        'required' => true
                    )),
                    'credit_card' => new EE_Credit_Card_Input(array(
                        'html_class' => 'eea-infusionsoft-billing-form-credit-card',
                        'html_label_text' => __('Card Number', 'event_espresso'),
                        'required' => true
                    )),
                    'exp_month' => new EE_Credit_Card_Month_Input(true, array(
                        'html_class' => 'eea-infusionsoft-billing-form-exp-month',
                        'html_label_text' =>  __('Expiry Month', 'event_espresso'),
                        'required' => true
                    )),
                    'exp_year' => new EE_Credit_Card_Year_Input(array(
                        'html_class' => 'eea-infusionsoft-billing-form-exp-year',
                        'html_label_text' => __('Expiry Year', 'event_espresso'),
                        'required' => true
                    )),
                    'card_cvv' => new EE_CVV_Input(array(
                        'html_class' => 'eea-infusionsoft-billing-form-card-cvv',
                        'html_label_text' => __('CVV', 'event_espresso'),
                        'required' => true
                    )),
                )
            )
        );

        return $form;
    }



    /**
     * Allow other code to filter the biling info sent to Infusionsoft, because
     * different gateways setup with IS may have different requirements
     * @param EE_Billing_Info_Form $billing_form
     * @return mixed|void
     */
    protected function _get_billing_values_from_form($billing_form)
    {
        return apply_filters(
            'FHEE__EE_PMT_Infusionsoft_Onsite___get_billing_values_from_form',
            parent::_get_billing_values_from_form($billing_form),
            $billing_form,
            $this
        );
    }

    /**
     * Returns an array of all the payment cards possibly supported by Infusionsoft Payments.
     * Keys are their values, values are their pretty names.
     *
     * @return array
     */
    public static function card_types_supported()
    {
        return array(
            'Visa'=> __('Visa', 'event_espresso'),
            'MasterCard'=> __('MasterCard', 'event_espresso'),
            'Amex'=>  __("American Express", 'event_espresso'),
            'Discover'=> __('Discover', 'event_espresso')
        );
    }
}
