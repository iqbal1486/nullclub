<?php
/**
 * ----------------------------------------------
 *
 * Class  EE_Infusionsoft_PM_Form
 *
 * @package         Event Espresso
 * @subpackage      eea-infusionsoft-payments
 * @author          Event Espresso
 *
 *
 * ----------------------------------------------
 */
class EE_Infusionsoft_PM_Form extends EE_Payment_Method_Form
{


    /**
     *
     * @param EE_PMT_Infusionsoft_Onsite $payment_method_type
     */
    public function __construct(EE_PMT_Infusionsoft_Onsite $payment_method_type)
    {
        // API credentials already present ?
        $private_key = $application_name = '';
        $api_config = EE_Registry::instance()->addons->EE_Infusionsoft->config();
        if ($api_config instanceof EE_Config_Base && ! empty($api_config->application_name) && ! empty($api_config->private_key)) {
            $private_key = $api_config->private_key;
            $application_name = $api_config->application_name;
        }

        $form_params = array(
            'payment_method_type' => $payment_method_type,
            'extra_meta_inputs' => array(
                'account_id' => new EE_Text_Input(array(
                    'html_label_text' => sprintf(__('Merchant Account ID %s', 'event_espresso'), $payment_method_type->get_help_tab_link()),
                    'html_help_text' => __('Your Infusionsoft Merchant Account ID.', 'event_espresso'),
                    'required' => true
                )),
                'credit_card_types' => new EE_Checkbox_Multi_Input($payment_method_type->card_types_supported(), array(
                    'html_label_text' => __('Card Types Supported', 'event_espresso'),
                    'required' => true
                ))
            ),
            'exclude' => array( 'PMD_debug_mode' )
        );

        parent::__construct($form_params);

        // IS creds. present ? If so, do not display the IS link.
        $is_connection = $this->test_is_connection();
        if ($is_connection == false) {
            $this->add_subsections(array(
                'is_settings_link' => new EE_Form_Section_HTML(
                    EEH_HTML::table(
                        EEH_HTML::tr(
                            EEH_HTML::th(
                                EEH_HTML::label(
                                    EEH_HTML::strong(__('IMPORTANT', 'event_espresso'), '', 'important-notice')
                                )
                            ) .
                            EEH_HTML::td(
                                EEH_HTML::strong(sprintf(
                                    // @codingStandardsIgnoreStart
                                    __('Don\'t forget to visit the %1$sInfusionsoft settings page%2$s to provide your application name and private key.', 'event_espresso'),
                                    // @codingStandardsIgnoreEnd
                                    '<a href="admin.php?page=espresso_infusionsoft">',
                                    '</a>'
                                ))
                            )
                        )
                    )
                )
            ));
        }
    }


    /**
     * Check the API Key and App ID.
     * Add an admin notification if the connection with these credentials was unsuccessful.
     *
     * @return void
     */
    protected function _validate()
    {
        parent::_validate();

        // IS connection OK ?
        $is_connection = $this->test_is_connection();
        if ($is_connection == false) {
            EE_Error::add_error(sprintf(__('Missing some Infusionsoft configuration. Please visit the %1$sInfusionsoft settings page%2$s and provide your application name and private key.', 'event_espresso'), '<a href="admin.php?page=espresso_infusionsoft">', '</a>'), __FILE__, __FUNCTION__, __LINE__);
        } elseif ($is_connection instanceof Exception) {
            EE_Error::add_error(sprintf(__('Error connecting to Infusionsoft: %1$s. Please double-check your %2$s application name and private key%3$s.', 'event_espresso'), $is_connection->getMessage(), '<a href="admin.php?page=espresso_infusionsoft">', '</a>'), __FILE__, __FUNCTION__, __LINE__);
        }
    }


    /**
     * Test IS credentials.
     *
     * @return mixed
     */
    public function test_is_connection()
    {
        $api_config = EE_Registry::instance()->addons->EE_Infusionsoft->config();
        $is_connect = true;

        // Test the credentials.
        if (! ($api_config instanceof EE_Config_Base) || empty($api_config->application_name) || empty($api_config->private_key)) {
            $is_connect = false;
        } else {
            try {
                EED_Infusionsoft::infusionsoft_connection(true);
            } catch (Exception $e) {
                $is_connect = $e;
            }
        }

        return $is_connect;
    }
}
