<p>
    <strong><?php _e('Infusionsoft Payments', 'event_espresso'); ?></strong>
</p>
<p>
    <?php _e('Adjust the settings for the Infusionsoft Payments.', 'event_espresso'); ?>
</p>
<p>
    <a target="_blank" href="https://eventespresso.com/gostandard/"><?php _e('Click here to sign up for an account with', 'event_espresso'); ?></a>
</p>

<p>
    <strong><?php _e('Infusionsoft Payments Settings', 'event_espresso'); ?></strong>
</p>
<ul>
    <li>
        <strong><?php _e('Merchant Account ID', 'event_espresso'); ?></strong><br/>
        <?php _e('Your Infusionsoft Merchant Account ID.', 'event_espresso'); ?><br/>
        <?php printf(
            __('Where to find your Merchant Account ID ? More information can be found on our %1$sInfusionsoft Integration%2$s documentation page, under the %3$s"Finding the Merchant ID within Infusionsoft"%4$s section.', 'event_espresso'),
            '<a target="_blank" href="https://eventespresso.com/wiki/infusionsoft-integration/#installinfusionsoftee3">',
            '</a>',
            '<strong>',
            '</strong>'
        ); ?>
    </li>
    <li>
        <strong><?php _e('Card Types Supported', 'event_espresso'); ?></strong><br/>
        <?php _e('Select card types that should be allowed for the checkout.', 'event_espresso'); ?>
    </li>
</ul>

<p>
    <?php printf(__('%1$sClick here%2$s for more information on how to setup Infusionsoft Payments on your account.', 'event_espresso'), '<a target="_blank" href="http://help.infusionsoft.com/userguides/sell-online/merchant-accounts/infusionsoft-payments-setup-guide">', '</a>'); ?>
</p>
<p>
    <?php printf(__('For testing please use a Merchant Account with Test mode enabled. %1$sClick here%2$s for more information.', 'event_espresso'), '<a target="_blank" href="http://help.infusionsoft.com/userguides/get-started/tips-and-tricks/how-to-test-just-about-anything">', '</a>'); ?>
</p>