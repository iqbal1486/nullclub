# Event Espresso Infusionsoft Changelog

All notable changes to this project will be documented in this file.

The format of this file is based on [Keep a Changelog](http://keepachangelog.com/en/1.0.0/)

Headings should be (only add headings as needed):

- Added (new features)
- Changed (changes in existing functionality)
- Deprecated (soon to be removed features)
- Removed (removed features)
- Fixed (bug fixes)
- Security (vulnerability fixes)

See [our documentation](https://github.com/eventespresso/event-espresso-core/blob/master/docs/A--Best-Practices/change-log.md) for more details.

## [$VID:$]

## [2.2.3.p]

## [2.2.2.p]

### Fixed
- Fixed integration so Infusionsoft triggers purchase actions even on free transactions ([11](https://github.com/eventespresso/ee4-infusionsoft/pull/11))
