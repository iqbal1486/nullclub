<?php


// define the plugin directory path and URL
define('EE_INFUSIONSOFT_PATH', plugin_dir_path(__FILE__));
define('EE_INFUSIONSOFT_URL', plugin_dir_url(__FILE__));
define('EE_INFUSIONSOFT_ADMIN', EE_INFUSIONSOFT_PATH . 'admin' . DS . 'infusionsoft' . DS);

/**
 * Class  EE_Infusionsoft
 *
 * @package     Event Espresso
 * @subpackage  espresso-new-addon
 * @author      Brent Christensen
 * @version    2.0.0.p
 */
class EE_Infusionsoft extends EE_Addon
{

    public static function deregister_addon()
    {
        EE_Register_Addon::deregister('Infusionsoft');
    }


    public static function register_addon()
    {
        // register addon via Plugin API
        EE_Register_Addon::register(
            'Infusionsoft',
            array(
                'version'          => EE_INFUSIONSOFT_VERSION,
                'min_core_version' => EE_INFUSIONSOFT_CORE_VERSION_REQUIRED,
                'main_file_path'   => EE_INFUSIONSOFT_PLUGIN_FILE,
                'admin_path'       => EE_INFUSIONSOFT_ADMIN,
                'admin_callback'   => 'additional_admin_hooks',
                'config_class'     => 'EE_Infusionsoft_Config',
                'config_name'      => 'EE_Infusionsoft',
                'autoloader_paths' => array(
                    'EE_PMT_Infusionsoft_Onsite'        => EE_INFUSIONSOFT_PATH . 'payment_methods' . DS . 'Infusionsoft_Onsite'
                                                        . DS . 'EE_PMT_Infusionsoft_Onsite.pm.php',
                    'EE_Infusionsoft'                   => EE_INFUSIONSOFT_PATH . 'EE_Infusionsoft.class.php',
                    'EE_Infusionsoft_Config'            => EE_INFUSIONSOFT_PATH . 'EE_Infusionsoft_Config.php',
                    'Infusionsoft_Admin_Page'           => EE_INFUSIONSOFT_ADMIN . 'Infusionsoft_Admin_Page.core.php',
                    'Infusionsoft_Admin_Page_Init'      => EE_INFUSIONSOFT_ADMIN . 'Infusionsoft_Admin_Page_Init.core.php',
                    'EEH_Infusionsoft_Product_Category' => EE_INFUSIONSOFT_PATH . 'core' . DS . 'helpers'
                                                           . DS . 'EEH_Infusionsoft_Product_Category.helper.php',
                    // Infusionsoft Payments
                    'EE_Infusionsoft_PM_Form' => EE_INFUSIONSOFT_PATH . 'payment_methods' . DS . 'Infusionsoft_Onsite'
                                                 . DS . 'EE_Infusionsoft_PM_Form.form.php'
                ),
            //              'dms_paths'             => array( EE_INFUSIONSOFT_PATH . 'core' . DS . 'data_migration_scripts' . DS ),
                'module_paths'     => array(
                    EE_INFUSIONSOFT_PATH . 'EED_Infusionsoft.module.php',
                    EE_INFUSIONSOFT_PATH . 'EED_Infusionsoft_Promotions_Integration.module.php'),
                'payment_method_paths' => array(
                    EE_INFUSIONSOFT_PATH . 'payment_methods' . DS . 'Infusionsoft_Onsite'
                ),
                'namespace' => array(
                    'FQNS' => 'EventEspresso\Infusionsoft',
                    'DIR' => __DIR__
                ),
                // if plugin update engine is being used for auto-updates. not needed if PUE is not being used.
                'pue_options'      => array(
                    'pue_plugin_slug' => 'eea-infusionsoft',
                    'plugin_basename' => EE_INFUSIONSOFT_BASE_NAME,
                    'checkPeriod'     => '24',
                    'use_wp_update'   => false
                ),
                'privacy_policies' => array(
                    'EventEspresso\Infusionsoft\core\domain\services\admin\privacy\policy\PrivacyPolicy'
                )
            )
        );
        if (! did_action('activate_plugin')) {
            EE_Register_Model_Extensions::register('Infusionsoft', array(
                'class_extension_paths' => array(
                    EE_INFUSIONSOFT_PATH . 'core' . DS . 'db_class_extensions',
                )
            ));
        }
    }


    /**
     * a safe space for addons to add additional logic like setting hooks
     * that will run immediately after addon registration
     * making this a great place for code that needs to be "omnipresent"
     * !!! IMPORTANT !!! REQUIRES MIN CORE VERSION 4.9.26
     */
    // public function after_registration()
    // {
    // }



    /**
     *  additional_admin_hooks
     *
     *  @access     public
     *  @return     void
     */
    public function additional_admin_hooks()
    {
        // is admin and not in M-Mode ?
        if (is_admin() && ! EE_Maintenance_Mode::instance()->level()) {
            add_filter('plugin_action_links', array( $this, 'plugin_actions' ), 10, 2);
        }
    }



    /**
     * plugin_actions
     *
     * Add a settings link to the Plugins page, so people can go straight from the plugin page to the settings page.
     * @param $links
     * @param $file
     * @return array
     */
    public function plugin_actions($links, $file)
    {
        if ($file === EE_INFUSIONSOFT_BASE_NAME) {
            // before other links
            array_unshift($links, '<a href="admin.php?page=espresso_infusionsoft">' . __('Settings', 'event_espresso') . '</a>');
        }
        return $links;
    }
}
