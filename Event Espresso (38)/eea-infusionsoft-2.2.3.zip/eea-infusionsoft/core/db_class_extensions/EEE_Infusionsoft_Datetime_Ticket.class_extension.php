<?php

/**
 *
 * EEE_Infusionsoft_Datetime_Ticket
 *
 * @package         Event Espresso
 * @subpackage
 * @author              Mike Nelson
 *
 */
class EEE_Infusionsoft_Datetime_Ticket extends EEE_Base_Class
{

    public function __construct()
    {
        $this->_model_name_extended = 'Datetime_Ticket';
        parent::__construct();
    }
    public function ext_sync_to_infusionsoft()
    {
        if (! $this->_->ID()  || EED_Infusionsoft::synced_on_this_request($this->_)) {
            return false;
        }
        // this might have added a relation between a ticket and a datetime, thus
        // allowing us to sync that ticket. so let's try it
        $ticket = $this->_->get_first_related('Ticket');
        if ($ticket instanceof EE_Ticket) {
            $ticket->sync_to_infusionsoft();
        }
        EED_Infusionsoft::mark_model_obj_synced($this->_);
    }
}
