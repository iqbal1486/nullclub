<?php

/**
 *
 * EEE_Infusionsoft_Attendee
 *
 * @package         Event Espresso
 * @subpackage
 * @author              Mike Nelson
 *
 */
class EEE_Infusionsoft_Transaction extends EEE_Base_Class
{

    public function __construct()
    {
        $this->_model_name_extended = 'Transaction';
        parent::__construct();
    }
    const extra_meta_IS_invoice_ID = 'IS_invoice_ID';

    /**
     * The model object being extended on each function call
     * @var EE_Transaction $_
     */
    protected $_;
    public function ext_sync_to_infusionsoft()
    {
        try {
            // this transaction needs an ID before it can be sync'd to IS

            if (! $this->_->ID() || EED_Infusionsoft::synced_on_this_request($this->_)) {
                return false;
            }
            $primary_reg = $this->_->primary_registration();
            if (! $primary_reg instanceof EE_Registration ||
                    ( $primary_reg instanceof EE_Registration && ! $primary_reg->reg_code() ) ) {
                // no primary registration on this transaction (at least yet)
                // or they don't yet have a reg code. hmph!
                return false;
            }
            $attendee = $primary_reg ->attendee();
            if (! $attendee instanceof EE_Attendee) {
                return false;
            }
            $IS_contact_ID = $attendee->get_IS_contact_ID();
            if (! $IS_contact_ID) {
                $attendee->sync_to_infusionsoft();
            }
            if (! $IS_contact_ID) {
                return false;
            }
            if ($this->_->get_IS_invoice_ID()) {
                // previously sync'd to IS
                $newly_synced = false;
                // bah forget about it then. I don't think we have anything new to send to IS
                return true;
            } else {
                // this will be a new sync
                $newly_synced = true;
            }

            // Retrieve the affiliate id in the cookie, if it were ever set
            if (isset($_COOKIE['EE_IS_AffId'])) {
                $aid = $_COOKIE['EE_IS_AffId'];
            } else {
                $aid = 0;
            }
            
            // wait don't sync while the order is still in flux (because we can't
            // easily change the IS order after we've sent it)
            if (! in_array(
                $this->_->status_ID(),
                apply_filters(
                    'FHEE__EEE_Infusionsoft_Transaction__sync_to_infusionsoft__transaction_stati_to_sync_to_IS',
                    array( EEM_Transaction::complete_status_code, EEM_Transaction::incomplete_status_code ),
                    $this->_
                )
            )
            ) {
                return false;
            }

            $ee_infusionsoft = EED_Infusionsoft::infusionsoft_connection();
            // Creates an invoice in the Infusionsoft system
            $order_name =  htmlentities(wp_strip_all_tags($primary_reg->event()->name())) . ' [' . $primary_reg->event()->slug() . '][' . $primary_reg->reg_code().']';
            $invoiceId = $ee_infusionsoft->blankOrder($IS_contact_ID, $order_name, date(EED_Infusionsoft::IS_datetime_format, time()), $aid, $aid);
            if (EED_Infusionsoft::is_IS_error($invoiceId)) {
                EE_Log::instance()->log(
                    __FILE__,
                    __FUNCTION__,
                    sprintf(
                        __('Infusionsoft error. Could not create blank order for contact %1$s, with name %2$s for transaction %3$s. Error was %4$s', 'event_espresso'),
                        $IS_contact_ID,
                        $order_name,
                        $this->_->ID(),
                        $invoiceId
                    ),
                    'infusionsoft'
                );
                return false;
            }
            $this->_->set_IS_invoice_ID($invoiceId);
            // and there are a few other fields we would like to set on the order
            $invoice = $ee_infusionsoft->dsLoad('Invoice', $invoiceId, array( 'JobId' ));
            if (EED_Infusionsoft::is_IS_error($invoice)) {
                EE_Log::instance()->log(
                    __FILE__,
                    __FUNCTION__,
                    sprintf(
                        __('Infusionsoft error. Could not load invoice with ID %1$s, for transaction %2$s. Error was %3$s', 'event_espresso'),
                        $invoiceId,
                        $this->_->ID(),
                        $invoice
                    ),
                    'infusionsoft'
                );
                return false;
            }
            $updated_order = $ee_infusionsoft->dsUpdate('Job', $invoice['JobId'], array( 'OrderType' => 'Online' ));
            if (EED_Infusionsoft::is_IS_error($updated_order)) {
                EE_Log::instance()->log(
                    __FILE__,
                    __FUNCTION__,
                    sprintf(
                        __('Infusionsoft error. Could not update job with ID %1$s, for transaction %2$s. Error was %3$s', 'event_espresso'),
                        $invoice['JobId'],
                        $this->_->ID(),
                        $updated_order
                    ),
                    'infusionsoft'
                );
            }
            // it's possible that the line items for this invoice haven't been sync'd yet, so let's double check that
            foreach ($this->_->line_items() as $line_item) {
                $line_item->sync_to_infusionsoft();
            }
            // if this is a free order, we still want to send a "payment" to Infusionsoft
            // otherwise its automated actions won't be triggered.
            // See https://github.com/eventespresso/ee4-infusionsoft/issues/10
            if (EEH_Money::compare_floats($this->_->total(), 0)) {
                $zero_dollar_payment = $ee_infusionsoft->manualPmt(
                    (int) $invoiceId, // invoiceid
                    (float) 0, // amount
                    date(EED_Infusionsoft::IS_datetime_format, $this->_->get_raw('TXN_timestamp')), // paydate
                    esc_html__('Event Espresso', 'event_espresso'), // paytype
                    __('Automatically added by Event Espresso', 'event_espresso'), // paydesc
                    true // bypasscommission
                );
                if (EED_Infusionsoft::is_IS_error($zero_dollar_payment)) {
                    EE_Log::instance()->log(
                        __FILE__,
                        __FUNCTION__,
                        sprintf(
                            __('Infusionsoft error. Could not create "zero-dollar payment" for free order with ID %1$s, for transaction %2$s. Error was %3$s', 'event_espresso'),
                            $invoice['JobId'],
                            $this->_->ID(),
                            $zero_dollar_payment
                        ),
                        'infusionsoft'
                    );
                }
            }
            /**
             * Action performed after syncing an EE Tranaction to an IS invoice successfully
             *
             * @param EE_Attendee $attendee
             * @param string $IS_contact_ID the ID of the IS contact in IS
             * @param boolean $newly_synced whether we just sync'd for the first time or not
             */
            do_action('AHEE__EEE_Infusionsoft_Transaction__sync_to_infusionsoft__end', $this->_, $invoiceId, $newly_synced);
        } catch (Exception $e) {
            EE_Log::instance()->log(
                __FILE__,
                __FUNCTION__,
                sprintf(
                    __('Exception thrown! Could not sync Event Espresso Transaction (%1$s) to Infusionsoft Order because: %2$s', 'event_espresso'),
                    $this->_->ID(),
                    $e->getMessage() . $e->getTraceAsString()
                ),
                'infusionsoft'
            );
        }
        EED_Infusionsoft::mark_model_obj_synced($this->_);
    }

    public function ext_get_IS_invoice_ID()
    {
        $IS_invoice_ID_string = $this->_->get_extra_meta(self::extra_meta_IS_invoice_ID, true);
        // echo '|~ '. $IS_invoice_ID_string .' ~|';
        if ($IS_invoice_ID_string !== null) {
            return (int) $IS_invoice_ID_string;
        } else {
            return null;
        }
    }
    public function ext_set_IS_invoice_ID($new_id)
    {
        $this->_->update_extra_meta(self::extra_meta_IS_invoice_ID, $new_id);
    }
}
