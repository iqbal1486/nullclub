<?php

/**
 * EEE_Infusionsoft_Event
 *
 * @package               Event Espresso
 * @subpackage
 * @author                Mike Nelson
 */
class EEE_Infusionsoft_Question_Option extends EEE_Base_Class
{
    const extra_meta_IS_tag_id = 'IS_tag_id';

    public function __construct()
    {
        $this->_model_name_extended = 'Question_Option';
        parent::__construct();
    }



    /**
     * Gets the IS tag ID
     *
     * @return int
     */
    public function ext_get_IS_tag_IDs()
    {
        return $this->_->get_extra_meta(
            EEE_Infusionsoft_Question_Option::extra_meta_IS_tag_id,
            false,
            array()
        );
    }



    /**
     * Saves the IS tag ID for the question option
     *
     * @param string $IS_tag_IDs
     */
    public function ext_set_IS_tag_IDs($IS_tag_IDs)
    {
        $IS_tag_IDs = (array) $IS_tag_IDs;
        $normalized_IS_tag_IDs = array();
        foreach ($IS_tag_IDs as $IS_tag_ID) {
            $normalized_IS_tag_IDs[] = (string) $IS_tag_ID;
        }
        // if they're the same, don't bother changing anything
        $existing_tags = array_values($this->ext_get_IS_tag_IDs());
        if ($normalized_IS_tag_IDs === $existing_tags) {
            return true;
        }
        $this->_->delete_extra_meta(EEE_Infusionsoft_Question_Option::extra_meta_IS_tag_id);
        foreach ($normalized_IS_tag_IDs as $submitted_tag_ID) {
            $this->_->add_extra_meta(
                EEE_Infusionsoft_Question_Option::extra_meta_IS_tag_id,
                $submitted_tag_ID
            );
        }
    }
}
