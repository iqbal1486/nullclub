<?php

/**
 *
 * EEE_Infusionsoft_Payment
 *
 * Syncs new line items to IS after sync'ing their transaction to an order
 *
 * @package         Event Espresso
 * @subpackage
 * @author              Mike Nelson
 *
 */
class EEE_Infusionsoft_Payment extends EEE_Base_Class
{
    /**
     *
     * @var EE_Payment
     */
    protected $_;
    public function __construct()
    {
        $this->_model_name_extended = 'Payment';
        parent::__construct();
    }
    const extra_meta_synced_to_IS = 'synced_to_IS';

    /**
     * Gets the synced-to-IS status of this line item
     * @return boolean
     */
    public function ext_synced_to_infusionsoft()
    {
        return $this->_->get_extra_meta(self::extra_meta_synced_to_IS, true, false);
    }
    /**
     * Sets teh synced-to-IS status of this line item
     * @param boolean $synced_status
     * @return boolean success
     */
    public function ext_set_synced_to_infusionsoft($synced_status = true)
    {
        return $this->_->update_extra_meta(self::extra_meta_synced_to_IS, $synced_status);
    }
    public function ext_sync_to_infusionsoft()
    {
        try {
            // only sync attendees actually in the DB
            $transaction = $this->_->transaction();
            if (! $this->_->ID()
                || EED_Infusionsoft::synced_on_this_request($this->_)
                || ! $transaction instanceof EE_Transaction
            ) {
                return false;
            }
            // make sure the transaction is already sync'ed. Otherwise, there is no IS order
            // to attribute the IS payment to
            $transaction->sync_to_infusionsoft();
            // if already sent to IS, or if it'sn ot approved, don't change it
            if ($this->_->synced_to_infusionsoft() || ! $this->_->is_approved()) {
                return true;
            }
            // get the IS invoice ID from the transaction
            $invoice_id = $transaction->get_IS_invoice_ID();
            // only sync this payment to IS if we know which invoice its for
            if (! $invoice_id) {
                return false;
            }
            $isdk = EED_Infusionsoft::infusionsoft_connection();
            if (version_compare(espresso_version(), '4.6.0.dev', '<')) {
                $description = $this->_->gateway();
            } else {
                $description = $this->_->payment_method() ? $this->_->payment_method()->admin_name() : __('Unknown', 'event_espresso');
            }
            $success = $isdk->manualPmt(
                $invoice_id, // invoiceid
                $this->_->amount(), // amount
                date(EED_Infusionsoft::IS_datetime_format, $this->_->get_raw('PAY_timestamp')), // paydate
                $description, // paytype
                __('Automatically added by Event Espresso', 'event_espresso'), // paydesc
                false // bypasscommission
            );
            if ($success) {
                $this->_->set_synced_to_infusionsoft(true);
            } else {
                EE_Log::instance()->log(
                    __FILE__,
                    __FUNCTION__,
                    sprintf(
                        __('Could not sync payment %1$s for invoice_id %2$s. Infusionsoft error was %3$s', 'event_espresso'),
                        $this->_->ID(),
                        $invoice_id,
                        $success
                    ),
                    'infusionsoft'
                );
            }

            /**
             * Action performed after syncing an EE Payment to an IS payment successfully
             *
             * @param EE_Payment $line_item
             * @param boolean $newly_synced whether we just sync'd for the first time or not (for now, by default
             * this is always true because we only sync line items once; we never update them)
             */
            do_action('AHEE__EEE_Infusionsoft_Payment__sync_to_infusionsoft__end', $this->_, true);
        } catch (Exception $e) {
            EE_Log::instance()->log(
                __FILE__,
                __FUNCTION__,
                sprintf(
                    __('Exception thrown! Could not sync Event Espresso Payment (%1$s) to Infusionsoft Payment because: %2$s', 'event_espresso'),
                    $this->_->ID(),
                    $e->getMessage() . $e->getTraceAsString()
                ),
                'infusionsoft'
            );
        }
    }
}
