<?php

/**
 * EEE_Infusionsoft_Event
 *
 * @package               Event Espresso
 * @subpackage
 * @author                Mike Nelson
 */
class EEE_Infusionsoft_Event extends EEE_Base_Class
{

    const post_meta_IS_tags = '_IS_tag_id';

    public function __construct()
    {
        $this->_model_name_extended = 'Event';
        parent::__construct();
    }



    public function ext_sync_to_infusionsoft()
    {
        if (! $this->_->ID() || EED_Infusionsoft::synced_on_this_request($this->_)) {
            return false;
        }
        // this might have added a relation between a ticket and a datetime, thus
        // allowing us to sync that ticket. so let's try it
        $tickets = EE_Registry::instance()->load_model('Ticket')->get_all(array(array('Datetime.EVT_ID' => $this->_->ID())));
        foreach ($tickets as $ticket) {
            $ticket->sync_to_infusionsoft();
        }
        EED_Infusionsoft::mark_model_obj_synced($this->_);
    }


    /**
     * Gets the IS tags for associated with this event
     * (speciically, the tags to asign to IS contacts when they
     * register for this event)
     *
     * @return string
     */
    public function ext_get_IS_tag_IDs()
    {
        return $this->_->get_extra_meta(
            EEE_Infusionsoft_Event::post_meta_IS_tags,
            false,
            array()
        );
    }


    /**
     * Saves the IS tags for this event
     *
     * @param string $IS_tag_IDs
     */
    public function ext_set_IS_tag_IDs($IS_tag_IDs)
    {
        $IS_tag_IDs = (array) $IS_tag_IDs;
        $normalized_IS_tag_IDs = array();
        foreach ($IS_tag_IDs as $IS_tag_ID) {
            if (! empty($IS_tag_ID)) {
                $normalized_IS_tag_IDs[] = (string) $IS_tag_ID;
            }
        }
        // if they're the same, don't bother changing anything
        $existing_tags = array_values($this->ext_get_IS_tag_IDs());
        if ($normalized_IS_tag_IDs === $existing_tags) {
            return true;
        }
        $this->_->delete_extra_meta(EEE_Infusionsoft_Event::post_meta_IS_tags);
        foreach ($normalized_IS_tag_IDs as $submitted_tag_ID) {
            $this->_->add_extra_meta(
                EEE_Infusionsoft_Event::post_meta_IS_tags,
                $submitted_tag_ID
            );
        }
    }
}
