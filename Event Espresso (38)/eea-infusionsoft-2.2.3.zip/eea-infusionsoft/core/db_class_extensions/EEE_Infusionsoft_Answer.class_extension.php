<?php

/**
 *
 * EEE_Infusionsoft_Event
 *
 * @package         Event Espresso
 * @subpackage
 * @author              Mike Nelson
 *
 */
class EEE_Infusionsoft_Answer extends EEE_Base_Class
{

    public function __construct()
    {
        $this->_model_name_extended = 'Answer';
        parent::__construct();
    }
    public function ext_sync_to_infusionsoft()
    {
        if (! $this->_->ID()  || EED_Infusionsoft::synced_on_this_request($this->_)) {
            return false;
        }
        // we may want to re-sync the registratin and attendee
        $reg = $this->_->get_first_related('Registration');
        if ($reg instanceof EE_Registration) {
            $reg->sync_to_infusionsoft();
        }
        EED_Infusionsoft::mark_model_obj_synced($this->_);
    }
}
