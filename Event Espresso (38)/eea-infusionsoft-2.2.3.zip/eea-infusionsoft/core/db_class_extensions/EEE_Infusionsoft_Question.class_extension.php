<?php

/**
 * EEE_Infusionsoft_Event
 *
 * @package               Event Espresso
 * @subpackage
 * @author                Mike Nelson
 */
class EEE_Infusionsoft_Question extends EEE_Base_Class
{
    const extra_meta_IS_field_name = 'IS_field_name';

    public function __construct()
    {
        $this->_model_name_extended = 'Question';
        parent::__construct();
    }



    /**
     * Gets the IS field name
     *
     * @return string
     */
    public function ext_get_IS_field_name()
    {
        return $this->_->get_extra_meta(
            EEE_Infusionsoft_Question::extra_meta_IS_field_name,
            true,
            ''
        );
    }



    /**
     * Gets the IS field's DB name. See https://help.infusionsoft.com/userguides/get-started/create-custom-fields/backend-database-names-for-custom-fields
     *
     * @return string
     */
    public function ext_get_IS_field_db_name()
    {
        return '_'
            . $this->ext_get_IS_field_name();
    }



    /**
     * Saves the IS custom field's name
     *
     * @param string $IS_custom_field_name
     */
    public function ext_set_IS_field_name($IS_custom_field_name)
    {
        $this->_->update_extra_meta(
            EEE_Infusionsoft_Question::extra_meta_IS_field_name,
            $IS_custom_field_name
        );
    }
}
