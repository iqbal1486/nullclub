<?php

use EventEspresso\Infusionsoft\core\domain\InfusionsoftOrderItemProperties;

/**
 * EEE_Infusionsoft_Line_Item
 * Syncs new line items to IS after sync'ing their transaction to an order
 *
 * @package               Event Espresso
 * @subpackage
 * @author                Mike Nelson
 */
class EEE_Infusionsoft_Line_Item extends EEE_Base_Class
{

    /**
     * @var EE_Line_Item
     */
    protected $_;



    public function __construct()
    {
        $this->_model_name_extended = 'Line_Item';
        parent::__construct();
    }



    /**
     * The name of the extra meta key that used to store whether or not the line item was
     * already sync'ed to IS. But since 2.1.7.rc.005 we no longer use this for storing
     * whether or not a line item was sync'ed to IS; instead we're using a different
     * extra meta key to store the order item's ID
     */
    const extra_meta_synced_to_IS    = 'synced_to_IS';

    const extra_meta_IS_line_item_ID = 'IS_order_item_ID';

    const IS_product_type            = 4;

    /**
     * We don't want to add taxes to IS as "tax type" because if someone clicks to
     * "recalculate tax" in IS, this tax item will be removed and be replaced
     * with the taxes as calculated by IS. But in order for EE and IS to remain in sync
     * we need to use EE's tax decisions.
     * So we record these as "other" too
     */
    const IS_tax_type  = 16;

    const IS_misc_type = 3;



    /**
     * Gets the synced-to-IS status of this line item
     *
     * @return boolean
     * @throws \EE_Error
     * @deprecated We used to only record whether or not the line item was synced to infusionsoft,
     *             but since 2.1.7.rc.005 we record its IS order ID instead
     */
    public function ext_synced_to_infusionsoft()
    {
        return $this->_->get_extra_meta(self::extra_meta_synced_to_IS, true, false);
    }



    /**
     * Sets the synced-to-IS status of this line item
     *
     * @param boolean $synced_status
     * @return boolean success
     * @throws \EE_Error
     * @deprecated We used to only record whether or not the line item was synced to infusionsoft,
     *             but since 2.1.7.rc.005 we record its IS order ID instead
     */
    public function ext_set_synced_to_infusionsoft($synced_status = true)
    {
        return $this->_->update_extra_meta(self::extra_meta_synced_to_IS, $synced_status);
    }



    /**
     * Sets the synced-to-IS status of this line item
     *
     * @return boolean success
     * @throws \EE_Error
     */
    public function ext_synced_to_infusionsoft_without_IS_order_ID()
    {
        return $this->_->get_extra_meta(self::extra_meta_synced_to_IS, true, false);
    }



    /**
     * Sets the order item ID on the EE object (using extra meta)
     *
     * @param $new_id
     * @throws \EE_Error
     */
    public function ext_set_IS_order_item_ID($new_id)
    {
        $this->_->update_extra_meta(self::extra_meta_IS_line_item_ID, $new_id);
    }



    /**
     * Syncs normal and tax line items to Infusionsoft as "Order items" and "Invoice Items"
     * (but not totals, sub-totals, or sub-items).
     * First verifies the EE transaction was sync'd to IS as an order.
     * Records the IS Order Item ID so it can be updated later.
     *
     * @return bool true if the EE line item is sync'd to an IS order item and invoice item
     * @throws \EE_Error
     */
    public function ext_sync_to_infusionsoft()
    {
        try {
            // only sync new line items
            if (EED_Infusionsoft::synced_on_this_request($this->_)) {
                return true;
            }
            // if we didn't bother to record an order item ID, but we did record that it was synced
            // (behaviour before 2.1.7.rc.005) don't sync it again.
            if ($this->_->synced_to_infusionsoft()) {
                return true;
            }
            if (in_array(
                $this->_->type(),
                array(
                    EEM_Line_Item::type_line_item,
                    EEM_Line_Item::type_tax,
                ),
                true
            )) {
                $txn_invoice_id = $this->_->transaction() ? $this->_->transaction()->get_IS_invoice_ID() : null;
                if (! $txn_invoice_id) {
                    return false;
                }
                if ($this->_->type() === EEM_Line_Item::type_line_item) {
                    // line item is for a ticket or maybe something else
                    if ($this->_->OBJ_type() === 'Ticket') {
                        $tkt_product_id = $this->_->ticket() ? $this->_->ticket()->get_IS_product_ID(true) : null;
                    } else {
                        $tkt_product_id = $this->_get_or_create_IS_product_ID();
                    }
                    if ($this->_->transaction()
                        && $this->_->transaction()->primary_registration()
                    ) {
                        $primary_reg_code = $this->_->transaction()->primary_registration()->reg_code();
                        $primary_attendee_id = $this->_->transaction()->primary_registration()->attendee_ID();
                    } else {
                        $primary_reg_code = esc_html__('Unknown', 'event_espresso');
                        $primary_attendee_id = esc_html__('Unknown', 'event_espresso');
                    }
                    // get invoice ID for this
                    // it's a normal line item that's been saved or
                    $product_id = apply_filters(
                        'FHEE__EEE_Infusionsoft_Line_Item__ext_sync_to_infusionsoft__product_id',
                        $tkt_product_id,
                        $this->_
                    );
                    $type = apply_filters(
                        'FHEE__EEE_Infusionsoft_Line_Item__ext_sync_to_infusionsoft__product_type',
                        self::IS_product_type,
                        $this->_
                    );
                    $total = $this->_->is_percent() ? $this->_->total() : $this->_->unit_price();
                    $quantity = $this->_->is_percent() ? 1 : $this->_->quantity();
                    $description = $this->_->ticket_event_name();
                    $notes = esc_html__('Attendee ID:', 'event_espresso')
                             . ' '
                             . $primary_attendee_id
                             . ' '
                             . esc_html__('Reg. ID:', 'event_espresso')
                             . ' '
                             . $primary_reg_code;
                } else {
                    // or the line item is for a tax
                    // get invoice ID for this
                    // it's a normal line item that's been saved or
                    $product_id = 0;
                    $type = self::IS_tax_type;
                    $total = $this->_->total();
                    $quantity = 1;
                    $description = $this->_->name();
                    $notes = $this->_->desc();
                }
                $success = $this->_add_or_update_order_item(
                    new InfusionsoftOrderItemProperties(
                        $txn_invoice_id,
                        $product_id,
                        $type,
                        $total,
                        $quantity,
                        $description,
                        $notes,
                        $this->_->get_IS_order_item_ID()
                    )
                );
                if (EED_Infusionsoft::is_IS_error($success)) {
                    EE_Log::instance()->log(
                        __FILE__,
                        __FUNCTION__,
                        sprintf(
                            esc_html__(
                                // @codingStandardsIgnoreStart
                                'Could not add EE line item %1$s with code %2$s (IS product %3$s) to IS invoice %4$s because %5$s',
                                // @codingStandardsIgnoreEnd
                                'event_espresso'
                            ),
                            $this->_->ID(),
                            $this->_->code(),
                            $product_id,
                            $txn_invoice_id,
                            (string) $success
                        ),
                        'infusionsoft'
                    );
                    $success = false;
                }
            } else {
                // line item is for something else (a total, subtotal, or something else?
                $is_order_item_id = $this->_->get_IS_order_item_ID();
                if ($is_order_item_id) {
                    /**
                     * Gives other addons a chance to add different logic for how to sync other
                     * line item types to infusionsoft THAT HAVE ALREADY BEEN SYNC'ED ONCE
                     *
                     * @param boolean      $successful_syncing (defaults to false)
                     * @param EE_Line_Item $line_item_being_synced
                     */
                    $is_order_item_id = apply_filters(
                        'FHEE__EEE_Infusionsoft_Line_Item__sync_existing_unknown_line_item_type_to_infusionsoft',
                        false,
                        $this->_,
                        $is_order_item_id
                    );
                } else {
                    /**
                     * Gives other addons a chance to add different logic for how to sync other
                     * line item types to infusionsoft that HAVE NEVER BEEN SYNC'ED YET
                     *
                     * @param boolean      $successful_syncing (defaults to false)
                     * @param EE_Line_Item $line_item_being_synced
                     */
                    $is_order_item_id = apply_filters(
                        'FHEE__EEE_Infusionsoft_Line_Item__sync_unknown_line_item_type_to_infusionsoft',
                        false,
                        $this->_
                    );
                }
                if (! EED_Infusionsoft::is_IS_error($is_order_item_id)) {
                    $this->_->set_IS_order_item_ID($is_order_item_id);
                    $success = true;
                } else {
                    $success = false;
                }
            }
            /**
             * Action performed after syncing an EE Ticket to an IS product successfully
             *
             * @param EE_Line_Item   $line_item
             * @param boolean        $newly_synced whether we just sync'd for the first time or not (for now, by default
             *                                     this is always true because we only sync line items once; we never
             *                                     update them)
             * @param boolean|string $success      the response from infusionsoft
             */
            do_action('AHEE__EEE_Infusionsoft_Line_Item__sync_to_infusionsoft__end', $this->_, true, $success);
        } catch (Exception $e) {
            EE_Log::instance()->log(
                __FILE__,
                __FUNCTION__,
                sprintf(
                    esc_html__(
                        // @codingStandardsIgnoreStart
                        'Exception thrown! Could not sync Event Espresso Line Item (%1$s) to Infusionsoft Order Item because: %2$s',
                        // @codingStandardsIgnoreEnd
                        'event_espresso'
                    ),
                    $this->_->ID(),
                    $e->getMessage() . $e->getTraceAsString()
                ),
                'infusionsoft'
            );
            $success = false;
        }
        EED_Infusionsoft::mark_model_obj_synced($this->_);
        return (boolean) $success;
    }



    /**
     * Adds the IS order item, or updates it if it has already been added previouslyl
     *
     * @param EventEspresso\Infusionsoft\core\domain\InfusionsoftOrderItemProperties  $orderItemProperties
     * @return boolean|array of true or an array indicating an IS error
     * @throws \EE_Error
     */
    protected function _add_or_update_order_item(
        InfusionsoftOrderItemProperties $orderItemProperties
    ) {
        // ok we have all the data, let's send it over!
        if ($orderItemProperties->getOrderItemId()) {
            $success = $this->_update_order_item($orderItemProperties);
        } else {
            $success = $this->_add_order_item($orderItemProperties);
        }
        return $success;
    }



    /**
     * Updates the order item in IS
     * @param InfusionsoftOrderItemProperties $orderItemProperties
     * @return array|bool|string
     */
    protected function _update_order_item(InfusionsoftOrderItemProperties $orderItemProperties)
    {
        $ee_infusionsoft = EED_Infusionsoft::infusionsoft_connection();
        // if we have an IS ID for it, just update it
        // @todo: if there isa product ID, don't change the name
        $success_update_order_item = $ee_infusionsoft->dsUpdate(
            'OrderItem',
            $orderItemProperties->getOrderItemId(),
            array(
                'OrderId'         => $orderItemProperties->getOrderId(),
                'ProductId'       => $orderItemProperties->getProductId(),
                'ItemType'        => $orderItemProperties->getType(),
                'PPU'             => $orderItemProperties->getPrice(),
                'CPU'             => $orderItemProperties->getPrice(),
                'Qty'             => $orderItemProperties->getQuantity(),
                'ItemName'        => $orderItemProperties->getDescription(),
                'ItemDescription' => $orderItemProperties->getDescription(),
            )
        );
        if (EED_Infusionsoft::is_IS_error($success_update_order_item)) {
            // if we got an error, return it now so we can report it
            return $success_update_order_item;
        }
        // I think we also need to update its corresponding invoice item
        // fetch the corresponding invoice item
        $invoice_items = $ee_infusionsoft->dsQuery(
            'InvoiceItem',
            1,
            0,
            array(
                'OrderItemId' => $orderItemProperties->getOrderItemId(),
            ),
            array(
                'Id',
                'InvoiceId',
                'DateCreated',
            )
        );
        // (check for an error, of course)
        if (EED_Infusionsoft::is_IS_error($invoice_items)) {
            // if we got an error, return it now so we can report it
            return $invoice_items;
        }
        // extract its ID
        if (! is_array($invoice_items)
            || empty($invoice_items)) {
            return EED_Infusionsoft::IS_error_response_prefix
                   . sprintf(
                       esc_html__(
                           'Could not find invoice item for order item %1$s',
                           'event_espresso'
                       ),
                       $orderItemProperties->getOrderItemId()
                   );
        }
        // update the invoice item
        $first_matching_invoice_item = array_shift($invoice_items);
        if (! isset(
            $first_matching_invoice_item['Id'],
            $first_matching_invoice_item['InvoiceId'],
            $first_matching_invoice_item['DateCreated']
        )) {
            return EED_Infusionsoft::IS_error_response_prefix
                   . sprintf(
                       esc_html__(
                       // @codingStandardsIgnoreStart
                           'Infusionsoft did not return the invoice item\'s Id, InvoiceId and DateCreated as requested.',
                           // @codingStandardsIgnoreEnd
                           'event_espresso'
                       )
                   );
        }
        $is_invoice_item_id = $first_matching_invoice_item['Id'];
        $is_invoice_id = $first_matching_invoice_item['InvoiceId'];
        $is_invoice_date_created = $first_matching_invoice_item['DateCreated'];
        $successful_update_invoice_item = $ee_infusionsoft->dsUpdate(
            'InvoiceItem',
            $is_invoice_item_id,
            array(
                'InvoiceAmt' => $orderItemProperties->getPrice(),
            )
        );
        if (EED_Infusionsoft::is_IS_error($successful_update_invoice_item)) {
            return $successful_update_invoice_item;
        }
        return $this->_recalculate_order_total($is_invoice_id, $ee_infusionsoft);
    }



    /**
     * Adds the order item to IS
     * @param InfusionsoftOrderItemProperties $orderItemProperties
     * @return array|string
     */
    protected function _add_order_item(InfusionsoftOrderItemProperties $orderItemProperties)
    {
        $ee_infusionsoft = EED_Infusionsoft::infusionsoft_connection();
        // otherwise, insert a new one and get its ID
        $success = $ee_infusionsoft->addOrderItem(
            $orderItemProperties->getOrderId(),
            $orderItemProperties->getProductId(),
            $orderItemProperties->getType(),
            $orderItemProperties->getPrice(),
            $orderItemProperties->getQuantity(),
            $orderItemProperties->getDescription(),
            $orderItemProperties->getNotes()
        );
        if (EED_Infusionsoft::is_IS_error($success)) {
            // if we got an error, return it now so we can report it
            return $success;
        }
        $existing_is_line_item = $ee_infusionsoft->dsQuery(
            'OrderItem',
            1,
            0,
            array(
                'OrderId'         => $orderItemProperties->getOrderId(),
                'ProductId'       => $orderItemProperties->getProductId(),
                // 'ItemType' => $type,
                // 'PPU' => $price,
                // 'Qty' => $qty,
                'ItemDescription' => $orderItemProperties->getDescription(),
            ),
            array(
                'Id',
                // 'OrderId',
                // 'ProductId',
                // 'ItemType',
                // 'PPU',
                // 'Qty',
                // 'ItemName',
                // 'ItemDescription'
            )
        );
        if (EED_Infusionsoft::is_IS_error($existing_is_line_item)) {
            // if we got an error, return it now so we can report it
            return $existing_is_line_item;
        }
        if (! is_array($existing_is_line_item)
            || empty($existing_is_line_item)) {
            return EED_Infusionsoft::IS_error_response_prefix
                   . sprintf(
                       esc_html__(
                       // @codingStandardsIgnoreStart
                           'Could not find an order item right after we inserted it for order %1$s and with product ID %2$s',
                           // @codingStandardsIgnoreEnd
                           'event_espresso'
                       ),
                       $orderItemProperties->getOrderId(),
                       $orderItemProperties->getProductId()
                   );
        }
        $first_matching_order_item = array_shift($existing_is_line_item);
        $is_order_item_id = $first_matching_order_item['Id'];
        $this->_->set_IS_order_item_ID($is_order_item_id);
        // if it wasn't for a product, IS gives the order item a name that matches the type.
        // So if the type was "Misc" or "Other", that's becomes its name. Ugh.
        // Better to use the $desc as the name
        if ($orderItemProperties->getProductId() === 0) {
            $success = $ee_infusionsoft->dsUpdate(
                'OrderItem',
                $is_order_item_id,
                array(
                    'ItemName' => $orderItemProperties->getDescription(),
                )
            );
        }
        return $success;
    }


    /**
     * Gets Infusionsoft to recalculate the order total
     * (right now, it does so by asking for the tax to be recalculated. This adds a "sales tax" of 0,
     * which is weird, but probably less weird than having an incorrect total...)
     *
     * @param int      $is_invoice_id
     * @param EE_iSDK  $ee_infusionsoft
     * @return boolean|String true if successful, otherwise an IS error string
     */
    protected function _recalculate_order_total($is_invoice_id, EE_iSDK $ee_infusionsoft)
    {
        return $ee_infusionsoft->recalculateTax($is_invoice_id);
    }



    /**
     * Gets the ID of the Infusionsoft product for this line item's object.
     *
     * @return int
     * @throws \EE_Error
     */
    protected function _get_or_create_IS_product_ID()
    {
        $object_line_item_is_for = $this->_->get_object();
        if (! $object_line_item_is_for instanceof EE_Base_Class) {
            return null;
        }
        $IS_product_ID = apply_filters(
            'FHEE__EEE_Infusionsoft_Line_Item__get_or_create_IS_product_ID',
            $object_line_item_is_for->get_extra_meta(
                EEE_Infusionsoft_Ticket::extra_meta_IS_product_ID,
                true
            ),
            $this->_
        );
        // verify it STILL exists. Cause if not, we should forget about it
        if ($IS_product_ID && ! EED_Infusionsoft::IS_product_exists($IS_product_ID)) {
            $IS_product_ID = null;
            $object_line_item_is_for->update_extra_meta(
                EEE_Infusionsoft_Ticket::extra_meta_IS_product_ID,
                $IS_product_ID
            );
        }
        if ($IS_product_ID) {
            return $IS_product_ID;
        }
        // ok fine no product for this thing, no addon decided to add it,
        // let's make it
        return $this->_create_IS_product();
    }



    /**
     * Creates a product from this line item and its associated object
     *
     * @return int IS product ID
     * @throws \EE_Error
     */
    protected function _create_IS_product()
    {
        $object = $this->_->get_object();
        $product_data = array(
            'Sku'              => $this->_->OBJ_type() . $this->_->OBJ_ID(),
            'ProductPrice'     => $this->_->unit_price(),
            'ProductName' => apply_filters(
                'FHEE__EEE_Infusionsoft_Line_Item__create_IS_product__ProductName',
                htmlentities(wp_strip_all_tags($object instanceof EE_Base_Class ? $object->name() : $this->_->name())),
                $this->_
            ),
            'Description'      => apply_filters(
                'FHEE__EEE_Infusionsoft_Line_Item__create_IS_product__description',
                $this->_->desc(),
                $this->_
            ),
            'ShortDescription' => apply_filters(
                'FHEE__EEE_Infusionsoft_Line_Item__create_IS_product__short_description',
                $this->_->desc(),
                $this->_
            ),
            'Taxable'          => $this->_->is_taxable() ? 1 : 0,
            'HideInStore'      => 0,
            'Status'           => 0,
        );
        /**
         * filters the product data we are about to send to Infusionsoft
         *
         * @see https://developer.infusionsoft.com/docs/read/Table_Documentation to see what
         * other keys you can provide to infusionsoft
         * @param array     $product_data
         * @param EE_Ticket $ticket the IS product is based off
         */
        $product_data = apply_filters(
            'FHEE__EEE_Infusionsoft_Line_Item___create_IS_product__product_data',
            $product_data,
            $this->_
        );
        $ee_infusionsoft = EED_Infusionsoft::infusionsoft_connection();
        $IS_product_ID = $ee_infusionsoft->dsAdd('Product', $product_data);
        if (EED_Infusionsoft::is_IS_error($IS_product_ID)) {
            EE_Log::instance()->log(
                __FILE__,
                __FUNCTION__,
                sprintf(
                    esc_html__(
                        // @codingStandardsIgnoreStart
                        'Unable to insert new Infusionsoft Product with data %1$s from EE %2$s %3$d. Infusionsoft replied with %4$s',
                        // @codingStandardsIgnoreEnd
                        'event_espresso'
                    ),
                    json_encode($product_data),
                    $this->_->OBJ_type(),
                    $this->_->ID(),
                    $IS_product_ID
                ),
                'infusionsoft'
            );
        } else {
            $object->update_extra_meta(EEE_Infusionsoft_Ticket::extra_meta_IS_product_ID, $IS_product_ID);
            $category_id = EEH_Infusionsoft_Product_Category::get_or_create_IS_product_category(
                apply_filters(
                    'FHEE__EEE_Infusionsoft_Line_Item___create_IS_product__product_category_name',
                    $this->_->OBJ_type(),
                    $this->_
                ),
                EEH_Infusionsoft_Product_Category::verify_top_level_IS_product_category()
            );
            if ($IS_product_ID && $category_id) {
                EEH_Infusionsoft_Product_Category::assign_product_to_category($IS_product_ID, $category_id);
            }
            do_action('AHEE__EEE_Infusionsoft_Line_Item___create_IS_product__success', $IS_product_ID, $this->_);
        }
        return $IS_product_ID;
    }



    /**
     * Gets the infusionsoft order ID we recorded on an earlier request
     *
     * @return int|null
     * @throws \EE_Error
     */
    public function ext_get_IS_order_item_ID()
    {
        $IS_thing_ID_string = $this->_->get_extra_meta(
            EEE_Infusionsoft_Line_Item::extra_meta_IS_line_item_ID,
            true
        );
        if ($IS_thing_ID_string !== null) {
            return (int) $IS_thing_ID_string;
        }
        return null;
    }
}
