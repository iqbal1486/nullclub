<?php

/**
 *
 * EEE_Infusionsoft_Attendee
 *
 * @package         Event Espresso
 * @subpackage
 * @author              Mike Nelson
 *
 */
class EEE_Infusionsoft_Ticket extends EEE_Base_Class
{

    public function __construct()
    {
        $this->_model_name_extended = 'Ticket';
        parent::__construct();
    }
    const extra_meta_IS_product_ID = 'IS_product_ID';
    public function ext_sync_to_infusionsoft()
    {
        try {
            // only sync attendees actually in the DB
            if (! $this->_->ID()  || EED_Infusionsoft::synced_on_this_request($this->_)) {
                return false;
            }
            $event = null;
            $datetimes_of_ticket = $this->_->datetimes();
            if (is_array($datetimes_of_ticket)) {
                $first_datetime = reset($datetimes_of_ticket);
                if ($first_datetime instanceof EE_Datetime) {
                    $event = $first_datetime->event();
                }
            }
            if (! $event instanceof EE_Event) {
                // we need an event to sync an IS product from an EE Ticket
                return false;
            }
            // map the EE4 Attendee fields onto IS contact data
            $uniquess_product_data = array(
                'ProductName' => htmlentities(wp_strip_all_tags($event->name())) . '@' . $this->_->name(),
            );
            $datetime_names = array();
            foreach ($datetimes_of_ticket as $datetime) {
                $datetime_names[] = $datetime->get_dtt_display_name(true);
            }

            $product_description = $this->_->description() .
                    __('Grants admission to datetimes: ', 'event_espresso') .
                    implode(', ', $datetime_names);
            $product_data = array(
                'Sku' => "event-" . $this->_->ID(),
                'ProductPrice' => $this->_->price(),
                'Description' => $product_description,
                'ShortDescription' => $product_description,
                'Taxable' => $this->_->taxable() ? 1 : 0,
                'HideInStore' => 0,
                'Status' => 1,
            );
            $product_data = array_merge($uniquess_product_data, $product_data);
            /**
             * filters the product data we are about to send to Infusionsoft
             * @see https://developer.infusionsoft.com/docs/read/Table_Documentation to see what
             * other keys you can provide to infusionsoft
             * @param array $product_data
             * @param EE_Ticket $ticket the IS product is based off
             */
            $product_data = apply_filters('FHEE__EEE_Infusionsoft_Ticket__sync_to_infusionsoft__product_data', $product_data, $this->_);
            $IS_product_ID = $this->_->get_IS_product_ID();

            $ee_infusionsoft = EED_Infusionsoft::infusionsoft_connection();
            
            // verify it STILL exists. Cause if not, we should forget about it
            if ($IS_product_ID && ! EED_Infusionsoft::IS_product_exists($IS_product_ID)) {
                $IS_product_ID = null;
                $this->_->set_IS_product_ID($IS_product_ID);
            }
            
            if (! $IS_product_ID) {
                // apparently this hasn't been sync'd to IS before...
                // but let's double-check there isn't an old EE 3.1 Infusionsoft addon entry in IS
                $matching_product_ids = $ee_infusionsoft->dsQuery("Product", 1, 0, $uniquess_product_data, array('Id'));
                if (is_array($matching_product_ids) &&
                        ! empty($matching_product_ids) ) {
                    $first_matching_product = array_shift($matching_product_ids);
                    $IS_product_ID = $first_matching_product['Id'];
                    $this->_->set_IS_product_ID($IS_product_ID);
                }
            }

            if ($IS_product_ID) {
                // we know which produc to update
                $success = $ee_infusionsoft->dsUpdate('Product', $IS_product_ID, $product_data);
                if (EED_Infusionsoft::is_IS_error($success)) {
                    EE_Log::instance()->log(
                        __FILE__,
                        __FUNCTION__,
                        sprintf(
                            __('Unable to update Infusionsoft Product with ID "%1$d" with the data %2$s from EE ticket %3$d. Infusionsoft replied with %4$s', 'event_espresso'),
                            $IS_product_ID,
                            json_encode($product_data),
                            $this->_->ID(),
                            $success
                        ),
                        'infusionsoft'
                    );
                }
                $newly_synced = false;
            } else {
                // we don't know which product ot update. So insert one
                $IS_product_ID = $ee_infusionsoft->dsAdd('Product', $product_data);
                if (EED_Infusionsoft::is_IS_error($IS_product_ID)) {
                    EE_Log::instance()->log(
                        __FILE__,
                        __FUNCTION__,
                        sprintf(
                            __('Unable to insert new Infusionsoft Product with data %1$s from EE Ticket %2$d. Infusionsoft replied with %3$s', 'event_espresso'),
                            json_encode($product_data),
                            $this->_->ID(),
                            $IS_product_ID
                        ),
                        'infusionsoft'
                    );
                } else {
                    $this->_->set_IS_product_ID($IS_product_ID);
                }
                $newly_synced = true;
            }
            // assign the ticket to the ticket category
            $category_id = EEH_Infusionsoft_Product_Category::get_or_create_IS_product_category(
                apply_filters(
                    'FHEE__EEE_Infusionsoft_Ticket__sync_to_infusionsoft__ticket_category_name',
                    __('Ticket', 'event_espresso'),
                    $this->_
                ),
                EEH_Infusionsoft_Product_Category::verify_top_level_IS_product_category()
            );
            if ($IS_product_ID && $category_id) {
                EEH_Infusionsoft_Product_Category::assign_product_to_category($IS_product_ID, $category_id);
            }
            /**
             * Action performed after syncing an EE Ticket to an IS product successfully
             *
             * @param EE_Ticket $ticket
             * @param string $IS_producct_ID the ID of the IS product in IS
             * @param array $product_data sent to IS
             * @param boolean $newly_synced whether we just sync'd for the first time or not
             */
            do_action('AHEE__EEE_Infusionsoft_Ticket__sync_to_infusionsoft__end', $this->_, $IS_product_ID, $product_data, $newly_synced);
        } catch (Exception $e) {
            EE_Log::instance()->log(
                __FILE__,
                __FUNCTION__,
                sprintf(
                    __('Exception thrown! Could not sync Event Espresso Ticket (%1$s) to Infusionsoft Product because: %2$s', 'event_espresso'),
                    $this->_->ID(),
                    $e->getMessage() . $e->getTraceAsString()
                ),
                'infusionsoft'
            );
        }
        EED_Infusionsoft::mark_model_obj_synced($this->_);
    }

    /**
     * Gets the product ID for the ticket. if somehow this ticket doesn't have an
     * IS product and $sync_if_necessary is true, sync and try again
     * @param boolean $sync_if_necessary if there is no product ID, try syncing
     * and then get the product ID again
     * @return int
     */
    public function ext_get_IS_product_ID($sync_if_necessary = false)
    {
        $product_id = $this->_get_IS_product_ID_from_extra_meta();
        if (! $product_id && $sync_if_necessary) {
            $this->ext_sync_to_infusionsoft();
            $product_id = $this->_get_IS_product_ID_from_extra_meta();
        }
        return $product_id;
    }
    
    /**
     * Simply gets the IS product ID from the extra meta row. If its not found
     * gives up
     * @return int
     */
    protected function _get_IS_product_ID_from_extra_meta()
    {
        $IS_contact_ID_string = $this->_->get_extra_meta(self::extra_meta_IS_product_ID, true);
        if ($IS_contact_ID_string !== null) {
            return (int) $IS_contact_ID_string;
        } else {
            return null;
        }
    }
    public function ext_set_IS_product_ID($new_id)
    {
        $this->_->update_extra_meta(self::extra_meta_IS_product_ID, $new_id);
    }
}
