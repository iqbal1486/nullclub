<?php

/**
 * EEE_Infusionsoft_Registration
 *
 * @package               Event Espresso
 * @subpackage
 * @author                Mike Nelson
 */
class EEE_Infusionsoft_Registration extends EEE_Base_Class
{

    /**
     * @var EE_Registration
     */
    protected $_;

    public function __construct()
    {
        $this->_model_name_extended = 'Registration';
        parent::__construct();
    }



    /**
     * @var EE_Registration $_
     * @return bool
     * @throws \EventEspresso\core\exceptions\EntityNotFoundException
     * @throws \InvalidArgumentException
     * @throws \EventEspresso\core\exceptions\InvalidInterfaceException
     * @throws \EventEspresso\core\exceptions\InvalidDataTypeException
     * @throws \EE_Error
     */
    public function ext_sync_to_infusionsoft()
    {
        if (EED_Infusionsoft::synced_on_this_request($this->_)) {
            return false;
        }
        // if this is a primary registration, we should double-check the transaction has
        // had pushed its IS invoice (because it's common to first save a transaction,
        // and use its ID when saving its registrations. ANd we can only push a transactions'
        // invoice to IS when we have its primary reg and its attendee
        if ($this->_->is_primary_registrant() && $this->_->transaction()) {
            $this->_->transaction()->sync_to_infusionsoft();
        }
        $tags_to_apply = array_merge(
            // get tags set by the metabox
            // by using EEE_infusionsof_Event::ext_get_IS_tag_IDs()
            // fyi it's safe to chain method calls because EE_Registration::event()
            // throws an exception if it doesn't return an EE_Event
            // and it's no less efficient because the result is cached on EE_Registration
            $this->_->event()->get_IS_tag_IDs(),
            // get legacy tags too
            $this->_->event()->get_post_meta(
                'infusionsoft_tag_id',
                false
            )
        );
        // add tags based on reg's answers to questions with options associated to tags
        // get questions whose options are associated with IS tags and were answered by this reg
        $answers_to_conditionally_tagging_questions = EEM_Answer::instance()->get_all(
            array(
                array(
                    // @codingStandardsIgnoreStart
                    'Question.Question_Option.Extra_Meta.EXM_key' => EEE_Infusionsoft_Question_Option::extra_meta_IS_tag_id,
                    // @codingStandardsIgnoreEnd
                    'REG_ID' => $this->_->ID()
                )
            )
        );
        foreach ($answers_to_conditionally_tagging_questions as $answer) {
            // if the answer isn't a group of choices, convert it into one
            // so the following code is simpler
            /**
             * @var $answer EE_Answer
             */
            $chosen_answers = (array) $answer->value();
            foreach ($chosen_answers as $choice) {
                $tags = EEM_Extra_Meta::instance()->get_col(
                    array(
                        array(
                            'Question_Option.QSO_value' => (string) $choice,
                            'EXM_key' => EEE_Infusionsoft_Question_Option::extra_meta_IS_tag_id
                        )
                    ),
                    'EXM_value'
                );
                foreach ($tags as $tag) {
                    $tags_to_apply[] = $tag;
                }
            }
        }

        // Add tags to the contact record using the infusionsoft_tag_id meta field
        /**
         * Filters an array of infusionsoft group Ids (aka "tags") to assign to the contact when they register
         * for an event. Normally this list is determined only by the event's postmetas with key 'infusionsoft_tag_id',
         * but you can dynamically add any others you like based on the registration provided as the 2nd argument.
         * Also note: we take care of making sure the contacts are only assigned to that group ("tag") once
         * @param string[] $infusionsoft_tags array of strings of infusionsoft group IDs
         * @param EE_Registration $registration
         */
        $infusionsoft_tags = apply_filters(
            'FHEE__EEE_Infusionsoft_Registration__sync_to_infusionsoft__infusionsoft_tags',
            $tags_to_apply,
            $this->_
        );
        if (! $infusionsoft_tags) {
            return false;
        }
        $attendee = $this->_->attendee();
        if ($attendee instanceof EE_Attendee) {
            // make sure attendee is sync'ed, or possibly re-sync
            $attendee->sync_to_infusionsoft();
            $IS_contact_id = $attendee->get_extra_meta(EEE_Infusionsoft_Attendee::extra_meta_IS_contact_ID, true);
        } else {
            $IS_contact_id = null;
        }
        if (! $IS_contact_id) {
            return false;
        }
        $groups_to_sync = (array) $attendee->determine_groups_to_sync($infusionsoft_tags);
        $ee_infusionsoft = EED_Infusionsoft::infusionsoft_connection();
        foreach ($groups_to_sync as $tag) {
            $success = $ee_infusionsoft->grpAssign($IS_contact_id, $tag);
            if (EED_Infusionsoft::is_IS_error($success)) {
                EE_Log::instance()->log(
                    __FILE__,
                    __FUNCTION__,
                    sprintf(
                        esc_html__(
                            // @codingStandardsIgnoreStart
                            'Could not assign Infusionsoft Contact %1$s for EE registration %2$s to tag %3$s. Infusionsoft Error was %4$s',
                            // @codingStandardsIgnoreEnd
                            'event_espresso'
                        ),
                        $IS_contact_id,
                        $this->_->ID(),
                        $tag,
                        $success
                    ),
                    'infusionsoft'
                );
            } else {
                $attendee->save_group_synced($tag);
            }
        }
        EED_Infusionsoft::mark_model_obj_synced($this->_);
    }
}
