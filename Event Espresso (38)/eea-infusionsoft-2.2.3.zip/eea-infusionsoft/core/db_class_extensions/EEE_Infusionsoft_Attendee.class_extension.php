<?php

/**
 *
 * EEE_Infusionsoft_Attendee
 *
 * @package         Event Espresso
 * @subpackage
 * @author              Mike Nelson
 *
 */
class EEE_Infusionsoft_Attendee extends EEE_Base_Class
{

    /**
     *
     * @var EE_Attendee
     */
    protected $_;
    public function __construct()
    {
        $this->_model_name_extended = 'Attendee';
        parent::__construct();
    }
    const extra_meta_IS_contact_ID = 'IS_contact_ID';
    const extra_meta_IS_group_IDs = 'IS_group_IDs';
    public function ext_sync_to_infusionsoft()
    {
        try {
            // only sync attendees actually in the DB
            if (! $this->_->ID() || EED_Infusionsoft::synced_on_this_request($this->_)) {
                return false;
            }
            $IS_contact_ID = $this->_->get_IS_contact_ID();
            $isdk = EED_Infusionsoft::infusionsoft_connection();

            $StreetAddress1 = $this->_->address();
            $StreetAddress2 = $this->_->address2();
            $City           = $this->_->city();
            $State          = $this->_->state_name();
            $PostalCode     = $this->_->zip();
            $Phone1         = $this->_->phone();
            $Country        = $this->_->country_name();


            // map the EE4 Attendee fields onto IS contact data
            $contact_data = array(
                'FirstName' => $this->_->fname(),
                'LastName' => $this->_->lname(),
                'Email' => $this->_->email(),
                'StreetAddress1' => $StreetAddress1,
                'StreetAddress2' => $StreetAddress2,
                'City' => $City,
                'State' => $State,
                'PostalCode' => $PostalCode,
                'Phone1' => $Phone1,
                'Country' => $Country,
            );

            // also record their answers to custom questions
            $mapped_custom_questions = EEM_Question::instance()->get_all(
                array(
                    array(
                        'Extra_Meta.EXM_key' => EEE_Infusionsoft_Question::extra_meta_IS_field_name,
                        'Extra_Meta.EXM_value' => array('!=', ''),
                        'Extra_Meta.EXM_value' => array('IS_NOT_NULL'),
                    )
                )
            );
            foreach ($mapped_custom_questions as $question) {
                $answer_to_that_question = EEM_Answer::instance()->get_var(
                    array(
                        array(
                            'QST_ID' => $question->ID()
                        ),
                        'order_by' => array(
                            'REG_ID' => 'DESC'
                        )
                    ),
                    'ANS_value'
                );
                if ($question->type() === EEM_Question::QST_type_date) {
                    // @todo: convert it form a format like "November 10, 2017" to EED_Infusionsoft::IS_datetime_format
                    $datetime = DateTime::createFromFormat(get_option('date_format'), $answer_to_that_question);
                    if (! $datetime instanceof DateTime) {
                        // if we didn't get a datetime, it's an invalid format.
                        // it's possible it was a valid format at one point, so just leave it alone
                        continue;
                    } else {
                        $answer_to_that_question = $datetime->format(EED_Infusionsoft::IS_datetime_format);
                    }
                }
                // use dynamically added method in EEE_Infusionsoft_Question
                $contact_data[ $question->get_IS_field_db_name() ] = $answer_to_that_question;
            }

            if (empty($StreetAddress1)) {
                unset($contact_data['StreetAddress1']);
            }
            if (empty($StreetAddress2)) {
                unset($contact_data['StreetAddress2']);
            }
            if (empty($City)) {
                unset($contact_data['City']);
            }
            $state_id = $this->_->state_ID();
            if (empty($state_id)) {
                unset($contact_data['State']);
            }
            if (empty($PostalCode)) {
                unset($contact_data['PostalCode']);
            }
            if (empty($Phone1)) {
                unset($contact_data['Phone1']);
            }
            $country_id = $this->_->country_ID();
            if (empty($country_id)) {
                unset($contact_data['Country']);
            }


//          echo "got IS fields";
//          var_dump($contact_data);

            /**
             * Filters the fields sync'd from an EE Attendee to its corresponding IS contact
             *
             * @param array $attendee_data keys are Contact field names mentioned on https://developer.infusionsoft.com/docs/read/Table_Documentation
             * @param EE_Attendee $attendee the EE4 attendee being sync'd to IS
             */
            $contact_data = apply_filters('FHEE__EED_Infusionsoft__save_infusionsoft_attendee__extra_attendee_data', $contact_data, $this->_);

            $newly_synced = false;
            if ($IS_contact_ID) {
                $previous_contact_data = $isdk->dsLoad("Contact", $IS_contact_ID, array('ContactNotes'));
                if (EED_Infusionsoft::is_IS_error($previous_contact_data)) {
                    EE_Log::instance()->log(
                        __FILE__,
                        __FUNCTION__,
                        sprintf(
                            __('Infusionsoft error. Could not load contact with ID %1$s from EE attendee %2$s. Error was %3$s', 'event_espresso'),
                            $IS_contact_ID,
                            $this->_->ID(),
                            $previous_contact_data
                        ),
                        'infusionsoft'
                    );
                    return false;
                }
                $old_contact_notes = isset($previous_contact_data['ContactNotes']) ? $previous_contact_data['ContactNotes'] : '';
                $new_contact_data = $old_contact_notes . '\r\n' . sprintf(__('Account was updated on %s via your event registration system (Event Espresso %s).', 'event_espresso'), date("Y-m-d", time()), espresso_version(), $this->_->ID());
                $contact_data['ContactNotes'] = $new_contact_data;
                $success = $isdk->dsUpdate('Contact', $IS_contact_ID, $contact_data);
                if (EED_Infusionsoft::is_IS_error($success)) {
                    EE_Log::instance()->log(
                        __FILE__,
                        __FUNCTION__,
                        sprintf(__('Did not successfully updated IS contact \'%1$s\' with data %2$s. Infusionsoft API response was %s', 'event_espresso'), $IS_contact_ID, json_encode($contact_data)),
                        'infusionsoft'
                    );
                }
                $newly_synced = false;
            } else {
			    // @codingStandardsIgnoreStart
				//Create a variable for the contact id
				$IS_contact_ID = EED_Infusionsoft::addWithDupCheck($contact_data);
				$this->_->set_IS_contact_ID( $IS_contact_ID );
				if ( $IS_contact_ID ){
					$isdk->optIn($contact_data['Email']);
					$new_contact_notes = sprintf( __('Account was created on %s via your event registration system (Event Espresso %s). Attendee ID: %d ', 'event_espresso'), date("Y-m-d", time()), espresso_version(), $this->_->ID() );
					$success = $isdk->dsUpdate('Contact', $IS_contact_ID, array( 'ContactNotes' => $new_contact_notes));
					if( EED_Infusionsoft::is_IS_error( $success ) ) {
						EE_Log::instance()->log( 
								__FILE__,
								__FUNCTION__,
								sprintf( __( 'Did not successfully add IS contact to IS from attendee with ID %1$s. Response from IS was %2$s', 'event_espresso' ), $this->_->ID(), $success ),
								'infusionsoft');
					}
				}
				$newly_synced = TRUE;
			}
			/**
			 * Action performed after syncing an EE Attendee to an IS contact successfully
			 *
			 * @param EE_Attendee $attendee
			 * @param string $IS_contact_ID the ID of the IS contact in IS
			 * @param array $contact_data sent to IS
			 * @param boolean $newly_synced whether we just sync'd for the first time or not
			 */
			do_action( 'AHEE__EEE_Infusionsoft_Attendee__sync_to_infusionsoft__end', $this->_, $IS_contact_ID, $contact_data, $newly_synced );
		}catch(Exception $e){
			EE_Log::instance()->log(
					__FILE__,
					__FUNCTION__,
					sprintf( 
						__( 'Exception thrown! Could not sync Event Espresso Attendee (%1$s) to Infusionsoft Contact because: %2$s', 'event_espresso' ), 
							$this->_->ID(), 
							$e->getMessage() . $e->getTraceAsString() ),
					'infusionsoft' );
		}
		EED_Infusionsoft::mark_model_obj_synced( $this->_ );
	}

	public function ext_get_IS_contact_ID(){
		$IS_contact_ID_string = $this->_->get_extra_meta(self::extra_meta_IS_contact_ID, TRUE );
		if( $IS_contact_ID_string !== NULL){
			return (int)$IS_contact_ID_string;
		}else{
			return NULL;
		}
	}
	public function ext_set_IS_contact_ID( $new_id ){
		$this->_->update_extra_meta(self::extra_meta_IS_contact_ID, $new_id );
	}
	/**
	 * Gets the locally saved array of strings whose values are group IDs
	 * we know we've assigned this registrant's contact to
	 * @return string[] numerically indexed with values of IS group IDs
	 */
	public function ext_groups_synced(){
		return $this->_->get_extra_meta(self::extra_meta_IS_group_IDs, FALSE, array() );
	}
	public function ext_save_group_synced( $group_id ){
		return $this->_->add_extra_meta( self::extra_meta_IS_group_IDs, $group_id, FALSE );
	}
	/**
	 * Returns an array of all the IS groups in $group_ids that we have not yet
	 * sync'ed this contact to
	 * @param string[] $group_ids
	 * @return string[] all the IS groups we should add this contact to in IS
	 */
	public function ext_determine_groups_to_sync( $group_ids ){
		return array_diff( $group_ids, $this->_->groups_synced() );
	}
}
