<?php

namespace EventEspresso\Infusionsoft\core\domain;

/**
 * Class  InfusionsoftOrderItemProperties
 * Data transfer object (DTO) for passing around information necessary
 * to insert or update an Infusionsoft Order Item
 *
 * @package               Event Espresso
 * @subpackage            eea-infusionsoft
 * @author                Mike Nelson
 */
class InfusionsoftOrderItemProperties
{

    /**
     * Infusionsoft Order ID
     *
     * @var int
     */
    protected $orderId;

    /**
     * Infusionsoft Product ID this order item is for. Can be 0.
     *
     * @var int
     */
    protected $productId;

    /**
     * Order item type. See https://developer.infusionsoft.com/docs/table-schema/ under "order item"
     *
     * @var int
     */
    protected $type;

    /**
     * The price of an individual item
     *
     * @var float
     */
    protected $price;

    /**
     * Quantity of products on this order item
     *
     * @var int
     */
    protected $quantity;

    /**
     * Description on the order item. If there is no product, this will be the order item name too
     *
     * @var string
     */
    protected $description;

    /**
     * Notes to use on the order item
     *
     * @var string
     */
    protected $notes;

    /**
     * Infusionsoft Order Item ID (if it already exists in Infusionsoft, otherwise 0)
     *
     * @var int
     */
    protected $orderItemId;


    /**
     * InfusionsoftOrderItemProperties constructor.
     *
     * @param int  $orderId
     * @param int  $productId
     * @param int  $type
     * @param int  $price
     * @param int  $quantity
     * @param int  $description
     * @param int  $notes
     * @param null $orderItemId
     */
    public function __construct(
        $orderId,
        $productId,
        $type,
        $price,
        $quantity,
        $description,
        $notes,
        $orderItemId = null
    ) {
        $this->orderId = $orderId;
        $this->productId = $productId;
        $this->type = $type;
        $this->price = $price;
        $this->quantity = $quantity;
        $this->description = $description;
        $this->notes = $notes;
        $this->orderItemId = $orderItemId;
    }


    /**
     * Gets the order ID (not invoice ID)
     *
     * @return int
     */
    public function getOrderId()
    {
        return $this->orderId;
    }


    /**
     * Gets the product's ID. Is 0 when there is no product
     *
     * @return int
     */
    public function getProductId()
    {
        return $this->productId;
    }


    /**
     * Gets the type (see https://developer.infusionsoft.com/docs/table-schema/ under "order item")
     *
     * @return int
     */
    public function getType()
    {
        return $this->type;
    }


    /**
     * Gets the per-unit price
     *
     * @return float
     */
    public function getPrice()
    {
        return $this->price;
    }


    /**
     * Gets the item's quantity
     *
     * @return int
     */
    public function getQuantity()
    {
        return $this->quantity;
    }


    /**
     * Gets the item's description
     *
     * @return string
     */
    public function getDescription()
    {
        return $this->description;
    }


    /**
     * Gets the item's notes
     *
     * @return string
     */
    public function getNotes()
    {
        return $this->notes;
    }


    /**
     * Gets the order item's ID
     *
     * @return int
     */
    public function getOrderItemId()
    {
        return $this->orderItemId;
    }
}
