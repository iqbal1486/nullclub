<h2><?php esc_html_e('Registration Data Sent to Infusionsoft', 'event_espresso'); ?></h2>
<p><?php esc_html_e('Registration data, including name, email, and address, are sent to the webservice Infusionsoft for customer relations management and marketing.', 'event_espresso');?></p>
<p><?php
    printf(
        esc_html__('Please see %1$sInfusionsoft\'s Privacy Policy%2$s (link opens in new tab).', 'event_espresso'),
        '<a href="https://www.infusionsoft.com/legal/privacy-policy" target="_blank">',
        '</a>'
    );
?></p>

