<?php

namespace EventEspresso\Infusionsoft\core\domain\services\admin\privacy\policy;

use EventEspresso\core\services\privacy\policy\PrivacyPolicyInterface;

/**
 * Class PrivacyPolicy
 * Description
 *
 * @package        Event Espresso
 * @author         Mike Nelson
 * @since          2.2.2.p
 */
class PrivacyPolicy implements PrivacyPolicyInterface
{


    /**
     * Returns the translated name to display in this privacy policy's section's title
     *
     * @return string
     */
    public function getName()
    {
        return esc_html__('Event Espresso - Infusionsoft', 'event_espresso');
    }


    /**
     * Returns the suggested privacy policy content for this plugin. May contain HTML
     *
     * @return string
     */
    public function getContent()
    {
        return \EEH_Template::display_template(
            __DIR__ . '/privacy_policy.template.php',
            array(),
            true
        );
    }
}
// End of file PrivacyPolicy.php
// Location: ${NAMESPACE}/PrivacyPolicy.php
