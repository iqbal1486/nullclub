<?php

/**
 *
 * Class EEH_Infusionsoft_Product_Category
 *
 * Helper for Infusionsoft product category-related functions
 *
 * @package         Event Espresso
 * @subpackage
 * @author              Mike Nelson
 *
 *
 */
class EEH_Infusionsoft_Product_Category extends EEH_Base
{
    /**
     * Option name for the wordpress option which will store IS cateogry IDs and such
     */
    const IS_category_id_option_name = 'IS_category_ids';
    
    public static function verify_top_level_IS_product_category()
    {
        $top_level_category = apply_filters(
            'FHEE__EEH_Infusionsoft_Product_Category__verify_top_level_IS_product_category__top_level_category_name',
            __('Event Products', 'event_espresso')
        );
        return EEH_Infusionsoft_Product_Category::get_or_create_IS_product_category($top_level_category, 0);
    }
    
    /**
     * Gets the product cateogory's ID in Infusionsoft, either from our cached
     * data in the wordpress option, or from IS directly by querying them
     * @param string $name
     * @param int $parent_category
     * @return int
     */
    public static function get_IS_product_category_ID($name, $parent_category)
    {
        $isdk = EED_Infusionsoft::infusionsoft_connection();
        $product_category_data = EEH_Infusionsoft_Product_Category::get_IS_product_category_data();
        $product_id = array_search(
            array( 'name' => $name, 'parent_id' => $parent_category ),
            $product_category_data
        );
        if ($product_id) {
            return $product_id;
        }
        $product_ids = $isdk->dsQuery(
            'ProductCategory',
            1, // limit
            1, // page
            array( 'CategoryDisplayName' => $name ), // where
            array( 'Id' ) // fields to return
        );
        if (is_array($product_ids) &&
                        ! empty($product_ids) ) {
                    $first_matching_product = array_shift($product_ids);
                    return $first_matching_product['Id'];
        }
        return 0;
    }
    
    
    /**
     * Gets the product category's ID (first by checking local cache, then searching
     * infusionsoft), and if it doesn't exist creates sucha  category
     * @param string $name
     * @param int $parent_category
     * @return int product category ID
     */
    public static function get_or_create_IS_product_category($name, $parent_category)
    {
        $product_category_id = EEH_Infusionsoft_Product_Category::get_IS_product_category_ID($name, $parent_category);
        if (! $product_category_id) {
            $product_category_id = EEH_Infusionsoft_Product_Category::create_IS_product_category($name, $parent_category);
        }
        return $product_category_id;
    }
    /**
     * Adds product category data to our wordpress option
     * @param type $id
     * @param type $name
     * @param type $parent_id
     */
    public static function cache_product_category_data($id, $name, $parent_id)
    {
        $product_category_data = EEH_Infusionsoft_Product_Category::get_IS_product_category_data();
        $product_category_data[ $id ] = array( 'name' => $name, 'parent_id' => $parent_id );
        update_option(EEH_Infusionsoft_Product_Category::IS_category_id_option_name, $product_category_data);
    }
    /**
     * Creates a product category in infusionsoft and returns its ID
     * @param string $name
     * @param int $parent_category
     * @throw Exception if we can't connect to infusionsoft
     * @return int
     */
    public static function create_IS_product_category($name, $parent_category)
    {
        $isdk = EED_Infusionsoft::infusionsoft_connection();
        $product_category_data = array( 'CategoryDisplayName' => $name, 'ParentId' => $parent_category );
        $product_category_id =  $isdk->dsAdd('ProductCategory', $product_category_data);
        if (EED_Infusionsoft::is_IS_error($product_category_id)) {
            EE_Log::instance()->log(
                __FILE__,
                __FUNCTION__,
                sprintf(
                    __('Unable to insert new Infusionsoft Product Category with data %1$s. Infusionsoft replied with %2$s', 'event_espresso'),
                    json_encode($product_category_data),
                    $product_category_id
                ),
                'infusionsoft'
            );
            return 0;
        } else {
            if ($product_category_id) {
                EEH_Infusionsoft_Product_Category::cache_product_category_data($product_category_id, $name, $parent_category);
            }
            return $product_category_id;
        }
    }
    
    /**
     * Gets the array of cached IS product category data
     * @return array keys are IS product IDs, values are arrays with keys: 'name', and 'parent_id'
     */
    public static function get_IS_product_category_data()
    {
        return get_option(EEH_Infusionsoft_Product_Category::IS_category_id_option_name, array());
    }
    
    /**
     *
     * @param int $product_id
     * @param int $category_id
     * @return int
     */
    public static function assign_product_to_category($product_id, $category_id)
    {
        $isdk = EED_Infusionsoft::infusionsoft_connection();
        $product_category_data = array( 'ProductCategoryId' => $category_id, 'ProductId' => $product_id );
        $product_category_assignment_id =  $isdk->dsAdd('ProductCategoryAssign', $product_category_data);
        if (EED_Infusionsoft::is_IS_error($product_category_assignment_id)) {
            EE_Log::instance()->log(
                __FILE__,
                __FUNCTION__,
                sprintf(
                    __('Unable to assign Infusionsoft Product %1$s to category %2$s. Infusionsoft replied with %2$s', 'event_espresso'),
                    $product_id,
                    $category_id,
                    $product_category_assignment_id
                ),
                'infusionsoft'
            );
            return 0;
        } else {
            return $product_category_assignment_id;
        }
    }
}
