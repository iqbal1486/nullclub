<?php
/*
  Plugin Name: Event Espresso - Infusionsoft (EE4.4+)
  Plugin URI: https://www.eventespresso.com
  Description: Infusionsoft for Event Espresso will transfer contact and transaction information to Infusionsoft during registration checkout. Infusionsoft is also available as an on-site payment method for Event Espresso for accepting credit and debit cards and is available to event organizers in several countries. An account with Infusionsoft is required.
  Version: 2.2.3.p
  Author: Event Espresso
  Author URI: https://www.eventespresso.com
  Copyright 2014 Event Espresso (email : support@eventespresso.com)

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License, version 2, as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA02110-1301USA
 *
 * ------------------------------------------------------------------------
 *
 * Event Espresso
 *
 * Event Registration and Management Plugin for WordPress
 *
 * @ package		Event Espresso
 * @ author			Event Espresso
 * @ copyright	(c) 2008-2014 Event Espresso  All Rights Reserved.
 * @ license		https://eventespresso.com/support/terms-conditions/   * see Plugin Licensing *
 * @ link				https://www.eventespresso.com
 * @ version	 	EE4
 *
 * ------------------------------------------------------------------------
 */
define('EE_INFUSIONSOFT_CORE_VERSION_REQUIRED', '4.9.51.rc.000');
define('EE_INFUSIONSOFT_VERSION', '2.2.3.p');
define('EE_INFUSIONSOFT_PLUGIN_FILE', __FILE__);
define('EE_INFUSIONSOFT_BASE_NAME', plugin_basename(__FILE__));
function load_espresso_infusionsoft()
{
    if (class_exists('EE_Addon')) {
        // infusionsoft version
        require_once(plugin_dir_path(__FILE__) . 'EE_Infusionsoft.class.php');
        EE_Infusionsoft::register_addon();
    }
}

add_action('AHEE__EE_System__load_espresso_addons', 'load_espresso_infusionsoft');

// Stores the affiliate id as a cookie
function espresso_infusionsoft_get_affiliate_name()
{

    if (isset($_REQUEST['ref'])) {
        // set the cookie with the affiliates name in it
        setcookie("EE_IS_AffName", $_REQUEST['ref'], time() + 60 * 60 * 24 * 30, "/");
    } elseif (isset($_REQUEST['affiliate'])) {
        // set the cookie with the affiliates id in it
        // This will be generated using a URL like https://appName.infusionsoft.com/aff.html?to=http://mywebsite.com/event-registration/
        setcookie("EE_IS_AffID", $_REQUEST['affiliate'], time() + 60 * 60 * 24 * 30, "/");
    }

    do_action('AHEE__EED_Infusionsoft__get_affiliate_name');
}
// add_action('init', 'AHEE__EED_Infusionsoft__get_affiliate_name', 100);

// End of file espresso_infusionsoft.php
// Location: wp-content/plugins/espresso-new-addon/espresso_infusionsoft.php
