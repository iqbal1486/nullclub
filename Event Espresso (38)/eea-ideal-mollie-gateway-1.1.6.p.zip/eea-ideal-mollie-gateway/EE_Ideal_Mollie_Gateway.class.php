<?php if ( ! defined( 'EVENT_ESPRESSO_VERSION' ) ) { exit('NO direct script access allowed'); }
/**
 * ------------------------------------------------------------------------
 *
 * Class  EE_Ideal_Mollie_Gateway
 *
 * @package			Event Espresso
 * @subpackage		eea-ideal-mollie-gateway
 * @author			Event Espresso
 *
 *
 * ------------------------------------------------------------------------
 */

// Define the plugin directory path and URL.
define( 'EEA_IDEAL_MOLLIE_BASENAME', plugin_basename( EEA_IDEAL_MOLLIE_PLUGIN_FILE ) );
define( 'EEA_IDEAL_MOLLIE_PATH', plugin_dir_path( __FILE__ ) );
define( 'EEA_IDEAL_MOLLIE_URL', plugin_dir_url( __FILE__ ) );


class EE_Ideal_Mollie_Gateway extends EE_Addon {

	/**
	 * class constructor
	 */
	public function __construct() {}

	public static function register_addon() {
		// Register addon via Plugin API.
		EE_Register_Addon::register(
			'Ideal_Mollie_Gateway',
			array(
				'version' => EEA_IDEAL_MOLLIE_VERSION,
				'min_core_version' => '4.9.34.p',
				'main_file_path' => EEA_IDEAL_MOLLIE_PLUGIN_FILE,
				'admin_callback' => 'additional_ideal_mollie_admin_hooks',
				// if plugin update engine is being used for auto-updates. not needed if PUE is not being used.
				'pue_options' => array(
					'pue_plugin_slug' => 'eea-ideal-mollie-gateway',
					'plugin_basename' => EEA_IDEAL_MOLLIE_BASENAME,
					'checkPeriod' => '24',
					'use_wp_update' => false,
				),
				'payment_method_paths' => array(
					EEA_IDEAL_MOLLIE_PATH . 'payment_methods' . DS . 'Ideal_Mollie'
				),
			)
		);
	}


	/**
	 * 	Additional admin hooks.
	 *
	 *  @access 	public
	 *  @return 	void
	 */
	public static function additional_ideal_mollie_admin_hooks() {
		// is admin and not in M-Mode ?
		if ( is_admin() && ! EE_Maintenance_Mode::instance()->level() ) {
			add_filter( 'plugin_action_links', array( 'EE_Ideal_Mollie_Gateway', 'plugin_actions' ), 10, 2 );
		}
	}


	/**
	 * Add a settings link to the Plugins page.
	 *
	 * Add a settings link to the Plugins page, so people can go straight from the plugin page to the settings page.
	 * @param 	$links
	 * @param 	$file
	 * @return 	array
	 */
	public static function plugin_actions( $links, $file ) {
		if ( $file == EEA_IDEAL_MOLLIE_BASENAME ) {
			// Before other links
			array_unshift( $links, '<a href="admin.php?page=espresso_payment_settings">' . __('Settings') . '</a>' );
		}
		return $links;
	}
}

// End of file EE_Ideal_Mollie_Gateway.class.php
// Location: wp-content/plugins/eea-ideal-mollie-gateway/EE_Ideal_Mollie_Gateway.class.php
