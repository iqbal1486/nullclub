<?php if ( ! defined( 'EVENT_ESPRESSO_VERSION' ) ) { exit('No direct script access allowed'); }

/**
 *
 * EE_PMT_Ideal_Mollie
 *
 * @package			Event Espresso
 * @subpackage		eea-ideal-mollie-gateway
 * @author			Event Espresso
 *
 */

class EE_PMT_Ideal_Mollie extends EE_PMT_Base {

	/**
	 * path to the templates folder for the Mollie Ideal PM
	 * @var string
	 */
	protected $_template_path = null;


	/**
	 * @return \EE_PMT_Ideal_Mollie
	 */
	public function __construct( $pm_instance = null ) {
		require_once( $this->file_folder() . 'EEG_Ideal_Mollie.gateway.php' );
		$this->_gateway = new EEG_Ideal_Mollie();
		$this->_pretty_name = __("Mollie", 'event_espresso');
		$this->_default_description = sprintf( __( 'After clicking \'Finalize Registration\', you will be forwarded to Mollie to make your payment. %1$sMake sure you return to this site in order to properly finalize your registration.%2$s', 'event_espresso' ), '<strong>', '</strong>' );
		$this->_template_path = dirname(__FILE__) . DS . 'templates' . DS;

		parent::__construct( $pm_instance );
		$this->_default_button_url = $this->file_url() . 'lib' . DS . 'mollie.png';
	}

	
	/**
	 * Gets the form for all the settings related to this payment method type
	 *
	 * @return EE_Payment_Method_Form
	 */
	public function generate_new_settings_form() {
		$form = new EE_Payment_Method_Form( array(
			'extra_meta_inputs' => array(
				'api_key' => new EE_Text_Input( array(
					'html_label_text' => sprintf( __("Mollie API Key %s", "event_espresso"), $this->get_help_tab_link() ),
					'required' => true
				)),
				'mollie_locale' => new EE_Select_Input(
                    array(
                        null => __('Default (Browsers locale)', 'event_espresso'),
                        'en_US' => __('English', 'event_espresso'),
                        'de_DE' => __('German', 'event_espresso'),
                        'de_CH' => __('German (Switzerland)', 'event_espresso'),
                        'de_AT' => __('German (Somethig)', 'event_espresso'),
                        'es_ES' => __('Spanish', 'event_espresso'),
                        'fr_FR' => __('French', 'event_espresso'),
                        'fr_BE' => __('French (Belgium)', 'event_espresso'),
                        'nl_NL' => __('Dutch', 'event_espresso'),
                        'nl_BE' => __('Dutch (Belgium)', 'event_espresso')
                    ),
                    array(
                        'html_label_text' => sprintf(__("Checkout locale %s", 'event_espresso'), $this->get_help_tab_link()),
                        'html_help_text' => __("This is the locale sent to Mollie to determine which language the checkout modal should use.", 'event_espresso')
                    )
                )
			),
			'exclude' => array( 'PMD_debug_mode' ),
		));

		return $form;
	}


	/**
	 * Creates the billing form for this payment method type.
	 * @param \EE_Transaction $transaction
	 * @return null
	 */
	public function generate_new_billing_form( EE_Transaction $transaction = null ) {
		return null;
	}


	public function help_tabs_config() {
		return array(
			$this->get_help_tab_name() => array(
				'title' => __('Mollie Settings', 'event_espresso'),
				'filename' => 'payment_methods_overview_ideal_mollie'
			),
		);
	}

}

// End of file EE_PMT_Ideal_Mollie.pm.php
