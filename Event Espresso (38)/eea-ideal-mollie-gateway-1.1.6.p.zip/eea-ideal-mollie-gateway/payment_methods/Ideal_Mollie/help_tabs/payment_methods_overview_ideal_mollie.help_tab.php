<p><strong><?php _e('Mollie Payment Method', 'event_espresso'); ?></strong></p>
	<?php _e('Your attendees can register quickly and pay securely with Mollie (which supports payment services like credit cards, iDEAL, SEPA, etc) and you’ll receive payments in your merchant account.', 'event_espresso'); ?>
</p>
<p>
	<?php _e('After the consumer selects the iDEAL payment method the consumer’s bank is selected. The actual payment then takes place in the bank’s trusted online banking environment – for which security is guaranteed by the bank.', 'event_espresso'); ?>
</p>
<p>
	<?php printf( __('Adjust the settings for the Mollie payment method.', 'event_espresso') ); ?>
</p>
<p><strong><?php _e('Mollie Settings', 'event_espresso'); ?></strong></p>
<ul>
	<li>
		<strong><?php _e('Mollie API Key', 'event_espresso'); ?></strong><br />
		<?php printf( __('Enter your Mollie API Key. Your API Key can be found in your %s Mollie account dashboard. %s', 'event_espresso'), '<a href="https://www.mollie.com/beheer/account/profielen/" target="_blank">', '</a>'); ?>
	</li>
	<li>
		<strong><?php _e('Mollie Debug Mode', 'event_espresso'); ?></strong><br />
		<?php printf( __('To create test payments you will need to use the %s Mollie Test API key %s. Using Test API key will cause your Mollie Gateway to (automatically) only create test payments. Both, Test and Live API Keys can be found in %s your dashboard. %s', 'event_espresso'), '<b>', '</b>', '<a href="https://www.mollie.com/beheer/account/profielen/" target="_blank">', '</a>'); ?>
	</li>
</ul>