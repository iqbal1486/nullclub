<?php

if (!defined('EVENT_ESPRESSO_VERSION')) {
    exit('No direct script access allowed');
}



/**
 *
 * EEG_Ideal_Mollie
 *
 * @package			Event Espresso
 * @subpackage		eea-ideal-mollie-gateway
 * @author			Event Espresso
 *
 */
class EEG_Ideal_Mollie extends EE_Offsite_Gateway
{

    /**
     *
     * @var $_Ideal_Mollie_api_key string.
     */
    protected $_api_key = null;

    /**
     *
     * @var $_Ideal_Mollie_mollie_locale string.
     */
    protected $_mollie_locale = null;
    /**
     *
     * @var $mollie  Mollie_API_Client Object.
     */
    protected $mollie = null;

    /**
     *
     * @var $payment_id string.
     */
    protected $payment_id = null;

    protected $_currencies_supported = array(
        'EUR'
    );


    /**
     * @return EEG_Ideal_Mollie
     */
    public function __construct()
    {
        $this->set_uses_separate_IPN_request(true);
        parent::__construct();
    }


    /**
     * @param EEI_Payment $payment      to process
     * @param array       $billing_info but should be empty for this gateway
     * @param string      $return_url   URL to send the user to after payment on the payment provider's website
     * @param string      $notify_url   URL to send the instant payment notification
     * @param string      $cancel_url   URL to send the user to after a cancelled payment attempt on teh payment provider's website
     * @return EEI_Payment
     */
    public function set_redirection_info(
        $payment,
        $billing_info = array(),
        $return_url = null,
        $notify_url = null,
        $cancel_url = null
    )
    {
        $redirect_args = array();
        $transaction = $payment->transaction();
        $primary_registrant = $transaction->primary_registration();
        $gateway_formatter  = $this->_get_gateway_formatter();
        $order_description  = $gateway_formatter->formatOrderDescription($payment);

        $amount = $gateway_formatter->formatCurrency( $payment->amount() ); 

        $redirect_args['amount'] = $amount;
        $redirect_args['description'] = $order_description;
        $redirect_args['redirectUrl'] = $return_url;
        $redirect_args['webhookUrl'] = $notify_url;

        if ( $this->_mollie_locale ) {
            $redirect_args['locale'] = $this->_mollie_locale;
        }

        // Load and setup Mollie API.
        $mollie = $this->load_mollie();
        try {
            $mollie_payment = $mollie->payments->create($redirect_args);
        } catch (Mollie_API_Exception $e) {
            $this->log(
                array(
                    'log_description' => __('Exception thrown while creating a Mollie payment', 'event_espresso'),
                    'message'         => $e->getMessage(),
                    'payment'         => $payment->model_field_array(),
                ),
                $payment
            );
            $payment->set_status($this->_pay_model->failed_status());
            $payment->set_gateway_response($e->getMessage());
            return $payment;
        }

        $payment->set_txn_id_chq_nmbr($mollie_payment->id);
        $payment->set_redirect_url($mollie_payment->links->paymentUrl);

        return $payment;
    }


    /**
     * Handles the payment update (Webhook).
     *
     * @param array $update_info like $_POST
     * @param EEI_Transaction $transaction
     * @return EE_Payment updated
     * @throws EE_Error
     */
    public function handle_payment_update($update_info, $transaction)
    {
        // Verify there's a payment ID in the IPN.
        // If no ID then pull the last payment object from the transaction and return it if Approved.
        // If the payment is not Approved, check with Mollie if the payment is valid.
        // The IPN should've updated the payment before the return page.
        if (!isset($update_info['id']) || empty($update_info['id'])) {
            $payment = $transaction->last_payment();
            if($payment->is_approved()) {
                return $payment;
            }
            $this->log(
                array(
                    'message'   => __('No ID set on IPN request data so using the last payment from the transaction', 'event_espresso'),
                    'payment'   => $payment->model_field_array(),
                    'IPN_data'  => $update_info,
                ),
                $payment
            );
        } else { // IPN call from Mollie, so lets process the payment.
            add_filter('FHEE__EES_Espresso_Txn_Page__run__exit', array($this, 'send_response_and_exit'));
            $payment = $this->_pay_model->get_payment_by_txn_id_chq_nmbr($update_info['id']);
        }

        if ($payment && $payment instanceof EEI_Payment) {
            $mollie = $this->load_mollie();
            try {
                $mollie_payment = $mollie->payments->get($payment->txn_id_chq_nmbr());
            } catch (Mollie_API_Exception $e) {
                $payment->set_status($this->_pay_model->declined_status());
                $payment->set_gateway_response($e->getMessage());
                $this->log(
                    array(
                        'log_description' => __('Exception thrown while retrieving a Mollie payment', 'event_espresso'),
                        'message' => $e->getMessage(),
                        'payment' => $payment->model_field_array(),
                    ),
                    $payment
                );
                return $payment;
            }

            if ($mollie_payment->isPaid()) {
                $payment_status = $this->_pay_model->approved_status();
                $gateway_response = __('Your payment was approved.', 'event_espresso');
            } elseif (!$mollie_payment->isOpen()) {
                $payment_status = $this->_pay_model->declined_status();
                $gateway_response = __('Your payment has been declined.', 'event_espresso');
            } else {
                $payment_status = $this->_pay_model->pending_status();
                $gateway_response = __(
                    'Your payment is in progress. Another message should be sent when payment is approved.',
                    'event_espresso'
                );
            }

            $payment->set_status($payment_status);
            $payment->set_amount(floatval($mollie_payment->amount));
            $payment->set_gateway_response($gateway_response);
            $payment->set_details($update_info);
            $this->log(
                array(
                    'message'        => __('Updated payment from IPN that came from Mollie', 'event_espresso'),
                    'payment'        => $payment->model_field_array(),
                    'IPN_data'       => $update_info,
                    'mollie payment' => $mollie_payment
                ),
                $payment
            );

            return $payment;
        } else {
            throw new EE_Error(
                sprintf(__("Could not find Mollie payment for transaction %s", 'event_espresso'),
                $transaction->ID())
            );
        }
    }


    /**
     * Send OK response on IPN call and exit.
     *
     * @return bool  exit/not.
     */
    public function send_response_and_exit($do_exit)
    {
        echo '200 OK';
        return true;
    }


    /**
     * Load and setup Mollie API.
     *
     * @return Mollie_API_Client.
     */
    public function load_mollie()
    {
        if (!class_exists('Mollie_API_Client')) {
            require_once( EEA_IDEAL_MOLLIE_PATH . 'api_src/Mollie/API/Autoloader.php' );
        }
        $mollie = new Mollie_API_Client;
        $mollie->setApiKey($this->_api_key);
        return $mollie;
    }
}

// End of file EEG_Ideal_Mollie.gateway.php
