<?php if ( ! defined( 'EVENT_ESPRESSO_VERSION' )) { exit('NO direct script access allowed'); }
/**
* This file contains the definition of the iPay88 Gateway Config.
*
**/

/**
* ------------------------------------------------------------------------
* EE_IPay88_Gateway_Config class
*
* Class defining the iPay88 Gateway Config object stored on EE_Registry::instance->CFG.
*
* @since 1.0.0
*
* @package        EE iPay88 Gateway
* @subpackage     admin
*
* ------------------------------------------------------------------------
*/

class EE_IPay88_Gateway_Config extends EE_Config_Base {

    /**
     * 
     * @var boolean
     */
    public $widget;

    /**
     * Class constructor.
     */
    public function __construct() {
        $this->widget = FALSE;
    }

}