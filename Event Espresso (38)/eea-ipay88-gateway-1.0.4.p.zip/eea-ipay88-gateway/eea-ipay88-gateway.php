<?php
/*
  Plugin Name: Event Espresso - iPay88 Payment Gateway (EE 4.8+)
  Plugin URI: https://eventespresso.com/
  Description: iPay88 is an off-site payment method for Event Espresso accepting credit and debit cards and is available to event organizers in Malaysia and Indonesia. An account with iPay88 is required to accept payments.

  Version: 1.0.4.p

  Usage: This plugin will add an iPay88 gateway to an existing list of EE4 gateways. Configure your iPay88 gateway credentials under Event Espresso -> Payment Methods.
  Author: Event Espresso
  Author URI: https://eventespresso.com

  Copyright (c) 2008-2014  Event Espresso  All Rights Reserved.

     This program is free software; you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation; either version 2 of the License, or
     (at your option) any later version.

     This program is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
     GNU General Public License for more details.

     You should have received a copy of the GNU General Public License
     along with this program; if not, write to the Free Software
     Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */

// Define version.
define( 'EE_IPAY88_GATEWAY_VERSION', '1.0.4.p' );
define( 'EE_IPAY88_GATEWAY_PLUGIN_FILE', __FILE__ );

function load_ee4_ipay88_gateway() {
  if ( class_exists( 'EE_Addon' ) ) {
    require_once( plugin_dir_path( __FILE__ ) . 'EE_IPay88_Gateway.class.php' );
    EE_IPay88_Gateway::register_addon();
  }
}
add_action('AHEE__EE_System__load_espresso_addons', 'load_ee4_ipay88_gateway');

// Location: /wp-content/plugins/eea-ipay-88/eea-ipay88-gateway.php
