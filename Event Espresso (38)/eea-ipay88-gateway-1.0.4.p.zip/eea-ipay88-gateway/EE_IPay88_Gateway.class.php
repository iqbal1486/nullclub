<?php if ( ! defined( 'EVENT_ESPRESSO_VERSION' ) ) { exit('NO direct script access allowed'); }
/**
 * ------------------------------------------------------------------------
 *
 * Class  EE_IPay88_Gateway
 *
 * @package         Event Espresso
 * @subpackage      espresso-ipay88-gateway
 * @author          Event Espresso
 *
 * ------------------------------------------------------------------------
 */

// define the plugin directory path and URL.
define( 'EE_IPAY88_GATEWAY_PATH', plugin_dir_path( __FILE__ ));
define( 'EE_IPAY88_GATEWAY_URL', plugin_dir_url( __FILE__ ));
define( 'EE_IPAY88_GATEWAY_BASENAME', plugin_basename( EE_IPAY88_GATEWAY_PLUGIN_FILE ));
define( 'EE_IPAY88_GATEWAY_ADMIN', EE_IPAY88_GATEWAY_PATH . 'admin' . DS . 'ipay88_gateway' . DS );


class EE_IPay88_Gateway extends EE_Addon {

    /**
     * Class constructor.
     */
    public function __construct() {

    }

    /**
     * Register our gateway in EE.
     *
     * @access public
     * @return void
     */
    public static function register_addon() {
        // Register our add-on via Plugin API.
        EE_Register_Addon::register(
            'iPay88_Gateway',
            array(
                'version' => EE_IPAY88_GATEWAY_VERSION,
                'min_core_version' => '4.8.0',
                'main_file_path' => EE_IPAY88_GATEWAY_PLUGIN_FILE,
                'admin_callback' => 'additional_admin_hooks',
                'pue_options' => array(
                    'pue_plugin_slug' => 'eea-ipay88-gateway',
                    'plugin_basename' => EE_IPAY88_GATEWAY_BASENAME,
                    'checkPeriod' => '24',
                    'use_wp_update' => false
                ),
                'payment_method_paths' => array(
                    EE_IPAY88_GATEWAY_PATH . 'payment_methods' . DS . 'IPay88'
                )
            )
        );
    }


    /**
     *  Setup default data for the add-on.
     *
     *  @access public
     *  @return void
     */
    public function initialize_default_data() {
        parent::initialize_default_data();

        // Setup default currencies supported by this gateway (if list updated).
        $ipay88 = EEM_Payment_method::instance()->get_one_of_type( 'iPay88_Gateway' );
        // Update if the Payment Method exists.
        if ( $ipay88 ) {
            $currencies = $ipay88->get_all_usable_currencies();
            $all_related = $ipay88->get_many_related( 'Currency' );

            if ( $currencies != $all_related ) {
                $ipay88->_remove_relations( 'Currency' );
                foreach ( $currencies as $currency_obj ) {
                    $ipay88->_add_relation_to( $currency_obj, 'Currency' );
                }
            }
        }
    }


    /**
     *  Additional admin hooks.
     *
     * @access public
     * @return void
     */
    public static function additional_admin_hooks() {
        // Is admin and not in M-Mode ?
        if ( is_admin() && ! EE_Maintenance_Mode::instance()->level() ) {
            add_filter( 'plugin_action_links', array('EE_IPay88_Gateway', 'espresso_ipay88_plugin_settings'), 10, 2 );
        }
    }

    /**
     * Add a settings link to the Plugins page.
     *
     * @param array $links  List of existing links.
     * @param string $file  Main plugins file name.
     * @return array  Updated Links list
     */
    public static function espresso_ipay88_plugin_settings( $links, $file ) {
        if ( $file == EE_IPAY88_GATEWAY_BASENAME ) {
            $mci_settings = '<a href="admin.php?page=espresso_payment_settings">' . __('Settings') . '</a>';
            array_unshift($links, $mci_settings);
        }
        return $links;
    }

}
