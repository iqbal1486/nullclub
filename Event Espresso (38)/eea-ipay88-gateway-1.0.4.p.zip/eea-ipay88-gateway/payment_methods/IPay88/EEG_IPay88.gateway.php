<?php if ( ! defined( 'EVENT_ESPRESSO_VERSION' )) { exit('NO direct script access allowed'); }

/**
 * ------------------------------------------------------------------------
 *
 * EEG_IPay88
 *
 * @package			Event Espresso
 * @subpackage		espresso-ipay88-gateway
 *
 * ------------------------------------------------------------------------
 */
class EEG_IPay88 extends EE_Offsite_Gateway {

	/**
	 *
	 * @var $iPay88_integration_type string
	 */
	protected $_iPay88_integration_type = null;

	/**
	 *
	 * @var $iPay88_merchant_key string
	 */
	protected $_iPay88_merchant_key = null;

	/**
	 *
	 * @var $iPay88_merchant_code string
	 */
	protected $_iPay88_merchant_code = null;

	/**
	 *
	 * @var $_base_gateway_url string
	 */
	protected $_base_gateway_url = null;

	/**
	 *
	 * @var $_currencies_supported array with the supported currencies
	 */
	protected $_currencies_supported = array(
		'IDR',
		'MYR'
	);


	/**
	 * @return EEG_IPay88
	 */
	public function __construct() {
		$this->set_uses_separate_IPN_request( true ) ;
		parent::__construct();
	}


    /**
     * Sets the gateway url variable based on whether debug mode is enabled or not.
     *
     * @param type $settings_array
     */
    public function set_settings( $settings_array ) {
        parent::set_settings($settings_array);
        if ( $this->_iPay88_integration_type === 'indonesian' ) {
            // Indonesian integration.
            if ( $this->_debug_mode ) {
                $this->_base_gateway_url = 'https://sandbox.ipay88.co.id/epayment/';
            } else {
                $this->_base_gateway_url = 'https://payment.ipay88.co.id/epayment/';
            }
        } else {
            // Different URLs are used for Malaysian integration.
            if ( $this->_debug_mode ) {
                $this->_base_gateway_url = 'https://payment.ipay88.com.my/epayment/';
            } else {
                $this->_base_gateway_url = 'https://payment.ipay88.com.my/epayment/';
            }
        }
    }


	/**
	 *
	 * @param EEI_Payment $payment      to process
	 * @param array       $billing_info but should be empty for this gateway
	 * @param string      $return_url   URL to send the user to after payment on the payment provider's website
	 * @param string      $notify_url   URL to send the instant payment notification
	 * @param string      $cancel_url   URL to send the user to after a canceled payment attempt on teh payment provider's website
	 * @return EEI_Payment
	 */
	public function set_redirection_info( $payment, $billing_info = array(), $return_url = null, $notify_url = null, $cancel_url = null ) {
		if ( empty($billing_info) ) {
			$billing_info = $_POST['IPay88_Billing_Form'];
		}
		$redirect_args = array();
		$transaction = $payment->transaction();
		$primary_registrant = $transaction->primary_registration();
		$order_description  = $this->_get_gateway_formatter()->formatOrderDescription($payment);
		$ref_number = wp_generate_password(12, false);
		if ( $this->_iPay88_integration_type === 'indonesian' ) {
			$amount = str_replace( array(',', '.'), '', number_format( $payment->amount(), 2) );
		} else {
			$amount = $this->format_currency( $payment->amount() );
		}
		$signature_params = array(
			'MerchantCode' => $this->_iPay88_merchant_code,
			'RefNo' => $ref_number,
			'Amount' => $amount,
			'Currency' => $payment->currency_code()
		);

		$the_signature = $this->generate_signature($signature_params);
		if ( ! $the_signature ) {
			$gateway_response = __('Failed to generate a Signature !', 'event_espresso');
			$payment->set_gateway_response( $gateway_response );
			$payment->set_status( $this->_pay_model->failed_status() );
			$this->log( array($gateway_response => $signature_params), $payment );
			return $payment;
		}

		$redirect_args['MerchantCode'] = $this->_iPay88_merchant_code;   // The Merchant Code provided by iPay88 and use to uniquely identify the Merchant.
		if ( $this->_iPay88_integration_type === 'indonesian' ) {
			$redirect_args['PaymentId'] = '1';	// Indonesian integration.
		} else {
			$redirect_args['PaymentId'] = '2';	// Malaysia.
		}
		$redirect_args['RefNo'] = $ref_number;   // Unique merchant transaction number / Order ID.
		$redirect_args['Amount'] = $amount;   // The amount must not contain any decimal points.
		$redirect_args['Currency'] = $payment->currency_code();
		$redirect_args['ProdDesc'] = $order_description;   // Product description.

		$redirect_args['UserName'] = $billing_info['first_name'] . ' ' . $billing_info['last_name'];   // Customer name.
		$redirect_args['UserEmail'] = $billing_info['email'];   // Customer email for receiving receipt.
		$redirect_args['UserContact'] = $billing_info['contact_number'];   // Customer contact number.

		$redirect_args['Signature'] = $the_signature;   // SHA1 signature.
		$redirect_args['ResponseURL'] = $return_url;   // Payment response page.
		$redirect_args['BackendURL'] = $notify_url;   // Back-end response page URL.
		$payment->set_redirect_url( $this->_base_gateway_url . 'entry.asp' );
		$payment->set_redirect_args( $redirect_args );
		$this->log( array('iPay88 Request' => $redirect_args), $payment );

		return $payment;
	}


	/**
	 * Handles the payment update.
	 *
	 * @param array $update_info like $_POST
	 * @param EEI_Transaction $transaction
	 * @return EE_Payment updated
	 * @throws EE_Error
	 */
	public function handle_payment_update( $update_info, $transaction ) {
		$gateway_response = '';
		$payment = false;
		if ( isset($update_info['txn_id']) ) {
			$payment = $this->_pay_model->get_payment_by_txn_id_chq_nmbr( $update_info['txn_id'] );
		}
		if ( ! $payment instanceof EEI_Payment ) {
			$payment = $transaction->last_payment();
		}

		// Check if payment processed bore; maybe by IPN ?
		if ( $payment instanceof EEI_Payment ) {
			//First log all of the incoming data
			$clean_info = $update_info;
			unset($clean_info['Signature']);
			$this->log( array('iPay88 Response' => $clean_info), $payment );
			
			// Check payment. Do Re-query.
			$requery = array(
				'MerchantCode' => $update_info['MerchantCode'],
				'RefNo' => $update_info['RefNo'],
				'Amount' => $update_info['Amount']
			);
			if ( $this->requery_payment_status($requery, $payment) !== '00' || $update_info['Status'] == '0' ) {
				$this->log( array('Failed to verify transaction! Requery:' => $requery), $payment );
				$payment_status = $this->_pay_model->declined_status();
				$gateway_response = ( ! empty($update_info['ErrDesc']) ) ? $update_info['ErrDesc'] : __('Failed to verify transaction!', 'event_espresso');
			} else {
				// Compare signature.
				$signature = array(
					'MerchantCode' => $update_info['MerchantCode'],
					'PaymentId' => $update_info['PaymentId'],
					'RefNo' => $update_info['RefNo'],
					'Amount' => $update_info['Amount'],
					'Currency' => $update_info['Currency'],
					'Status' => $update_info['Status']
				);
				$the_signature = $this->generate_signature($signature);
				$response_sign = trim($update_info['Signature']);
                // Sometimes the signature in the response includes spaces, where those have to be encoded.
				$clean_response_sign = str_replace(' ', '+', $response_sign);
				if (
					$the_signature
					&& ($the_signature === $response_sign || $the_signature === $clean_response_sign)
					&& ($update_info['Status'] == '1')
				) {
					$payment_txn_id = $update_info['TransId'];
					if ( $this->_iPay88_integration_type === 'indonesian' ) {
						$payment_amount = floatval( $update_info['Amount'] / 100 );
					} else{
						$payment_amount = str_replace(',', '', $update_info['Amount']);
					}
					$payment_status = $this->_pay_model->approved_status();
					$gateway_response = __('Your payment was approved.', 'event_espresso');
				} else {
					$this->log( array('Signature verification Failed! Signature:' => $signature), $payment );
					$payment_status = $this->_pay_model->declined_status();
					$gateway_response = __('Signature verification Failed!', 'event_espresso');
				}
			}

			// If this is a payment with the same amount and status - no need to update.
			if ( isset($payment_status) && $payment->status() == $payment_status && isset($payment_amount) && $payment->amount() == $payment_amount ) {
				return $payment;
			}

			if ( isset($payment_status) )
				$payment->set_status( $payment_status );
			if ( isset($payment_amount) )
				$payment->set_amount( $payment_amount );
			if ( isset($payment_txn_id) )
				$payment->set_txn_id_chq_nmbr( $payment_txn_id );
			$payment->set_gateway_response( $gateway_response );
			$payment->set_details( $clean_info );
		}

		return $payment;
	}


	/**
	 * Allows gateway to dynamically decide whether or not to handle a payment update.
	 *
	 * @param array $request_data
	 * @param boolean $separate_IPN_request
	 * @return boolean
	 */
	public function handle_IPN_in_this_request( $request_data, $separate_IPN_request ) {
		if ( has_filter('FHEE__EES_Espresso_Txn_Page__run__exit', array($this, 'send_response_and_exit')) ) {
			remove_filter( 'FHEE__EES_Espresso_Txn_Page__run__exit', array($this, 'send_response_and_exit') );
		}
		if ( $separate_IPN_request ) {
			add_filter( 'FHEE__EES_Espresso_Txn_Page__run__exit', array($this, 'send_response_and_exit') );
		}
		if ( ( $separate_IPN_request && isset($request_data['Status']) && $request_data['Status'] == '1' ) || ( ! $separate_IPN_request && isset($request_data['Status']) && $request_data['Status'] != '1' ) ) {
			// Payment data being sent in a request separate from the user.
			// It is this other request that will update the TXN and payment info.
			return $this->_uses_separate_IPN_request;
		} else {
			// It's a request where the user returned from an off-site gateway WITH the payment data.
			return ! $this->_uses_separate_IPN_request;
		}
	}


	/**
	 * Send OK response on IPN call and exit.
	 *
	 * @return bool  exit/not.
	 */
	public function send_response_and_exit( $do_exit ) {
		echo 'RECEIVEOK';
		return true;
	}


    /**
     * Re-query Payment Status.
     *
     * @param array $requery_data
     * @return boolean
     */
    public function requery_payment_status($requery_data, $payment) {
        // Send a POST request to iPay88 using the requery_data array.
        $post_url = $this->_base_gateway_url . 'enquiry.asp';
        $post_args = array(
            'method'      => 'POST',
            'timeout'     => 10,
            'body'        => $requery_data
        );
        $response = wp_remote_post($post_url, $post_args);

        // If we have a WP_Error object, log the error in the payment logs.
        if (is_wp_error($response)) {
            $this->log(
                array(
                    'iPay88 Requery Request Failed' => $response->get_error_message(),
                    'requery_data' => $requery_data
                ),
                $payment
            );
        } elseif(isset($response['body'])) {
            // Otherwise return the response body if we have one.
            $this->log(
                array(
                    'iPay88 Requery Request' => $response
                ),
               	$payment
            );
            return $response['body'];
        }

        // Still here? No body set on the response, failed requery.
        return false;
    }

	/**
	 * Generate signature to be used for transaction.
	 * Signature can be verified online:
	 * http://www.mobile88.com/epayment/testing/TestSignature.asp
	 *
	 * @access public
	 * @param array $params  Fields required to generate signature.
	 */
	public function generate_signature( $params = array() ) {
		$signature = '';
		$defaults = array(
			'MerchantCode' => '',
			'PaymentId' => '',
			'RefNo' => '',
			'Amount' => '',
			'Currency' => '',
			'Status' => ''
		);
		$signature_params = array_merge($defaults, $params);
		if ( $signature_params ) {
			$sign_params = array('MerchantCode', 'RefNo', 'Amount', 'Currency');
			foreach ( $sign_params as $val ) {
				if ( ! isset($signature_params[$val]) ) {
					return false;
				}
			}
			foreach ( $signature_params as $key => $val ) {
				// Some formatting.
				switch ($key) {
					case 'Amount':
						$signature_params[$key] = str_replace(array('.', ','), '', $val);
						break;
					case 'Lang':
						$signature_params[$key] = strtoupper($val);
						break;
				}
			}
		} else {
			return false;
		}

		$signature .= $this->_iPay88_merchant_key;
		$signature .= $signature_params['MerchantCode'];
		$signature .= $signature_params['PaymentId'];
		$signature .= $signature_params['RefNo'];
		$signature .= $signature_params['Amount'];
		$signature .= $signature_params['Currency'];
		$signature .= $signature_params['Status'];
		return base64_encode( $this->_hex2bin(sha1($signature)) );
	}


	/**
	*
	* @access private
	* @param string $hexSource  String to convert.
	* @return string  Binary representation of the string.
	*/
	private function _hex2bin( $hexSource ) {
		$bin = '';
	    for ( $i=0; $i < strlen($hexSource); $i=$i+2 ) {
	      $bin .= chr( hexdec(substr($hexSource, $i, 2)) );
	    }
		return $bin;
	}
}