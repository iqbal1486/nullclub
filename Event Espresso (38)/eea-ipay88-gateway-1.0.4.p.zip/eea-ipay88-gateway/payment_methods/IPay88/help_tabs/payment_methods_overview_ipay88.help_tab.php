<p><strong><?php _e('iPay88', 'event_espresso'); ?></strong></p>
<p>
    <?php _e('Adjust the settings for the iPay88 payment gateway.', 'event_espresso'); ?><br />
    <?php printf( __('Note that this gateway supports %1$s Malaysian and Indonesian iPay88 accounts %2$s.', 'event_espresso'), '<strong>', '</strong>' ); ?>
</p>
<p><strong><?php _e('iPay88 Settings', 'event_espresso'); ?></strong></p>
<ul>
    <li>
        <strong><?php _e('iPay88 Account Country', 'event_espresso'); ?></strong><br />
        <?php _e('Your iPay88 account\'s country division. If you got it from "ipay88.com" use "Indonesia", if you got it from "mobile88.com" use "Malaysia".', 'event_espresso'); ?>
    </li>
    <li>
        <strong><?php _e('iPay88 Merchant Code', 'event_espresso'); ?></strong><br />
        <?php _e('The Merchant Code provided by iPay88 and use to uniquely identify the Merchant.', 'event_espresso'); ?>
    </li>
    <li>
        <strong><?php _e('iPay88 Merchant Key', 'event_espresso'); ?></strong><br />
        <?php _e('The iPay88 OPSG Merchant Key is a shared secret (between merchant and iPay88 OPSG), and is one of the key pieces of information in the hash. One can be assured that if the signature generated on your end matched the one sent with the
            transaction, then the transaction has in fact been processed by our system, and has not been posted back to the merchant’s server from any other location.', 'event_espresso'); ?>
    </li>
    <li>
        <strong><?php _e('Image URL', 'event_espresso'); ?></strong><br />
        <?php _e('Select an image / logo that should be shown on the payment page for iPay88.', 'event_espresso'); ?>
    </li>
    <li>
        <strong><?php _e('Use the Debug Mode', 'event_espresso'); ?></strong><br />
        <?php _e('Specify if you want to test the payment gateway by submitting a test transaction. If this option is enabled, be sure to enter your iPay sandbox credentials in the fields above. Be sure to turn this setting off when you are done testing.', 'event_espresso'); ?><br />
        <p>
            <strong><?php _e('! Important Notice for testing process:', 'event_espresso'); ?></strong><br />
            <?php printf( __('Test transaction must go from %1$s registered Request URL %2$s.', 'event_espresso'), '<strong>', '</strong>' ); ?><br />
            <?php printf( __('For %1$sIndonesian%2$s accounts test transaction should be with an amount of %1$s IDR 3.000,00%2$s.', 'event_espresso'), '<strong>', '</strong>' ); ?><br />
            <?php printf( __('For %1$sMalaysian%2$s accounts test transaction should be with an amount of %1$s MYR 1.00%2$s.', 'event_espresso'), '<strong>', '</strong>' ); ?><br />
            <?php printf( __('Test transaction limited to %1$s credit card ONLY %2$s.', 'event_espresso'), '<strong>', '</strong>' ); ?><br />
        </p>
    </li>
    <li>
        <strong><?php _e('Button Image URL', 'event_espresso'); ?></strong><br />
        <?php _e('Change the image that is used for this payment gateway.', 'event_espresso'); ?>
    </li>
    <li>
        <strong><?php _e('Country Currency', 'event_espresso'); ?></strong><br />
        <?php _e('Select the currency for your country. Payments will be accepted in this currency.', 'event_espresso'); ?>
    </li>
    <li>
        <strong><?php _e('Accepted Card Types', 'event_espresso'); ?></strong><br />
        <?php _e('Select the card types that you want to accept payments from.', 'event_espresso'); ?>
    </li>
</ul>