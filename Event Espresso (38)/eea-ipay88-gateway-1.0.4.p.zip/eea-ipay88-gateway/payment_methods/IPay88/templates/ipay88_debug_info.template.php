<?php if ( ! defined( 'EVENT_ESPRESSO_VERSION' ) ) { exit('No direct script access allowed'); }
/**
 * ------------------------------------------------------------------------
 *
 * ipay88_settings_before_form
 *
 * @package			Event Espresso
 * @subpackage		espresso-ipay88-gateway
 *
 * ------------------------------------------------------------------------
 */

/**
 * @var $form_section EE_Billing_Info_Form
 */
?>
    <div class="sandbox-panel">
        <h2 class="section-title"><?php esc_html_e('iPay88 Sandbox Mode', 'event_espresso'); ?></h2>
        <h3 style="color:#ff0000;"><?php esc_html_e('Debug Mode Is Turned On. Payments will not be processed', 'event_espresso'); ?></h3>

        <p class="test-credit-cards-info-pg">
            <strong><?php esc_html_e('Credit Card Numbers Used for Testing', 'event_espresso'); ?></strong><br/>
            <span class="small-text"><?php esc_html_e('Use the following credit card information for testing:', 'event_espresso'); ?></span>
        </p>

        <div class="tbl-wrap">
            <table id="ipay88-test-credit-cards" class="test-credit-card-data-tbl">
                <thead>
                    <tr>
                        <td><?php esc_html_e('Card Number', 'event_espresso'); ?></td>
                        <td><?php esc_html_e('CVV/CVV2', 'event_espresso'); ?></td>
                        <td><?php esc_html_e('Exp Date (DD/MM)', 'event_espresso'); ?></td>
                        <td><?php esc_html_e('Card Status', 'event_espresso'); ?></td>
                        <td><?php esc_html_e('Error message', 'event_espresso'); ?></td>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>4000000000000002</td>
                        <td>123</td>
                        <td>05/18</td>
                        <td>Good card</td>
                        <td>OK</td>
                    </tr>
                    <tr>
                        <td>5200000000000031</td>
                        <td>123</td>
                        <td>05/18</td>
                        <td>Good card</td>
                        <td>OK</td>
                    </tr>
                    <tr>
                        <td>4000000000000028</td>
                        <td>223</td>
                        <td>07/18</td>
                        <td>Bad Card</td>
                        <td>Bank declined transaction</td>
                    </tr>
                    <tr>
                        <td>5200000000000007</td>
                        <td>223</td>
                        <td>07/18</td>
                        <td>Bad Card</td>
                        <td>Bank declined transaction</td>
                    </tr>
                    <tr>
                        <td>5200000000000015</td>
                        <td>223</td>
                        <td>07/18</td>
                        <td>Bad Card</td>
                        <td>Bank declined transaction</td>
                    </tr>
                </tbody>
            </table>
        </div><br/>
    </div>
