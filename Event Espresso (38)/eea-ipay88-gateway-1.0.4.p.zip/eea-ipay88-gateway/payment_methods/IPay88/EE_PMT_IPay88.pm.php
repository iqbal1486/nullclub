<?php if ( ! defined( 'EVENT_ESPRESSO_VERSION' )) { exit('NO direct script access allowed'); }

/**
 * ------------------------------------------------------------------------
 *
 * EE_PMT_IPay88
 *
 * @package			Event Espresso
 * @subpackage		espresso-ipay88-gateway
 *
 * ------------------------------------------------------------------------
 */
class EE_PMT_IPay88 extends EE_PMT_Base {
	
	/**
     * Class constructor.
     */
	public function __construct( $pm_instance = NULL ) {
		require_once( $this->file_folder() . 'EEG_IPay88.gateway.php' );
		$this->_gateway = new EEG_IPay88();
		$this->_pretty_name = esc_html__( "IPay88", 'event_espresso' );
		$this->_template_path = dirname(__FILE__) . DS . 'templates' . DS;
		$this->_default_description = esc_html__( 'Please provide the following billing information.', 'event_espresso' );

		parent::__construct( $pm_instance );
		$this->_default_button_url = $this->file_url() . 'lib' . DS . 'ipay88-logo.png';
	}

	/**
	 * Generate a new payment settings form.
	 *
	 * @return EE_Payment_Method_Form
	 */
	public function generate_new_settings_form() {
		$integrations = $this->get_ipay_integration_types();
		return new EE_Payment_Method_Form( array(
			'extra_meta_inputs' => array(
				'iPay88_integration_type' => new EE_Select_Input( $integrations, array(
					'html_label_text' => sprintf( esc_html__("iPay88 Account Country %s", "event_espresso"), $this->get_help_tab_link() ),
					'default' => 'malaysian',
					'required' => true
				)),
				'iPay88_merchant_code' => new EE_Text_Input( array(
					'html_label_text' => sprintf( esc_html__("iPay88 Merchant Code %s", "event_espresso"), $this->get_help_tab_link() ),
					'required' => true
				)),
				'iPay88_merchant_key' => new EE_Text_Input( array(
					'html_label_text' => sprintf( esc_html__("iPay88 Merchant Key %s", "event_espresso"), $this->get_help_tab_link() ),
					'required' => true
				))
			)
		));
	}

	/**
	 * Creates the billing form for this payment method type.
	 *
	 * @return EE_Billing_Info_Form
	 */
	public function generate_new_billing_form( EE_Transaction $transaction = null ) {
		$form_name = 'IPay88_Billing_Form';

		$form_args = array(
			'name' => $form_name,
			'subsections' => array(
				'contact_number' => new EE_Text_Input( array(
					'html_class' => 'ee-billing-qstn',
					'html_label_text' => esc_html__( 'Phone Number', 'event_espresso' ),
					'required' => true
				))
			),
			'exclude' => array( 'phone', 'state', 'country', 'zip', 'city', 'address', 'address2' ),
		);

		$billing_form = new EE_Billing_Attendee_Info_Form( $this->_pm_instance, $form_args );

		// Put in the debug content.
		$this->apply_billing_form_debug_settings( $billing_form );
		
		return $billing_form;
	}


	/**
	 * Get supported integration types.
	 *
	 * @return array
	 */
	public function get_ipay_integration_types() {
		return array(
			'malaysian' => 'Malaysia',
			'indonesian' => 'Indonesia'
		);
	}


	/**
	 * apply_billing_form_debug_settings
	 * applies debug data to the form
	 *
	 * @param \EE_Billing_Info_Form $billing_form
	 * @return \EE_Billing_Info_Form
	 */
	public function apply_billing_form_debug_settings( EE_Billing_Info_Form $billing_form ) {
		if ( $this->_pm_instance->debug_mode() ) {
			$billing_form->add_subsections(
				array( 'fyi_about_autofill' => $billing_form->payment_fields_autofilled_notice_html() ),
				'contact_number'
			);
			$billing_form->add_subsections(
				array( 'debug_content' => new EE_Form_Section_HTML_From_Template( dirname(__FILE__) . DS . 'templates' . DS . 'ipay88_debug_info.template.php' ) ),
				'first_name'
			);

			$billing_form->get_input('contact_number')->set_default('025 25 259');
		}
		return $billing_form;
	}

	/**
	 * Adds the help tab for this payment method type.
	 *
	 * @see EE_PMT_Base::help_tabs_config()
	 * @return array 
	 */
	public function help_tabs_config() {
		return array(
			$this->get_help_tab_name() => array(
				'title' =>  esc_html__("iPay88 Settings", 'event_espresso'),
				'filename' => 'payment_methods_overview_ipay88'
			)
		);
	}
}