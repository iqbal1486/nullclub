<?php if ( ! defined( 'EVENT_ESPRESSO_VERSION' )) { exit('NO direct script access allowed'); }


define( 'EEA_CYBERSOURCE_PLUGIN_BASENAME', plugin_basename(EEA_CYBERSOURCE_PLUGIN_FILE) );
define( 'EEA_CYBERSOURCE_PLUGIN_URL', plugin_dir_url(EEA_CYBERSOURCE_PLUGIN_FILE) );


/**
 * Class EE_CyberSource_Gateway
 *
 * @package			Event Espresso
 * @subpackage		eea-cybersource-gateway
 * @author			Event Espresso
 * @version			2.0.1.p
 */
class EE_CyberSource_Gateway extends EE_Addon {


	/**
	 *	Class constructor
	 *	@return EE_CyberSource_Gateway
	 */
	function __construct() {

	}


	/**
	 *	Register this add-on.
	 *
	 *	@access public
	 *	@return void
	 */
	public static function register_addon() {
		// Register this PM Add-on via a Plugin API.
		EE_Register_Addon::register(
			'CyberSource_Gateway',
			array(
				'version' => EEA_CYBERSOURCE_VERSION,
				'min_core_version' => '4.8.0',
				'main_file_path' => EEA_CYBERSOURCE_PLUGIN_FILE,
				'admin_callback' => 'additional_cybersource_admin_hooks',
				'autoloader_paths' => array(
					'EE_PMT_Base' => EE_LIBRARIES . 'payment_methods' . DS . 'EE_PMT_Base.lib.php',
					'EE_PMT_CyberSource_Offsite' => EEA_CYBERSOURCE_PLUGIN_PATH . 'payment_methods' . DS . 'CyberSource_Offsite' . DS . 'EE_PMT_CyberSource_Offsite.pm.php',
				),
				'pue_options' => array(
					'pue_plugin_slug' => 'eea-cybersource-gateway',
					'plugin_basename' => EEA_CYBERSOURCE_PLUGIN_BASENAME,
					'checkPeriod' => '24',
					'use_wp_update' => false
				),
				'payment_method_paths' => array(
					EEA_CYBERSOURCE_PLUGIN_PATH . 'payment_methods' . DS . 'CyberSource_Offsite'
				)
			)
		);
	}


	/**
	 *	Initialize data.
	 *
	 * @access public
	 * @return void
	 */
	public function initialize_default_data() {
		parent::initialize_default_data();
		// Update the currencies supported by this gateway (if changed).
		$cs = EEM_Payment_method::instance()->get_one_of_type( 'CyberSource_Offsite' );
		// Update If the payment method already exists.
		if ( $cs ) {
			$currencies = $cs->get_all_usable_currencies();
			$all_related = $cs->get_many_related( 'Currency' );
			if ( ( $currencies != $all_related ) ) {
				$cs->_remove_relations( 'Currency' );
				foreach ( $currencies as $currency_obj ) {
					$cs->_add_relation_to( $currency_obj, 'Currency' );
				}
			}
		}
	}


	/**
	 *	Additional admin hooks.
	 *
	 *	@access public
	 *	@return void
	 */
	public static function additional_cybersource_admin_hooks() {
		// is admin and not in M-Mode ?
		if ( is_admin() && ! EE_Maintenance_Mode::instance()->level() ) {
			add_filter( 'plugin_action_links', array( 'EE_CyberSource_Gateway', 'plugin_actions' ), 10, 2 );
		}
	}


	/**
	 *	Add a settings link to the Plugins page.
	 *
	 *	@param $links
	 *	@param $file
	 *	@return array
	 */
	public static function plugin_actions( $links, $file ) {
		if ( $file == EEA_CYBERSOURCE_PLUGIN_BASENAME ) {
			// Before other links
			array_unshift( $links, '<a href="admin.php?page=espresso_payment_settings">' . __('Settings') . '</a>' );
		}
		return $links;
	}

}