<?php if ( ! defined( 'EVENT_ESPRESSO_VERSION' )) { exit('NO direct script access allowed'); }


/**
 * ------------------------------------------------------------------------
 *
 * EE_PMT_CyberSource_Offsite
 *
 * @package			Event Espresso
 * @subpackage		eea-cybersource-gateway
 * @author			Event Espresso
 * @version			2.0.1.p
 *
 * ------------------------------------------------------------------------
 */
class EE_PMT_CyberSource_Offsite extends EE_PMT_Base {

	/**
     * Class constructor.
     */
	public function __construct( $pm_instance = NULL ) {
		require_once( EEA_CYBERSOURCE_PLUGIN_PATH . 'payment_methods' . DS . 'CyberSource_Offsite' . DS . 'EEG_CyberSource_Offsite.gateway.php' );
		$this->_gateway = new EEG_CyberSource_Offsite();
		$this->_pretty_name = __( 'CyberSource', 'event_espresso' );
		$this->_template_path = dirname(__FILE__) . DS . 'templates' . DS;
		$this->_default_description = sprintf( __( 'After clicking \'Finalize Registration\', you will be forwarded to a secure checkout hosted by CyberSource to make your payment. %1$sMake sure you return to this site in order to properly finalize your registration.%2$s', 'event_espresso' ), '<strong>', '</strong>' );
		$this->_default_button_url = EEA_CYBERSOURCE_PLUGIN_URL . 'payment_methods' . DS . 'CyberSource_Offsite' . DS . 'lib' . DS . 'cybersource-checkout-logo.png';
		$this->_cache_billing_form = false;

		parent::__construct( $pm_instance );
	}


	/**
	 * Generate a new payment settings form.
	 *
	 * @return EE_Payment_Method_Form
	 */
	public function generate_new_settings_form() {
		return new EE_Payment_Method_Form( array(
			'extra_meta_inputs' => array(
				'cybersource_profile_id' => new EE_Text_Input( array(
					'html_label_text' => sprintf( __('CyberSource Profile ID %s', 'event_espresso'), $this->get_help_tab_link() ),
					'required' => true
				)),
				'cybersource_access_key' => new EE_Text_Input( array(
					'html_label_text' => sprintf( __('CyberSource Access Key %s', 'event_espresso'), $this->get_help_tab_link() ),
					'required' => true
				)),
				'cybersource_secret_key' => new EE_Text_Input( array(
					'html_label_text' => sprintf( __('CyberSource Secret Key %s', 'event_espresso'), $this->get_help_tab_link() ),
					'required' => true
				))
			)
		));
	}


	/**
	 *	Creates a billing form for this payment method type.
	 *
	 *	@param \EE_Transaction $transaction
	 *	@return \EE_Billing_Info_Form
	 */
	public function generate_new_billing_form( EE_Transaction $transaction = null ) {
		$settings = $this->_pm_instance->settings_array();
		$form = new EE_Billing_Info_Form(
			$this->_pm_instance,
			array(
				'name' => 'CyberSource_Info_Form',
				'html_id'=> 'cybersource-info-form',
				'subsections' => array(
					new EE_Form_Section_Proper(
						array(
							'layout_strategy' => new EE_Template_Layout(
								array(
									'layout_template_file' => $this->_template_path . 'cybersource_debug_info.template.php',
									'template_args' => array( 'debug_mode' => $this->_pm_instance->debug_mode() )
								)
							)
						)
					)
				)
			)
		);

		return $form;
	}

	
	/**
	 * Adds the help tab for this payment method type.
	 *
	 * @see EE_PMT_Base::help_tabs_config()
	 * @return array 
	 */
	public function help_tabs_config() {
		return array(
			$this->get_help_tab_name() => array(
				'title' =>  __('CyberSource Settings', 'event_espresso'),
				'filename' => 'payment_methods_overview_cybersource'
			)
		);
	}

}