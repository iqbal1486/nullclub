<?php if ( ! defined( 'EVENT_ESPRESSO_VERSION' )) { exit('NO direct script access allowed'); }


/**
 * ------------------------------------------------------------------------
 *
 * EEG_CyberSource_Offsite
 *
 * @package			Event Espresso
 * @subpackage		eea-cybersource-gateway
 * @author			Event Espresso
 * @version			2.0.1.p
 *
 * ------------------------------------------------------------------------
 */
 class EEG_CyberSource_Offsite extends EE_Offsite_Gateway {

	/**
	 *
	 * @var $_cybersource_profile_id string
	 */
	protected $_cybersource_profile_id = null;

	/**
	 *
	 * @var $_cybersource_access_key string
	 */
	protected $_cybersource_access_key = null;

	/**
	 *
	 * @var $_cybersource_secret_key string
	 */
	protected $_cybersource_secret_key = null;

	/**
	 *
	 * @var $_currencies_supported array with the supported currencies
	 */
	protected $_currencies_supported = EE_Gateway::all_currencies_supported;

	/**
	 * Sets the gateway url variable based on whether debug mode is enabled or not.
	 *
	 * @param type $settings_array
	 */
	public function set_settings( $settings_array ) {
		parent::set_settings($settings_array);
		if ( $this->_debug_mode ) {
			$this->_gateway_url = 'https://testsecureacceptance.cybersource.com/pay';
		} else {
			$this->_gateway_url = 'https://secureacceptance.cybersource.com/pay';
		}
	}
	

	/**
	 *
	 * @param EEI_Payment $payment      to process
	 * @param array       $billing_info but should be empty for this gateway
	 * @param string      $return_url   URL to send the user to after payment on the payment provider's website
	 * @param string      $notify_url   URL to send the instant payment notification
	 * @param string      $cancel_url   URL to send the user to after a cancelled payment attempt on teh payment provider's website
	 * @return EEI_Payment
	 */
	public function set_redirection_info( $payment, $billing_info = array(), $return_url = null, $notify_url = null, $cancel_url = null ) {
		$request_fields = array();
		$transaction = $payment->transaction();

		$request_fields['access_key'] = $this->_cybersource_access_key;  // Required for authentication with Secure Acceptance.
		$request_fields['profile_id'] = $this->_cybersource_profile_id;  // Identifies the profile to use with each transaction.
		$request_fields['currency'] = $payment->currency_code();   // Currency used for the order. For the possible values, see the CyberSource ISO currency codes.
		$request_fields['amount'] = str_replace( ',', '', number_format($transaction->total(), 2) );    // Total amount for the order. Must be greater than or equal to zero and must equal the total amount of each line item including the tax amount.

		// Generate RefNo.
		$trans_id = $transaction->ID();
		$transaction_id = ( ! empty($trans_id) ) ? $trans_id : uniqid();
		$ref_prelength = 13 - strlen( (string) $transaction_id );
		$pre_num = ( $ref_prelength >= 2 ) ? substr(number_format(time() * rand(), 0, '', ''), 0, $ref_prelength - 1) : '';
		$ref_number =  'EV' . $pre_num . '-' . $transaction_id;

		$request_fields['reference_number'] = $ref_number;  // Unique merchant-generated order reference or tracking number for each transaction.
		$request_fields['transaction_type'] = 'sale';  // The type of transaction. Required by the Secure Acceptance application.
		$request_fields['locale'] = 'en';   // Indicates the language to use for customer-facing content. Possible value: en-us.
		$request_fields['transaction_uuid'] = uniqid(); // Unique merchant-generated identifier. Include with the access_key field for each transaction. This identifier must be unique for each transaction. This field is used to check for duplicate transaction attempts.
		$request_fields['signed_date_time'] = gmdate("Y-m-d\TH:i:s\Z"); // The date and time that the signature was generated. Must be in UTC Date & Time format. This field is used to check for duplicate transaction attempts.
		$request_fields['unsigned_field_names'] = '';   // A comma-separated list of request fields that are not signed.
		$request_fields['override_custom_cancel_page'] = $cancel_url;   // Overrides the custom cancel page setting with your own URL.
		$request_fields['override_custom_receipt_page'] = $return_url;  // Overrides the custom receipt profile setting with your own URL.

		$request_fields['signed_field_names'] = "access_key,profile_id,transaction_uuid,signed_field_names,unsigned_field_names,signed_date_time,locale,transaction_type,reference_number,amount,currency,override_custom_receipt_page,override_custom_cancel_page";

		$cs_signature = $this->cybersource_sign($request_fields);
		$request_fields['signature'] = $cs_signature;

		$payment->set_redirect_url( $this->_gateway_url );
		$payment->set_redirect_args( $request_fields );
		$this->log( array('CyberSource Request' => $request_fields), $payment );

		return $payment;
	}


	/**
	 * Handles the payment update.
	 *
	 * @param array $update_info like $_POST
	 * @param EEI_Transaction $transaction
	 * @return EE_Payment updated
	 * @throws EE_Error
	 */
	public function handle_payment_update( $update_info, $transaction ) {
		$payment = false;
		if ( $transaction->ID() !== null ) {
			$payment = $this->_pay_model->get_payment_by_txn_id_chq_nmbr( $transaction->ID() );
		}
		if ( ! $payment ) {
			$payment = $transaction->last_payment();
		}
		$clean_info = $update_info;
		unset($clean_info['req_access_key']);
		unset($clean_info['signature']);

		$this->log( array('CyberSource Response' => $clean_info), $payment );

		$payment_status = $update_info['decision'];
		$gateway_response = $pm_status = '';
		if ( $payment instanceof EE_Payment ) {
			$cs_signature = $this->cybersource_sign( $update_info );
			$req_sign = trim( $update_info['signature'] );
			if ( $cs_signature === $req_sign ) {
				if ( $payment_status === 'ACCEPT' ) {
					$pm_status = $this->_pay_model->approved_status();
					$payment->set_txn_id_chq_nmbr( $update_info['transaction_id'] );
					$payment->set_amount( floatval( $update_info['auth_amount']) );
					$gateway_response = $update_info['message'];
				} elseif ( $payment_status === 'DECLINE' ) {
					$gateway_response = $update_info['message'];
					$pm_status = $this->_pay_model->declined_status();
				} elseif ( $payment_status === 'ERROR' ) {
					$gateway_response = $update_info['message'];
					$pm_status = $this->_pay_model->failed_status();
				} elseif ( $payment_status === 'CANCEL' ) {
					$gateway_response = $update_info['message'];
					$pm_status = $this->_pay_model->cancelled_status();
				}
			} else {
				$pm_status = $this->_pay_model->declined_status();
				$gateway_response = __('Signature verification Failed !', 'event_espresso');
			}
		}
		$this->log( array('Payment Status:' => $gateway_response), $payment );

		$payment->set_status( $pm_status );
		$payment->set_gateway_response( $gateway_response );
		$payment->set_details( $clean_info );

		return $payment;
	}


	/**
	 * CyberSource Secure Acceptance security script.
	 *
	 * @param $params  signed field names and values
	 * @return SA Signature
	 */
	public function cybersource_sign( $params ) {
		return $this->cybersource_signData($this->cybersource_buildDataToSign($params), $this->_cybersource_secret_key);
	}

	private function cybersource_signData( $data, $secretKey ) {
		return base64_encode(hash_hmac('sha256', $data, $secretKey, true));
	}

	private function cybersource_buildDataToSign( $params ) {
		$signedFieldNames = explode(",", $params["signed_field_names"]);
		foreach ( $signedFieldNames as &$field ) {
			$dataToSign[] = $field . "=" . $params[$field];
		}
		return $this->cybersource_commaSeparate( $dataToSign );
	}

	private function cybersource_commaSeparate ( $dataToSign ) {
		return implode(",", $dataToSign);
	}

}