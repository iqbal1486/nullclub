<p><strong><?php _e('CyberSource Gateway', 'event_espresso'); ?></strong></p>
<p>
	<?php printf(__('Test account settings may be %s adjusted here %s.', 'event_espresso'), '<a href="https://ebctest.cybersource.com">','</a>'); ?>
</p>
<p>
	<?php printf(__('To configure your live account visit %s this link. %s', 'event_espresso'), '<a href="https://ebctest.cybersource.com">','</a>'); ?>
</p>
<p><strong><?php _e('CyberSource Settings', 'event_espresso'); ?></strong></p>
<ul>
	<li>
		<strong><?php _e('CyberSource Profile ID', 'event_espresso'); ?></strong><br />
		<?php _e('Your CyberSource Unique identifier for the organization.', 'event_espresso'); ?>
	</li>
	<li>
		<strong><?php _e('CyberSource Access Key', 'event_espresso'); ?></strong><br />
		<?php _e('Secure Sockets Layer (SSL) authentication with Secure Acceptance Silent Order POST. You can have many access keys per profile.', 'event_espresso'); ?>
	</li>
	<li>
		<strong><?php _e('CyberSource Secret Key', 'event_espresso'); ?></strong><br />
		<?php _e('Secret key: signs the transaction data and is required for each transaction. ', 'event_espresso'); ?>
	</li>
</ul>
<p>
	<?php printf(__('For more info on %s Creating a Security Key %s visit %s this page. %s', 'event_espresso'), '<strong>', '</strong>', '<a href="http://apps.cybersource.com/library/documentation/dev_guides/Secure_Acceptance_SOP/html/wwhelp/wwhimpl/js/html/wwhelp.htm#href=creating_profile.05.3.html">','</a>'); ?>
</p>