<?php if ( ! defined( 'EVENT_ESPRESSO_VERSION' ) ) { exit('No direct script access allowed'); } ?>

	<div id="сybersource-sandbox-panel" class="sandbox-panel">

		<?php if ( $debug_mode ) { ?>
			<h6 class="important-notice" style="text-align: center;"><?php _e('Debug Mode is turned ON. After clicking \'Finalize Registration\' You will be redirected to the CyberSource Sandbox (Test) environment.', 'event_espresso'); ?></h6>
		<?php } ?>

		<?php if ( $debug_mode ) { ?>
			<p class="test-credit-cards-info-pg">
				<strong><?php _e('Information to use for Testing:', 'event_espresso'); ?></strong>
			</p>
			<div class="tbl-wrap">
				<table id="cs-test-credit-cards" class="test-credit-card-data-tbl">
					<thead>
						<tr>
							<td colspan="2"><b><?php _e('Test Cards:', 'event_espresso'); ?></b></td>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td>4111111111111111</td>
							<td><?php _e('Visa', 'event_espresso'); ?></td>
						</tr>
						<tr>
							<td>5555555555554444</td>
							<td><?php _e('MasterCard', 'event_espresso'); ?></td>
						</tr>
						<tr>
							<td>378282246310005</td>
							<td><?php _e('American Express', 'event_espresso'); ?></td>
						</tr>
						<tr>
							<td>6011111111111117</td>
							<td><?php _e('Discover', 'event_espresso'); ?></td>
						</tr>
						<tr>
							<td>3566111111111113</td>
							<td><?php _e('JCB', 'event_espresso'); ?></td>
						</tr>
						<tr>
							<td>38000000000006</td>
							<td><?php _e('Diners Club', 'event_espresso'); ?></td>
						</tr>
						<tr>
							<td>6000340000009859</td>
							<td><?php _e('Maestro International', 'event_espresso'); ?></td>
						</tr>
						<tr>
							<td>6759180000005546</td>
							<td><?php _e('Maestro Domestic', 'event_espresso'); ?></td>
						</tr>
					</tbody>
				</table>
			</div>
		<?php } ?>
	</div>
