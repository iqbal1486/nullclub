<!-- BEGIN ACTIVATION BUTTON -->
<?php $meta_value = get_post_meta( get_the_ID(), 'nest-hide-button', true ); if( !empty( $meta_value ) ) { ?>
<?php } else { ?>
    <div class="nest-button-wrapper<?php if ( is_admin_bar_showing() ) { ?> wp-toolbar-active<?php } ?>">
        <div class="nest-button<?php $meta_value = get_post_meta( get_the_ID(), 'nest-button-style', true ); ?><?php if ($meta_value=="styletwo") { ?>-two<?php } elseif ($meta_value=="stylethree") { ?>-three<?php } elseif ($meta_value=="stylefour") { ?>-four<?php } else { ?><?php } ?>">
            <?php $meta_value = get_post_meta( get_the_ID(), 'nest-button-text', true ); if($meta_value !== '') { ?>
                <?php if( !empty( $meta_value ) ) { echo $meta_value; } ?>
            <?php } else { ?>
                <?php echo get_theme_mod( 'nest_button_text', 'Show info' ); ?>
            <?php } ?>
        </div>
    </div>
<?php } ?>
<!-- END ACTIVATION BUTTON -->

<!-- BEGIN BACKGROUND OVERLAY -->
<div class="nest-background-overlay<?php $meta_value = get_post_meta( get_the_ID(), 'nest-overlay-cursor', true ); if( !empty( $meta_value ) ) { ?> nest-background-overlay-cursor<?php } ?>"></div>
<!-- END BACKGROUND OVERLAY -->

<!-- BEGIN SINGULAR INFO PANE -->
<div class="nest-slide-wrapper">
    
    <!-- BEGIN CLOSE BUTTON -->
    <div class="nest-close-button-wrapper">
        <div class="nest-close-button<?php $meta_value = get_post_meta( get_the_ID(), 'nest-close-button-style', true ); ?><?php if ($meta_value=="styletwo") { ?>-two<?php } elseif ($meta_value=="stylethree") { ?>-three<?php } else { ?><?php } ?>">
            <!-- BEGIN IF THIRD STYLE, SHOW EXTRA ELEMENTS -->
            <?php $meta_value = get_post_meta( get_the_ID(), 'nest-close-button-style', true ); ?><?php if ($meta_value=="stylethree") { ?>
                <div class="top-left"></div>
                <div class="top-right"></div>
                <div class="bottom-left"></div>
                <div class="bottom-right"></div>
            <?php } ?>
            <!-- END IF THIRD STYLE, SHOW EXTRA ELEMENTS -->
        </div>
        <?php $meta_value = get_post_meta( get_the_ID(), 'nest-close-button-style', true ); ?><?php if ($meta_value=="styletwo") { ?>
            <div class="nest-close-button-two-bottom"></div>
        <?php } else { ?><?php } ?>
    </div>
    <!-- END CLOSE BUTTON -->
    
    <!-- BEGIN BACKGROUND IMAGE -->
    <div class="nest-slide-background-image" style="background-image:url(<?php $meta_value = get_post_meta( get_the_ID(), 'nest-image-upload', true ); if( !empty( $meta_value ) ) { echo $meta_value; } ?>);"></div>
    <!-- END BACKGROUND IMAGE -->
    
    <!-- BEGIN BACKGROUND COLOR-->
    <div class="nest-slide-background-color"></div>
    <!-- END BACKGROUND COLOR -->
    
    <!-- BEGIN CONTENT -->
	<div class="nest-slide-inner">
		<div class="nest-slide-inner-inner">

			<div class="nest-content-wrapper">
                <div class="nest-content-inner">
                    <?php 
                    $nest_single_id=$bonfire_nest_meta_box_select; 
                    $post = get_post($nest_single_id); 
                    $content = apply_filters('the_content', $post->post_content); 
                    echo $content;  
                    ?>
                </div>
            </div>

		</div>
	</div>
    <!-- END CONTENT -->
</div>
<!-- END SINGULAR INFO PANE -->

<!-- BEGIN CUSTOM COLORS & other settings for SINGULAR SLIDE -->
<style>
/* menu button position */
<?php $meta_value = get_post_meta( get_the_ID(), 'nest-button-position', true ); ?>
<?php if ($meta_value=="topright") { ?>
.nest-button-wrapper {
    left:auto;
	right:20px;
}
<?php } elseif ($meta_value=="bottomleft") { ?>
.nest-button-wrapper {
    top:auto;
    bottom:20px;
}
<?php } elseif ($meta_value=="bottomright") { ?>
.nest-button-wrapper {
    top:auto;
    bottom:20px;
    left:auto;
	right:20px;
}
<?php } else { ?>
<?php } ?>
/* activation button absolute */
<?php $meta_value = get_post_meta( get_the_ID(), 'nest-button-absolute', true ); if( !empty( $meta_value ) ) { ?>
.nest-button-wrapper { position:absolute; }
<?php } ?>

/* activation button distances */
.nest-button-wrapper {
<?php $meta_value = get_post_meta( get_the_ID(), 'nest-activation-button-top', true ); if($meta_value !== '') { ?>
    top:<?php if( !empty( $meta_value ) ) { echo $meta_value; } ?>px;
<?php } ?>
<?php $meta_value = get_post_meta( get_the_ID(), 'nest-activation-button-left', true ); if($meta_value !== '') { ?>
    left:<?php if( !empty( $meta_value ) ) { echo $meta_value; } ?>px;
<?php } ?>

<?php $meta_value = get_post_meta( get_the_ID(), 'nest-button-position', true ); ?>
<?php if ($meta_value=="topright") { ?>
    <?php $meta_value = get_post_meta( get_the_ID(), 'nest-activation-button-top', true ); if($meta_value !== '') { ?>
        top:<?php if( !empty( $meta_value ) ) { echo $meta_value; } ?>px;
    <?php } ?>
    <?php $meta_value = get_post_meta( get_the_ID(), 'nest-activation-button-right', true ); if($meta_value !== '') { ?>
        right:<?php if( !empty( $meta_value ) ) { echo $meta_value; } ?>px;
    <?php } ?>
    left:auto;
    bottom:auto;
<?php } elseif ($meta_value=="bottomleft") { ?>
    <?php $meta_value = get_post_meta( get_the_ID(), 'nest-activation-button-left', true ); if($meta_value !== '') { ?>
        left:<?php if( !empty( $meta_value ) ) { echo $meta_value; } ?>px;
    <?php } ?>
    <?php $meta_value = get_post_meta( get_the_ID(), 'nest-activation-button-bottom', true ); if($meta_value !== '') { ?>
        bottom:<?php if( !empty( $meta_value ) ) { echo $meta_value; } ?>px;
    <?php } ?>
    top:auto;
    right:auto;
<?php } elseif ($meta_value=="bottomright") { ?>
    <?php $meta_value = get_post_meta( get_the_ID(), 'nest-activation-button-right', true ); if($meta_value !== '') { ?>
        right:<?php if( !empty( $meta_value ) ) { echo $meta_value; } ?>px;
    <?php } ?>
    <?php $meta_value = get_post_meta( get_the_ID(), 'nest-activation-button-bottom', true ); if($meta_value !== '') { ?>
        bottom:<?php if( !empty( $meta_value ) ) { echo $meta_value; } ?>px;
    <?php } ?>
    top:auto;
    left:auto;
<?php } else { ?>
<?php } ?>
}

/* activation button colors */
.nest-button,
.nest-button-two,
.nest-button-three,
.nest-button-four {
    color:<?php $meta_value = get_post_meta( get_the_ID(), 'nest-activation-button-text-color', true ); if( !empty( $meta_value ) ) { echo $meta_value; } ?>;
}
.nest-button:hover,
.nest-button-two:hover,
.nest-button-three:hover,
.nest-button-four:hover {
    color:<?php $meta_value = get_post_meta( get_the_ID(), 'nest-activation-button-text-hover-color', true ); if( !empty( $meta_value ) ) { echo $meta_value; } ?>;
}
/* activation button font size */
.nest-button, .nest-button-two, .nest-button-three, .nest-button-four { font-size:<?php $meta_value = get_post_meta( get_the_ID(), 'nest-button-text-size', true ); if($meta_value !== '') { ?><?php if( !empty( $meta_value ) ) { echo $meta_value; } ?><?php } ?>px; }
/* activation button (style #1) */
.nest-button { background-color:<?php $meta_value = get_post_meta( get_the_ID(), 'nest-activation-button-bg-color', true ); if( !empty( $meta_value ) ) { echo $meta_value; } ?>; }
.nest-button:hover { background-color:<?php $meta_value = get_post_meta( get_the_ID(), 'nest-activation-button-bg-hover-color', true ); if( !empty( $meta_value ) ) { echo $meta_value; } ?>; }
/* activation button (style #2) */
.nest-button-two { border-color:<?php $meta_value = get_post_meta( get_the_ID(), 'nest-activation-button-bg-color', true ); if( !empty( $meta_value ) ) { echo $meta_value; } ?>; }
.nest-button-two:hover { border-color:<?php $meta_value = get_post_meta( get_the_ID(), 'nest-activation-button-bg-hover-color', true ); if( !empty( $meta_value ) ) { echo $meta_value; } ?>; }
/* activation button (style #3) */
.nest-button-three::after { background-color:<?php $meta_value = get_post_meta( get_the_ID(), 'nest-activation-button-bg-color', true ); if( !empty( $meta_value ) ) { echo $meta_value; } ?>; }
.nest-button-three:hover::after { background-color:<?php $meta_value = get_post_meta( get_the_ID(), 'nest-activation-button-bg-hover-color', true ); if( !empty( $meta_value ) ) { echo $meta_value; } ?>; }
/* activation button (style #4) */
.nest-button-four { background-color:<?php $meta_value = get_post_meta( get_the_ID(), 'nest-activation-button-bg-color', true ); if( !empty( $meta_value ) ) { echo $meta_value; } ?>; }
.nest-button-four:hover { background-color:<?php $meta_value = get_post_meta( get_the_ID(), 'nest-activation-button-bg-hover-color', true ); if( !empty( $meta_value ) ) { echo $meta_value; } ?>; }

/* background image as cover/pattern + background image opacity */
.nest-slide-background-image {
<?php $meta_value = get_post_meta( get_the_ID(), 'nest-background-pattern', true ); if( !empty( $meta_value ) ) { ?>
    background-repeat:repeat;
<?php } else { ?>
    background-size:cover;
    background-repeat:no-repeat;
<?php } ?>
<?php $meta_value = get_post_meta( get_the_ID(), 'nest-background-image-opacity', true ); if($meta_value !== '') { ?>
    opacity:<?php if( !empty( $meta_value ) ) { echo $meta_value; } ?>;
<?php } ?>
}
/* background color + background color opacity */
.nest-slide-background-color {
    background-color:<?php $meta_value = get_post_meta( get_the_ID(), 'nest-bg-color', true ); if( !empty( $meta_value ) ) { echo $meta_value; } ?>;
<?php $meta_value = get_post_meta( get_the_ID(), 'nest-background-color-opacity', true ); if($meta_value !== '') { ?>
    opacity:<?php if( !empty( $meta_value ) ) { echo $meta_value; } ?>;
<?php } ?>
}
/* overlay color + overlay color opacity */
.nest-background-overlay {
    background-color:<?php $meta_value = get_post_meta( get_the_ID(), 'nest-overlay-color', true ); if( !empty( $meta_value ) ) { echo $meta_value; } ?>;
    
    -webkit-transition:opacity <?php $meta_value = get_post_meta( get_the_ID(), 'nest-appearance-speed', true ); if($meta_value !== '') { ?><?php if( !empty( $meta_value ) ) { echo $meta_value; } ?><?php } else { ?>.5<?php } ?>s ease, left 0s ease <?php $meta_value = get_post_meta( get_the_ID(), 'nest-appearance-speed', true ); if($meta_value !== '') { ?><?php if( !empty( $meta_value ) ) { echo $meta_value; } ?><?php } else { ?>.5<?php } ?>s;
    -moz-transition:opacity <?php $meta_value = get_post_meta( get_the_ID(), 'nest-appearance-speed', true ); if($meta_value !== '') { ?><?php if( !empty( $meta_value ) ) { echo $meta_value; } ?><?php } else { ?>.5<?php } ?>s ease, left 0s ease <?php $meta_value = get_post_meta( get_the_ID(), 'nest-appearance-speed', true ); if($meta_value !== '') { ?><?php if( !empty( $meta_value ) ) { echo $meta_value; } ?><?php } else { ?>.5<?php } ?>s;
    transition:opacity <?php $meta_value = get_post_meta( get_the_ID(), 'nest-appearance-speed', true ); if($meta_value !== '') { ?><?php if( !empty( $meta_value ) ) { echo $meta_value; } ?><?php } else { ?>.5<?php } ?>s ease, left 0s ease <?php $meta_value = get_post_meta( get_the_ID(), 'nest-appearance-speed', true ); if($meta_value !== '') { ?><?php if( !empty( $meta_value ) ) { echo $meta_value; } ?><?php } else { ?>.5<?php } ?>s;
}
.nest-background-overlay-active {
<?php $meta_value = get_post_meta( get_the_ID(), 'nest-overlay-color-opacity', true ); if($meta_value !== '') { ?>
    opacity:<?php if( !empty( $meta_value ) ) { echo $meta_value; } ?>;
<?php } ?>
    -webkit-transition:opacity <?php $meta_value = get_post_meta( get_the_ID(), 'nest-appearance-speed', true ); if($meta_value !== '') { ?><?php if( !empty( $meta_value ) ) { echo $meta_value; } ?><?php } else { ?>.5<?php } ?>s ease, left 0s ease 0s;
    -moz-transition:opacity <?php $meta_value = get_post_meta( get_the_ID(), 'nest-appearance-speed', true ); if($meta_value !== '') { ?><?php if( !empty( $meta_value ) ) { echo $meta_value; } ?><?php } else { ?>.5<?php } ?>s ease, left 0s ease 0s;
    transition:opacity <?php $meta_value = get_post_meta( get_the_ID(), 'nest-appearance-speed', true ); if($meta_value !== '') { ?><?php if( !empty( $meta_value ) ) { echo $meta_value; } ?><?php } else { ?>.5<?php } ?>s ease, left 0s ease 0s;
}

/* main slide animation speed */
.nest-slide-wrapper {
    -webkit-transition:-webkit-transform <?php $meta_value = get_post_meta( get_the_ID(), 'nest-appearance-speed', true ); if($meta_value !== '') { ?><?php if( !empty( $meta_value ) ) { echo $meta_value; } ?><?php } else { ?>.5<?php } ?>s ease;
    -moz-transition:-moz-transform <?php $meta_value = get_post_meta( get_the_ID(), 'nest-appearance-speed', true ); if($meta_value !== '') { ?><?php if( !empty( $meta_value ) ) { echo $meta_value; } ?><?php } else { ?>.5<?php } ?>s ease;
    transition:transform <?php $meta_value = get_post_meta( get_the_ID(), 'nest-appearance-speed', true ); if($meta_value !== '') { ?><?php if( !empty( $meta_value ) ) { echo $meta_value; } ?><?php } else { ?>.5<?php } ?>s ease;
}

/* if fade-in option selected */
<?php $meta_value = get_post_meta( get_the_ID(), 'nest-fade-in', true ); if( !empty( $meta_value ) ) { ?>
.nest-slide-wrapper .nest-content-inner { opacity:0; }
.nest-slide-wrapper-active .nest-content-inner { opacity:1; }
<?php } ?>

/* apply custom width, except when slide-in direction is top/bottom */
<?php $meta_value = get_post_meta( get_the_ID(), 'nest-direction', true ); ?>
<?php if ($meta_value=="top") { ?>
<?php } elseif ($meta_value=="bottom") { ?>
<?php } else { ?>
.nest-slide-wrapper { max-height:100%; max-width:<?php $meta_value = get_post_meta( get_the_ID(), 'nest-slide-width', true ); if($meta_value !== '') { ?><?php if( !empty( $meta_value ) ) { echo $meta_value; } ?>px<?php } else { ?>100%<?php } ?>; }
<?php } ?>
        
/* apply custom height, except when slide-in direction is left/right */
<?php $meta_value = get_post_meta( get_the_ID(), 'nest-direction', true ); ?>
<?php if ($meta_value=="left") { ?>
<?php } elseif ($meta_value=="right") { ?>
<?php } else { ?>
.nest-slide-wrapper { max-width:100%; max-height:<?php $meta_value = get_post_meta( get_the_ID(), 'nest-slide-height', true ); if($meta_value !== '') { ?><?php if( !empty( $meta_value ) ) { echo $meta_value; } ?>px<?php } else { ?>100%<?php } ?>; }
<?php } ?>

/* inner content width */
.nest-content-wrapper {
    max-width:<?php $meta_value = get_post_meta( get_the_ID(), 'nest-content-width', true ); if( !empty( $meta_value ) ) { echo $meta_value; } ?>px;
}

/* slide-in direction, custom width/height (if custom singular slide-in direction chosen) */
<?php $meta_value = get_post_meta( get_the_ID(), 'nest-direction', true ); ?>
<?php if ($meta_value=="top") { ?>
.nest-slide-wrapper {
    top:0;
	bottom:auto;
    -webkit-transform:translateY(-<?php $meta_value = get_post_meta( get_the_ID(), 'nest-slide-height', true ); if($meta_value !== '') { ?><?php if( !empty( $meta_value ) ) { echo $meta_value; } ?>px<?php } else { ?>100%<?php } ?>);
    -moz-transform:translateY(-<?php $meta_value = get_post_meta( get_the_ID(), 'nest-slide-height', true ); if($meta_value !== '') { ?><?php if( !empty( $meta_value ) ) { echo $meta_value; } ?>px<?php } else { ?>100%<?php } ?>);
    transform:translateY(-<?php $meta_value = get_post_meta( get_the_ID(), 'nest-slide-height', true ); if($meta_value !== '') { ?><?php if( !empty( $meta_value ) ) { echo $meta_value; } ?>px<?php } else { ?>100%<?php } ?>);
}
<?php } ?>

<?php $meta_value = get_post_meta( get_the_ID(), 'nest-direction', true ); ?>
<?php if ($meta_value=="left") { ?>
.nest-slide-wrapper {
    left:0;
	right:auto;
    -webkit-transform:translateX(-<?php $meta_value = get_post_meta( get_the_ID(), 'nest-slide-width', true ); if($meta_value !== '') { ?><?php if( !empty( $meta_value ) ) { echo $meta_value; } ?>px<?php } else { ?>100%<?php } ?>);
    -moz-transform:translateX(-<?php $meta_value = get_post_meta( get_the_ID(), 'nest-slide-width', true ); if($meta_value !== '') { ?><?php if( !empty( $meta_value ) ) { echo $meta_value; } ?>px<?php } else { ?>100%<?php } ?>);
    transform:translateX(-<?php $meta_value = get_post_meta( get_the_ID(), 'nest-slide-width', true ); if($meta_value !== '') { ?><?php if( !empty( $meta_value ) ) { echo $meta_value; } ?>px<?php } else { ?>100%<?php } ?>);
}
<?php } ?>

<?php $meta_value = get_post_meta( get_the_ID(), 'nest-direction', true ); ?>
<?php if ($meta_value=="right") { ?>
.nest-slide-wrapper {
    left:auto;
	right:0;
   -webkit-transform:translateX(<?php $meta_value = get_post_meta( get_the_ID(), 'nest-slide-width', true ); if($meta_value !== '') { ?><?php if( !empty( $meta_value ) ) { echo $meta_value; } ?>px<?php } else { ?>100%<?php } ?>);
    -moz-transform:translateX(<?php $meta_value = get_post_meta( get_the_ID(), 'nest-slide-width', true ); if($meta_value !== '') { ?><?php if( !empty( $meta_value ) ) { echo $meta_value; } ?>px<?php } else { ?>100%<?php } ?>);
    transform:translateX(<?php $meta_value = get_post_meta( get_the_ID(), 'nest-slide-width', true ); if($meta_value !== '') { ?><?php if( !empty( $meta_value ) ) { echo $meta_value; } ?>px<?php } else { ?>100%<?php } ?>);
}
<?php } ?>

<?php $meta_value = get_post_meta( get_the_ID(), 'nest-direction', true ); ?>
<?php if ($meta_value=="bottom") { ?>
.nest-slide-wrapper {
    top:auto;
	bottom:0;
    -webkit-transform:translateY(<?php $meta_value = get_post_meta( get_the_ID(), 'nest-slide-height', true ); if($meta_value !== '') { ?><?php if( !empty( $meta_value ) ) { echo $meta_value; } ?>px<?php } else { ?>100%<?php } ?>);
    -moz-transform:translateY(<?php $meta_value = get_post_meta( get_the_ID(), 'nest-slide-height', true ); if($meta_value !== '') { ?><?php if( !empty( $meta_value ) ) { echo $meta_value; } ?>px<?php } else { ?>100%<?php } ?>);
    transform:translateY(<?php $meta_value = get_post_meta( get_the_ID(), 'nest-slide-height', true ); if($meta_value !== '') { ?><?php if( !empty( $meta_value ) ) { echo $meta_value; } ?>px<?php } else { ?>100%<?php } ?>);
}
<?php } ?>

/* close button location */
<?php $meta_value = get_post_meta( get_the_ID(), 'nest-close-button', true ); ?>
<?php if ($meta_value=="center") { ?>
.nest-close-button-wrapper {
    left:50%;
    margin-left:-20px;
}
<?php } ?>
<?php $meta_value = get_post_meta( get_the_ID(), 'nest-close-button', true ); ?>
<?php if ($meta_value=="right") { ?>
.nest-close-button-wrapper {
    left:auto;
    right:15px;
}
<?php } ?>

/* close button distances */
.nest-close-button-wrapper {
    <?php $meta_value = get_post_meta( get_the_ID(), 'nest-close-button-top', true ); if($meta_value !== '') { ?>
    top:<?php if( !empty( $meta_value ) ) { echo $meta_value; } ?>px;
    <?php } ?>
    <?php $meta_value = get_post_meta( get_the_ID(), 'nest-close-button-left', true ); if($meta_value !== '') { ?>
    left:<?php if( !empty( $meta_value ) ) { echo $meta_value; } ?>px;
    <?php } ?>
}
<?php $meta_value = get_post_meta( get_the_ID(), 'nest-close-button', true ); ?>
<?php if ($meta_value=="center") { ?>
.nest-close-button-wrapper {
    <?php $meta_value = get_post_meta( get_the_ID(), 'nest-close-button-top', true ); if($meta_value !== '') { ?>
    top:<?php if( !empty( $meta_value ) ) { echo $meta_value; } ?>px;
    <?php } ?>
    left:50%;
}
<?php } ?>
<?php $meta_value = get_post_meta( get_the_ID(), 'nest-close-button', true ); ?>
<?php if ($meta_value=="right") { ?>
.nest-close-button-wrapper {
    left:auto;
    <?php $meta_value = get_post_meta( get_the_ID(), 'nest-close-button-right', true ); if($meta_value !== '') { ?>
        right:<?php if( !empty( $meta_value ) ) { echo $meta_value; } ?>px;
    <?php } ?>
}
<?php } ?>

/* close button colors */
.nest-close-button::before,
.nest-close-button::after,
.nest-close-button-two::before,
.nest-close-button-two::after,
.nest-close-button-two-bottom::before,
.nest-close-button-two-bottom::after,
.nest-close-button-three .top-left,
.nest-close-button-three .top-right,
.nest-close-button-three .bottom-left,
.nest-close-button-three .bottom-right {
    background-color:<?php $meta_value = get_post_meta( get_the_ID(), 'nest-close-button-color', true ); if( !empty( $meta_value ) ) { echo $meta_value; } ?>;
}
.nest-close-button-wrapper:hover .nest-close-button::before,
.nest-close-button-wrapper:hover .nest-close-button::after,
.nest-close-button-wrapper:hover .nest-close-button-two::before,
.nest-close-button-wrapper:hover .nest-close-button-two::after,
.nest-close-button-wrapper:hover .nest-close-button-two-bottom::before,
.nest-close-button-wrapper:hover .nest-close-button-two-bottom::after,
.nest-close-button-three .top-left:before,
.nest-close-button-three .top-right:before,
.nest-close-button-three .bottom-left:before,
.nest-close-button-three .bottom-right:before {
    background-color:<?php $meta_value = get_post_meta( get_the_ID(), 'nest-close-button-hover-color', true ); if( !empty( $meta_value ) ) { echo $meta_value; } ?>;
}

/* animate close button style #3 */
<?php $meta_value = get_post_meta( get_the_ID(), 'nest-close-button-style', true ); ?><?php if ($meta_value=="stylethree") { ?>
.nest-close-button-wrapper:hover {
    -webkit-transform:rotate(90deg);
    -moz-transform:rotate(90deg);
    transform:rotate(90deg);
}
<?php } ?>

/* styled scrollbar */
.nest-slide-inner-inner > .scroll-element .scroll-bar { background-color:<?php $meta_value = get_post_meta( get_the_ID(), 'nest-scrollbar-color', true ); if( !empty( $meta_value ) ) { echo $meta_value; } ?>; }
.nest-slide-inner-inner > .scroll-element .scroll-element_track { background-color:<?php $meta_value = get_post_meta( get_the_ID(), 'nest-scrollbar-background-color', true ); if( !empty( $meta_value ) ) { echo $meta_value; } ?>; }
.nest-slide-inner-inner > .scroll-element.scroll-y {
    right:<?php $meta_value = get_post_meta( get_the_ID(), 'nest-scrollbar-distance', true ); if($meta_value !== '') { ?><?php if( !empty( $meta_value ) ) { echo $meta_value; } ?><?php } ?>px;
	top:<?php $meta_value = get_post_meta( get_the_ID(), 'nest-scrollbar-distance', true ); if($meta_value !== '') { ?><?php if( !empty( $meta_value ) ) { echo $meta_value; } ?><?php } ?>px;
    bottom:<?php $meta_value = get_post_meta( get_the_ID(), 'nest-scrollbar-distance', true ); if($meta_value !== '') { ?><?php if( !empty( $meta_value ) ) { echo $meta_value; } ?><?php } ?>px;
	width:<?php $meta_value = get_post_meta( get_the_ID(), 'nest-scrollbar-thickness', true ); if($meta_value !== '') { ?><?php if( !empty( $meta_value ) ) { echo $meta_value; } ?><?php } ?>px;
}
.nest-slide-inner-inner > .scroll-element div {
    border-radius:<?php $meta_value = get_post_meta( get_the_ID(), 'nest-scrollbar-roundness', true ); if($meta_value !== '') { ?><?php if( !empty( $meta_value ) ) { echo $meta_value; } ?><?php } ?>px;
}

/* content animation */
<?php $meta_value = get_post_meta( get_the_ID(), 'nest-content-animation-elements', true ); if($meta_value !== '') { ?>
<?php if( !empty( $meta_value ) ) { echo $meta_value; } ?> {
    -webkit-transition:-webkit-transform <?php $meta_value = get_post_meta( get_the_ID(), 'nest-appearance-speed', true ); if($meta_value !== '') { ?><?php if( !empty( $meta_value ) ) { echo $meta_value; } ?><?php } else { ?>.5<?php } ?>s ease, opacity <?php $meta_value = get_post_meta( get_the_ID(), 'nest-appearance-speed', true ); if($meta_value !== '') { ?><?php if( !empty( $meta_value ) ) { echo $meta_value; } ?><?php } else { ?>.5<?php } ?>s ease, -webkit-filter <?php $meta_value = get_post_meta( get_the_ID(), 'nest-appearance-speed', true ); if($meta_value !== '') { ?><?php if( !empty( $meta_value ) ) { echo $meta_value; } ?><?php } else { ?>.5<?php } ?>s ease;
    -moz-transition:-moz-transform <?php $meta_value = get_post_meta( get_the_ID(), 'nest-appearance-speed', true ); if($meta_value !== '') { ?><?php if( !empty( $meta_value ) ) { echo $meta_value; } ?><?php } else { ?>.5<?php } ?>s ease, opacity <?php $meta_value = get_post_meta( get_the_ID(), 'nest-appearance-speed', true ); if($meta_value !== '') { ?><?php if( !empty( $meta_value ) ) { echo $meta_value; } ?><?php } else { ?>.5<?php } ?>s ease, -moz-filter <?php $meta_value = get_post_meta( get_the_ID(), 'nest-appearance-speed', true ); if($meta_value !== '') { ?><?php if( !empty( $meta_value ) ) { echo $meta_value; } ?><?php } else { ?>.5<?php } ?>s ease;
    transition:transform <?php $meta_value = get_post_meta( get_the_ID(), 'nest-appearance-speed', true ); if($meta_value !== '') { ?><?php if( !empty( $meta_value ) ) { echo $meta_value; } ?><?php } else { ?>.5<?php } ?>s ease, opacity <?php $meta_value = get_post_meta( get_the_ID(), 'nest-appearance-speed', true ); if($meta_value !== '') { ?><?php if( !empty( $meta_value ) ) { echo $meta_value; } ?><?php } else { ?>.5<?php } ?>s ease, filter <?php $meta_value = get_post_meta( get_the_ID(), 'nest-appearance-speed', true ); if($meta_value !== '') { ?><?php if( !empty( $meta_value ) ) { echo $meta_value; } ?><?php } else { ?>.5<?php } ?>s ease;
}
<?php } ?>
.content-animation-active {
    -webkit-transform:scale(<?php $meta_value = get_post_meta( get_the_ID(), 'nest-content-animation-scale', true ); if($meta_value !== '') { ?><?php if( !empty( $meta_value ) ) { echo $meta_value; } ?><?php } else { ?>0.9<?php } ?>);
    -moz-transform:scale(<?php $meta_value = get_post_meta( get_the_ID(), 'nest-content-animation-scale', true ); if($meta_value !== '') { ?><?php if( !empty( $meta_value ) ) { echo $meta_value; } ?><?php } else { ?>0.9<?php } ?>);
    transform:scale(<?php $meta_value = get_post_meta( get_the_ID(), 'nest-content-animation-scale', true ); if($meta_value !== '') { ?><?php if( !empty( $meta_value ) ) { echo $meta_value; } ?><?php } else { ?>0.9<?php } ?>);
    opacity:<?php $meta_value = get_post_meta( get_the_ID(), 'nest-content-animation-opacity', true ); if($meta_value !== '') { ?><?php if( !empty( $meta_value ) ) { echo $meta_value; } ?><?php } ?>;
    
    -webkit-filter:blur(<?php $meta_value = get_post_meta( get_the_ID(), 'nest-content-blur', true ); if($meta_value !== '') { ?><?php if( !empty( $meta_value ) ) { echo $meta_value; } ?><?php } ?>px);
    -moz-filter:blur(<?php $meta_value = get_post_meta( get_the_ID(), 'nest-content-blur', true ); if($meta_value !== '') { ?><?php if( !empty( $meta_value ) ) { echo $meta_value; } ?><?php } ?>px);
    filter:blur(<?php $meta_value = get_post_meta( get_the_ID(), 'nest-content-blur', true ); if($meta_value !== '') { ?><?php if( !empty( $meta_value ) ) { echo $meta_value; } ?><?php } ?>px);
}
/* hide Nest between resolutions */
@media ( min-width:<?php $meta_value = get_post_meta( get_the_ID(), 'nest-smaller-than', true ); if($meta_value !== '') { ?><?php if( !empty( $meta_value ) ) { echo $meta_value; } ?><?php } if ( false !== $meta_value ) { ?>0<?php } ?>px) and (max-width:<?php $meta_value = get_post_meta( get_the_ID(), 'nest-larger-than', true ); if($meta_value !== '') { ?><?php if( !empty( $meta_value ) ) { echo $meta_value; } ?><?php } ?>px) {
    .nest-button-wrapper,
    .nest-background-overlay,
    .nest-slide-wrapper { display:none; }
}
</style>
<!-- END CUSTOM COLORS & other settings for SINGULAR SLIDE -->

<!-- BEGIN AUTO ACTIVATION -->
<?php $meta_value = get_post_meta( get_the_ID(), 'nest-automatic-activation', true ); if($meta_value !== '') { ?>
<script>
/* once per session */
<?php $meta_value = get_post_meta( get_the_ID(), 'nest-once-per-session', true ); if( !empty( $meta_value ) ) { ?>
jQuery(document).ready(function($){
    if (sessionStorage.getItem('oncePerSession') !== 'true') {
<?php } ?> 
    setTimeout(function(){
        jQuery('.nest-slide-wrapper').addClass('nest-slide-wrapper-active');
        jQuery('.nest-background-overlay').addClass('nest-background-overlay-active');
        /* add content scaling */
        <?php $meta_value = get_post_meta( get_the_ID(), 'nest-content-animation-elements', true ); if($meta_value !== '') { ?>
        jQuery('<?php if( !empty( $meta_value ) ) { echo $meta_value; } ?>').addClass('content-animation-active');
        <?php } ?>
    },<?php $meta_value = get_post_meta( get_the_ID(), 'nest-automatic-activation', true ); if($meta_value !== '') { ?><?php if( !empty( $meta_value ) ) { echo $meta_value; } ?><?php } ?>);
<?php $meta_value = get_post_meta( get_the_ID(), 'nest-once-per-session', true ); if( !empty( $meta_value ) ) { ?>
        sessionStorage.setItem('oncePerSession','true');
    }
});
<?php } ?>
</script>
<?php } ?>
<!-- END AUTO ACTIVATION -->

<!-- BEGIN ANCHOR ACTIVATION -->
<?php $meta_value = get_post_meta( get_the_ID(), 'nest-anchor-activation', true ); if($meta_value !== '') { ?>
<script>
/* anchor activation */
jQuery('<?php if( !empty( $meta_value ) ) { echo $meta_value; } ?>').on('inview', function(event, isInView) {
    if (isInView) {
        jQuery('.nest-slide-wrapper').addClass('nest-slide-wrapper-active');
        jQuery('.nest-background-overlay').addClass('nest-background-overlay-active');
        /* add content scaling */
        <?php $meta_value = get_post_meta( get_the_ID(), 'nest-content-animation-elements', true ); if($meta_value !== '') { ?>
        jQuery('<?php if( !empty( $meta_value ) ) { echo $meta_value; } ?>').addClass('content-animation-active');
        <?php } ?>
    } else {
        jQuery('.nest-slide-wrapper').removeClass('nest-slide-wrapper-active');
        jQuery('.nest-background-overlay').removeClass('nest-background-overlay-active');
        /* remove content scaling */
        <?php $meta_value = get_post_meta( get_the_ID(), 'nest-content-animation-elements', true ); if($meta_value !== '') { ?>
        jQuery('<?php if( !empty( $meta_value ) ) { echo $meta_value; } ?>').removeClass('content-animation-active');
        <?php } ?>
    }
});
</script>
<?php } ?>
<!-- END ANCHOR ACTIVATION -->

<!-- BEGIN CONTENT SCALING -->
<?php $meta_value = get_post_meta( get_the_ID(), 'nest-content-animation-elements', true ); if($meta_value !== '') { ?>
<script>
jQuery('.nest-button-wrapper, .nest-button-wrapper-shortcode, .nest-close-button-wrapper, .nest-background-overlay, .nest-custom-activator').on('click', function(e) {
'use strict';
	e.preventDefault();
		if(jQuery('.nest-slide-wrapper').hasClass('nest-slide-wrapper-active'))
		{
			/* remove content scaling */
			jQuery('<?php if( !empty( $meta_value ) ) { echo $meta_value; } ?>').removeClass('content-animation-active');
		} else {
			/* add content scaling */
			jQuery('<?php if( !empty( $meta_value ) ) { echo $meta_value; } ?>').addClass('content-animation-active');
		}
});
/* on ESC press */
jQuery(document).keyup(function(e) {
'use strict';
	if (e.keyCode == 27) { 
		/* remove content scaling */
		jQuery('<?php if( !empty( $meta_value ) ) { echo $meta_value; } ?>').removeClass('content-animation-active');
		return false;
	}
});
</script>
<?php } ?>
<!-- END CONTENT SCALING -->