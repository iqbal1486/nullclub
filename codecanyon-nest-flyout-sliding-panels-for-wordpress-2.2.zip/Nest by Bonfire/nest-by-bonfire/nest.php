<?php
/*
Plugin Name: Nest by Bonfire
Plugin URI: http://bonfirethemes.com/
Description: Animated Flyout Panels for WordPress
Version: 2.2
Author: Bonfire Themes
Author URI: http://bonfirethemes.com/
*/

    //
    // NEST SITE-WIDE FLYOUT + BUTTONS SETTINGS PAGES
    //
    function nest_customizer( $wp_customize ) {
        
        //
        // ADD "NEST PLUGIN" PANEL TO LIVE CUSTOMIZER
        //
        $wp_customize->add_panel('nest_panel', array('title' => __('Nest Plugin', 'nest'),'priority' => 10,));

        //
        // // ADD "Main Settings" SECTION TO "NEST" PANEL
        //
        $wp_customize->add_section('nest_main_section',array('title' => 'Main Settings','description' => 'Site-wide slide settings.','panel'  => 'nest_panel','priority' => 1,));
        
        /* drop-down page list */
        $wp_customize->add_setting( 'nest_main_section', array( 'sanitize_callback' => 'nest_sanitize_integer' ));
        $wp_customize->add_control( 'nest_main_section', array(
            'type' => 'dropdown-pages',
            'label' => 'Select page',
            'description'=>'Select the page that will be shown in the site-wide flyout panel.',
            'section' => 'nest_main_section'
        ));
        function nest_sanitize_integer( $input ) { if( is_numeric( $input ) ) { return intval( $input ); }}
        
        /* front page only */
        $wp_customize->add_setting(
            'nest_front_page_only',
            array(
                'sanitize_callback' => 'sanitize_nest_front_page_only',
            )
        );
        function sanitize_nest_front_page_only( $input ) {
            if ( $input == 1 ) {
                return 1;
            } else {
                return '';
            }
        }
        $wp_customize->add_control(
            'nest_front_page_only',
            array(
                'type' => 'checkbox',
                'label' => 'Show panel on front page only',
                'section' => 'nest_main_section',
            )
        );
        
        /* animation speed */
        $wp_customize->add_setting(
            'nest_animation_speed',
            array(
                'default' => '0.5',
                'sanitize_callback' => 'sanitize_nest_animation_speed',
            )
        );
        function sanitize_nest_animation_speed($input) {
        return wp_kses_post(force_balance_tags($input));
        }
        $wp_customize->add_control(
            'nest_animation_speed',
            array(
                'type' => 'text',
                'label' => 'Animation speed (in seconds)',
                'description'=>'Example: 1.5. If empty, defaults to 0.5',
                'section' => 'nest_main_section',
            )
        );
        
        
        /* fade in content */
        $wp_customize->add_setting(
            'nest_fade_in',
            array(
                'sanitize_callback' => 'sanitize_nest_fade_in',
            )
        );
        function sanitize_nest_fade_in( $input ) {
            if ( $input == 1 ) {
                return 1;
            } else {
                return '';
            }
        }
        $wp_customize->add_control(
            'nest_fade_in',
            array(
                'type' => 'checkbox',
                'label' => 'Add subtle fade-in effect to content',
                'section' => 'nest_main_section',
            )
        );
        
        
        /* slideout direction */
        $wp_customize->add_setting(
            'nest_direction',
            array(
                'default' => 'left',
            )
        );
        $wp_customize->add_control(
            'nest_direction',
            array(
                'type' => 'radio',
                'label' => 'Flyout direction',
                'description'=>'Choose direction of the panel',
                'section' => 'nest_main_section',
                'choices' => array(
                    'top' => 'Top',
                    'left' => 'Left',
                    'right' => 'Right',
                    'bottom' => 'Bottom',
                ),
            )
        );
        
        
        /* slide width */
        $wp_customize->add_setting(
            'nest_slide_width',
            array(
                'default' => '',
                'sanitize_callback' => 'sanitize_nest_slide_width',
            )
        );
        function sanitize_nest_slide_width($input) {
            return wp_kses_post(force_balance_tags($input));
        }
        
        $wp_customize->add_control(
            'nest_slide_width',
            array(
                'type' => 'text',
                'label' => 'Flyout width (in pixels)',
                'description'=>'Example: 250. If empty, defaults to full-screen. Ignored when left/right flyout direction chosen.',
                'section' => 'nest_main_section',
            )
        );
        
        
        /* slide height */
        $wp_customize->add_setting(
            'nest_slide_height',
            array(
                'default' => '',
                'sanitize_callback' => 'sanitize_nest_slide_height',
            )
        );
        function sanitize_nest_slide_height($input) {
            return wp_kses_post(force_balance_tags($input));
        }
        $wp_customize->add_control(
            'nest_slide_height',
            array(
                'type' => 'text',
                'label' => 'Flyout height (in pixels)',
                'description'=>'Example: 250. If empty, defaults to full-screen. Ignored when top/bottom flyout direction chosen.',
                'section' => 'nest_main_section',
            )
        );
        
        
        /* content width */
        $wp_customize->add_setting(
            'nest_content_width',
            array(
                'default' => '',
                'sanitize_callback' => 'sanitize_nest_content_width',
            )
        );
        function sanitize_nest_content_width($input) {
            return wp_kses_post(force_balance_tags($input));
        }
        $wp_customize->add_control(
            'nest_content_width',
            array(
                'type' => 'text',
                'label' => 'Content maximum width (in pixels)',
                'description' => 'Example: 250. If empty, defaults to full-width.',
                'section' => 'nest_main_section',
            )
        );
        
        
        /* background image */
        $wp_customize->add_setting( 'nest_background_image' );
        $wp_customize->add_control(
            new WP_Customize_Image_Control(
                $wp_customize,
                'nest_background_image',
                array(
                    'label' => 'Background image',
                    'description' => 'Choose background image',
                    'section' => 'nest_main_section',
                    'settings' => 'nest_background_image'
                )
            )
        );
        
        
        /* background as pattern */
        $wp_customize->add_setting(
            'nest_background_pattern',
            array(
                'sanitize_callback' => 'sanitize_nest_background_pattern',
            )
        );
        function sanitize_nest_background_pattern( $input ) {
            if ( $input == 1 ) {
                return 1;
            } else {
                return '';
            }
        }
        $wp_customize->add_control(
            'nest_background_pattern',
            array(
                'type' => 'checkbox',
                'label' => 'Show background image as pattern',
                'section' => 'nest_main_section',
            )
        );
        
        
        /* background image opacity */
        $wp_customize->add_setting(
            'nest_background_image_opacity',
            array(
                'default' => '',
                'sanitize_callback' => 'sanitize_nest_background_image_opacity',
            )
        );
        function sanitize_nest_background_image_opacity($input) {
            return wp_kses_post(force_balance_tags($input));
        }
        $wp_customize->add_control(
            'nest_background_image_opacity',
            array(
                'type' => 'text',
                'label' => 'Background image opacity',
                'description' => 'Example: 0.5. If empty, defaults to 1.',
                'section' => 'nest_main_section',
            )
        );
        
        
        /* background color */
        $wp_customize->add_setting( 'nest_background_color', array( 'sanitize_callback' => 'sanitize_hex_color' ));
        $wp_customize->add_control(
            new WP_Customize_Color_Control( $wp_customize, 'nest_background_color',
                array( 'label' => 'Background color', 'section' => 'nest_main_section', 'settings' => 'nest_background_color' )
            )
        );

        
        /* background color opacity */
        $wp_customize->add_setting(
            'nest_background_color_opacity',
            array(
                'default' => '',
                'sanitize_callback' => 'sanitize_nest_background_color_opacity',
            )
        );
        function sanitize_nest_background_color_opacity($input) {
            return wp_kses_post(force_balance_tags($input));
        }
        $wp_customize->add_control(
            'nest_background_color_opacity',
            array(
                'type' => 'text',
                'label' => 'Background color opacity',
                'description' => 'Example: 0.5. If empty, defaults to 1',
                'section' => 'nest_main_section',
            )
        );
        
        
        /* overlay color */
        $wp_customize->add_setting( 'nest_overlay_color', array( 'sanitize_callback' => 'sanitize_hex_color' ));
        $wp_customize->add_control(
            new WP_Customize_Color_Control( $wp_customize, 'nest_overlay_color',
                array( 'label' => 'Overlay color', 'section' => 'nest_main_section', 'settings' => 'nest_overlay_color' )
            )
        );

        
        /* overlay color opacity */
        $wp_customize->add_setting(
            'nest_overlay_color_opacity',
            array(
                'default' => '',
                'sanitize_callback' => 'sanitize_nest_overlay_color_opacity',
            )
        );
        function sanitize_nest_overlay_color_opacity($input) {
            return wp_kses_post(force_balance_tags($input));
        }
        $wp_customize->add_control(
            'nest_overlay_color_opacity',
            array(
                'type' => 'text',
                'label' => 'Overlay color opacity',
                'description' => 'Example: 0.5. If empty, defaults to 0.75',
                'section' => 'nest_main_section',
            )
        );


        /* show close cursor */
        $wp_customize->add_setting(
            'nest_overlay_cursor',
            array(
                'sanitize_callback' => 'sanitize_nest_overlay_cursor',
            )
        );
        function sanitize_nest_overlay_cursor( $input ) {
            if ( $input == 1 ) {
                return 1;
            } else {
                return '';
            }
        }
        $wp_customize->add_control(
            'nest_overlay_cursor',
            array(
                'type' => 'checkbox',
                'label' => 'Show cursor as icon on overlay',
                'description' => 'When hovering on the background overlay, mouse cursor will be shown as "x" icon',
                'section' => 'nest_main_section',
            )
        );
        
        
        //
        // ADD "Activation Button" SECTION TO "NEST" PANEL
        //
        $wp_customize->add_section('nest_button_section',array('title' => 'Activation Button','panel'  => 'nest_panel','priority' => 2,));
        
        /* hide activation button */
        $wp_customize->add_setting('nest_hide_button',array('sanitize_callback' => 'sanitize_nest_hide_button',));
        function sanitize_nest_hide_button( $input ) {if ( $input == 1 ) {return 1;} else {return '';}}
        $wp_customize->add_control(
            'nest_hide_button',
            array(
                'type' => 'checkbox',
                'label' => 'Hide activation button',
                'description' => 'Useful when you want to use the button shortcodes or the ".nest-custom-activator" class on a custom activation element.',
                'section' => 'nest_button_section',
            )
        );
        
        /* custom button text */
        $wp_customize->add_setting(
            'nest_button_text',
            array( 'default' => 'Show info' )
        );
        $wp_customize->add_control(
            'nest_button_text',
            array(
                'type' => 'text',
                'label' => 'Activation button text',
                'section' => 'nest_button_section',
            )
        );
        
        /* custom button text size */
        $wp_customize->add_setting(
            'nest_button_text_size',
            array( 'default' => '' )
        );
        $wp_customize->add_control(
            'nest_button_text_size',
            array(
                'type' => 'text',
                'label' => 'Activation button text size (in pixels)',
                'description' => 'Example: 12. If empty, defaults to 10',
                'section' => 'nest_button_section',
            )
        );
        
        /* activation button style */
        $wp_customize->add_setting(
            'nest_button_style',
            array( 'default' => 'styleone' )
        );
        $wp_customize->add_control(
            'nest_button_style',
            array(
                'type' => 'radio',
                'label' => 'Activation button style',
                'section' => 'nest_button_section',
                'choices' => array(
                    'styleone' => 'Style #1',
                    'styletwo' => 'Style #2',
                    'stylethree' => 'Style #3',
                    'stylefour' => 'Style #4',
                ),
            )
        );
        
        /* activation button text color */
        $wp_customize->add_setting( 'nest_activation_button_text_color', array( 'sanitize_callback' => 'sanitize_hex_color' ));
        $wp_customize->add_control(
            new WP_Customize_Color_Control( $wp_customize, 'nest_activation_button_text_color',
                array( 'label' => 'Activation button text color', 'section' => 'nest_button_section', 'settings' => 'nest_activation_button_text_color' )
            )
        );
        
        /* activation button text color (hover) */
        $wp_customize->add_setting( 'nest_activation_button_text_hover_color', array( 'sanitize_callback' => 'sanitize_hex_color' ));
        $wp_customize->add_control(
            new WP_Customize_Color_Control( $wp_customize, 'nest_activation_button_text_hover_color',
                array( 'label' => 'Activation button text color (hover)', 'section' => 'nest_button_section', 'settings' => 'nest_activation_button_text_hover_color' )
            )
        );
        
        /* activation button color */
        $wp_customize->add_setting( 'nest_activation_button_background_color', array( 'sanitize_callback' => 'sanitize_hex_color' ));
        $wp_customize->add_control(
            new WP_Customize_Color_Control( $wp_customize, 'nest_activation_button_background_color',
                array( 'label' => 'Activation button color', 'section' => 'nest_button_section', 'settings' => 'nest_activation_button_background_color' )
            )
        );
        
        /* activation button color (hover) */
        $wp_customize->add_setting( 'nest_activation_button_background_hover_color', array( 'sanitize_callback' => 'sanitize_hex_color' ));
        $wp_customize->add_control(
            new WP_Customize_Color_Control( $wp_customize, 'nest_activation_button_background_hover_color',
                array( 'label' => 'Activation button color (hover)', 'section' => 'nest_button_section', 'settings' => 'nest_activation_button_background_hover_color' )
            )
        );
        
        /* activation button position */
        $wp_customize->add_setting('nest_button_position',array( 'default' => 'topleft' ));
        $wp_customize->add_control('nest_button_position',
            array(
                'type' => 'radio',
                'label' => 'Activation button position',
                'section' => 'nest_button_section',
                'choices' => array(
                    'topleft' => 'Top-Left',
                    'topright' => 'Top-Right',
                    'bottomleft' => 'Bottom-Left',
                    'bottomright' => 'Bottom-Right',
                ),
            )
        );
        
        /* activation button absolute */
        $wp_customize->add_setting('nest_button_absolute',array('sanitize_callback' => 'sanitize_nest_button_absolute',));
        function sanitize_nest_button_absolute( $input ) {if ( $input == 1 ) {return 1;} else {return '';}}
        $wp_customize->add_control(
            'nest_button_absolute',
            array(
                'type' => 'checkbox',
                'label' => 'Absolute position',
                'description' => 'When ticked, the activation button scrolls with the page. If unticked, the button stays in place.',
                'section' => 'nest_button_section',
            )
        );
        
        /* activation button top distance */
        $wp_customize->add_setting('nest_button_top',array('default' => '','sanitize_callback' => 'sanitize_nest_button_top',));
        function sanitize_nest_button_top($input) {return wp_kses_post(force_balance_tags($input));}
        $wp_customize->add_control('nest_button_top',
            array(
                'type' => 'text',
                'label' => 'Top distance (in pixels)',
                'description' => 'Example: 50. If empty, defaults to 20.',
                'section' => 'nest_button_section',
            )
        );
        
        /* activation button left distance */
        $wp_customize->add_setting(
            'nest_button_left',
            array(
                'default' => '',
                'sanitize_callback' => 'sanitize_nest_button_left',
            )
        );
        function sanitize_nest_button_left($input) {
            return wp_kses_post(force_balance_tags($input));
        }
        
        $wp_customize->add_control(
            'nest_button_left',
            array(
                'type' => 'text',
                'label' => 'Left distance (in pixels)',
                'description' => 'Example: 50. If empty, defaults to 20.',
                'section' => 'nest_button_section',
            )
        );
        
        /* activation button right distance */
        $wp_customize->add_setting(
            'nest_button_right',
            array(
                'default' => '',
                'sanitize_callback' => 'sanitize_nest_button_right',
            )
        );
        function sanitize_nest_button_right($input) {
            return wp_kses_post(force_balance_tags($input));
        }
        
        $wp_customize->add_control(
            'nest_button_right',
            array(
                'type' => 'text',
                'label' => 'Right distance (in pixels)',
                'description' => 'Example: 50. If empty, defaults to 20.',
                'section' => 'nest_button_section',
            )
        );
        
        /* activation button bottom distance */
        $wp_customize->add_setting(
            'nest_button_bottom',
            array(
                'default' => '',
                'sanitize_callback' => 'sanitize_nest_button_bottom',
            )
        );
        function sanitize_nest_button_bottom($input) {
            return wp_kses_post(force_balance_tags($input));
        }
        
        $wp_customize->add_control(
            'nest_button_bottom',
            array(
                'type' => 'text',
                'label' => 'Bottom distance (in pixels)',
                'description' => 'Example: 50. If empty, defaults to 20.',
                'section' => 'nest_button_section',
            )
        );
        
        //
        // ADD "Alternate Activation" SECTION TO "NEST" PANEL
        //
        $wp_customize->add_section(
        'nest_alternate_activation_section', array('title' => 'Alternate Activation','panel'  => 'nest_panel','priority' => 3,));
        
        /* automatic activation */
        $wp_customize->add_setting('nest_auto_activation',array('default' => '','sanitize_callback' => 'sanitize_nest_auto_activation',));
        function sanitize_nest_auto_activation($input) { return wp_kses_post(force_balance_tags($input)); }
        $wp_customize->add_control('nest_auto_activation',
            array(
                'type' => 'text',
                'label' => 'Automatic activation',
                'description' => 'To open the panel automatically and without user interaction, enter a time delay below (in milliseconds). Example: 0 (immediately) or 2000 (2 seconds).',
                'section' => 'nest_alternate_activation_section',
            )
        );
        
        /* auto-activate once per browser session */
        $wp_customize->add_setting('nest_browser_session',array('sanitize_callback' => 'sanitize_nest_browser_session',));
        function sanitize_nest_browser_session( $input ) {if ( $input == 1 ) {return 1;} else {return '';}}
        $wp_customize->add_control(
            'nest_browser_session',
            array(
                'type' => 'checkbox',
                'label' => 'Auto-activate once per session',
                'description' => 'Panel will auto-activate once per visitor browser session.',
                'section' => 'nest_alternate_activation_section',
            )
        );
        
        /* anchor activation */
        $wp_customize->add_setting('nest_anchor_activation',array('default' => '','sanitize_callback' => 'sanitize_nest_anchor_activation',));
        function sanitize_nest_anchor_activation($input) { return wp_kses_post(force_balance_tags($input)); }
        $wp_customize->add_control('nest_anchor_activation',
            array(
                'type' => 'text',
                'label' => 'Anchor activation',
                'description' => 'To open the panel when scrolled to an anchor, enter the anchor ID/class name below. Example: #my-anchor or .my-anchor',
                'section' => 'nest_alternate_activation_section',
            )
        );
        
        //
        // ADD "Close Button" SECTION TO "NEST" PANEL
        //
        
        $wp_customize->add_section(
        'nest_close_button_section',array('title' => 'Close Button','panel'  => 'nest_panel','priority' => 4,));
        
        /* close button style */
        $wp_customize->add_setting(
            'nest_close_button_style',
            array( 'default' => 'styleone' )
        );
        $wp_customize->add_control(
            'nest_close_button_style',
            array(
                'type' => 'radio',
                'label' => 'Close button style',
                'section' => 'nest_close_button_section',
                'choices' => array(
                    'styleone' => 'Style #1',
                    'styletwo' => 'Style #2',
                    'stylethree' => 'Style #3',
                ),
            )
        );
        
        /* close button color */
        $wp_customize->add_setting( 'nest_close_button_color', array( 'sanitize_callback' => 'sanitize_hex_color' ));
        $wp_customize->add_control(
            new WP_Customize_Color_Control( $wp_customize, 'nest_close_button_color',
                array( 'label' => 'Close button color (primary)', 'section' => 'nest_close_button_section', 'settings' => 'nest_close_button_color' )
            )
        );
        
        /* close button color (hover) */
        $wp_customize->add_setting( 'nest_close_button_hover_color', array( 'sanitize_callback' => 'sanitize_hex_color' ));
        $wp_customize->add_control(
            new WP_Customize_Color_Control( $wp_customize, 'nest_close_button_hover_color',
                array( 'label' => 'Close button color (hover, secondary)', 'section' => 'nest_close_button_section', 'settings' => 'nest_close_button_hover_color' )
            )
        );
        
        /* close button position */
        $wp_customize->add_setting(
            'nest_close_button_position',
            array( 'default' => 'left' )
        );
        $wp_customize->add_control(
            'nest_close_button_position',
            array(
                'type' => 'radio',
                'label' => 'Close button position',
                'section' => 'nest_close_button_section',
                'choices' => array(
                    'left' => 'Left',
                    'center' => 'Center',
                    'right' => 'Right',
                ),
            )
        );
        
        /* close button top distance */
        $wp_customize->add_setting(
            'nest_close_button_top',
            array(
                'default' => '',
                'sanitize_callback' => 'sanitize_nest_close_button_top',
            )
        );
        function sanitize_nest_close_button_top($input) {
            return wp_kses_post(force_balance_tags($input));
        }
        
        $wp_customize->add_control(
            'nest_close_button_top',
            array(
                'type' => 'text',
                'label' => 'Top distance (in pixels)',
                'description' => 'Example: 50. If empty, defaults to 20.',
                'section' => 'nest_close_button_section',
            )
        );
        
        /* close button left distance */
        $wp_customize->add_setting(
            'nest_close_button_left',
            array(
                'default' => '',
                'sanitize_callback' => 'sanitize_nest_close_button_left',
            )
        );
        function sanitize_nest_close_button_left($input) {
            return wp_kses_post(force_balance_tags($input));
        }
        
        $wp_customize->add_control(
            'nest_close_button_left',
            array(
                'type' => 'text',
                'label' => 'Left distance (in pixels)',
                'description' => 'Example: 50. If empty, defaults to 20.',
                'section' => 'nest_close_button_section',
            )
        );
        
        /* close button right distance */
        $wp_customize->add_setting(
            'nest_close_button_right',
            array(
                'default' => '',
                'sanitize_callback' => 'sanitize_nest_close_button_right',
            )
        );
        function sanitize_nest_close_button_right($input) {
            return wp_kses_post(force_balance_tags($input));
        }
        
        $wp_customize->add_control(
            'nest_close_button_right',
            array(
                'type' => 'text',
                'label' => 'Right distance (in pixels)',
                'description' => 'Example: 50. If empty, defaults to 20.',
                'section' => 'nest_close_button_section',
            )
        );
        
        
        //
        // ADD "Styled Scrollbar" SECTION TO "NEST" PANEL
        //
        
        $wp_customize->add_section(
        'nest_scrollbar_section',array('title' => 'Styled Scrollbar','panel'  => 'nest_panel','priority' => 4,));
        
        /* scrollbar color */
        $wp_customize->add_setting( 'nest_scrollbar_color', array( 'sanitize_callback' => 'sanitize_hex_color' ));
        $wp_customize->add_control(
            new WP_Customize_Color_Control( $wp_customize, 'nest_scrollbar_color',
                array( 'label' => 'Scrollbar', 'section' => 'nest_scrollbar_section', 'settings' => 'nest_scrollbar_color' )
            )
        );
        
        /* scrollbar background color */
        $wp_customize->add_setting( 'nest_scrollbar_background_color', array( 'sanitize_callback' => 'sanitize_hex_color' ));
        $wp_customize->add_control(
            new WP_Customize_Color_Control( $wp_customize, 'nest_scrollbar_background_color',
                array( 'label' => 'Scrollbar background', 'section' => 'nest_scrollbar_section', 'settings' => 'nest_scrollbar_background_color' )
            )
        );
        
        /* scrollbar thickness */
        $wp_customize->add_setting('nest_scrollbar_thickness',array('default' => '','sanitize_callback' => 'sanitize_nest_scrollbar_thickness',));
        function sanitize_nest_scrollbar_thickness($input) {return wp_kses_post(force_balance_tags($input));}
        $wp_customize->add_control('nest_scrollbar_thickness',array('type' => 'text','label' => 'Scrollbar thickness (in pixels)','description' => 'If empty, defaults to 5','section' => 'nest_scrollbar_section',));
        
        /* scrollbar roundness */
        $wp_customize->add_setting('nest_scrollbar_roundness',array('default' => '','sanitize_callback' => 'sanitize_nest_scrollbar_roundness',));
        function sanitize_nest_scrollbar_roundness($input) {return wp_kses_post(force_balance_tags($input));}
        $wp_customize->add_control('nest_scrollbar_roundness',array('type' => 'text','label' => 'Scrollbar roundness (in pixels)','section' => 'nest_scrollbar_section',));
        
        /* scrollbar distance */
        $wp_customize->add_setting('nest_scrollbar_distance',array('default' => '','sanitize_callback' => 'sanitize_nest_scrollbar_distance',));
        function sanitize_nest_scrollbar_distance($input) {return wp_kses_post(force_balance_tags($input));}
        $wp_customize->add_control('nest_scrollbar_distance',array('type' => 'text','label' => 'Scrollbar distance from sides (in pixels)','description' => 'If empty, defaults to 3','section' => 'nest_scrollbar_section',));
        
        //
        // ADD "Content Animation" SECTION TO "NEST" PANEL
        //
        
        $wp_customize->add_section(
        'nest_content_animation_section',array('title' => 'Content Animation','description' => 'Use these settings to add a nifty animation to your site content when the Nest panel opens/closes.','panel'  => 'nest_panel','priority' => 4,));
        
        /* elements to animate */
        $wp_customize->add_setting('nest_content_animation_elements',array('default' => '','sanitize_callback' => 'sanitize_nest_content_animation_elements',));
        function sanitize_nest_content_animation_elements($input) {return wp_kses_post(force_balance_tags($input));}
        $wp_customize->add_control('nest_content_animation_elements',array('type' => 'text','label' => 'Enter elements to animate (*required for animation to kick in)','description' => 'Enter the classes/IDs of the elements you wish to scale, separate with comma. Example: "#my-content, .content-wrapper"','section' => 'nest_content_animation_section',));
        
        /* scaling */
        $wp_customize->add_setting('nest_content_animation_scale',array('default' => '','sanitize_callback' => 'sanitize_nest_content_animation_scale',));
        function sanitize_nest_content_animation_scale($input) {return wp_kses_post(force_balance_tags($input));}
        $wp_customize->add_control('nest_content_animation_scale',array('type' => 'text','label' => 'Scaling','description' => 'To scale down, enter number smaller than 1. To scale up, enter number higher than 1. Example: 0.8 or 1.25. If empty, defaults to 0.95','section' => 'nest_content_animation_section',));
        
        /* opacity */
        $wp_customize->add_setting('nest_content_animation_opacity',array('default' => '','sanitize_callback' => 'sanitize_nest_content_animation_opacity',));
        function sanitize_nest_content_animation_opacity($input) {return wp_kses_post(force_balance_tags($input));}
        $wp_customize->add_control('nest_content_animation_opacity',array('type' => 'text','label' => 'Opacity','description' => 'Example: 0.6 or 0.75. If empty, defaults to 1','section' => 'nest_content_animation_section',));
        
        /* blur */
        $wp_customize->add_setting('nest_content_blur',array('default' => '','sanitize_callback' => 'sanitize_nest_content_blur',));
        function sanitize_nest_content_blur($input) {return wp_kses_post(force_balance_tags($input));}
        $wp_customize->add_control('nest_content_blur',array('type' => 'text','label' => 'Blur','description' => 'Example: 5 or 10. If empty, blur effect disabled','section' => 'nest_content_animation_section',));
        
        //
        // ADD "Misc" SECTION TO "NEST" PANEL
        //
        
        $wp_customize->add_section(
        'nest_misc_section',array('title' => 'Misc','panel'  => 'nest_panel','priority' => 4,));
        
        /* body scroll lock */
        $wp_customize->add_setting('nest_body_scroll_lock',array('sanitize_callback' => 'sanitize_nest_body_scroll_lock',));
        function sanitize_nest_body_scroll_lock( $input ) { if ( $input == 1 ) { return 1; } else { return ''; } }
        $wp_customize->add_control('nest_body_scroll_lock',array('type' => 'checkbox','label' => 'Lock body scroll','description' => 'If ticked, the body scroll will be disabled when a panel is opened (unless scrolling is handled in an unusual way by the theme).', 'section' => 'nest_misc_section',));
        
        /* show to logged in/out users */
        $wp_customize->add_setting(
            'nest_show_logged'
        );
        $wp_customize->add_control(
            'nest_show_logged',
            array(
                'type' => 'radio',
                'label' => 'Show flyout panel to:',
                'section' => 'nest_misc_section',
                'choices' => array(
                    'showall' => 'All users',
                    'showloggedin' => 'Logged in users only',
                    'showloggedout' => 'Logged out users only',
                ),
            )
        );

        /* smaller than */
        $wp_customize->add_setting('nest_smaller_than',array('sanitize_callback' => 'sanitize_nest_smaller_than',));
        function sanitize_nest_smaller_than($input) {return wp_kses_post(force_balance_tags($input));}
        $wp_customize->add_control('nest_smaller_than',array(
            'type' => 'text',
            'label' => 'Hide at certain width/resolution',
            'description' => '<strong>Example #1:</strong> If you want to show Nest on desktop only, enter the values as 0 and 500. <br><br> <strong>Example #2:</strong> If you want to show Nest on mobile only, enter the values as 500 and 5000. <br><br> Feel free to experiment with your own values to get the result that is right for you. If fields are empty, Nest will be visible at all browser widths and resolutions. <br><br> Hide Nest panel if browser width or screen resolution (in pixels) is between...',
            'section' => 'nest_misc_section',
        ));
        
        /* larger than */
        $wp_customize->add_setting('nest_larger_than',array('sanitize_callback' => 'sanitize_nest_larger_than',));
        function sanitize_nest_larger_than($input) {return wp_kses_post(force_balance_tags($input));}
        $wp_customize->add_control('nest_larger_than',array(
            'type' => 'text',
            'description' => '..and:',
            'section' => 'nest_misc_section',
        ));

    }
    add_action( 'customize_register', 'nest_customizer' );


    //
    // NEST PER-POST/PAGE FLYOUT SELECT & CUSTOMIZATIONS
    //
    
    /* add meta box to the post/page editing screen */
    function nest_custom_meta() {
        add_meta_box( 'nest_meta', __( 'Nest Plugin: Per-Post', 'nest' ), 'nest_meta_callback', 'post' );
        add_meta_box( 'nest_meta', __( 'Nest Plugin: Per-Page', 'nest' ), 'nest_meta_callback', 'page' );
    }
    add_action( 'add_meta_boxes', 'nest_custom_meta' );

     /* place content into meta box */
    function nest_meta_callback( $post ) {
        
        /* anchors */
        echo 'Jump to: <a href="#nest-page-select">Page Select/Hide</a> | <a href="#nest-main-settings">Main Settings</a> | <a href="#nest-activation-button">Activation Button</a> | <a href="#nest-alternate-activation">Alternate Activation</a> | <a href="#nest-close-button">Close Button</a> | <a href="#nest-styled-scrollbar">Styled Scrollbar</a> | <a href="#nest-content-animation">Content Animation</a> | <a href="#nest-misc">Misc</a>';
        
        wp_nonce_field( basename( __FILE__ ), 'nest_nonce' );
        $nest_stored_meta = get_post_meta( $post->ID );
        /* page selector */
        $values = get_post_custom( $post->ID );
		$selected = isset( $values['bonfire_nest_meta_box_select'] ) ? esc_attr( $values['bonfire_nest_meta_box_select'][0] ) : '';
        ?>
        
        <p>
            <h3 id="nest-page-select" style="padding-top:50px;">Page Select/Hide:</h3>
        </p>
        
        <!-- Hide panel on this post/page -->
        <p>
            <label for="nest-hide">
                <input type="checkbox" name="nest-hide" id="nest-hide" value="yes" <?php if ( isset ( $nest_stored_meta['nest-hide'] ) ) checked( $nest_stored_meta['nest-hide'][0], 'yes' ); ?> />
				<?php _e( 'Hide panel on this post/page', 'nest' )?>
			</label>
        </p>
        <!-- Page select drop-down -->
        <p>
            <label for="bonfire_nest_meta_box_select" class="nest-row-title"><?php _e( 'Select page to show in flyout <br>(must select for customization tools below to take effect):', 'nest' )?></label>
            <?php wp_dropdown_pages( array( 'name' => 'bonfire_nest_meta_box_select', 'id' => 'bonfire_nest_meta_box_select', 'selected' => $selected, 'show_option_none' => '— Select —' ) ); ?>
        </p>

        <p>
            <h3 id="nest-main-settings" style="padding-top:50px;">Main Settings:</h3>
        </p>
        
        <!-- Appearance speed -->
        <p>
            <label for="nest-appearance-speed" class="nest-row-title"><?php _e( 'Animation speed in seconds (example: 1.5). <br>If left empty, defaults to 0.5', 'nest' )?></label>
            <input type="text" name="nest-appearance-speed" id="nest-appearance-speed" value="<?php if ( isset ( $nest_stored_meta['nest-appearance-speed'] ) ) echo $nest_stored_meta['nest-appearance-speed'][0]; ?>" style="width:55px;" />s
        </p>
        <!-- Fade-in content -->
        <p>
            <label for="nest-fade-in">
                <input type="checkbox" name="nest-fade-in" id="nest-fade-in" value="yes" <?php if ( isset ( $nest_stored_meta['nest-fade-in'] ) ) checked( $nest_stored_meta['nest-fade-in'][0], 'yes' ); ?> />
				<?php _e( 'Add subtle fade-in effect to content', 'nest' )?>
			</label>
        </p>
        <!-- Flyout direction radio buttons -->
        <p>
            <span class="nest-row-title"><?php _e( 'Flyout direction', 'nest' )?></span>
            <div class="nest-row-content">
                <label for="nest-direction-top">
                    <input type="radio" name="nest-direction" id="nest-direction-top" value="top" <?php if ( isset ( $nest_stored_meta['nest-direction'] ) ) checked( $nest_stored_meta['nest-direction'][0], 'top' ); ?> checked="checked">
                    <?php _e( 'Top', 'nest' )?>
                </label>
                <label for="nest-direction-left">
                    <input type="radio" name="nest-direction" id="nest-direction-left" value="left" <?php if ( isset ( $nest_stored_meta['nest-direction'] ) ) checked( $nest_stored_meta['nest-direction'][0], 'left' ); ?>>
                    <?php _e( 'Left', 'nest' )?>
                </label>
                <label for="nest-direction-right">
                    <input type="radio" name="nest-direction" id="nest-direction-right" value="right" <?php if ( isset ( $nest_stored_meta['nest-direction'] ) ) checked( $nest_stored_meta['nest-direction'][0], 'right' ); ?>>
                    <?php _e( 'Right', 'nest' )?>
                </label>
                <label for="nest-direction-bottom">
                    <input type="radio" name="nest-direction" id="nest-direction-bottom" value="bottom" <?php if ( isset ( $nest_stored_meta['nest-direction'] ) ) checked( $nest_stored_meta['nest-direction'][0], 'bottom' ); ?>>
                    <?php _e( 'Bottom', 'nest' )?>
                </label>
            </div>
        </p>
        <!-- Slide width -->
        <p>
            <label for="nest-slide-width" class="nest-row-title"><?php _e( 'Flyout width in pixels (example: 250). <br>If left empty, defaults to full-screen. Ignored when left/right slide-in direction chosen.', 'nest' )?></label>
            <input type="text" name="nest-slide-width" id="nest-slide-width" value="<?php if ( isset ( $nest_stored_meta['nest-slide-width'] ) ) echo $nest_stored_meta['nest-slide-width'][0]; ?>" style="width:55px;" />px
        </p>
        <!-- Slide height -->
        <p>
            <label for="nest-slide-height" class="nest-row-title"><?php _e( 'Flyout height in pixels (example: 250). <br>If left empty, defaults to full-screen. Ignored when top/bottom slide-in direction chosen.', 'nest' )?></label>
            <input type="text" name="nest-slide-height" id="nest-slide-height" value="<?php if ( isset ( $nest_stored_meta['nest-slide-height'] ) ) echo $nest_stored_meta['nest-slide-height'][0]; ?>" style="width:55px;" />px
        </p>
        <!-- Content width -->
        <p>
            <label for="nest-content-width" class="nest-row-title"><?php _e( 'Content maximum width in pixels (example: 250). <br>If left empty, defaults to full-width).', 'nest' )?></label>
            <input type="text" name="nest-content-width" id="nest-content-width" value="<?php if ( isset ( $nest_stored_meta['nest-content-width'] ) ) echo $nest_stored_meta['nest-content-width'][0]; ?>" style="width:55px;" />px
        </p>
        <!-- Image uploader -->
        <p>
            <label for="nest-image-upload" class="nest-row-title"><?php _e( 'Background image', 'nest' )?></label>
            <input type="text" name="nest-image-upload" id="nest-image-upload" value="<?php if ( isset ( $nest_stored_meta['nest-image-upload'] ) ) echo $nest_stored_meta['nest-image-upload'][0]; ?>" />
            <input type="button" id="nest-image-upload-button" class="button" value="<?php _e( 'Choose or Upload an Image', 'nest' )?>" /><br>
            <!-- Show background as pattern -->
            <label for="nest-background-pattern">
                <input type="checkbox" name="nest-background-pattern" id="nest-background-pattern" value="yes" <?php if ( isset ( $nest_stored_meta['nest-background-pattern'] ) ) checked( $nest_stored_meta['nest-background-pattern'][0], 'yes' ); ?> />
				<?php _e( 'Show background image as pattern', 'nest' )?>
			</label>
        </p>
        <!-- Background image opacity -->
        <p>
            <label for="nest-background-image-opacity" class="nest-row-title"><?php _e( 'Background image opacity (example: 0.5). <br>If left empty, defaults to 1.', 'nest' )?></label>
            <input type="text" name="nest-background-image-opacity" id="nest-background-image-opacity" value="<?php if ( isset ( $nest_stored_meta['nest-background-image-opacity'] ) ) echo $nest_stored_meta['nest-background-image-opacity'][0]; ?>" style="width:55px;" />
        </p>
        <!-- Background color -->
        <p>
            <label for="nest-bg-color" class="nest-row-title"><?php _e( 'Background color', 'nest' )?></label>
            <input name="nest-bg-color" type="text" value="<?php if ( isset ( $nest_stored_meta['nest-bg-color'] ) ) echo $nest_stored_meta['nest-bg-color'][0]; ?>" class="nest-bg-color" />
        </p>
        <!-- Background color opacity -->
        <p>
            <label for="nest-background-color-opacity" class="nest-row-title"><?php _e( 'Background color opacity (example: 0.5). <br>If left empty, defaults to 1', 'nest' )?></label>
            <input type="text" name="nest-background-color-opacity" id="nest-background-color-opacity" value="<?php if ( isset ( $nest_stored_meta['nest-background-color-opacity'] ) ) echo $nest_stored_meta['nest-background-color-opacity'][0]; ?>" style="width:55px;" />
        </p>
        <!-- Overlay color -->
        <p>
            <label for="nest-overlay-color" class="nest-row-title"><?php _e( 'Overlay color', 'nest' )?></label>
            <input name="nest-overlay-color" type="text" value="<?php if ( isset ( $nest_stored_meta['nest-overlay-color'] ) ) echo $nest_stored_meta['nest-overlay-color'][0]; ?>" class="nest-overlay-color" />
        </p>
        <!-- Overlay color opacity -->
        <p>
            <label for="nest-overlay-color-opacity" class="nest-row-title"><?php _e( 'Overlay color opacity (example: 0.5). <br>If left empty, defaults to 0.75', 'nest' )?></label>
            <input type="text" name="nest-overlay-color-opacity" id="nest-overlay-color-opacity" value="<?php if ( isset ( $nest_stored_meta['nest-overlay-color-opacity'] ) ) echo $nest_stored_meta['nest-overlay-color-opacity'][0]; ?>" style="width:55px;" />
        </p>
        <!-- Show close cursor -->
        <p>
            <label for="nest-overlay-cursor">
                <input type="checkbox" name="nest-overlay-cursor" id="nest-overlay-cursor" value="yes" <?php if ( isset ( $nest_stored_meta['nest-overlay-cursor'] ) ) checked( $nest_stored_meta['nest-overlay-cursor'][0], 'yes' ); ?> />
				<?php _e( 'Show cursor as icon on overlay', 'nest' )?>
			</label>
        </p>
        
        <p>
            <h3 id="nest-activation-button" style="padding-top:50px;">Activation Button:</h3>
        </p>
        
        <!-- Activation button hide -->
        <p>
            <label for="nest-hide-button">
                <input type="checkbox" name="nest-hide-button" id="nest-hide-button" value="yes" <?php if ( isset ( $nest_stored_meta['nest-hide-button'] ) ) checked( $nest_stored_meta['nest-hide-button'][0], 'yes' ); ?> />
				<?php _e( 'Hide activation button (useful when you want to use the button shortcodes or the ".nest-custom-activator" class on a custom activation element)', 'nest' )?>
			</label>
        </p>
        <!-- Activation button text -->
        <p>
            <label for="nest-button-text" class="nest-row-title"><?php _e( 'Activation button text:', 'nest' )?></label>
            <input type="text" name="nest-button-text" id="nest-button-text" value="<?php if ( isset ( $nest_stored_meta['nest-button-text'] ) ) echo $nest_stored_meta['nest-button-text'][0]; ?>" />
        </p>
        <!-- Activation button text size -->
        <p>
            <label for="nest-button-text-size" class="nest-row-title"><?php _e( 'Activation button text size (in pixels):', 'nest' )?></label>
            <input type="text" name="nest-button-text-size" id="nest-button-text-size" value="<?php if ( isset ( $nest_stored_meta['nest-button-text-size'] ) ) echo $nest_stored_meta['nest-button-text-size'][0]; ?>" style="width:55px;" />
        </p>
        <!-- Activation button style radio buttons -->
        <p>
            <span class="nest-row-title"><?php _e( 'Activation button style', 'nest' )?></span>
            <div class="nest-row-content">
                <label for="nest-button-style-one">
                    <input type="radio" name="nest-button-style" id="nest-button-style-one" value="styleone" <?php if ( isset ( $nest_stored_meta['nest-button-style'] ) ) checked( $nest_stored_meta['nest-button-style'][0], 'styleone' ); ?> checked="checked">
                    <?php _e( 'Style #1', 'nest' )?>
                </label>
                <label for="nest-button-style-two">
                    <input type="radio" name="nest-button-style" id="nest-button-style-two" value="styletwo" <?php if ( isset ( $nest_stored_meta['nest-button-style'] ) ) checked( $nest_stored_meta['nest-button-style'][0], 'styletwo' ); ?>>
                    <?php _e( 'Style #2', 'nest' )?>
                </label>
                <label for="nest-button-style-three">
                    <input type="radio" name="nest-button-style" id="nest-button-style-three" value="stylethree" <?php if ( isset ( $nest_stored_meta['nest-button-style'] ) ) checked( $nest_stored_meta['nest-button-style'][0], 'stylethree' ); ?>>
                    <?php _e( 'Style #3', 'nest' )?>
                </label>
                <label for="nest-button-style-four">
                    <input type="radio" name="nest-button-style" id="nest-button-style-four" value="stylefour" <?php if ( isset ( $nest_stored_meta['nest-button-style'] ) ) checked( $nest_stored_meta['nest-button-style'][0], 'stylefour' ); ?>>
                    <?php _e( 'Style #4', 'nest' )?>
                </label>
            </div>
        </p>
        <!-- Activation button text color -->
        <p>
            <label for="nest-activation-button-text-color" class="nest-row-title"><?php _e( 'Activation button text color:', 'nest' )?></label>
            <input name="nest-activation-button-text-color" type="text" value="<?php if ( isset ( $nest_stored_meta['nest-activation-button-text-color'] ) ) echo $nest_stored_meta['nest-activation-button-text-color'][0]; ?>" class="nest-activation-button-text-color" />
        </p>
        <!-- Activation button text color (hover) -->
        <p>
            <label for="nest-activation-button-text-hover-color" class="nest-row-title"><?php _e( 'Activation button text color (hover):', 'nest' )?></label>
            <input name="nest-activation-button-text-hover-color" type="text" value="<?php if ( isset ( $nest_stored_meta['nest-activation-button-text-hover-color'] ) ) echo $nest_stored_meta['nest-activation-button-text-hover-color'][0]; ?>" class="nest-activation-button-text-hover-color" />
        </p>
        <!-- Activation button color -->
        <p>
            <label for="nest-activation-button-bg-color" class="nest-row-title"><?php _e( 'Activation button color:', 'nest' )?></label>
            <input name="nest-activation-button-bg-color" type="text" value="<?php if ( isset ( $nest_stored_meta['nest-activation-button-bg-color'] ) ) echo $nest_stored_meta['nest-activation-button-bg-color'][0]; ?>" class="nest-activation-button-bg-color" />
        </p>
        <!-- Activation button color (hover) -->
        <p>
            <label for="nest-activation-button-bg-hover-color" class="nest-row-title"><?php _e( 'Activation button color (hover):', 'nest' )?></label>
            <input name="nest-activation-button-bg-hover-color" type="text" value="<?php if ( isset ( $nest_stored_meta['nest-activation-button-bg-hover-color'] ) ) echo $nest_stored_meta['nest-activation-button-bg-hover-color'][0]; ?>" class="nest-activation-button-bg-hover-color" />
        </p>
        <!-- Activation button position -->
        <p>
            <span class="nest-row-title"><?php _e( 'Button position', 'nest' )?></span>
            <div class="nest-row-content">
                <label for="nest-button-top-left">
                    <input type="radio" name="nest-button-position" id="nest-button-top-left" value="topleft" <?php if ( isset ( $nest_stored_meta['nest-button-position'] ) ) checked( $nest_stored_meta['nest-button-position'][0], 'topleft' ); ?> checked="checked">
                    <?php _e( 'Top-Left', 'nest' )?>
                </label>
                <label for="nest-button-top-right">
                    <input type="radio" name="nest-button-position" id="nest-button-top-right" value="topright" <?php if ( isset ( $nest_stored_meta['nest-button-position'] ) ) checked( $nest_stored_meta['nest-button-position'][0], 'topright' ); ?>>
                    <?php _e( 'Top-Right', 'nest' )?>
                </label>
                <label for="nest-button-bottom-left">
                    <input type="radio" name="nest-button-position" id="nest-button-bottom-left" value="bottomleft" <?php if ( isset ( $nest_stored_meta['nest-button-position'] ) ) checked( $nest_stored_meta['nest-button-position'][0], 'bottomleft' ); ?>>
                    <?php _e( 'Bottom-Left', 'nest' )?>
                </label>
                <label for="nest-button-bottom-right">
                    <input type="radio" name="nest-button-position" id="nest-button-bottom-right" value="bottomright" <?php if ( isset ( $nest_stored_meta['nest-button-position'] ) ) checked( $nest_stored_meta['nest-button-position'][0], 'bottomright' ); ?>>
                    <?php _e( 'Bottom-Right', 'nest' )?>
                </label>
            </div>
        </p>
        <!-- Activation button hide -->
        <p>
            <label for="nest-button-absolute">
                <input type="checkbox" name="nest-button-absolute" id="nest-button-absolute" value="yes" <?php if ( isset ( $nest_stored_meta['nest-button-absolute'] ) ) checked( $nest_stored_meta['nest-button-absolute'][0], 'yes' ); ?> />
				<?php _e( 'Absolute position<br>When ticked, the activation button scrolls with the page. If unticked, the button stays in place.', 'nest' )?>
			</label>
        </p>
        <!-- Activation button top distance -->
        <p>
            <label for="nest-activation-button-top" class="nest-row-title"><?php _e( 'Top distance<br>Example: 50. If empty, defaults to 20.', 'nest' )?></label>
            <input type="text" name="nest-activation-button-top" id="nest-activation-button-top" value="<?php if ( isset ( $nest_stored_meta['nest-activation-button-top'] ) ) echo $nest_stored_meta['nest-activation-button-top'][0]; ?>" style="width:55px;" />
        </p>
        <!-- Activation button left distance -->
        <p>
            <label for="nest-activation-button-left" class="nest-row-title"><?php _e( 'Left distance<br>Example: 50. If empty, defaults to 20.', 'nest' )?></label>
            <input type="text" name="nest-activation-button-left" id="nest-activation-button-left" value="<?php if ( isset ( $nest_stored_meta['nest-activation-button-left'] ) ) echo $nest_stored_meta['nest-activation-button-left'][0]; ?>" style="width:55px;" />
        </p>
        <!-- Activation button right distance -->
        <p>
            <label for="nest-activation-button-right" class="nest-row-title"><?php _e( 'Right distance<br>Example: 50. If empty, defaults to 20.', 'nest' )?></label>
            <input type="text" name="nest-activation-button-right" id="nest-activation-button-right" value="<?php if ( isset ( $nest_stored_meta['nest-activation-button-right'] ) ) echo $nest_stored_meta['nest-activation-button-right'][0]; ?>" style="width:55px;" />
        </p>
        <!-- Activation button bottom distance -->
        <p>
            <label for="nest-activation-button-bottom" class="nest-row-title"><?php _e( 'Bottom distance<br>Example: 50. If empty, defaults to 20.', 'nest' )?></label>
            <input type="text" name="nest-activation-button-bottom" id="nest-activation-button-bottom" value="<?php if ( isset ( $nest_stored_meta['nest-activation-button-bottom'] ) ) echo $nest_stored_meta['nest-activation-button-bottom'][0]; ?>" style="width:55px;" />
        </p>
        
        <p>
            <h3 id="nest-alternate-activation" style="padding-top:50px;">Alternate Activation:</h3>
        </p>
        
        <!-- Automatic Activation -->
        <p>
            <label for="nest-automatic-activation" class="nest-row-title"><?php _e( 'Automatic activation<br>To open the panel automatically and without user interaction, enter a time delay below (in milliseconds).<br>Example: 0 (immediately) or 2000 (2 seconds).', 'nest' )?></label>
            <input type="text" name="nest-automatic-activation" id="nest-automatic-activation" value="<?php if ( isset ( $nest_stored_meta['nest-automatic-activation'] ) ) echo $nest_stored_meta['nest-automatic-activation'][0]; ?>" />
        </p>
        <!-- Once per session -->
        <p>
            <label for="nest-once-per-session">
                <input type="checkbox" name="nest-once-per-session" id="nest-once-per-session" value="yes" <?php if ( isset ( $nest_stored_meta['nest-once-per-session'] ) ) checked( $nest_stored_meta['nest-once-per-session'][0], 'yes' ); ?> />
				<?php _e( 'Auto-activate once per session<br>Panel will auto-activate once per visitor browser session.', 'nest' )?>
			</label>
        </p>
        <!-- Anchor Activation -->
        <p>
            <label for="nest-anchor-activation" class="nest-row-title"><?php _e( 'Anchor activation<br>To open the panel when scrolled to an anchor, enter the anchor ID/class name below. Example: #my-anchor or .my-anchor', 'nest' )?></label>
            <input type="text" name="nest-anchor-activation" id="nest-anchor-activation" value="<?php if ( isset ( $nest_stored_meta['nest-anchor-activation'] ) ) echo $nest_stored_meta['nest-anchor-activation'][0]; ?>" />
        </p>
        
        <p>
            <h3 id="nest-close-button" style="padding-top:50px;">Close Button:</h3>
        </p>
        
        <!-- Close button style -->
        <p>
            <span class="nest-row-title"><?php _e( 'Close button style', 'nest' )?></span>
            <div class="nest-row-content">
                <label for="nest-close-button-style-one">
                    <input type="radio" name="nest-close-button-style" id="nest-close-button-style-one" value="styleone" <?php if ( isset ( $nest_stored_meta['nest-close-button-style'] ) ) checked( $nest_stored_meta['nest-close-button-style'][0], 'styleone' ); ?> checked="checked">
                    <?php _e( 'Style #1', 'nest' )?>
                </label>
                <label for="nest-close-button-style-two">
                    <input type="radio" name="nest-close-button-style" id="nest-close-button-style-two" value="styletwo" <?php if ( isset ( $nest_stored_meta['nest-close-button-style'] ) ) checked( $nest_stored_meta['nest-close-button-style'][0], 'styletwo' ); ?>>
                    <?php _e( 'Style #2', 'nest' )?>
                </label>
                <label for="nest-close-button-style-three">
                    <input type="radio" name="nest-close-button-style" id="nest-close-button-style-three" value="stylethree" <?php if ( isset ( $nest_stored_meta['nest-close-button-style'] ) ) checked( $nest_stored_meta['nest-close-button-style'][0], 'stylethree' ); ?>>
                    <?php _e( 'Style #3', 'nest' )?>
                </label>
            </div>
        </p>
        <!-- Close button color -->
        <p>
            <label for="nest-close-button-color" class="nest-row-title"><?php _e( 'Close button color (primary):', 'nest' )?></label>
            <input name="nest-close-button-color" type="text" value="<?php if ( isset ( $nest_stored_meta['nest-close-button-color'] ) ) echo $nest_stored_meta['nest-close-button-color'][0]; ?>" class="nest-close-button-color" />
        </p>
        <!-- Close button color (hover) -->
        <p>
            <label for="nest-close-button-hover-color" class="nest-row-title"><?php _e( 'Close button color (hover, secondary):', 'nest' )?></label>
            <input name="nest-close-button-hover-color" type="text" value="<?php if ( isset ( $nest_stored_meta['nest-close-button-hover-color'] ) ) echo $nest_stored_meta['nest-close-button-hover-color'][0]; ?>" class="nest-close-button-hover-color" />
        </p>
        <!-- Close button position -->
        <p>
            <span class="nest-row-title"><?php _e( 'Close button position', 'nest' )?></span>
            <div class="nest-row-content">
                <label>
                    <input type="radio" name="nest-close-button" id="nest-close-button-left" value="left" <?php if ( isset ( $nest_stored_meta['nest-close-button'] ) ) checked( $nest_stored_meta['nest-close-button'][0], 'left' ); ?> checked="checked">
                    <?php _e( 'Left', 'nest' )?>
                </label>
                <label>
                    <input type="radio" name="nest-close-button" id="nest-close-button-center" value="center" <?php if ( isset ( $nest_stored_meta['nest-close-button'] ) ) checked( $nest_stored_meta['nest-close-button'][0], 'center' ); ?>>
                    <?php _e( 'Center', 'nest' )?>
                </label>
                <label>
                    <input type="radio" name="nest-close-button" id="nest-close-button-right" value="right" <?php if ( isset ( $nest_stored_meta['nest-close-button'] ) ) checked( $nest_stored_meta['nest-close-button'][0], 'right' ); ?>>
                    <?php _e( 'Right', 'nest' )?>
                </label>
            </div>
        </p>
        <!-- Close button top distance -->
        <p>
            <label for="nest-close-button-top" class="nest-row-title"><?php _e( 'Top distance<br>Example: 50. If empty, defaults to 20.', 'nest' )?></label>
            <input type="text" name="nest-close-button-top" id="nest-close-button-top" value="<?php if ( isset ( $nest_stored_meta['nest-close-button-top'] ) ) echo $nest_stored_meta['nest-close-button-top'][0]; ?>" style="width:55px;" />
        </p>
        <!-- Close button left distance -->
        <p>
            <label for="nest-close-button-left" class="nest-row-title"><?php _e( 'Left distance<br>Example: 50. If empty, defaults to 20.', 'nest' )?></label>
            <input type="text" name="nest-close-button-left" id="nest-close-button-left" value="<?php if ( isset ( $nest_stored_meta['nest-close-button-left'] ) ) echo $nest_stored_meta['nest-close-button-left'][0]; ?>" style="width:55px;" />
        </p>
        <!-- Close button right distance -->
        <p>
            <label for="nest-close-button-right" class="nest-row-title"><?php _e( 'Right distance<br>Example: 50. If empty, defaults to 20.', 'nest' )?></label>
            <input type="text" name="nest-close-button-right" id="nest-close-button-right" value="<?php if ( isset ( $nest_stored_meta['nest-close-button-right'] ) ) echo $nest_stored_meta['nest-close-button-right'][0]; ?>" style="width:55px;" />
        </p>
        
        <p>
            <h3 id="nest-styled-scrollbar" style="padding-top:50px;">Styled scrollbar:</h3>
        </p>
        
        <!-- Scrollbar color -->
        <p>
            <label for="nest-scrollbar-color" class="nest-row-title"><?php _e( 'Scrollbar:', 'nest' )?></label>
            <input name="nest-scrollbar-color" type="text" value="<?php if ( isset ( $nest_stored_meta['nest-scrollbar-color'] ) ) echo $nest_stored_meta['nest-scrollbar-color'][0]; ?>" class="nest-scrollbar-color" />
        </p>
        <!-- Scrollbar background color -->
        <p>
            <label for="nest-scrollbar-background-color" class="nest-row-title"><?php _e( 'Scrollbar background:', 'nest' )?></label>
            <input name="nest-scrollbar-background-color" type="text" value="<?php if ( isset ( $nest_stored_meta['nest-scrollbar-background-color'] ) ) echo $nest_stored_meta['nest-scrollbar-background-color'][0]; ?>" class="nest-scrollbar-background-color" />
        </p>
        <!-- Scrollbar thickness -->
        <p>
            <label for="nest-scrollbar-thickness" class="nest-row-title"><?php _e( 'Scrollbar thickness (in pixels). If empty, defaults to 5', 'nest' )?></label>
            <input type="text" name="nest-scrollbar-thickness" id="nest-scrollbar-thickness" value="<?php if ( isset ( $nest_stored_meta['nest-scrollbar-thickness'] ) ) echo $nest_stored_meta['nest-scrollbar-thickness'][0]; ?>"/>
        </p>
        <!-- Scrollbar roundness -->
        <p>
            <label for="nest-scrollbar-roundness" class="nest-row-title"><?php _e( 'Scrollbar roundness (in pixels)', 'nest' )?></label>
            <input type="text" name="nest-scrollbar-roundness" id="nest-scrollbar-roundness" value="<?php if ( isset ( $nest_stored_meta['nest-scrollbar-roundness'] ) ) echo $nest_stored_meta['nest-scrollbar-roundness'][0]; ?>"/>
        </p>
        <!-- Scrollbar distance from sides -->
        <p>
            <label for="nest-scrollbar-distance" class="nest-row-title"><?php _e( 'Scrollbar distance from sides (in pixels). If empty, defaults to 3', 'nest' )?></label>
            <input type="text" name="nest-scrollbar-distance" id="nest-scrollbar-distance" value="<?php if ( isset ( $nest_stored_meta['nest-scrollbar-distance'] ) ) echo $nest_stored_meta['nest-scrollbar-distance'][0]; ?>"/>
        </p>
        
        <p>
            <h3 id="nest-content-animation" style="padding-top:50px;">Content Animation:</h3>
        </p>
        
        <!-- Elements to animate -->
        <p>
            <label for="nest-content-animation-elements" class="nest-row-title"><?php _e( 'Enter elements to animate (*required for animation to kick in)<br>Enter the classes/IDs of the elements you wish to scale, separate with comma. Example: "#my-content, .content-wrapper"', 'nest' )?></label>
            <input type="text" name="nest-content-animation-elements" id="nest-content-animation-elements" value="<?php if ( isset ( $nest_stored_meta['nest-content-animation-elements'] ) ) echo $nest_stored_meta['nest-content-animation-elements'][0]; ?>"/>
        </p>
        <!-- Scaling -->
        <p>
            <label for="nest-content-animation-scale" class="nest-row-title"><?php _e( 'Scaling<br>To scale down, enter number smaller than 1. To scale up, enter number higher than 1. Example: 0.8 or 1.25. If empty, defaults to 0.95', 'nest' )?></label>
            <input type="text" name="nest-content-animation-scale" id="nest-content-animation-scale" value="<?php if ( isset ( $nest_stored_meta['nest-content-animation-scale'] ) ) echo $nest_stored_meta['nest-content-animation-scale'][0]; ?>"/>
        </p>
        <!-- Opacity -->
        <p>
            <label for="nest-content-animation-opacity" class="nest-row-title"><?php _e( 'Opacity<br>Example: 0.6 or 0.75. If empty, defaults to 1', 'nest' )?></label>
            <input type="text" name="nest-content-animation-opacity" id="nest-content-animation-opacity" value="<?php if ( isset ( $nest_stored_meta['nest-content-animation-opacity'] ) ) echo $nest_stored_meta['nest-content-animation-opacity'][0]; ?>"/>
        </p>
        <!-- Blur -->
        <p>
            <label for="nest-content-blur" class="nest-row-title"><?php _e( 'Blur<br>Example: 5 or 10. If empty, blur effect disabled', 'nest' )?></label>
            <input type="text" name="nest-content-blur" id="nest-content-blur" value="<?php if ( isset ( $nest_stored_meta['nest-content-blur'] ) ) echo $nest_stored_meta['nest-content-blur'][0]; ?>"/>
        </p>
        <!-- Show to logged in/out users -->
        <p>
            <span class="nest-row-title"><?php _e( 'Show flyout panel to:', 'nest' )?></span>
            <div class="nest-row-content">
                <label for="nest-show-all">
                    <input type="radio" name="nest-showto" id="nest-showto-all" value="all" <?php if ( isset ( $nest_stored_meta['nest-showto'] ) ) checked( $nest_stored_meta['nest-showto'][0], 'all' ); ?> checked="checked">
                    <?php _e( 'All users', 'nest' )?>
                </label>
                <label for="nest-show-loggedin">
                    <input type="radio" name="nest-showto" id="nest-showto-loggedin" value="loggedin" <?php if ( isset ( $nest_stored_meta['nest-showto'] ) ) checked( $nest_stored_meta['nest-showto'][0], 'loggedin' ); ?>>
                    <?php _e( 'Logged in users only', 'nest' )?>
                </label>
                <label for="nest-show-loggedout">
                    <input type="radio" name="nest-showto" id="nest-showto-loggedout" value="loggedout" <?php if ( isset ( $nest_stored_meta['nest-showto'] ) ) checked( $nest_stored_meta['nest-showto'][0], 'loggedout' ); ?>>
                    <?php _e( 'Logged out users only', 'nest' )?>
                </label>
            </div>
        </p>

        <p>
            <h3 id="nest-misc" style="padding-top:50px;">Misc:</h3>
            <h3 style="padding-top:10px;">Hide at certain width/resolution</h3>
        </p>
        
        <!-- Smaller than -->
        <p>
            <label for="nest-smaller-than" class="nest-row-title"><?php _e( 'Example #1: If you want to show Nest on desktop only, enter the values as 0 and 500. <br> Example #2: If you want to show Nest on mobile only, enter the values as 500 and 5000. <br> Feel free to experiment with your own values to get the result that is right for you. If fields are empty, Nest will be visible at all browser widths and resolutions. <br><br> Hide Nest panel if browser width or screen resolution (in pixels) is between...', 'nest' )?></label>
            <input type="text" name="nest-smaller-than" id="nest-smaller-than" value="<?php if ( isset ( $nest_stored_meta['nest-smaller-than'] ) ) echo $nest_stored_meta['nest-smaller-than'][0]; ?>"/>
        </p>
        <!-- Larger than -->
        <p>
            <label for="nest-larger-than" class="nest-row-title"><?php _e( '..and:', 'nest' )?></label>
            <input type="text" name="nest-larger-than" id="nest-larger-than" value="<?php if ( isset ( $nest_stored_meta['nest-larger-than'] ) ) echo $nest_stored_meta['nest-larger-than'][0]; ?>"/>
        </p>
    
        <?php
    }
    
    /* save custom meta input */
    function nest_meta_save( $post_id ) {
 
        // check save status
        $is_autosave = wp_is_post_autosave( $post_id );
        $is_revision = wp_is_post_revision( $post_id );
        $is_valid_nonce = ( isset( $_POST[ 'nest_nonce' ] ) && wp_verify_nonce( $_POST[ 'nest_nonce' ], basename( __FILE__ ) ) ) ? 'true' : 'false';
    
        // exits script depending on save status
        if ( $is_autosave || $is_revision || !$is_valid_nonce ) {
            return;
        }
        
        // hide on this post/page
		if( isset( $_POST[ 'nest-hide' ] ) ) {
			update_post_meta( $post_id, 'nest-hide', 'yes' );
		} else {
			update_post_meta( $post_id, 'nest-hide', '' );
		}

        // page selection
        if( isset( $_POST['bonfire_nest_meta_box_select'] ) )
		update_post_meta( $post_id, 'bonfire_nest_meta_box_select', esc_attr( $_POST['bonfire_nest_meta_box_select'] ) );

        // appearance speed
        if( isset( $_POST[ 'nest-appearance-speed' ] ) ) {
            update_post_meta( $post_id, 'nest-appearance-speed', sanitize_text_field( $_POST[ 'nest-appearance-speed' ] ) );
        }
        
        // slide fade-in
		if( isset( $_POST[ 'nest-fade-in' ] ) ) {
			update_post_meta( $post_id, 'nest-fade-in', 'yes' );
		} else {
			update_post_meta( $post_id, 'nest-fade-in', '' );
		}
        
        // slide direction
        if( isset( $_POST[ 'nest-direction' ] ) ) {
            update_post_meta( $post_id, 'nest-direction', $_POST[ 'nest-direction' ] );
        }

        // slide width
        if( isset( $_POST[ 'nest-slide-width' ] ) ) {
            update_post_meta( $post_id, 'nest-slide-width', sanitize_text_field( $_POST[ 'nest-slide-width' ] ) );
        }
        
        // slide height
        if( isset( $_POST[ 'nest-slide-height' ] ) ) {
            update_post_meta( $post_id, 'nest-slide-height', sanitize_text_field( $_POST[ 'nest-slide-height' ] ) );
        }
        
        // content width
        if( isset( $_POST[ 'nest-content-width' ] ) ) {
            update_post_meta( $post_id, 'nest-content-width', sanitize_text_field( $_POST[ 'nest-content-width' ] ) );
        }
        
        // background image
        if( isset( $_POST[ 'nest-image-upload' ] ) ) {
            update_post_meta( $post_id, 'nest-image-upload', $_POST[ 'nest-image-upload' ] );
        }
		
		// background as pattern
		if( isset( $_POST[ 'nest-background-pattern' ] ) ) {
			update_post_meta( $post_id, 'nest-background-pattern', 'yes' );
		} else {
			update_post_meta( $post_id, 'nest-background-pattern', '' );
		}
        
        // background image opacity
        if( isset( $_POST[ 'nest-background-image-opacity' ] ) ) {
            update_post_meta( $post_id, 'nest-background-image-opacity', sanitize_text_field( $_POST[ 'nest-background-image-opacity' ] ) );
        }
        
        // background color
        if( isset( $_POST[ 'nest-bg-color' ] ) ) {
            update_post_meta( $post_id, 'nest-bg-color', $_POST[ 'nest-bg-color' ] );
        }
        
        // background color opacity
        if( isset( $_POST[ 'nest-background-color-opacity' ] ) ) {
            update_post_meta( $post_id, 'nest-background-color-opacity', sanitize_text_field( $_POST[ 'nest-background-color-opacity' ] ) );
        }
        
        // overlay color
        if( isset( $_POST[ 'nest-overlay-color' ] ) ) {
            update_post_meta( $post_id, 'nest-overlay-color', $_POST[ 'nest-overlay-color' ] );
        }
        
        // overlay color opacity
        if( isset( $_POST[ 'nest-overlay-color-opacity' ] ) ) {
            update_post_meta( $post_id, 'nest-overlay-color-opacity', sanitize_text_field( $_POST[ 'nest-overlay-color-opacity' ] ) );
        }
        
        // show close cursor
		if( isset( $_POST[ 'nest-overlay-cursor' ] ) ) {
			update_post_meta( $post_id, 'nest-overlay-cursor', 'yes' );
		} else {
			update_post_meta( $post_id, 'nest-overlay-cursor', '' );
		}

        // button text
        if( isset( $_POST[ 'nest-button-text' ] ) ) {
            update_post_meta( $post_id, 'nest-button-text', sanitize_text_field( $_POST[ 'nest-button-text' ] ) );
        }
        
        // button text size
        if( isset( $_POST[ 'nest-button-text-size' ] ) ) {
            update_post_meta( $post_id, 'nest-button-text-size', sanitize_text_field( $_POST[ 'nest-button-text-size' ] ) );
        }
        
        // activation button style
        if( isset( $_POST[ 'nest-button-style' ] ) ) {
            update_post_meta( $post_id, 'nest-button-style', $_POST[ 'nest-button-style' ] );
        }
        
        // hide activation button
		if( isset( $_POST[ 'nest-hide-button' ] ) ) {
			update_post_meta( $post_id, 'nest-hide-button', 'yes' );
		} else {
			update_post_meta( $post_id, 'nest-hide-button', '' );
		}
        
        // activation button text color
        if( isset( $_POST[ 'nest-activation-button-text-color' ] ) ) {
            update_post_meta( $post_id, 'nest-activation-button-text-color', $_POST[ 'nest-activation-button-text-color' ] );
        }
        
        // activation button text color (hover)
        if( isset( $_POST[ 'nest-activation-button-text-hover-color' ] ) ) {
            update_post_meta( $post_id, 'nest-activation-button-text-hover-color', $_POST[ 'nest-activation-button-text-hover-color' ] );
        }
        
        // activation button color
        if( isset( $_POST[ 'nest-activation-button-bg-color' ] ) ) {
            update_post_meta( $post_id, 'nest-activation-button-bg-color', $_POST[ 'nest-activation-button-bg-color' ] );
        }
        
        // activation button color (hover)
        if( isset( $_POST[ 'nest-activation-button-bg-hover-color' ] ) ) {
            update_post_meta( $post_id, 'nest-activation-button-bg-hover-color', $_POST[ 'nest-activation-button-bg-hover-color' ] );
        }

        // activation button location
        if( isset( $_POST[ 'nest-button-position' ] ) ) {
            update_post_meta( $post_id, 'nest-button-position', $_POST[ 'nest-button-position' ] );
        }
        
        // activation button absolute
		if( isset( $_POST[ 'nest-button-absolute' ] ) ) {
			update_post_meta( $post_id, 'nest-button-absolute', 'yes' );
		} else {
			update_post_meta( $post_id, 'nest-button-absolute', '' );
		}
        
        // activation button top distance
        if( isset( $_POST[ 'nest-activation-button-top' ] ) ) {
            update_post_meta( $post_id, 'nest-activation-button-top', sanitize_text_field( $_POST[ 'nest-activation-button-top' ] ) );
        }
        
        // activation button left distance
        if( isset( $_POST[ 'nest-activation-button-left' ] ) ) {
            update_post_meta( $post_id, 'nest-activation-button-left', sanitize_text_field( $_POST[ 'nest-activation-button-left' ] ) );
        }
        
        // activation button right distance
        if( isset( $_POST[ 'nest-activation-button-right' ] ) ) {
            update_post_meta( $post_id, 'nest-activation-button-right', sanitize_text_field( $_POST[ 'nest-activation-button-right' ] ) );
        }
        
        // activation button bottom distance
        if( isset( $_POST[ 'nest-activation-button-bottom' ] ) ) {
            update_post_meta( $post_id, 'nest-activation-button-bottom', sanitize_text_field( $_POST[ 'nest-activation-button-bottom' ] ) );
        }
        
        // automatic activation
        if( isset( $_POST[ 'nest-automatic-activation' ] ) ) {
            update_post_meta( $post_id, 'nest-automatic-activation', sanitize_text_field( $_POST[ 'nest-automatic-activation' ] ) );
        }
        
        // once per session
		if( isset( $_POST[ 'nest-once-per-session' ] ) ) {
			update_post_meta( $post_id, 'nest-once-per-session', 'yes' );
		} else {
			update_post_meta( $post_id, 'nest-once-per-session', '' );
		}
        
        // anchor activation
        if( isset( $_POST[ 'nest-anchor-activation' ] ) ) {
            update_post_meta( $post_id, 'nest-anchor-activation', sanitize_text_field( $_POST[ 'nest-anchor-activation' ] ) );
        }
        
        // close button style
        if( isset( $_POST[ 'nest-close-button-style' ] ) ) {
            update_post_meta( $post_id, 'nest-close-button-style', $_POST[ 'nest-close-button-style' ] );
        }
        
        // close button color
        if( isset( $_POST[ 'nest-close-button-color' ] ) ) {
            update_post_meta( $post_id, 'nest-close-button-color', $_POST[ 'nest-close-button-color' ] );
        }
        
        // close button color (hover)
        if( isset( $_POST[ 'nest-close-button-hover-color' ] ) ) {
            update_post_meta( $post_id, 'nest-close-button-hover-color', $_POST[ 'nest-close-button-hover-color' ] );
        }
        
        // close button location
        if( isset( $_POST[ 'nest-close-button' ] ) ) {
            update_post_meta( $post_id, 'nest-close-button', $_POST[ 'nest-close-button' ] );
        }
        
        // close button top distance
        if( isset( $_POST[ 'nest-close-button-top' ] ) ) {
            update_post_meta( $post_id, 'nest-close-button-top', sanitize_text_field( $_POST[ 'nest-close-button-top' ] ) );
        }
        
        // close button left distance
        if( isset( $_POST[ 'nest-close-button-left' ] ) ) {
            update_post_meta( $post_id, 'nest-close-button-left', sanitize_text_field( $_POST[ 'nest-close-button-left' ] ) );
        }
        
        // close button right distance
        if( isset( $_POST[ 'nest-close-button-right' ] ) ) {
            update_post_meta( $post_id, 'nest-close-button-right', sanitize_text_field( $_POST[ 'nest-close-button-right' ] ) );
        }
        
        // scrollbar color
        if( isset( $_POST[ 'nest-scrollbar-color' ] ) ) {
            update_post_meta( $post_id, 'nest-scrollbar-color', $_POST[ 'nest-scrollbar-color' ] );
        }
        
        // scrollbar background color
        if( isset( $_POST[ 'nest-scrollbar-background-color' ] ) ) {
            update_post_meta( $post_id, 'nest-scrollbar-background-color', $_POST[ 'nest-scrollbar-background-color' ] );
        }
        
        // scrollbar thickness
        if( isset( $_POST[ 'nest-scrollbar-thickness' ] ) ) {
            update_post_meta( $post_id, 'nest-scrollbar-thickness', sanitize_text_field( $_POST[ 'nest-scrollbar-thickness' ] ) );
        }
        
        // scrollbar roundness
        if( isset( $_POST[ 'nest-scrollbar-roundness' ] ) ) {
            update_post_meta( $post_id, 'nest-scrollbar-roundness', sanitize_text_field( $_POST[ 'nest-scrollbar-roundness' ] ) );
        }
        
        // scrollbar distance from sides
        if( isset( $_POST[ 'nest-scrollbar-distance' ] ) ) {
            update_post_meta( $post_id, 'nest-scrollbar-distance', sanitize_text_field( $_POST[ 'nest-scrollbar-distance' ] ) );
        }
        
        // elements to animate
        if( isset( $_POST[ 'nest-content-animation-elements' ] ) ) {
            update_post_meta( $post_id, 'nest-content-animation-elements', sanitize_text_field( $_POST[ 'nest-content-animation-elements' ] ) );
        }
        
        // scaling 
        if( isset( $_POST[ 'nest-content-animation-scale' ] ) ) {
            update_post_meta( $post_id, 'nest-content-animation-scale', sanitize_text_field( $_POST[ 'nest-content-animation-scale' ] ) );
        }
        
        // opacity
        if( isset( $_POST[ 'nest-content-animation-opacity' ] ) ) {
            update_post_meta( $post_id, 'nest-content-animation-opacity', sanitize_text_field( $_POST[ 'nest-content-animation-opacity' ] ) );
        }
        
        // blur
        if( isset( $_POST[ 'nest-content-blur' ] ) ) {
            update_post_meta( $post_id, 'nest-content-blur', sanitize_text_field( $_POST[ 'nest-content-blur' ] ) );
        }

        // logged in/out
        if( isset( $_POST[ 'nest-showto' ] ) ) {
            update_post_meta( $post_id, 'nest-showto', $_POST[ 'nest-showto' ] );
        }
        
        // smaller than 
        if( isset( $_POST[ 'nest-smaller-than' ] ) ) {
            update_post_meta( $post_id, 'nest-smaller-than', sanitize_text_field( $_POST[ 'nest-smaller-than' ] ) );
        }
        
        // larger than 
        if( isset( $_POST[ 'nest-larger-than' ] ) ) {
            update_post_meta( $post_id, 'nest-larger-than', sanitize_text_field( $_POST[ 'nest-larger-than' ] ) );
        }
    
    }
    add_action( 'save_post', 'nest_meta_save' );
    
    
	//
	// ADD nest TO THEME
	//
	
	function bonfire_nest_footer() {
		?>

		<?php if ( is_singular() ) {  ?>
            <?php $meta_value = get_post_meta( get_the_ID(), 'nest-hide', true ); if( !empty( $meta_value ) ) { } else { ?>
            
                <?php global $wp_query; $bonfire_nest_meta_box_select = get_post_meta($wp_query->post->ID, 'bonfire_nest_meta_box_select', true); ?>
                <?php $var = 0; if (empty($bonfire_nest_meta_box_select)) { ?>

                    <!-- BEGIN SITE-WIDE INFO PANE -->
                    <?php $nest_show_logged = get_theme_mod('nest_show_logged'); if($nest_show_logged == '' || $nest_show_logged == 'showall') { ?>
                        <?php if( get_theme_mod('nest_front_page_only') != '') { ?>
                            <?php if(is_front_page() ) { ?>
                                <?php include( plugin_dir_path( __FILE__ ) . 'include-sitewide.php'); ?>
                            <?php } ?>
                        <?php } else { ?>
                            <?php include( plugin_dir_path( __FILE__ ) . 'include-sitewide.php'); ?>
                        <?php } ?>
                    <?php } else if($nest_show_logged != '') { switch ($nest_show_logged) { ?><?php case 'showloggedin': ?>
                        <?php if ( is_user_logged_in() ) { ?>
                            <?php if( get_theme_mod('nest_front_page_only') != '') { ?>
                                <?php if(is_front_page() ) { ?>
                                    <?php include( plugin_dir_path( __FILE__ ) . 'include-sitewide.php'); ?>
                                <?php } ?>
                            <?php } else { ?>
                                <?php include( plugin_dir_path( __FILE__ ) . 'include-sitewide.php'); ?>
                            <?php } ?>
                        <?php } ?>
                    <?php break; case 'showloggedout': ?>
                        <?php if ( is_user_logged_in() ) { } else { ?>
                            <?php if( get_theme_mod('nest_front_page_only') != '') { ?>
                                <?php if(is_front_page() ) { ?>
                                    <?php include( plugin_dir_path( __FILE__ ) . 'include-sitewide.php'); ?>
                                <?php } ?>
                            <?php } else { ?>
                                <?php include( plugin_dir_path( __FILE__ ) . 'include-sitewide.php'); ?>
                            <?php } ?>
                        <?php } ?>
                    <?php break; } } ?>
                    <!-- END SITE-WIDE INFO PANE -->

                <?php } else { ?>

                    <!-- BEGIN SINGULAR INFO PANE -->
                    <?php $meta_value = get_post_meta( get_the_ID(), 'nest-showto', true ); ?>
                    <?php if ($meta_value=="loggedin") { ?>
                        <?php if ( is_user_logged_in() ) { ?>
                            <?php include( plugin_dir_path( __FILE__ ) . 'include-singular.php'); ?>
                        <?php } ?>
                    <?php } elseif ($meta_value=="loggedout") { ?>
                        <?php if ( is_user_logged_in() ) { } else { ?>
                            <?php include( plugin_dir_path( __FILE__ ) . 'include-singular.php'); ?>
                        <?php } ?>
                    <?php } else { ?>
                        <?php include( plugin_dir_path( __FILE__ ) . 'include-singular.php'); ?>
                    <?php } ?>
                    <!-- END SINGULAR INFO PANE -->

                <?php } ?>
                
            <?php } ?>

		<?php } else { ?>

			<!-- BEGIN SITE-WIDE INFO PANE -->
            <?php $nest_show_logged = get_theme_mod('nest_show_logged'); if($nest_show_logged == '' || $nest_show_logged == 'showall') { ?>
                <?php if( get_theme_mod('nest_front_page_only') != '') { ?>
                    <?php if(is_front_page() ) { ?>
                        <?php include( plugin_dir_path( __FILE__ ) . 'include-sitewide.php'); ?>
                    <?php } ?>
                <?php } else { ?>
                    <?php include( plugin_dir_path( __FILE__ ) . 'include-sitewide.php'); ?>
                <?php } ?>
            <?php } else if($nest_show_logged != '') { switch ($nest_show_logged) { ?><?php case 'showloggedin': ?>
                <?php if ( is_user_logged_in() ) { ?>
                    <?php if( get_theme_mod('nest_front_page_only') != '') { ?>
                        <?php if(is_front_page() ) { ?>
                            <?php include( plugin_dir_path( __FILE__ ) . 'include-sitewide.php'); ?>
                        <?php } ?>
                    <?php } else { ?>
                        <?php include( plugin_dir_path( __FILE__ ) . 'include-sitewide.php'); ?>
                    <?php } ?>
                <?php } ?>
            <?php break; case 'showloggedout': ?>
                <?php if ( is_user_logged_in() ) { } else { ?>
                    <?php if( get_theme_mod('nest_front_page_only') != '') { ?>
                        <?php if(is_front_page() ) { ?>
                            <?php include( plugin_dir_path( __FILE__ ) . 'include-sitewide.php'); ?>
                        <?php } ?>
                    <?php } else { ?>
                        <?php include( plugin_dir_path( __FILE__ ) . 'include-sitewide.php'); ?>
                    <?php } ?>
                <?php } ?>
            <?php break; } } ?>
            <!-- END SITE-WIDE INFO PANE -->

		<?php } ?>

	<?php
	}
	add_action('wp_footer','bonfire_nest_footer');
	
    
    ///////////////////////////////////////
	// Enqueue Google WebFonts
	///////////////////////////////////////
	function nest_fonts_url() {
		$font_url = '';

		if ( 'off' !== _x( 'on', 'Google font: on or off', 'nest' ) ) {
			$font_url = add_query_arg( 'family', urlencode( 'Hind:300,500' ), "//fonts.googleapis.com/css" );
		}
		return $font_url;
	}
	function nest_scripts() {
		wp_enqueue_style( 'nest-fonts', nest_fonts_url(), array(), '1.0.0' );
	}
	add_action( 'wp_enqueue_scripts', 'nest_scripts' );
    
    
    //
    // ENQUEUE nest-admin.css
    //
    function nest_admin_styles(){
        global $typenow;
        if( $typenow == 'post' || 'page' ) {
            wp_enqueue_style( 'nest_meta_box_styles', plugin_dir_url( __FILE__ ) . 'nest-admin.css' );
        }
    }
    add_action( 'admin_print_styles', 'nest_admin_styles' );


    //
    // ENQUEUE nest-color-picker.js
    //
    function nest_color_enqueue() {
        global $typenow;
        if( $typenow == 'post' || $typenow == 'page' ) {
            wp_enqueue_style( 'wp-color-picker' );
            wp_enqueue_script( 'nest-color-picker-js', plugin_dir_url( __FILE__ ) . '/js/nest-color-picker.js', array( 'wp-color-picker' ) );
        }
    }
    add_action( 'admin_enqueue_scripts', 'nest_color_enqueue' );


    //
    // ENQUEUE nest-image-upload.js (Loads the image management javascript)
    //
    function nest_image_enqueue() {
        global $typenow;
        if( 'is_admin' ) {
            wp_enqueue_media();
    
            // Registers and enqueues the required javascript.
            wp_register_script( 'nest-image-upload', plugin_dir_url( __FILE__ ) . '/js/nest-image-upload.js', array( 'jquery' ) );
            wp_localize_script( 'nest-image-upload', 'meta_image',
                array(
                    'title' => __( 'Choose or Upload an Image', 'nest' ),
                    'button' => __( 'Use this image', 'nest' ),
                )
            );
            wp_enqueue_script( 'nest-image-upload' );
        }
    }
    add_action( 'admin_enqueue_scripts', 'nest_image_enqueue' );


	//
	// ENQUEUE nest.css
	//
	function bonfire_nest_css() {
		global $wp_query; $bonfire_nest_meta_box_select = get_post_meta($wp_query->post->ID, 'bonfire_nest_meta_box_select', true);	
		if ($bonfire_nest_meta_box_select > 0 && get_theme_mod( 'nest_main_section' ) == 0) {
			/* only single selected */
			if(is_singular()) {
				wp_register_style( 'bonfire-nest-css', plugins_url( 'nest.css', __FILE__ ) . '', array(), '1', 'all' );
				wp_enqueue_style( 'bonfire-nest-css' );
			}
		} elseif (empty($bonfire_nest_meta_box_select) && get_theme_mod( 'nest_main_section' ) > 0) {
			/* only sitewide selected*/
			wp_register_style( 'bonfire-nest-css', plugins_url( 'nest.css', __FILE__ ) . '', array(), '1', 'all' );
			wp_enqueue_style( 'bonfire-nest-css' );
		} elseif ($bonfire_nest_meta_box_select > 0 && get_theme_mod( 'nest_main_section' ) > 0) {
			/* both selected */
			wp_register_style( 'bonfire-nest-css', plugins_url( 'nest.css', __FILE__ ) . '', array(), '1', 'all' );
			wp_enqueue_style( 'bonfire-nest-css' );
		}
	}
	add_action( 'wp_enqueue_scripts', 'bonfire_nest_css' );


	//
	// ENQUEUE nest.js
	//
	
	function bonfire_nest_js() {
		global $wp_query; $bonfire_nest_meta_box_select = get_post_meta($wp_query->post->ID, 'bonfire_nest_meta_box_select', true);	
		if ($bonfire_nest_meta_box_select > 0 && get_theme_mod( 'nest_main_section' ) == 0) {
			/* only single selected */
			if(is_singular()) {
				wp_register_script( 'bonfire-nest-js', plugins_url( '/js/nest.js', __FILE__ ) . '', array( 'jquery' ), '1', true );  
				wp_enqueue_script( 'bonfire-nest-js' );
			}
		} elseif (empty($bonfire_nest_meta_box_select) && get_theme_mod( 'nest_main_section' ) > 0) {
			/* only sitewide selected*/
			wp_register_script( 'bonfire-nest-js', plugins_url( '/js/nest.js', __FILE__ ) . '', array( 'jquery' ), '1', true );  
			wp_enqueue_script( 'bonfire-nest-js' );
		} elseif ($bonfire_nest_meta_box_select > 0 && get_theme_mod( 'nest_main_section' ) > 0) {
			/* both selected */
			wp_register_script( 'bonfire-nest-js', plugins_url( '/js/nest.js', __FILE__ ) . '', array( 'jquery' ), '1', true );  
			wp_enqueue_script( 'bonfire-nest-js' );
		}
	}
	add_action( 'wp_enqueue_scripts', 'bonfire_nest_js' );
    
    
    //
	// ENQUEUE nest-body-scroll-lock.js
	//
    if(get_theme_mod('nest_body_scroll_lock') != '') {
        function bonfire_nest_body_scroll_lock_js() {
            wp_register_script( 'bonfire-nest-body-scroll-lock-js', plugins_url( '/js/nest-body-scroll-lock.js', __FILE__ ) . '', array( 'jquery' ), '1', true );  
            wp_enqueue_script( 'bonfire-nest-body-scroll-lock-js' );
        }
        add_action( 'wp_enqueue_scripts', 'bonfire_nest_body_scroll_lock_js' );
    }


	//
	// ENQUEUE jquery.scrollbar.min.js
	//
	
	function bonfire_nest_scrollbar_js() {
		global $wp_query; $bonfire_nest_meta_box_select = get_post_meta($wp_query->post->ID, 'bonfire_nest_meta_box_select', true);	
		if ($bonfire_nest_meta_box_select > 0 && get_theme_mod( 'nest_main_section' ) == 0) {
			/* only single selected */
			if(is_singular()) {
				wp_register_script( 'bonfire-nest-scrollbar-js', plugins_url( '/js/jquery.scrollbar.min.js', __FILE__ ) . '', array( 'jquery' ), '1', true );  
				wp_enqueue_script( 'bonfire-nest-scrollbar-js' );
			}
		} elseif (empty($bonfire_nest_meta_box_select) && get_theme_mod( 'nest_main_section' ) > 0) {
			/* only sitewide selected*/
			wp_register_script( 'bonfire-nest-scrollbar-js', plugins_url( '/js/jquery.scrollbar.min.js', __FILE__ ) . '', array( 'jquery' ), '1', true );  
			wp_enqueue_script( 'bonfire-nest-scrollbar-js' );
		} elseif ($bonfire_nest_meta_box_select > 0 && get_theme_mod( 'nest_main_section' ) > 0) {
			/* both selected */
			wp_register_script( 'bonfire-nest-scrollbar-js', plugins_url( '/js/jquery.scrollbar.min.js', __FILE__ ) . '', array( 'jquery' ), '1', true );  
			wp_enqueue_script( 'bonfire-nest-scrollbar-js' );
		}
	}
	add_action( 'wp_enqueue_scripts', 'bonfire_nest_scrollbar_js' );
    
    
    //
	// ENQUEUE jquery.inview.min.js
	//
	
	function bonfire_nest_inview_js() {
		global $wp_query; $bonfire_nest_meta_box_select = get_post_meta($wp_query->post->ID, 'bonfire_nest_meta_box_select', true);	
		if ($bonfire_nest_meta_box_select > 0 && get_theme_mod( 'nest_main_section' ) == 0) {
			/* only single selected */
			if(is_singular()) {
				wp_register_script( 'bonfire-nest-inview-js', plugins_url( '/js/jquery.inview.min.js', __FILE__ ) . '', array( 'jquery' ), '1' );  
				wp_enqueue_script( 'bonfire-nest-inview-js' );
			}
		} elseif (empty($bonfire_nest_meta_box_select) && get_theme_mod( 'nest_main_section' ) > 0) {
			/* only sitewide selected*/
			wp_register_script( 'bonfire-nest-inview-js', plugins_url( '/js/jquery.inview.min.js', __FILE__ ) . '', array( 'jquery' ), '1' );  
			wp_enqueue_script( 'bonfire-nest-inview-js' );
		} elseif ($bonfire_nest_meta_box_select > 0 && get_theme_mod( 'nest_main_section' ) > 0) {
			/* both selected */
			wp_register_script( 'bonfire-nest-inview-js', plugins_url( '/js/jquery.inview.min.js', __FILE__ ) . '', array( 'jquery' ), '1' );  
			wp_enqueue_script( 'bonfire-nest-inview-js' );
		}
	}
	add_action( 'wp_enqueue_scripts', 'bonfire_nest_inview_js' );


    //
	// SHORTCODE BUTTONS
	//
    
    //[nestbutton align=""]BUTTON TEXT HERE[/nestbutton]
	function nestbutton($atts, $content = null) {
	extract(shortcode_atts(array( 'link' => '#', ), $atts));
		return '<div class="nest-button-wrapper-shortcode"><div class="nest-button">'.do_shortcode($content).'</div></div>';}
	add_shortcode('nestbutton', 'nestbutton');
    
    //[nestbuttontwo]BUTTON TEXT HERE[/nestbuttontwo]
	function nestbuttontwo($atts, $content = null) {
	extract(shortcode_atts(array( 'link' => '#', ), $atts));
		return '<div class="nest-button-wrapper-shortcode"><div class="nest-button-two">'.do_shortcode($content).'</div></div>';}
	add_shortcode('nestbuttontwo', 'nestbuttontwo');
    
    //[nestbuttonthree]BUTTON TEXT HERE[/nestbuttonthree]
	function nestbuttonthree($atts, $content = null) {
	extract(shortcode_atts(array( 'link' => '#', ), $atts));
		return '<div class="nest-button-wrapper-shortcode"><div class="nest-button-three">'.do_shortcode($content).'</div></div>';}
	add_shortcode('nestbuttonthree', 'nestbuttonthree');
    
    //[nestbuttonfour]BUTTON TEXT HERE[/nestbuttonfour]
	function nestbuttonfour($atts, $content = null) {
	extract(shortcode_atts(array( 'link' => '#', ), $atts));
		return '<div class="nest-button-wrapper-shortcode"><div class="nest-button-four">'.do_shortcode($content).'</div></div>';}
	add_shortcode('nestbuttonfour', 'nestbuttonfour');


?>