/* when menu button, background overlay or custom activator used */
jQuery('.nest-button-wrapper, .nest-button-wrapper-shortcode, .nest-close-button-wrapper, .nest-background-overlay, .nest-custom-activator').on('click', function(e) {
	if(jQuery('.nest-slide-wrapper').hasClass('nest-slide-wrapper-active'))
	{

		/* disable browser scroll */
		var current = jQuery(window).scrollTop();
        jQuery(window).scroll(function() {
            jQuery(window).scrollTop(current);
        });

	} else {

		/* enable browser scroll */
		jQuery(window).off('scroll');

	}
});

/* enable when ESC button pressed */
jQuery(document).keyup(function(e) {
	if (e.keyCode == 27) { 

		/* enable browser scroll */
		jQuery(window).off('scroll');

		return false;

	}
});