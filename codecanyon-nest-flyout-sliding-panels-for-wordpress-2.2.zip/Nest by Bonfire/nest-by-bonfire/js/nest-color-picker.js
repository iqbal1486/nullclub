jQuery(document).ready(function($){
    $('.nest-bg-color, .nest-overlay-color, .nest-activation-button-text-color, .nest-activation-button-text-hover-color, .nest-activation-button-bg-color, .nest-activation-button-bg-hover-color, .nest-close-button-color, .nest-close-button-hover-color, .nest-scrollbar-color, .nest-scrollbar-background-color').wpColorPicker();
});