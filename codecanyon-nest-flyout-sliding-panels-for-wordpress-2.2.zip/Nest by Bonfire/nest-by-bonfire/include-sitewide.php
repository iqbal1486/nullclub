<?php if( get_theme_mod( 'nest_main_section' ) == 0) { ?>
<?php } else { ?>
<!-- BEGIN ACTIVATION BUTTON -->
<?php if( get_theme_mod('nest_hide_button') == '') { ?>
    <div class="nest-button-wrapper<?php if ( is_admin_bar_showing() ) { ?> wp-toolbar-active<?php } ?>">
        <div class="nest-button<?php $nest_button_style = get_theme_mod('nest_button_style'); if($nest_button_style != '') { switch ($nest_button_style) { ?><?php case 'styletwo': ?>-two<?php break; case 'stylethree': ?>-three<?php break; case 'stylefour': ?>-four<?php break; } } ?>">
            <?php echo get_theme_mod( 'nest_button_text', 'Show info' ); ?>
        </div>
    </div>
<?php } else { ?>
<?php } ?>
<!-- END ACTIVATION BUTTON -->

<!-- BEGIN BACKGROUND OVERLAY -->
<div class="nest-background-overlay<?php if( get_theme_mod('nest_overlay_cursor') != '') { ?> nest-background-overlay-cursor<?php } ?>"></div>
<!-- END BACKGROUND OVERLAY -->

<!-- BEGIN SITE-WIDE INFO PANE -->
<div class="nest-slide-wrapper">
    
    <!-- BEGIN CLOSE BUTTON -->
    <div class="nest-close-button-wrapper">
        <div class="nest-close-button<?php $nest_close_button_style = get_theme_mod('nest_close_button_style'); if($nest_close_button_style != '') { switch ($nest_close_button_style) { ?><?php case 'styletwo': ?>-two<?php break; case 'stylethree': ?>-three<?php break; } } ?>">
            <!-- BEGIN IF THIRD STYLE, SHOW EXTRA ELEMENTS -->
            <?php $nest_close_button_style = get_theme_mod('nest_close_button_style'); if($nest_close_button_style != '') { switch ($nest_close_button_style) { ?><?php case 'stylethree': ?>
                <div class="top-left"></div>
                <div class="top-right"></div>
                <div class="bottom-left"></div>
                <div class="bottom-right"></div>
            <?php break; } } ?>
            <!-- END IF THIRD STYLE, SHOW EXTRA ELEMENTS -->
        </div>
        <?php $nest_close_button_style = get_theme_mod('nest_close_button_style'); if($nest_close_button_style != '') { switch ($nest_close_button_style) { ?><?php case 'styletwo': ?>
            <div class="nest-close-button-two-bottom"></div>
        <?php break; } } ?>
    </div>
    <!-- END CLOSE BUTTON -->
    
    <!-- BEGIN BACKGROUND IMAGE -->
    <div class="nest-slide-background-image" style="background-image:url(<?php echo get_theme_mod('nest_background_image'); ?>);"></div>
    <!-- END BACKGROUND IMAGE -->
    
    <!-- BEGIN BACKGROUND COLOR-->
    <div class="nest-slide-background-color"></div>
    <!-- END BACKGROUND COLOR -->
    
    <!-- BEGIN CONTENT -->
	<div class="nest-slide-inner">
		<div class="nest-slide-inner-inner">

            <div class="nest-content-wrapper">
                <div class="nest-content-inner">
                    <?php $my_query = new WP_Query('page_id='.get_theme_mod('nest_main_section').''); ?>
                    <?php while ($my_query->have_posts()) : $my_query->the_post(); ?>
                        <?php the_content(); ?>
                    <?php endwhile; ?>
                </div>
            </div>

		</div>
	</div>
    <!-- END CONTENT -->
</div>
<!-- END SITE-WIDE INFO PANE -->
<?php } ?>

<!-- BEGIN CUSTOM COLORS & other settings for SITE-WIDE SLIDE -->
<style>
/* activation button position */
<?php $nest_button_position = get_theme_mod('nest_button_position'); if($nest_button_position != '') { switch ($nest_button_position) { ?>
<?php case 'topright': ?>
.nest-button-wrapper {
    left:auto;
	right:20px;
}
<?php break; case 'bottomleft': ?>
.nest-button-wrapper {
    top:auto;
    bottom:20px;
}
<?php break; case 'bottomright': ?>
.nest-button-wrapper {
    top:auto;
    bottom:20px;
    left:auto;
	right:20px;
}
<?php break; } } ?>
/* activation button absolute */
<?php if( get_theme_mod('nest_button_absolute') != '') { ?>
.nest-button-wrapper { position:absolute; }
<?php } ?>

/* activation button distances */
.nest-button-wrapper {
    top:<?php echo get_theme_mod('nest_button_top'); ?>px;
    left:<?php echo get_theme_mod('nest_button_left'); ?>px;
}
<?php $nest_button_position = get_theme_mod('nest_button_position'); if($nest_button_position != '') { switch ($nest_button_position) { ?>
<?php case 'topright': ?>
.nest-button-wrapper {
    top:<?php echo get_theme_mod('nest_button_top'); ?>px;
    right:<?php echo get_theme_mod('nest_button_right'); ?>px;
    left:auto;
    bottom:auto;
}
<?php break; case 'bottomleft': ?>
.nest-button-wrapper {
    left:<?php echo get_theme_mod('nest_button_left'); ?>px;
    bottom:<?php echo get_theme_mod('nest_button_bottom'); ?>px;
    top:auto;
    right:auto;
}
<?php break; case 'bottomright': ?>
.nest-button-wrapper {
    right:<?php echo get_theme_mod('nest_button_right'); ?>px;
    bottom:<?php echo get_theme_mod('nest_button_bottom'); ?>px;
    top:auto;
    left:auto;
}
<?php break; } } ?>

/* activation button colors */
.nest-button,
.nest-button-two,
.nest-button-three,
.nest-button-four {
    color:<?php echo get_theme_mod('nest_activation_button_text_color'); ?>;
}
.nest-button:hover,
.nest-button-two:hover,
.nest-button-three:hover,
.nest-button-four:hover {
    color:<?php echo get_theme_mod('nest_activation_button_text_hover_color'); ?>;
}
/* activation button font size */
.nest-button, .nest-button-two, .nest-button-three, .nest-button-four { font-size:<?php echo get_theme_mod( 'nest_button_text_size' ); ?>px; }
/* activation button (style #1) */
.nest-button { background-color:<?php echo get_theme_mod('nest_activation_button_background_color'); ?>; }
.nest-button:hover { background-color:<?php echo get_theme_mod('nest_activation_button_background_hover_color'); ?>; }
/* activation button (style #2) */
.nest-button-two { border-color:<?php echo get_theme_mod('nest_activation_button_background_color'); ?>; }
.nest-button-two:hover { border-color:<?php echo get_theme_mod('nest_activation_button_background_hover_color'); ?>; }
/* activation button (style #3) */
.nest-button-three::after { background-color:<?php echo get_theme_mod('nest_activation_button_background_color'); ?>; }
.nest-button-three:hover::after { background-color:<?php echo get_theme_mod('nest_activation_button_background_hover_color'); ?>; }
/* activation button (style #4) */
.nest-button-four { background-color:<?php echo get_theme_mod('nest_activation_button_background_color'); ?>; }
.nest-button-four:hover { background-color:<?php echo get_theme_mod('nest_activation_button_background_hover_color'); ?>; }

/* background image as cover/pattern + background image opacity */
.nest-slide-background-image {
<?php if( get_theme_mod('nest_background_pattern') == '') { ?>
    background-size:cover;
    background-repeat:no-repeat;
<?php } else { ?>
    background-repeat:repeat;
<?php } ?>
    opacity:<?php echo get_theme_mod('nest_background_image_opacity'); ?>;
}
/* background color + background color opacity */
.nest-slide-background-color {
    background-color:<?php echo get_theme_mod('nest_background_color'); ?>;
    opacity:<?php echo get_theme_mod('nest_background_color_opacity'); ?>;
}
/* overlay color + overlay color opacity */
.nest-background-overlay {
    background-color:<?php echo get_theme_mod('nest_overlay_color'); ?>;
    
    -webkit-transition:opacity <?php echo get_theme_mod('nest_animation_speed', '0.5'); ?>s ease, left 0s ease <?php echo get_theme_mod('nest_animation_speed', '0.5'); ?>s;
    -moz-transition:opacity <?php echo get_theme_mod('nest_animation_speed', '0.5'); ?>s ease, left 0s ease <?php echo get_theme_mod('nest_animation_speed', '0.5'); ?>s;
    transition:opacity <?php echo get_theme_mod('nest_animation_speed', '0.5'); ?>s ease, left 0s ease <?php echo get_theme_mod('nest_animation_speed', '0.5'); ?>s;
}
.nest-background-overlay-active {
    opacity:<?php echo get_theme_mod('nest_overlay_color_opacity'); ?>;
    
    -webkit-transition:opacity <?php echo get_theme_mod('nest_animation_speed', '0.5'); ?>s ease, left 0s ease 0s;
    -moz-transition:opacity <?php echo get_theme_mod('nest_animation_speed', '0.5'); ?>s ease, left 0s ease 0s;
    transition:opacity <?php echo get_theme_mod('nest_animation_speed', '0.5'); ?>s ease, left 0s ease 0s;
}

/* main slide animation speed */
.nest-slide-wrapper {
    -webkit-transition:-webkit-transform <?php echo get_theme_mod('nest_animation_speed', '0.5'); ?>s ease;
    -moz-transition:-moz-transform <?php echo get_theme_mod('nest_animation_speed', '0.5'); ?>s ease;
    transition:transform <?php echo get_theme_mod('nest_animation_speed', '0.5'); ?>s ease;
}

/* if fade-in option selected */
<?php if( get_theme_mod('nest_fade_in') != '') { ?>
.nest-slide-wrapper .nest-content-inner { opacity:0; }
.nest-slide-wrapper-active .nest-content-inner { opacity:1; }
<?php } ?>

/* apply custom content width/height, based on whether when slide-in direction is top/left/right/bottom */
<?php $nest_slide_direction = get_theme_mod('nest_direction'); if($nest_slide_direction != '') { switch ($nest_slide_direction) { ?>
<?php case 'top': ?>
.nest-slide-wrapper { max-height:<?php $value = get_theme_mod('nest_slide_height'); if ($value == '') { ?>100%<?php } else { ?><?php echo get_theme_mod('nest_slide_height'); ?>px<?php } ?>; }
<?php break; case 'left': ?>
.nest-slide-wrapper { max-width:<?php $value = get_theme_mod('nest_slide_width'); if ($value == '') { ?>100%<?php } else { ?><?php echo get_theme_mod('nest_slide_width'); ?>px<?php } ?>; }
<?php break; case 'right': ?>
.nest-slide-wrapper { max-width:<?php $value = get_theme_mod('nest_slide_width'); if ($value == '') { ?>100%<?php } else { ?><?php echo get_theme_mod('nest_slide_width'); ?>px<?php } ?>; }
<?php break; case 'bottom': ?>
.nest-slide-wrapper { max-height:<?php $value = get_theme_mod('nest_slide_height'); if ($value == '') { ?>100%<?php } else { ?><?php echo get_theme_mod('nest_slide_height'); ?>px<?php } ?>; }
<?php break; } } ?>

/* inner content width */
.nest-content-wrapper {
    max-width:<?php $value = get_theme_mod('nest_content_width'); if ($value == '') { ?>100%<?php } else { ?><?php echo get_theme_mod('nest_content_width'); ?>px<?php } ?>;
}

/* slide-in direction, custom width/height */
<?php $nest_slide_direction = get_theme_mod('nest_direction'); if($nest_slide_direction != '') { switch ($nest_slide_direction) { ?>
<?php case 'top': ?>
.nest-slide-wrapper {
    top:0;
    bottom:auto;
    -webkit-transform:translateY(-<?php $value = get_theme_mod('nest_slide_height' ); if ($value == '') { ?>100%<?php } else { ?><?php echo get_theme_mod('nest_slide_height'); ?>px<?php } ?>);
    -moz-transform:translateY(-<?php $value = get_theme_mod('nest_slide_height' ); if ($value == '') { ?>100%<?php } else { ?><?php echo get_theme_mod('nest_slide_height'); ?>px<?php } ?>);
    transform:translateY(-<?php $value = get_theme_mod('nest_slide_height' ); if ($value == '') { ?>100%<?php } else { ?><?php echo get_theme_mod('nest_slide_height'); ?>px<?php } ?>);
}
<?php break; case 'right': ?>
.nest-slide-wrapper {
    left:auto;
    right:0;
    -webkit-transform:translateX(<?php $value = get_theme_mod('nest_slide_width' ); if ($value == '') { ?>100%<?php } else { ?><?php echo get_theme_mod('nest_slide_width'); ?>px<?php } ?>);
    -moz-transform:translateX(<?php $value = get_theme_mod('nest_slide_width' ); if ($value == '') { ?>100%<?php } else { ?><?php echo get_theme_mod('nest_slide_width'); ?>px<?php } ?>);
    transform:translateX(<?php $value = get_theme_mod('nest_slide_width' ); if ($value == '') { ?>100%<?php } else { ?><?php echo get_theme_mod('nest_slide_width'); ?>px<?php } ?>);
}
<?php break; case 'bottom': ?>
.nest-slide-wrapper {
    bottom:0;
    top:auto;
    -webkit-transform:translateY(<?php $value = get_theme_mod('nest_slide_height' ); if ($value == '') { ?>100%<?php } else { ?><?php echo get_theme_mod('nest_slide_height'); ?>px<?php } ?>);
    -moz-transform:translateY(<?php $value = get_theme_mod('nest_slide_height' ); if ($value == '') { ?>100%<?php } else { ?><?php echo get_theme_mod('nest_slide_height'); ?>px<?php } ?>);
    transform:translateY(<?php $value = get_theme_mod('nest_slide_height' ); if ($value == '') { ?>100%<?php } else { ?><?php echo get_theme_mod('nest_slide_height'); ?>px<?php } ?>);
}
<?php break; } } ?>

/* close button location */
<?php $nest_close_button = get_theme_mod('nest_close_button_position'); if($nest_close_button != '') { switch ($nest_close_button) { ?>
<?php case 'center': ?>
.nest-close-button-wrapper {
    left:50%;
    margin-left:-20px;
}
<?php break; case 'right': ?>
.nest-close-button-wrapper {
    left:auto;
    right:15px;
}
<?php break; } } ?>

/* activation button distances */
.nest-close-button-wrapper {
    top:<?php echo get_theme_mod('nest_close_button_top'); ?>px;
    left:<?php echo get_theme_mod('nest_close_button_left'); ?>px;
}
<?php $nest_close_button_position = get_theme_mod('nest_close_button_position'); if($nest_close_button_position != '') { switch ($nest_close_button_position) { ?>
<?php case 'center': ?>
.nest-close-button-wrapper {
    top:<?php echo get_theme_mod('nest_close_button_top'); ?>px;
    left:50%;
}
<?php break; case 'right': ?>
.nest-close-button-wrapper {
    left:auto;
    right:<?php echo get_theme_mod('nest_close_button_right'); ?>px;
}
<?php break; } } ?>

/* close button colors */
.nest-close-button::before,
.nest-close-button::after,
.nest-close-button-two::before,
.nest-close-button-two::after,
.nest-close-button-two-bottom::before,
.nest-close-button-two-bottom::after,
.nest-close-button-three .top-left,
.nest-close-button-three .top-right,
.nest-close-button-three .bottom-left,
.nest-close-button-three .bottom-right {
    background-color:<?php echo get_theme_mod('nest_close_button_color'); ?>;
}
.nest-close-button-wrapper:hover .nest-close-button::before,
.nest-close-button-wrapper:hover .nest-close-button::after,
.nest-close-button-wrapper:hover .nest-close-button-two::before,
.nest-close-button-wrapper:hover .nest-close-button-two::after,
.nest-close-button-wrapper:hover .nest-close-button-two-bottom::before,
.nest-close-button-wrapper:hover .nest-close-button-two-bottom::after,
.nest-close-button-three .top-left:before,
.nest-close-button-three .top-right:before,
.nest-close-button-three .bottom-left:before,
.nest-close-button-three .bottom-right:before {
    background-color:<?php echo get_theme_mod('nest_close_button_hover_color'); ?>;
}

/* animate close button style #3 */
<?php $nest_close_button_style = get_theme_mod('nest_close_button_style'); if($nest_close_button_style != '') { switch ($nest_close_button_style) { ?><?php case 'stylethree': ?>
.nest-close-button-wrapper:hover {
    -webkit-transform:rotate(90deg);
    -moz-transform:rotate(90deg);
    transform:rotate(90deg);
}
<?php break; } } ?>

/* styled scrollbar */
.nest-slide-inner-inner > .scroll-element .scroll-bar { background-color:<?php echo get_theme_mod('nest_scrollbar_color'); ?>; }
.nest-slide-inner-inner > .scroll-element .scroll-element_track { background-color:<?php echo get_theme_mod('nest_scrollbar_background_color'); ?>; }
.nest-slide-inner-inner > .scroll-element.scroll-y {
    right:<?php echo get_theme_mod('nest_scrollbar_distance'); ?>px;
	top:<?php echo get_theme_mod('nest_scrollbar_distance'); ?>px;
    bottom:<?php echo get_theme_mod('nest_scrollbar_distance'); ?>px;
	width:<?php echo get_theme_mod('nest_scrollbar_thickness'); ?>px;
}
.nest-slide-inner-inner > .scroll-element div {
    border-radius:<?php echo get_theme_mod('nest_scrollbar_roundness'); ?>px;
}

/* content animation */
<?php if(get_theme_mod('nest_content_animation_elements') != '') { ?>
<?php echo get_theme_mod('nest_content_animation_elements'); ?> {
    -webkit-transition:-webkit-transform <?php echo get_theme_mod('nest_animation_speed', '0.5'); ?>s ease, opacity <?php echo get_theme_mod('nest_animation_speed', '0.5'); ?>s ease, -webkit-filter <?php echo get_theme_mod('nest_animation_speed', '0.5'); ?>s ease;
    -moz-transition:-moz-transform <?php echo get_theme_mod('nest_animation_speed', '0.5'); ?>s ease, opacity <?php echo get_theme_mod('nest_animation_speed', '0.5'); ?>s ease, -moz-filter <?php echo get_theme_mod('nest_animation_speed', '0.5'); ?>s ease;
    transition:transform <?php echo get_theme_mod('nest_animation_speed', '0.5'); ?>s ease, opacity <?php echo get_theme_mod('nest_animation_speed', '0.5'); ?>s ease, filter <?php echo get_theme_mod('nest_animation_speed', '0.5'); ?>s ease;
}
<?php } ?>
.content-animation-active {
    -webkit-transform:scale(<?php if(get_theme_mod('nest_content_animation_scale') != '') { ?><?php echo get_theme_mod('nest_content_animation_scale'); ?><?php } else { ?>0.9<?php } ?>);
    -moz-transform:scale(<?php if(get_theme_mod('nest_content_animation_scale') != '') { ?><?php echo get_theme_mod('nest_content_animation_scale'); ?><?php } else { ?>0.9<?php } ?>);
    transform:scale(<?php if(get_theme_mod('nest_content_animation_scale') != '') { ?><?php echo get_theme_mod('nest_content_animation_scale'); ?><?php } else { ?>0.9<?php } ?>);
    opacity:<?php echo get_theme_mod('nest_content_animation_opacity'); ?>;
    
    -webkit-filter:blur(<?php echo get_theme_mod('nest_content_blur'); ?>px);
    -moz-filter:blur(<?php echo get_theme_mod('nest_content_blur'); ?>px);
    filter:blur(<?php echo get_theme_mod('nest_content_blur'); ?>px);
}
/* hide Nest between resolutions */
@media ( min-width:<?php echo get_theme_mod('nest_smaller_than'); ?>px) and (max-width:<?php echo get_theme_mod('nest_larger_than'); ?>px) {
    .nest-button-wrapper,
    .nest-background-overlay,
    .nest-slide-wrapper { display:none; }
}
</style>
<!-- END CUSTOM COLORS & other settings for SITE-WIDE SLIDE -->

<!-- BEGIN AUTO ACTIVATION -->
<?php if( get_theme_mod('nest_auto_activation') != '') { ?>
<script>
<?php if( get_theme_mod('nest_browser_session') != '') { ?>
jQuery(document).ready(function($){
    if (sessionStorage.getItem('oncePerSession') !== 'true') {
<?php } ?>        
        setTimeout(function(){
            jQuery('.nest-slide-wrapper').addClass('nest-slide-wrapper-active');
            jQuery('.nest-background-overlay').addClass('nest-background-overlay-active');
            /* add content scaling */
            <?php if( get_theme_mod('nest_content_animation_elements') != '') { ?>
            jQuery('<?php echo get_theme_mod('nest_content_animation_elements'); ?>').addClass('content-animation-active');
            <?php } ?>
        },<?php echo get_theme_mod('nest_auto_activation'); ?>);
<?php if( get_theme_mod('nest_browser_session') != '') { ?>
        sessionStorage.setItem('oncePerSession','true');
    }
});
<?php } ?>
</script>
<?php } ?>
<!-- END AUTO ACTIVATION -->

<!-- BEGIN ANCHOR ACTIVATION -->
<?php if( get_theme_mod('nest_anchor_activation') != '') { ?>
<script>
/* anchor activation */
jQuery('<?php echo get_theme_mod('nest_anchor_activation'); ?>').on('inview', function(event, isInView) {
    if (isInView) {
        jQuery('.nest-slide-wrapper').addClass('nest-slide-wrapper-active');
        jQuery('.nest-background-overlay').addClass('nest-background-overlay-active');
        /* add content scaling */
        <?php if( get_theme_mod('nest_content_animation_elements') != '') { ?>
        jQuery('<?php echo get_theme_mod('nest_content_animation_elements'); ?>').addClass('content-animation-active');
        <?php } ?>
    } else {
        jQuery('.nest-slide-wrapper').removeClass('nest-slide-wrapper-active');
        jQuery('.nest-background-overlay').removeClass('nest-background-overlay-active');
        /* remove content scaling */
        <?php if( get_theme_mod('nest_content_animation_elements') != '') { ?>
        jQuery('<?php echo get_theme_mod('nest_content_animation_elements'); ?>').removeClass('content-animation-active');
        <?php } ?>
    }
});
</script>
<?php } ?>
<!-- END ANCHOR ACTIVATION -->

<!-- BEGIN CONTENT SCALING -->
<?php if( get_theme_mod('nest_content_animation_elements') != '') { ?>
<script>
jQuery('.nest-button-wrapper, .nest-button-wrapper-shortcode, .nest-close-button-wrapper, .nest-background-overlay, .nest-custom-activator').on('click', function(e) {
'use strict';
	e.preventDefault();
		if(jQuery('.nest-slide-wrapper').hasClass('nest-slide-wrapper-active'))
		{
			/* remove content scaling */
			jQuery('<?php echo get_theme_mod('nest_content_animation_elements'); ?>').removeClass('content-animation-active');
		} else {
			/* add content scaling */
			jQuery('<?php echo get_theme_mod('nest_content_animation_elements'); ?>').addClass('content-animation-active');
		}
});
/* on ESC press */
jQuery(document).keyup(function(e) {
'use strict';
	if (e.keyCode == 27) { 
		/* remove content scaling */
		jQuery('<?php echo get_theme_mod('nest_content_animation_elements'); ?>').removeClass('content-animation-active');
		return false;
	}
});
</script>
<?php } ?>
<!-- END CONTENT SCALING -->