<?php themify_post_media();?>

<!-- post-content -->
<div class="post-content">
    <?php themify_post_content();?>
</div>
<!-- /post-content -->