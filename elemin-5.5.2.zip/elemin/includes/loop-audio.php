<?php 
global $themify;
themify_image("field_name=post_image, image, wp_thumb&w=100&h=100&before=<p class='audio-image'><a href='".get_permalink()."'>&after=</a></p>"); ?>

<!-- audio-player -->
<div class="audio-player">
	<?php // Load audio player
	echo $themify->get_audio_player(themify_get('audio_url'), $post->ID); ?>
</div>
<!-- /audio-player -->

<!-- post-content -->
<div class="post-content">
	<?php themify_post_content();?>
</div>
<!-- /post-content -->