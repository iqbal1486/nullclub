<?php
/** Themify Default Variables
 *  @var object */
global $themify;
/** Check if slider is enabled */
if('on' === themify_get('setting-header_slider_enabled','on',true)) { 
	    $slider_args = array();
	    $slider_args['data-wrapvar'] = 'yes' === themify_get( 'setting-header_slider_wrap',false,true );
	    $slider_args['data-visible'] = themify_get( 'setting-header_slider_visible',4,true );
	    $slider_args['data-speed'] = themify_get( 'setting-header_slider_speed',.5,true );
	    $slider_args['data-scroll'] = themify_get( 'setting-header_slider_scroll',1,true );
	    $slider_args['data-auto'] = themify_get( 'setting-header_slider_auto',false,true );
	    $slider_args['data-space'] = 10;
	    $slider_args = apply_filters( 'themify_theme_header_slider_args', $slider_args );
	    $img_width = themify_get('setting-header_slider_width',220,true);
	    $img_height = themify_get('setting-header_slider_height',160,true);
	?>
	<?php themify_slider_before(); //hook ?>
	<div id="header-slider" class="pagewidth slider">
		<div class="slideshow-wrap tf_carousel tf_swiper-container tf_overflow tf_rel" data-lazy="1" <?php echo themify_get_element_attributes($slider_args)?>>
    	<?php themify_slider_start(); //hook ?>
            <div class="slides tf_swiper-wrapper tf_lazy tf_rel tf_w tf_h">
    		<?php
		$slider_args=null;
    		// Get image width and height or set default dimensions
		if(themify_get('setting-header_slider_display',false,true) === 'images'){
			
			$options = array('one','two','three','four','five','six','seven','eight','nine','ten');
			$hasIcl=function_exists( 'icl_t' );
			$isFirst=true;
			foreach($options as $option){
				$option = 'setting-header_slider_images_'.$option;
				$image = themify_get($option.'_image',false,true);
				if($image){
					echo '<div class="tf_swiper-slide">';
						$title=themify_get($option.'_title','',true);
						if($hasIcl===true && $title){
						    $title=icl_t('Themify', $option.'_title', $title);
						}
						$alt = $title? $title : '';
						$img=themify_get_image(
							array(
								'src'=>$image,
								'w'=>$img_width,
								'h'=>$img_height,
								'alt'=>$alt,
								'class'=>'feature-img',
								'lazy_load'=>$isFirst
							));
						$link = themify_get($option.'_link',false,true);
						if($link){
							$title_attr = $title? "title='$title'" : "title='$image'";
							echo "<div class='tf_lazy slide-feature-image'><a href='$link' $title_attr>" . $img . '</a></div>',
							 $title? '<div class="slide-content-wrap"><h3 class="slide-post-title"><a href="'.$link.'" '.$title_attr.'>'.$title.'</a></h3></div>' : '';
						} else {
							echo '<div class="tf_lazy slide-feature-image">' . $img. '</div>',
							    $title? '<div class="slide-content-wrap"><h3 class="slide-post-title">'.$title.'</h3></div>' : '';
						}
					echo '</div>';
					$isFirst=true;
				}
			}
		} else {
			$cat=themify_get('setting-header_slider_posts_category','',true);
			$cat=$cat?'&cat='.$cat:'';
			query_posts('showposts='.themify_get('setting-header_slider_posts_slides','7',true).$cat);

			if( have_posts() ) {
				$showTitle=themify_get('setting-header_slider_hide_title',false,true)!== 'yes';
				$display=themify_get('setting-header_slider_default_display','none',true);
				$isFirst=false;
				while ( have_posts() ) : the_post(); 

					$link = themify_permalink_attr(array(),false); 
					$link=$link['href'];
					$post_format = $themify->get_format_template();
					$video=themify_get('video_url');
					?>

					<div class="format-<?php echo $post_format; ?> tf_swiper-slide">

						<?php if( $video): ?>
							<!-- post-video -->
							<div class="tf_lazy post-video video-wrap" data-url="<?php echo $video?>"></div>
							<!-- /post-video -->
						<?php else: ?>
							<div class="tf_lazy slide-feature-image">
								<a href="<?php echo $link; ?>" title="<?php the_title_attribute(); ?>">
									<?php echo themify_get_image(array(
											'w'=>$img_width,
											'h'=>$img_height,
											'class'=>'feature-img',
											'lazy_load'=>$isFirst
										)); ?>
								</a>
							</div>
							<!-- /.slide-feature-image -->
						<?php endif; ?>

						<div class="slide-content-wrap">

							<?php if($showTitle===true): ?>
								<h3 class="slide-post-title"><a href="<?php echo $link; ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h3>
							<?php endif; ?>

							<?php // Load audio player
							if( 'audio' === $post_format ): ?>
								<?php echo $themify->get_audio_player(themify_get('audio_url'), $post->ID); ?>
							<?php endif; ?>

							<?php if($display !== 'none'): ?>
							    <div class="slide-excerpt <?php echo $post_format; ?>-content">
								<?php $display=== 'content'?the_content():the_excerpt(); ?>
							    </div>
							<?php endif; ?>

						</div>
						<!-- /.slide-content-wrap -->

						<?php if( 'quote' === $post_format ): ?>
							<?php echo $themify->get_quote_author(themify_get('quote_author'), themify_get('quote_author_link')); ?>
						<?php endif; ?>

			</div>
			<?php
				$isFirst=true;
				endwhile;
			}

			wp_reset_query();

		}
		?>
		</div>

        <?php themify_slider_end(); //hook ?>
		</div>
	</div>
	<!-- /#slider -->
    <?php themify_slider_after(); //hook ?>

<?php } 
