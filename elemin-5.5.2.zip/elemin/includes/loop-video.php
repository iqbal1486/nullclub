<?php themify_post_video();?>
<!-- post-content -->
<div class="post-content">
    <?php themify_post_content();?>
</div>
<!-- /post-content -->