<?php 
global $themify; ?>

<!-- quote-content -->
<div class="quote-content">
	
	<?php themify_post_content();?>
</div>
<!-- /quote-content -->

<?php echo $themify->get_quote_author(themify_get('quote_author'), themify_get('quote_author_link'));