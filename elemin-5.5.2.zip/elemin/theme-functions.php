<?php
/*
To add custom PHP functions to the theme, create a child theme (https://themify.me/docs/child-theme) and add it to the child theme functions.php file.
They will be added to the theme automatically.
*/


/**
 * Load Google fonts used by the theme
 *
 * @return array
 */
function themify_theme_google_fonts( $fonts ) {
	$fonts['ofl-sorts-mill'] = 'OFL+Sorts+Mill+Goudy+TT:regular,italic';
	return $fonts;
}
function themify_theme_avatar_size(){
    return 68;
}
add_filter('themify_comment_avatar_size','themify_theme_avatar_size');
add_filter( 'themify_google_fonts', 'themify_theme_google_fonts' );
add_filter('themify_register_sidebars','themify_theme_register_sidebars');


///////////////////////////////////////////////////////
// Adds rel="prettyPhoto" to all linked image files
///////////////////////////////////////////////////////
add_filter('the_content', 'themify_addlightboxrel_replace', 12);
add_filter('the_excerpt', 'themify_addlightboxrel_replace');
add_filter('widget_text', 'themify_addlightboxrel_replace');
add_filter('get_comment_text', 'themify_addlightboxrel_replace');
function themify_addlightboxrel_replace ($content){
	global $post;
	if(is_object($post) && isset($post->ID)){
        $pattern = "/<a(.*?)href=('|\")([^>]*).(bmp|gif|jpeg|jpg|png)('|\")(.*?)>(.*?)<\/a>/i";
        $replacement = '<a$1href=$2$3.$4$5 rel="prettyPhoto['.$post->ID.']"$6>$7</a>';
        $content = preg_replace($pattern, $replacement, $content);
    }
	return $content;
}

///////////////////////////////////////
// Filter RSS Feed to include Custom Fields
///////////////////////////////////////
add_filter('the_content', 'themify_post_format_custom_fields');

function themify_post_format_custom_fields( $content ) {

	global $post, $id, $themify_check;
	if(!is_feed() || $themify_check == true){
		return $content;
	}
	$post_format = themify_get('post_format');

	if(has_post_format( 'image' ) && themify_check('post_image')) {
		$content = "<img src='".themify_get('post_image')."'><br>".$content;
	} elseif(has_post_format( 'quote' ) && themify_check('quote_author')) {
		$content = '"'.$content.'" '.themify_get('quote_author')." - <a href='".themify_get('quote_author_link')."'>".themify_get('quote_author_link')."</a>";
	} elseif(has_post_format( 'link' ) && themify_check('link_url')) {
		$content .= "<a href='".themify_get('link_url')."'>".themify_get('link_url')."</a>";
	} elseif(has_post_format( 'audio' ) && themify_check('audio_url')) {
		$content = "<p><img src='".themify_get('post_image')."'></p><br>".$content;
		$content .= themify_get('audio_url');
	} elseif(has_post_format( 'video' ) && themify_check('video_url')) {
		$themify_check = true;
		$content = apply_filters('the_content', themify_get('video_url')) . $content;
	}
	$themify_check = false;
	return $content;
}

///////////////////////////////////////
// Register Custom Menu Function
///////////////////////////////////////
function themify_register_custom_nav() {
	/* prevent update checks from wp.org repository */
	add_theme_support( 'themify-exclude-theme-from-wp-update' );
		
	///////////////////////////////////////
	// Enable WordPress feature image
	///////////////////////////////////////
	add_theme_support( 'post-thumbnails' );

	///////////////////////////////////////
	// Add WordPress post formats
	///////////////////////////////////////
	add_theme_support( 'post-formats', array('aside', 'gallery', 'link', 'image', 'quote', 'status', 'video', 'audio', 'chat') );
	
	register_nav_menus( array(
		'main-nav' => __( 'Main Navigation', 'themify' ),
		'footer-nav' => __( 'Footer Navigation', 'themify' ),
	) );
}

// Register Custom Menu Function - Action
add_action('after_setup_theme', 'themify_register_custom_nav');
	
/**
 * Register sidebars
 * @since 1.0.0
 */
function themify_theme_register_sidebars($sidebars) {
    $sidebars[0]['name']= __('Sidebar 1', 'themify');
    $sidebars[]=array(
	    'name' => __('Sidebar 2A', 'themify'),
	    'id' => 'sidebar-main-2a',
	    'before_widget' => '<section id="%1$s" class="widget %2$s">',
	    'after_widget' => '</section>',
	    'before_title' => '<h4 class="widgettitle">',
	    'after_title' => '</h4>'
    );
    $sidebars[]=array(
	    'name' => __('Sidebar 2B', 'themify'),
	    'id' => 'sidebar-main-2b',
	    'before_widget' => '<section id="%1$s" class="widget %2$s">',
	    'after_widget' => '</section>',
	    'before_title' => '<h4 class="widgettitle">',
	    'after_title' => '</h4>'
    );
    $sidebars[]=array(
	    'name' => __('Sidebar 3', 'themify'),
	    'id' => 'sidebar-main-3',
	    'before_widget' => '<section id="%1$s" class="widget %2$s">',
	    'after_widget' => '</section>',
	    'before_title' => '<h4 class="widgettitle">',
	    'after_title' => '</h4>'
    );
    return $sidebars;
}
/**
 * Adds header slider and welcome message
 */
function themify_theme_layout_before(){
	$isFront=is_front_page();
	$isPaged=is_paged();
	if ( $isFront===true && $isPaged===false) {
		get_template_part( 'includes/welcome-message' );
	}
	if ($isFront===true || ($isPaged===false && themify_get( 'setting-header_slider_all_pages' ) ) ) {
		get_template_part( 'includes/header-slider' );
	}
}
add_action( 'themify_layout_before', 'themify_theme_layout_before' );
