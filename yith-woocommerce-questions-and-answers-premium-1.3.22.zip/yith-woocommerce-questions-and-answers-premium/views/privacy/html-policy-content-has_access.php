<p><?php _ex( 'Members of our team have access to the information you provide us. For example, both Administrators and Shop Managers can access:', 'Privacy Policy Content', 'yith-woocommerce-questions-and-answers' ) ?></p>

<ul>
    <li><?php _ex( 'Author name, date, title and content of the questions and answers you have made', 'Privacy Policy Content', 'yith-woocommerce-questions-and-answers' ); ?></li>
</ul>