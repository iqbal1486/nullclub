jQuery( document ).ready( function( $ ) {
    $('.gcal-slider').unslider({
        nav: false
    });
}( jQuery ));