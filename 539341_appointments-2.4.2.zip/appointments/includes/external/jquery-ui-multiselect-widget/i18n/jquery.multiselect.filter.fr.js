/* French initialisation for the jQuery UI multiselect plugin. */
/* Written by Charles SANQUER (charles.sanquer@spyrit.net). */

(function ( $ ) {

$.extend($.ech.multiselectfilter.prototype.options, {
	label: "Filtre:",
	placeholder: "Entrer un mot clé"
});

})( jQuery );
