/* Hungarian initialisation for the jQuery UI multiselect plugin. */
/* Written by Adam Fónagy (adam.fonagy@greenformatics.hu). */

(function ( $ ) {

$.extend($.ech.multiselectfilter.prototype.options, {
	label: "Keresés:",
	placeholder: "kulcsszó megadása"
});

})( jQuery );
