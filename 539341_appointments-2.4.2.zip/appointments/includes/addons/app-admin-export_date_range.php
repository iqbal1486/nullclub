<?php
/*
Plugin Name: Export Date Range
Description: Allows you to export appointments within a date range
Plugin URI: http://premium.wpmudev.org/project/appointments-plus/
Version: 1.0
AddonType: Export
Author: WPMU DEV
Free: true
*/