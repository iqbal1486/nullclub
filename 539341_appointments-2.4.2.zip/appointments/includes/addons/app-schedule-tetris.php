<?php
/*
Plugin Name: Tetris Mode
Description: Adjust schedule time slots dynamically to avoid free gaps after booked appointments and breaks.
Plugin URI: http://premium.wpmudev.org/project/appointments-plus/
Version: 1.0
AddonType: Schedule
Author: WPMU DEV
Free: true
*/