<?php
/*
Plugin Name: Administrative Permissions
Description: Allows you to select who can do what in your admin backend.
Plugin URI: http://premium.wpmudev.org/project/appointments-plus/
Version: 1.0
AddonType: Users
Author: WPMU DEV
Free: true
*/