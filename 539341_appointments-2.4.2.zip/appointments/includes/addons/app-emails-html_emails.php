<?php
/*
Plugin Name: Allow HTML emails
Description: By default, the plugin sents plain text emails. Activating this add-on will allow your emails to be sent as HTML.
Plugin URI: http://premium.wpmudev.org/project/appointments-plus/
Version: 1.0
AddonType: Emails
Author: WPMU DEV
Free: true
*/