<?php
/*
Plugin Name: Service Description post type
Description: Allows you to select a post type for your service descriptions (available under Settings &gt; General &gt; Advanced Settings)
Plugin URI: http://premium.wpmudev.org/project/appointments-plus/
Version: 1.0
AddonType: Post Types
Author: WPMU DEV
Free: true
*/