<?php
/*
Plugin Name: Show Scheduled Users
Description: Shows scheduled user names for unavailable appointment schedule segments.
Plugin URI: http://premium.wpmudev.org/project/appointments-plus/
Version: 1.0
AddonType: Schedule
Author: WPMU DEV
Free: true
*/