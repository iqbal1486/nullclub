<?php
/*
Plugin Name: Service provider names
Description: Allows you to select how a service provider will be introduced to your customers.
Plugin URI: http://premium.wpmudev.org/project/appointments-plus/
Version: 1.0
AddonType: Post Types
Author: WPMU DEV
Free: true
*/