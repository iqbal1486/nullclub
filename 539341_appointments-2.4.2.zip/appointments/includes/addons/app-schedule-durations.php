<?php
/*
Plugin Name: Durations
Description: Allows you to make changes to service durations calculus
Plugin URI: http://premium.wpmudev.org/project/appointments-plus/
Version: 1.0
AddonType: Schedule
Author: WPMU DEV
Free: true
*/