<?php
/*
Plugin Name: Locations on Google Maps
Description: Allows you to bind locations to your services.
Plugin URI: http://premium.wpmudev.org/project/appointments-plus/
Version: 1.0
AddonType: Locations
Requires: Locations,<a href="https://premium.wpmudev.org/project/wordpress-google-maps-plugin/">Google Maps Plugin</a>
Author: WPMU DEV
Free: true
*/