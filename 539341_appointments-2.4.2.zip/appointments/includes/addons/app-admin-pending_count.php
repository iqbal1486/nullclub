<?php
/*
Plugin Name: Pending Appointments count notification
Description: Adds a visual notification to your Appointments menu item and periodically syncs this count with the server.
Plugin URI: http://premium.wpmudev.org/project/appointments-plus/
Version: 1.1
AddonType: Admin
Author: WPMU DEV
Free: true
*/