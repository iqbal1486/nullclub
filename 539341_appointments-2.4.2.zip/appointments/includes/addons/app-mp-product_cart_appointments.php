<?php
/*
Plugin Name: Appointments in product cart
Description: Control how your appointments show in the product cart.
Plugin URI: http://premium.wpmudev.org/project/appointments-plus/
Version: 1.0
AddonType: Integration
Requires: <a href="https://premium.wpmudev.org/project/e-commerce/">MarketPress</a>
Author: WPMU DEV
Free: true
*/