<?php
/*
Plugin Name: Default Service
Description: Allows you to select the default service for your appointments, rather than always using the first defined one.
Plugin URI: http://premium.wpmudev.org/project/appointments-plus/
Version: 1.0
AddonType: Schedule
Author: WPMU DEV
Free: true
*/