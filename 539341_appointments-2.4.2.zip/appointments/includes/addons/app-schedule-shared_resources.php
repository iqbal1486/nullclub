<?php
/*
Plugin Name: Shared Resources
Description: Allows your services to define shared real-life resources, such as rooms or vehicles. The services that share resources will only allow appointments up to minimum common capacity.
Plugin URI: http://premium.wpmudev.org/project/appointments-plus/
Version: 1.0
AddonType: Schedule
Author: WPMU DEV
Free: true
*/