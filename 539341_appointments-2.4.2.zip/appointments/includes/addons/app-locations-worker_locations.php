<?php
/*
Plugin Name: Worker Locations
Description: Allows you to bind locations to your Service Providers.
Plugin URI: http://premium.wpmudev.org/project/appointments-plus/
Version: 1.0
AddonType: Locations
Requires: Locations
Author: WPMU DEV
Free: true
*/