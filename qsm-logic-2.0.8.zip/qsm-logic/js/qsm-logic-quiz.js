/**
 * QSM - Logic v0.1.0
 */

var QSM_Logic_Quiz;
(function ($) {
	QSM_Logic_Quiz = {
		VERSION: '1.0.1',
		DEFAULTS: {},
		checkRule: function (rule) {
			var conditionsTrue = 0;
			var totalIf = 0;
			$.each(rule.if, function (i, val) {
				totalIf++;

				var $question = $("input[name=question" + val.question + "]:checked, input[name='question" + val.question + "[]']:checked, select[name=question" + val.question + "], textarea[name=question" + val.question + "],input[name=question" + val.question + "][type='number'], input[name=question" + val.question + "][type='text']");
				// Get checkbox/select multiple selected/checked values
				var multipleCheckedVals = $question.map(function () {
					return this.value;
				}).get();
				// Check if input is select or checkbox
				var is_checkbox = false;
				if ($question.is(':checkbox')) {
					is_checkbox = true;
				}
				if ($question.is('select')) {
					is_checkbox = true;
				}

				if ("No Answer Provided" != $question.val()) {
					switch ( val.condition ) {
						case 'is equal to':
							if ($question.val() === decodeEntities( val.answer ).toString() || $.inArray(decodeEntities( val.answer ), multipleCheckedVals) !== -1) {
								conditionsTrue++;
							}
							break;
						case 'is not equal to':
							if ( $question.val() !== decodeEntities( val.answer ).toString() && !is_checkbox ) {
								conditionsTrue++;
							}
							if ( is_checkbox ) {
								if ($.inArray( decodeEntities( val.answer ).toSring() , multipleCheckedVals) === -1) {
									conditionsTrue++;
								}
							}
							break;
						case 'is greater than':
							if (parseFloat($question.val()) > parseFloat(decodeEntities( val.answer )) && !is_checkbox) {
								conditionsTrue++;
							}
							if ( is_checkbox ) {
								var check_g = false;
								$.each(multipleCheckedVals, function (k, v) {
									if (parseFloat(v) > parseFloat(decodeEntities( val.answer ))) {
										check_g = true;
									}
								});
								if (check_g) {
									conditionsTrue++;
								}
							}
							break;
						case 'is less than':
							if (parseFloat($question.val()) < parseFloat(decodeEntities( val.answer )) && !is_checkbox) {
								conditionsTrue++;
							}
							if (is_checkbox) {
								var check_g = false;
								$.each(multipleCheckedVals, function (k, v) {
									if (parseFloat(v) < parseFloat(decodeEntities( val.answer ))) {
										check_g = true;
									}
								});
								if (check_g) {
									conditionsTrue++;
								}
							}
							break;
						case 'is empty':
							if ('' === $question.val() || null === $question.val() ) {
								conditionsTrue++;
							}
							if ( !is_checkbox && 0 === multipleCheckedVals.length ) {
								conditionsTrue++;
							}
							break;
						case 'is not empty':
							if ('' !== $question.val() ) {
								conditionsTrue++;
							}
							if ( is_checkbox && 0 > multipleCheckedVals.length ) {
								conditionsTrue++;
							}
							break;
						default:
							// default
					}
				} else {
					// Default answer
				}
			});

			$.each(rule.then, function (i, val) {
				if (jQuery(".data-req-el-" + val.question)) {
					var req_class = jQuery(".data-req-el-" + val.question).attr("data-req-class");
					jQuery(".data-req-el-" + val.question).addClass(req_class);
				}
			});

			if (conditionsTrue === totalIf) {
				$.each(rule.then, function (i, val) {
					var thenVal = val.question;
					var sectionClass = '.question-section-id-'+thenVal;
					if (String(thenVal).indexOf('c') > -1) {
						sectionClass = '.category-section-id-'+thenVal;
					}
					if ('Show' === val.condition) {
						$(sectionClass).show().removeClass('qsm-logic-hidden');
						removeFromHiddenField(thenVal);
						QSMLogicRecalucateQuestionNumber(thenVal);
					} else {
						resetBeforeHide(thenVal);
						$(sectionClass).hide().addClass('qsm-logic-hidden');
						qsmRemoveRequired(sectionClass + ' *', sectionClass, thenVal);
						addToHiddenField(thenVal);
						QSMLogicRecalucateQuestionNumber(thenVal);
						$.each(qmn_quiz_data_new, function (j, valj) {
							var particular_quiz_rule = qmn_quiz_data_new[j];
							$.each(particular_quiz_rule, function (i, object_value) {
								$.each(object_value.if, function (i, ovi_val) {
									if (ovi_val.question == thenVal) {
										$.each(object_value.then, function (i, obt_val) {
											var objectThenVal = obt_val.question;
											var objectSectionClass = '.question-section-id-'+objectThenVal;
											if (String( objectThenVal ).indexOf('c') > -1) {
												objectSectionClass = '.category-section-id-'+objectThenVal;
											}
											resetBeforeHide(objectThenVal);
											$(objectSectionClass).hide().addClass('qsm-logic-hidden');
											qsmRemoveRequired(objectSectionClass + ' *', objectSectionClass, objectThenVal);
											addToHiddenField(objectThenVal);
											QSMLogicRecalucateQuestionNumber(thenVal);
										});
									}
								});

							});
						});
					}
				});
			} else {
				$.each(rule.then, function (i, val) {
					var thenVal = val.question;
					var sectionClass = '.question-section-id-'+thenVal;
					if (String(thenVal).indexOf('c') > -1) {
						sectionClass = '.category-section-id-'+thenVal;
					}
					if ('Show' !== val.condition) {
						$(sectionClass).show().removeClass('qsm-logic-hidden');
						removeFromHiddenField(thenVal);
						QSMLogicRecalucateQuestionNumber(thenVal);
					} else {
						resetBeforeHide(thenVal);
						$(sectionClass).hide().addClass('qsm-logic-hidden');
						qsmRemoveRequired(sectionClass + ' *', sectionClass, thenVal);
						addToHiddenField(thenVal);
						QSMLogicRecalucateQuestionNumber(thenVal);
						$.each(qmn_quiz_data_new, function (j, valj) {
							var particular_quiz_rule = qmn_quiz_data_new[j];
							$.each(particular_quiz_rule, function (i, object_value) {
								$.each(object_value.if, function (i, ovi_val) {
									if (ovi_val.question == thenVal) {
										$.each(object_value.then, function (i, obt_val) {
											var objectThenVal = obt_val.question;
											var objectSectionClass = '.question-section-id-'+objectThenVal;
											if (String( objectThenVal ).indexOf('c') > -1) {
												objectSectionClass = '.category-section-id-'+objectThenVal;
											}
											resetBeforeHide(objectThenVal);
											$(objectSectionClass).hide().addClass('qsm-logic-hidden');
											qsmRemoveRequired(objectSectionClass + ' *', objectSectionClass, objectThenVal);
											addToHiddenField(objectThenVal);
											QSMLogicRecalucateQuestionNumber(thenVal);
										});
									}
								});
							});
						});
					}
				});
			}
		}
	};

	function implement_logic() {
		var mr_field = ' ';
		var quiz_id = qsm_logic_quiz_id.quiz_id;
		$.each(qmn_quiz_data_new, function (j, valj) {
			var pagination = qmn_quiz_data[j].hasOwnProperty('pagination') ? qmn_quiz_data[j].pagination.amount : 0;
			if (pagination > 0) {
				return false;
			}
			var particular_quiz_rule = qmn_quiz_data_new[j];
			var execute_last = {};
			$.each(particular_quiz_rule, function (i, val) {
				QSM_Logic_Quiz.checkRule(particular_quiz_rule[i]);
				$.each(val.if, function (j, vals) {
					$('.question-section-id-' + vals.question).find('input[type=checkbox]').each(function () {
						mr_field += ', #' + $(this).attr('id');
					});
					$("input[name=question" + vals.question + "], textarea[name=question" + vals.question + "], select[name=question" + vals.question + "] " + mr_field).on("change keyup", function () {
						var current_val = $(this).val();
						$.each(particular_quiz_rule[i].if, function (qr, qr_val) {
							if ( decodeEntities( qr_val.answer ) == current_val) {
								execute_last = particular_quiz_rule[i];
							} else {
								QSM_Logic_Quiz.checkRule(particular_quiz_rule[i]);
							}
						});
						QSM_Logic_Quiz.checkRule(execute_last);
					});
				});
			});
		});
	}

	implement_logic();

	// implementing logic on Quiz Retake
	$(document).on('qsm_retake_quiz', function (e, quizID) {
		console.log('retake done');
		implement_logic();
	});
}(jQuery));



function qsmRemoveRequired(element, q_section, question_id) {
	jQuery(element).each(function () {
		if (jQuery(this).attr('class')) {
			if (jQuery(this).attr('class').indexOf('mlwEmail') !== -1) {
				jQuery(this).removeClass("mlwEmail");
				jQuery(this).attr("data-req-class", "mlwEmail");
				jQuery(this).addClass("data-req-el-" + question_id);
			}
			if (jQuery(this).attr('class').indexOf('mlwRequiredNumber') !== -1) {
				jQuery(this).removeClass("mlwRequiredNumber");
				jQuery(this).attr("data-req-class", "mlwRequiredNumber");
				jQuery(this).addClass("data-req-el-" + question_id);
			}
			if (jQuery(this).attr('class').indexOf('mlwRequiredText') !== -1) {
				jQuery(this).removeClass("mlwRequiredText");
				jQuery(this).attr("data-req-class", "mlwRequiredText");
				jQuery(this).addClass("data-req-el-" + question_id);
			}
			if (jQuery(this).attr('class').indexOf('mlwRequiredCaptcha') !== -1) {
				jQuery(this).removeClass("mlwRequiredCaptcha");
				jQuery(this).attr("data-req-class", "mlwRequiredCaptcha");
				jQuery(this).addClass("data-req-el-" + question_id);
			}
			if (jQuery(this).attr('class').indexOf('mlwRequiredAccept') !== -1) {
				jQuery(this).removeClass("mlwRequiredAccept");
				jQuery(this).attr("data-req-class", "mlwRequiredAccept");
				jQuery(this).addClass("data-req-el-" + question_id);
			}
			if (jQuery(this).attr('class').indexOf('mlwRequiredRadio') !== -1) {
				jQuery(this).removeClass("mlwRequiredRadio");
				jQuery(this).attr("data-req-class", "mlwRequiredRadio");
				jQuery(this).addClass("data-req-el-" + question_id);
			}
			if (jQuery(this).attr('class').indexOf('mlwRequiredFileUpload') !== -1) {
				jQuery(this).removeClass("mlwRequiredFileUpload");
				jQuery(this).attr("data-req-class", "mlwRequiredFileUpload");
				jQuery(this).addClass("data-req-el-" + question_id);
			}
			if (jQuery(this).attr('class').indexOf('qsmRequiredSelect') !== -1) {
				jQuery(this).removeClass("qsmRequiredSelect");
				jQuery(this).attr("data-req-class", "qsmRequiredSelect");
				jQuery(this).addClass("data-req-el-" + question_id);
			}
			if (jQuery(this).attr('class').indexOf('mlwRequiredCheck') !== -1) {
				jQuery(this).removeClass("mlwRequiredCheck");
				jQuery(this).attr("data-req-class", "mlwRequiredCheck");
				jQuery(this).addClass("data-req-el-" + question_id);
			}
			if (jQuery(this).attr('class').indexOf('g-recaptcha-response') !== -1) {
				jQuery(this).removeClass("g-recaptcha-response");
				jQuery(this).attr("data-req-class", "g-recaptcha-response");
				jQuery(this).addClass("data-req-el-" + question_id);
			}
		}
	});
}


function addToHiddenField(question_id) {
	var question_hidden = jQuery('#qsm_hidden_questions').val();
	if (question_hidden != "") {
		question_hidden = JSON.parse(question_hidden);
	} else {
		question_hidden = [];
	}

	// Put question id into hidden field
	if (jQuery.inArray(question_id, question_hidden) === -1) {
		question_hidden.push(question_id);
		jQuery("#qsm_hidden_questions").val(JSON.stringify(question_hidden));
	}
}

function removeFromHiddenField(question_id) {
	var question_hidden = jQuery('#qsm_hidden_questions').val();
	if (question_hidden != "") {
		question_hidden = JSON.parse(question_hidden);
		question_hidden = jQuery.grep(question_hidden, function (value) {
			return value != question_id;
		});
		jQuery("#qsm_hidden_questions").val(JSON.stringify(question_hidden));
	}
}

function QSMLogicRecalucateQuestionNumber(question_id) {
	var $questionnumber = 1;
	jQuery('.quiz_section').each(function (e) {
		if (jQuery(this).hasClass('quiz_begin') || jQuery(this).hasClass('quiz_end')) {
			//Do nothing.
		} else {
			if (jQuery(this).css('display') !== 'none' && jQuery(this).find('.mlw_qmn_question_number').length > 0) {
				jQuery(this).find('.mlw_qmn_question_number').text('').text($questionnumber + '. ');
				$questionnumber++;
			}
		}
	});
}
// Resets the options of question
function resetBeforeHide(question_id) {
	input = jQuery('.question-section-id-' + question_id).find('input')
	select = jQuery('.question-section-id-' + question_id).find('select');
	if (input.length > 0) {
		input.each(function () {
			switch (jQuery(this).attr('type')) {
				case 'radio':
				case 'checkbox':
					if (jQuery(this).prop('checked')) {
						jQuery(this).prop('checked', false);
						jQuery(document).trigger('qsm_reset_before_hide', jQuery(this));
					}

					break;
				case 'text':
				case 'number':
					jQuery(this).val('');
				default:
					break;
			}
		});
	}

	if (select.length > 0) {
		select.each(function () {
			jQuery(this).val('');
		})
	}

}

function decodeEntities (str ) {
	if(str && typeof str === 'string') {
		str = str.replace("\\'", "'");
		str = str.replace('\\"', '"');
	}
	return str;
};