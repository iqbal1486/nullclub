jQuery(function ($) {
	jQuery(document).on('qsm_after_add_result_block', function (event, conditions, page, redirect) {
		jQuery('.results-page:last-child').find('.results-page-condition').each(function () {
			var criteria = jQuery(this).find('.results-page-condition-criteria').val();
			var operator = jQuery(this).find('.results-page-condition-operator').val();
			var value = jQuery(this).find('input.results-page-condition-value').val();
			jQuery(this).find('.results-page-condition-criteria').trigger('change');
			if (criteria == 'question') {
				jQuery(this).find('.results-page-condition-operator').val(operator).trigger('change');
				jQuery(this).find('.condition-question-value').val(value).trigger('change');
			} else {
				jQuery(this).find('.results-page-condition-operator').val(operator);
				jQuery(this).find('.condition-question-value').val(value);
			}
		});
	});

	/**
	 * Handle email condition change events.
	 */
	jQuery(document).on('change', '.results-page-condition-criteria', function (event) {
		event.stopPropagation();
		var conditionOperator = jQuery(this).parents('.results-page-condition').find('.results-page-condition-operator');
		var default_operators = conditionOperator.find('option.default_operator');
		var question_operators = conditionOperator.find('option.question_operator');
		conditionOperator.find('option').hide();
		if (jQuery(this).val() == 'question') {
			question_operators.show();
			conditionOperator.val(question_operators.first().val()).trigger('change');
		} else {
			default_operators.show();
			conditionOperator.val(default_operators.first().val()).trigger('change');
		}
	});
	jQuery(document).on('change', '.results-page-condition-operator', function (event) {
		event.stopPropagation();
		var $parent = jQuery(this).parents('.results-page-condition');
		var criteria = $parent.find('.results-page-condition-criteria').val();
		$parent.find('.results-page-condition-value').hide();
		if (criteria == 'question') {
			var qid = jQuery(this).val();
			var $valueField = $parent.find('.condition-question-value');
			$valueField.find('option').hide();
			$valueField.find('option[data-qid="' + qid + '"]').show();
			$valueField.show().val($valueField.find('option[data-qid="' + qid + '"]').first().val()).trigger('change');
		} else {
			$parent.find('.condition-default-value').show();
		}
	});
	jQuery(document).on('change', '.condition-question-value', function (event) {
		event.stopPropagation();
		jQuery(this).parents('.results-page-condition').find('.results-page-condition-value').val(jQuery(this).val());
	});
});