<?php
if (!defined('ABSPATH')) {
	exit;
}
if (!class_exists('QSMQuizConditions')) {

	class QSMQuizConditions {

		public function __construct() {
			add_action('admin_enqueue_scripts', array(&$this, 'admin_enqueue_scripts'), 9999);

			add_action('qsm_email_condition_criteria', array(&$this, 'qsm_add_condition_criteria'));
			add_action('qsm_email_condition_operator', array(&$this, 'qsm_add_condition_operator'));
			add_action('qsm_email_condition_value', array(&$this, 'qsm_add_condition_value'));

			add_action('qsm_results_page_condition_criteria', array(&$this, 'qsm_add_condition_criteria'));
			add_action('qsm_results_page_condition_operator', array(&$this, 'qsm_add_condition_operator'));
			add_action('qsm_results_page_condition_value', array(&$this, 'qsm_add_condition_value'));

			add_filter('qsm_email_condition_check', array(&$this, 'qsm_condition_check'), 999, 3);
			add_filter('qsm_results_page_condition_check', array(&$this, 'qsm_condition_check'), 999, 3);
		}

		public function admin_enqueue_scripts($hook_suffix) {
			global $mlwQuizMasterNext;
			if ($hook_suffix == 'admin_page_mlw_quiz_options') {
				if (isset($_REQUEST['tab']) && $_REQUEST['tab'] == 'emails') {
					wp_enqueue_script('qsm_logic_email_conditions_admin', plugins_url('../js/qsm-email-conditions-admin.js', __FILE__), array('qsm_admin_js'), $mlwQuizMasterNext->version, true);
				}
				if (isset($_REQUEST['tab']) && $_REQUEST['tab'] == 'results-pages') {
					wp_enqueue_script('qsm_logic_result_conditions_admin', plugins_url('../js/qsm-result-conditions-admin.js', __FILE__), array('qsm_admin_js'), $mlwQuizMasterNext->version, true);
				}
			}
		}

		function qsm_add_condition_criteria() {
			if (is_admin() && isset($_REQUEST['quiz_id'])) {
				$quiz_id = $_REQUEST['quiz_id'];
				?><option value="question" <# if (data.criteria == 'question') { #>selected<# } #>><?php _e('Question', 'quiz-master-next'); ?></option><?php
			}
		}

		function qsm_add_condition_operator() {
			if (is_admin() && isset($_REQUEST['quiz_id'])) {
				global $wpdb;
				global $mlwQuizMasterNext;
				$quiz_id = $_REQUEST['quiz_id'];
				$questions = QSM_Questions::load_questions_by_pages($quiz_id);
				if (!empty($questions)) {
					foreach ($questions as $q) {
						$q_id = $q['question_id'];
						$question_type = $q['question_type_new'];
						$q_title = $q['settings']['question_title']
						?>
						<option class="question_operator" value="<?php echo $q_id; ?>" data-type="<?php echo $question_type; ?>" style="display:none;" <# if (data.operator == '<?php echo $q_id; ?>') { #>selected<# } #>><?php echo $q_title; ?></option>
						<?php
					}
				}
			}
		}

		function qsm_add_condition_value() {
			if (is_admin() && isset($_REQUEST['quiz_id'])) {
				global $wpdb;
				global $mlwQuizMasterNext;
				$quiz_id = $_REQUEST['quiz_id'];
				$questions = QSM_Questions::load_questions_by_pages($quiz_id);
				$condition_value_field = '';
				if (!empty($questions)) {
					$condition_value_field = '<select class="email-condition-value results-page-condition-value condition-question-value" style="display: none;min-width: 30%;">';
					foreach ($questions as $q) {
						$q_id = $q['question_id'];
						$answers = $q['answers'];
						if (!empty($answers)) {
							foreach ($answers as $ans) {
								$condition_value_field .= '<option class="criteria_question_value" value="' . $ans[0] . '" data-qid="' . $q_id . '" <# if (data.value == "' . $ans[0] . '") { #>selected<# } #> >' . $ans[0] . '</option>';
							}
						}
					}
					$condition_value_field .= '</select>';
				}
				echo $condition_value_field;
			}
		}

		function qsm_condition_check($show, $condition, $response_data) {
			if ($condition['criteria'] == 'question') {
				$show = true;
				$question_id = $condition['operator'];
				$answer = $condition['value'];
				$question_answers_array = isset($response_data['question_answers_array']) ? $response_data['question_answers_array'] : array();
				$key = array_search($question_id, array_column($question_answers_array, 'id'));
				if (isset($question_answers_array[$key])) {
					$q_answer = $question_answers_array[$key];
					if (!in_array($answer, explode('.', $q_answer[1]))) {
						$show = false;
					}
				}
			}
			return $show;
		}

	}

}
global $QSMQuizConditions;
$QSMQuizConditions = new QSMQuizConditions();
