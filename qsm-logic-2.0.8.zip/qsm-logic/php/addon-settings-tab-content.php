<?php
if ( ! defined( 'ABSPATH' ) )
	exit;

/**
 * Registers your tab in the addon  settings page
 *
 * @since 0.1.0
 * @return void
 */
function qsm_addon_logic_register_addon_settings_tabs() {
	global $mlwQuizMasterNext;
	if ( ! is_null( $mlwQuizMasterNext ) && ! is_null( $mlwQuizMasterNext->pluginHelper ) && method_exists( $mlwQuizMasterNext->pluginHelper, 'register_quiz_settings_tabs' ) ) {
		$mlwQuizMasterNext->pluginHelper->register_addon_settings_tab( "Logic", 'qsm_addon_logic_addon_settings_tabs_content' );
	}
}

/**
 * Generates the content for your addon settings tab
 *
 * @since 0.1.0
 * @return void
 */
function qsm_addon_logic_addon_settings_tabs_content() {
	global $mlwQuizMasterNext;
	//If nonce is correct, update settings from passed input
	if ( isset( $_POST["logic_nonce"] ) && wp_verify_nonce( $_POST['logic_nonce'], 'logic' ) ) {
		// Load previous license key
		$settings	 = get_option( 'qsm_addon_logic_settings', '' );
		$license	 = isset( $settings['license_key'] ) ? trim( $settings['license_key'] ) : '';

		$saved_license	 = isset( $_POST['license_key'] ) ? sanitize_text_field( wp_unslash( $_POST['license_key'] ) ) : '';
		$new_settings	 = array( 'license_key' => $saved_license );
		// Checks to see if the license key has changed.
		if ( $license !== $saved_license ) {
			$activation = QSM_license::activate( $saved_license, 'Logic' );
			if ( 'success' == $activation['status'] ) {
				$mlwQuizMasterNext->alertManager->newAlert( $activation['message'], 'success' );
			} else {
				$new_settings['license_key'] = '';
				$mlwQuizMasterNext->alertManager->newAlert( $activation['message'], 'error' );
			}
			// If previous license key was entered.
			$deactivation = QSM_license::deactivate( $license, 'Logic' );
		}
		update_option( 'qsm_addon_logic_settings', $new_settings );
		$mlwQuizMasterNext->alertManager->newAlert( 'Your settings has been saved successfully!', 'success' );
	}
	// Load settings.
	$settings_data = wp_parse_args( get_option( 'qsm_addon_logic_settings', array() ), array(
		'license_key' => '',
		)
	);
	// Show any alerts from saving
	$mlwQuizMasterNext->alertManager->showAlerts();
	?>
	<form action="" method="post">
		<table class="form-table" style="width: 100%;">
			<tr valign="top">
				<th scope="row"><label for="license_key"><?php _e( 'Addon License Key', 'qsm-logic' ); ?></label></th>
				<td><input type="text" name="license_key" id="license_key" value="<?php echo $settings_data["license_key"]; ?>"></td>
			</tr>
		</table>
		<?php wp_nonce_field( 'logic', 'logic_nonce' ); ?>
		<button class="button-primary"><?php _e( 'Save Changes', 'qsm-logic' ) ?></button>
	</form>
	<?php
}
