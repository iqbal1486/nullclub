<?php

/**
 * Saves the logic rules from the quiz settings tab
 *
 * @since 0.1.0
 * @return void
 */
function qsm_addon_logic_ajax() {
  global $wpdb;
  global $mlwQuizMasterNext;
  $mlwQuizMasterNext->quizCreator->set_id( intval( $_POST["quiz_id"] ) );
  $logic_ajax = qsm_update_logic_data($_POST["parameter"], $_POST["logic_rules"], $_POST["quiz_id"]);
  echo json_encode( $logic_ajax );
  die();
}

/**
*
* Saves the logic in mlw_logic table
*
* @since 2.0.0
* @return array number of rows saved / false incase query fails
*/
function qsm_update_logic_data($parameter, $logic, $quiz_id){
  global $wpdb;
  global $mlwQuizMasterNext;
  $table_exists = get_option("logic_rules_quiz_$quiz_id");
  $logic_table = $wpdb->prefix.'mlw_logic';
  if(empty($table_exists)){
      $wpdb->delete($logic_table, array('quiz_id' => $quiz_id));
      $value_array = array();
      foreach($logic as $logic_data){
          $data = array(
              $quiz_id,
              serialize($logic_data),
          );
          $value_array[] = stripslashes($wpdb->prepare("(%d, %s)", $data));
      }
      $values = implode(',', $value_array);
      $query = "INSERT INTO $logic_table (quiz_id, logic) VALUES ";
      $query .= $values;
      $saved = $wpdb->query($query);
      if($saved != FALSE){
          update_option("logic_rules_quiz_$quiz_id", date(time()));
          $mlwQuizMasterNext->pluginHelper->update_quiz_setting( "logic_rules", '' );
      }
      return array('status' => $saved);
  } else {
      foreach($parameter as $key => $param){
          if($param['status'] == 'updated'){
              if(!empty($param['id'])){
                  $data = array(
                      'logic' => serialize($logic[$key])
                  );
                  $where = array(
                      'id'    => $param['id']
                  );
                  $result = $wpdb->update($logic_table, $data, $where, array('%s'), array('%d'));
                  if($result){
                    return $response = array(
                        'status' => true,
                        'logicRulesObject' => array(
                            'logicRules' => array($logic[$key]),
                            'ids' => array($param['id']),
                        )
                    );
                  } else {
                    return $response = array('status' => false);
                  }
              } else {
                  $data = array(
                      'quiz_id'   => $quiz_id,
                      'logic' => serialize($logic[$key])
                  );
                  $result = $wpdb->insert($logic_table, $data, array('%d', '%s'));
                  if($result){
                    return $response = array(
                        'status' => true,
                        'logicRulesObject' => array(
                            'logicRules' => array($logic[$key]),
                            'ids' => array($wpdb->insert_id),
                        )
                    );
                  } else {
                    return $response = array('status' => false);
                  }
              }
          }
      }
  }
}

/**
*
* Deletes logic from mlw_logic table
* @since 2.0.0
*/
function qsm_addon_logic_ajax_delete(){
  global $wpdb;
  $table = $wpdb->prefix.'mlw_logic';
  $id = intval ($_POST['id']);
  $result = $wpdb->delete($table, array('id' => $id), '%d');
  echo json_encode(array('status' => $result));
  die();
}
/**
 *
 * Gets data from database to edit a record.
 *
 * @since 2.0.0
 * @return array
 */
function qsm_addon_logic_ajax_edit(){
  global $wpdb;
  $table = $wpdb->prefix.'mlw_logic';
  $id = intval ($_POST['id']);
  $query = "SELECT logic from $table where id = %d";

  $result = $wpdb->get_row($wpdb->prepare($query, $id));
  if($result){
      $response = array(
          'status'      => true,
          'logicRules'  => [unserialize($result->logic)],
          'ids'          => [$id],
      );
  } else {
    $response = array(
        'status'      => false,
    );
  }

  echo json_encode($response);
  die();
}

/**
 *
 * Deletes logic record from table in bulk
 *
 * @since 2.0.0
 */
function qsm_addon_logic_ajax_bulk_delete(){
    global $wpdb;
    $table = $wpdb->prefix.'mlw_logic';
    $ids = $_POST['ids'];
    $id_string = implode(', ', $ids);
    $query = "DELETE from $table where id in (%1s)";

    $result = $wpdb->query($wpdb->prepare($query, $id_string));
    if($result){
        $response = array(
            'status'      => true,
            'ids'          => $result,
        );
    } else {
      $response = array(
          'status'      => false,
      );
    }

    echo json_encode($response);
    die();
}

?>
