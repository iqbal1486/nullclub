<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers your tab in the quiz settings page
 *
 * @since 0.1.0
 * @return void
 */
function qsm_addon_logic_register_quiz_settings_tabs() {
	global $mlwQuizMasterNext;
	if ( ! is_null( $mlwQuizMasterNext ) && ! is_null( $mlwQuizMasterNext->pluginHelper ) && method_exists( $mlwQuizMasterNext->pluginHelper, 'register_quiz_settings_tabs' ) ) {
		$mlwQuizMasterNext->pluginHelper->register_quiz_settings_tabs( 'Logic', 'qsm_addon_logic_quiz_settings_tabs_content' );
	}
}

/**
 * Generates the content for your quiz settings tab
 *
 * @since 0.1.0
 * @return void
 */
function qsm_addon_logic_quiz_settings_tabs_content() {
	
	?>
<div class="logic-rule-message"></div>
<div class="upgrade-logic-rules" style="display:none">
	<h2><?php _e( 'Upgrade Message', 'qsm-logic' ); ?></h2>
	<?php _e( 'From version 2.0.0 we are upgrading to better database structure.', 'qsm-logic' ); ?><br />
	<?php _e( 'All your logic rules will be migrated to new tables', 'qsm-logic' ); ?><br />
	<?php _e( 'Hence we recommend to take a ', 'qsm-logic' ); ?>
	<strong><?php _e( 'database backup', 'qsm-logic' ); ?></strong><br /><br />
	<a class="save-rules button-primary"><?php _e( 'Upgrade', 'qsm-logic' ); ?></a>

</div>
<div class="no-logic-container" style="display:none"><span class="dashicons dashicons-lightbulb"></span><br />
	<h2>
		<?php _e( ' You don\'t have logic rules', 'qsm-logic' ); ?><br />
	</h2>
	<a class="add-rule button button-primary button-hero"><span
			class="dashicons dashicons-plus"></span><?php _e( 'Create New Rule', 'qsm-logic' ); ?></a>
</div>
<div class="logic-container" style="display:none">
	<a class="add-rule button-primary"><?php _e( 'Add Rule', 'qsm-logic' ); ?></a>
	<a class="delete-all-rules button"><?php _e( 'Delete Rules', 'qsm-logic' ); ?></a>
	<input type="text" class="search-logic" placeholder="<?php _e( 'Search Logic Rules', 'qsm-logic' ); ?>" />
	<table class="widefat logic-table">
		<thead>
			<tr>
				<th><input type="checkbox" name="check_all" id="check_all" value="all"></th>
				<th><strong><?php _e( 'When', 'qsm-logic' ); ?></strong></th>
				<th><strong><?php _e( 'Then', 'qsm-logic' ); ?></strong></th>
			</tr>
		</thead>
		<tbody class="logic-rules"></tbody>
	</table>
	<a class="add-rule button-primary"><?php _e( 'Add Rule', 'qsm-logic' ); ?></a>
	<a class="delete-all-rules button"><?php _e( 'Delete Rules', 'qsm-logic' ); ?></a>
</div>
<div class="qsm-popup qsm-popup-slide" id="modal-wizard-logic" aria-hidden="false" style="display:none;">
	<div class="qsm-popup__overlay" tabindex="-1" data-micromodal-close>
		<div class="qsm-popup__container" role="dialog" aria-modal="true" aria-labelledby="modal-wizard-logic-title">
			<header class="qsm-popup__header">
				<img src="<?php echo QSM_PLUGIN_URL . '/assets/icon-128x128.png'; ?>" />
				<h2 class="qsm-popup__title" id="modal-wizard-logic-title">
					<?php _e( 'Logic Rules', 'qsm-logic' ); ?>
				</h2>
				<a class="qsm-popup__close" aria-label="Close modal" data-micromodal-close></a>
			</header>
			<main class="qsm-popup__content" id="modal-wizard-logic-content">
			</main>
			<footer class="qsm-popup__footer">
				<button class="qsm-popup__btn" data-micromodal-close=""
					aria-label="Close this dialog window"><?php _e( 'Cancel', 'qsm-logic' ); ?></button>
				<button id="save-logic-button"
					class="save-new-rule qsm-popup__btn qsm-popup__btn-primary"><?php _e( 'Save', 'qsm-logic' ); ?></button>
			</footer>
		</div>
	</div>
</div>
<?php
}
?>