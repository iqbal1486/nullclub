<?php

namespace Barn2\WQM_Lib\WooCommerce\Admin;

use Barn2\WQM_Lib\Admin\Settings_Util;
use Barn2\WQM_Lib\Plugin\Plugin;
use Barn2\WQM_Lib\Registerable;
use Barn2\WQM_Lib\Util;

/**
 * Provides functions to add the plugin promo to the plugin settings section of the WooCommerce setting page.
 *
 * @package   Barn2\barn2-lib
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 * @version   1.1.0
 */
class Plugin_Promo implements Registerable {

	/**
	 * @var Plugin The plugin object.
	 */
	private $plugin;

	/**
	 * @var string The WooCommerce settings tab to display the promo, e.g. products
	 */
	private $tab;

	/**
	 * @var string The WooCommerce settings section to display the promo, e.g. inventory
	 */
	private $section;

	/**
	 * @var string The content of the plugin promo.
	 */
	private $plugin_promo = null;

	/**
	 * Constructor.
	 *
	 * @param Plugin $plugin           The plugin object
	 * @param string $settings_tab     The WooCommerce settings tab to display the promo, e.g. products
	 * @param string $settings_section The WooCommerce settings section to display the promo, e.g. inventory
	 */
	public function __construct( Plugin $plugin, $settings_tab, $settings_section = '' ) {
		$this->plugin  = $plugin;
		$this->tab     = $settings_tab;
		$this->section = $settings_section;
	}

	public function register() {
		if ( ! Settings_Util::is_current_wc_settings_page( $this->section, $this->tab ) ) {
			return;
		}

		foreach ( [ 'barn2_promo_start', 'barn2_promo_end' ] as $promo_field ) {
			if ( ! has_action( "woocommerce_admin_field_{$promo_field}" ) ) {
				add_action( "woocommerce_admin_field_{$promo_field}", [ $this, "{$promo_field}_field" ] );
			}
		}

		add_filter( 'woocommerce_get_settings_' . $this->tab, [ $this, 'add_plugin_promo_field' ], 11, 2 );
		add_action( 'admin_enqueue_scripts', [ $this, 'load_styles' ] );
	}

	public function add_plugin_promo_field( $settings, $current_section ) {
		// Bail if we're not in the correct settings section.
		if ( $this->section && $current_section !== $this->section ) {
			return $settings;
		}

		$promo_fields = array_filter(
			$settings,
			function ( $field ) {
				return isset( $field['type'] ) && 'barn2_promo_start' === $field['type'];
			}
		);

		// Bail if a 'barn2_promo_start' field is already present.
		if ( ! empty( $promo_fields ) ) {
			return $settings;
		}

		// Bail if there's no promo content.
		if ( empty( $this->get_plugin_promo() ) ) {
			return $settings;
		}

		// Wrap the settings in a promo start and promo end field.
		array_unshift(
			$settings,
			[
				'id'   => 'barn2_promo_start',
				'type' => 'barn2_promo_start'
			]
		);

		$settings[] = [
			'id'   => 'barn2_promo_end',
			'type' => 'barn2_promo_end'
		];

		return $settings;
	}

	public function barn2_promo_start_field( $field ) {
		$settings_id = $this->section ?: $this->tab;
		?>
		<div class="barn2-promo-wrap">
		<div class="barn2-promo-inner barn2-settings barn2-settings-<?php echo esc_attr( $settings_id ); ?>">
		<?php
	}

	public function barn2_promo_end_field( $field ) {
		$plugin_promo = $this->get_plugin_promo();

		if ( ! empty( $plugin_promo ) ) {
			$GLOBALS['hide_save_button'] = true;

			?>
			<p class="submit barn2-settings-submit">
				<button name="save" class="button-primary woocommerce-save-button" type="submit"
						value="<?php esc_attr_e( 'Save changes', 'woocommerce' ); ?>"><?php esc_html_e( 'Save changes', 'woocommerce' ); ?></button>
			</p>
			</div><!-- barn2-promo-inner -->
			<div id="barn2_plugins_promo" class="barn2-plugins-promo">
				<?php echo wp_kses_post( $plugin_promo ); ?>
			</div>
			</div><!-- barn2-promo-wrap -->
			<?php
		} else {
			?>
			</div><!-- barn2-promo-inner -->
			</div><!-- barn2-promo-wrap -->
			<?php
		}
	}

	public function load_styles() {
		wp_enqueue_style( 'barn2-wc-promo', plugins_url( 'lib/assets/css/admin/plugin-promo.css', $this->plugin->get_file() ), [], $this->plugin->get_version() );
	}

	public function get_plugin_promo() {
		if ( null === $this->plugin_promo ) {
			$this->plugin_promo = $this->get_promo_content();
		}

		return $this->plugin_promo;
	}

	private function get_promo_content() {
		$promo_content = get_transient( 'barn2_plugin_promo_' . $this->plugin->get_id() );

		if ( false === $promo_content ) {
			$promo_response = wp_remote_get( Util::barn2_url( '/wp-json/barn2/v2/pluginpromo/' . $this->plugin->get_id() . '?_=' . gmdate( 'mdY' ) ) );

			if ( wp_remote_retrieve_response_code( $promo_response ) !== 200 ) {
				return '';
			}

			$promo_content = json_decode( wp_remote_retrieve_body( $promo_response ), true );

			set_transient( 'barn2_plugin_promo_' . $this->plugin->get_id(), $promo_content, 3 * DAY_IN_SECONDS );
		}

		if ( empty( $promo_content ) || is_array( $promo_content ) ) {
			return '';
		}

		return $promo_content;
	}

}
