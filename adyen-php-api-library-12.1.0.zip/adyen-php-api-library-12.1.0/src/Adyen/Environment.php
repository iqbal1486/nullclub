<?php

namespace Adyen;

class Environment
{
    const TEST = "test";
    const LIVE = "live";
}
