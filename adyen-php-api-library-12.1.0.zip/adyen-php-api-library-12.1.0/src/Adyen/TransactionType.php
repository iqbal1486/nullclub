<?php

namespace Adyen;

class TransactionType
{
    const NORMAL = 'Normal';
    const REFUND = 'Refund';
}
