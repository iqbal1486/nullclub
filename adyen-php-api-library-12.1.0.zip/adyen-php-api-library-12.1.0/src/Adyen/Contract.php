<?php

namespace Adyen;

class Contract
{
    const NONE = "";
    const ONECLICK = "ONECLICK";
    const RECURRING = "RECURRING";
    const ONECLICK_RECURRING = "ONECLICK,RECURRING";
}
