<?php

namespace Adyen;

use Exception;

class ConnectionException extends Exception
{
}
