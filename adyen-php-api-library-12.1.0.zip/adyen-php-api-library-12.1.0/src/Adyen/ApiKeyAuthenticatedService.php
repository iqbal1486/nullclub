<?php

namespace Adyen;

class ApiKeyAuthenticatedService extends Service
{
    /**
     * @var bool
     */
    protected $requiresApiKey = true;
}
