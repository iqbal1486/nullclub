<?php

// Exit if accessed directly
defined('ABSPATH') || exit;

/**
 * WooCommerce Custom Order Admin
 *
 * @class RightPress_WC_Custom_Order_Admin
 * @package RightPress
 * @author RightPress
 */
abstract class RightPress_WC_Custom_Order_Admin
{

    /**
     * Constructor
     *
     * @access public
     * @return void
     */
    public function __construct()
    {

    }





}
