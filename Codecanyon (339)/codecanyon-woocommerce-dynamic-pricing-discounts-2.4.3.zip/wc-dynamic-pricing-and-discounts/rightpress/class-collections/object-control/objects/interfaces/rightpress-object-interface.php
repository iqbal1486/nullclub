<?php

// Exit if accessed directly
defined('ABSPATH') || exit;

/**
 * Object Interface
 *
 * @package RightPress
 * @author RightPress
 */
interface RightPress_Object_Interface
{





}
