<?php
/**
 * Plugin Name: Contact Form 7 Storage
 * Description: Store all Contact Form 7 submissions (including attachments) in your WordPress dashboard.
 * Plugin URI: https://preseto.com/plugins/contact-form-7-storage
 * Author: Preseto
 * Author URI: https://preseto.com
 * Version: 2.1.1
 * Tested up to: 5.7
 * License: GPL2
 * Text Domain: cf7-storage
 */

$cf7_storage_src_dir = dirname( __FILE__ );

// Until we have autoloading.
include_once $cf7_storage_src_dir . '/src/class-cf7-storage-options-store.php';
include_once $cf7_storage_src_dir . '/src/class-cf7-storage-meta-store.php';

include_once $cf7_storage_src_dir . '/src/class-cf7-storage-plugin-settings-page.php';
include_once $cf7_storage_src_dir . '/src/class-cf7-storage-plugin-settings.php';

include_once $cf7_storage_src_dir . '/src/class-cf7-storage-form-settings-page.php';
include_once $cf7_storage_src_dir . '/src/class-cf7-storage-form-settings.php';

include_once $cf7_storage_src_dir . '/src/class-cf7-storage-plugin.php';
include_once $cf7_storage_src_dir . '/src/class-cf7-storage.php';

$cf7_storage_plugin = new Cf7_Storage_Plugin( __FILE__ );
$cf7_storage = new Cf7_Storage( $cf7_storage_plugin );

// And we have a liftoff.
add_action( 'plugins_loaded', array( $cf7_storage, 'init' ) );
