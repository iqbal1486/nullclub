/* global jQuery */
jQuery( document ).ready( function( $ ) {
	'use strict';

	var $storageTabLink = $( '#cf7-storage-tab a' );

	if ( '#cf7-storage' === location.hash && $storageTabLink.length ) {
		$storageTabLink.trigger( 'click' );
	}
} );
