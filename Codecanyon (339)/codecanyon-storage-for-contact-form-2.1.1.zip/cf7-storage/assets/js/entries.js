/* global jQuery */
jQuery( document ).ready( function( $ ) {
	'use strict';

	$( '.quick-preview a' ).on( 'click', function( e ) {
		e.preventDefault();

		$( this ).toggleClass( 'expanded' );
		$( $( this ).attr( 'href' ) ).toggleClass( 'expanded' );
	} );
} );
