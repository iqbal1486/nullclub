<?php
/**
 * Plugin installer.
 *
 * @package bsf-core
 */

/**
 * Prevent direct access.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit();
}

require_once BSF_UPDATER_PATH . '/includes/views/list-bundled-products.php';
