<?php
$rangeid=0;
$prevcid=-2;
$prevwidth=-1;
$interval=false;
$range=array (
);
?>