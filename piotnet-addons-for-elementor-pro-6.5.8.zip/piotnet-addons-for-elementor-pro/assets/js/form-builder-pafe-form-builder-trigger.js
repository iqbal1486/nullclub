jQuery(document).ready(function( $ ) {

	$(document).on('click','#pafe-form-builder-trigger-success-YOUR-FORM-ID',function(e){
		// do something after success
	});

	$(document).on('click','#pafe-form-builder-trigger-failed-YOUR-FORM-ID',function(e){
		// do something after failed
	});

}); 