jQuery(document).ready(function($) {

//console.log($('[data-pafe-stripe]').data('pafe-stripe'));
 
});
