<?php

if ( isset( $variation_Found ) ) {

	$_variation_product = $variation;
	if ( $variation_Found ) {
		$title             = $_variation_product->get_title();
		$sku               = $_variation_product->get_sku();
		$short_description = $_variation_product->get_short_description();
		$Child_Product_ID  = $variation->get_id();

	}

} else {
	if ( 'variation' == $_product->get_type() ) {
		$attributes = implode( ',', array_values( $_product->get_variation_attributes() ) );
		$title      = $_product->get_title() . ' - ' . $attributes;
	}
	$variation_Found = true;
}

if ( ! isset( $Child_Product_ID ) ) {
	$Child_Product_ID = 0;
}


if ( apply_filters( 'yith_qof_show_product_line', true, $Child_Product_ID ) ) {
	?>
	<div class="YITH_WC_qof_product_line">

		<div id="YITH_WC_qof_product_line_AJAX_Selecting_Variation_ID_<?php echo $Parent_Product_ID; ?>_<?php echo $Yith_Post_ID; ?>" class="YITH_WC_qof_product_line_AJAX_Selecting_Variation"></div>

		<div class="YITH_WC_QOF_Horizontal_Line"></div>

		<?php

		if ( get_post_meta( $Yith_Post_ID, 'yith_wc_quick_order_form_thumbnail_checkbox', true ) ) {
			?>

			<div class="YITH_WC_qof_product_line_image">

				<a href="<?php echo get_post_permalink( $Child_Product_ID ); ?>" class="YITH_WC_qof_product_line_a">

					<?php

					$Child_Image = get_the_post_thumbnail( $Child_Product_ID, apply_filters( 'yith_quick_order_form_image_size', 'thumbnail' ), array( 'class' => 'YITH_WC_qof_product_thumbnail' ) );
					if ( $Child_Image == "" ) {
						$Parent_Image = get_the_post_thumbnail( wp_get_post_parent_id( $Child_Product_ID ), apply_filters( 'yith_quick_order_form_image_size', 'thumbnail' ), array( 'class' => 'YITH_WC_qof_product_thumbnail' ) );
						if ( $Parent_Image == "" ) {
							$no_image = YITH_YWQOF_ASSETS_URL . '/images/no-image.jpg';
							echo "<img width='150' height='150' src='$no_image' class='YITH_WC_qof_product_thumbnail wp-post-image' alt='YITH NO IMAGE'/>";
						} else {
							echo $Parent_Image;
						}
					} else {
						echo $Child_Image;
					} ?>


				</a>

			</div>

			<?php
		}

		?>

		<div class="YITH_WC_qof_product_line_name_and_SKU">

			<div class="YITH_WC_qof_product_line_name">
				<a href="<?php echo get_post_permalink( $Child_Product_ID ); ?>" class="YITH_WC_qof_product_line_a">

					<?php

					if ( $variation_Found ) {
						echo $title;
					} else {
						_e( 'No product matching the selection found', 'yith-quick-order-forms-for-woocommerce' );
					}

					?>

				</a>
			</div>

			<?php


			if ( get_post_meta( $Yith_Post_ID, 'yith_wc_quick_order_form_SKU_checkbox', true ) ) {
				?>

				<div class="YITH_WC_qof_product_line_name_SKU">
					<a href="<?php echo get_post_permalink( $Child_Product_ID ); ?>" class="YITH_WC_qof_product_line_a">
						<?php echo $sku; ?>
					</a>
				</div>

				<?php
			}

			?>

		</div>

		<?php

		if ( get_post_meta( $Yith_Post_ID, 'yith_wc_quick_order_form_price_checkbox', true ) ) {
			?>

			<div class="YITH_WC_qof_product_line_Price">

				<?php

				if ( $variation_Found ) {
					if ( $_product->is_type( 'variable' ) ) {

						$variations = $_product->get_available_variations();

						$_product_for_price = ( $variation_Found ? $_variation_product : $_product );

						echo( get_post_meta( $Yith_Post_ID, 'yith_wc_quick_order_form_discount_checkbox', true ) ? apply_filters( 'yith_wc_quick_order_get_price', $_product_for_price->get_price_html(), $_product_for_price ) : apply_filters( 'yith_wc_quick_order_get_price', wc_price( $_product_for_price->get_price() ), $_product_for_price ) );

					} else {
						echo( get_post_meta( $Yith_Post_ID, 'yith_wc_quick_order_form_discount_checkbox', true ) ? apply_filters( 'yith_wc_quick_order_get_price', $_product->get_price_html(), $_product ) : apply_filters( 'yith_wc_quick_order_get_price', wc_price( $_product->get_price() ), $_product ) );
					}
				}

				?>

			</div>

			<?php

		}
		?>

		<div class="YITH_WC_qof_product_line_description">

			<?php
			if ( get_post_meta( $Yith_Post_ID, 'yith_wc_quick_order_form_short_description_checkbox', true ) ) {

				$product = wc_get_product( $Child_Product_ID );

				if ( 'variation' == $product->get_type() ) {
					$description = $product->get_description();
				} else {
					$description = $product->get_short_description();
				}

				echo $description;

			}
			?>

		</div>


		<div id="yith_wc_qof_button_and_price_<?php echo $Parent_Product_ID; ?>_<?php echo $Yith_Post_ID; ?>" class="yith_wc_qof_button_and_price">

			<form>

				<?php

				$Stock_Quantity = ( $_product->is_type( 'variable' ) ? $_variation_product->get_stock_quantity() : $_product->get_stock_quantity() );

				$_current_product = ( $_product->is_type( 'variable' ) ? $_variation_product : $_product );

				global $woocommerce;

				if ( ! $_current_product->is_in_stock() ) {
					if ( version_compare( $woocommerce->version, '3.0', '<' ) ) {
						echo "<p class='stock out-of-stock'>Out of stock</p>";
					} else {
						echo wc_get_stock_html( $_current_product );
					}


					$quote_checkbox = get_post_meta( $Yith_Post_ID, 'yith_wc_quick_order_form_quote_button_checkbox' );

					if ( isset( $quote_checkbox ) && isset( $quote_checkbox['0'] ) && $quote_checkbox['0'] == '1' && defined( 'YITH_YWRAQ_PREMIUM' ) && function_exists( 'YITH_YWRAQ_Frontend' ) ) {
						YITH_YWRAQ_Frontend()->print_button( $_current_product->get_id() );
					}


					if ( defined( 'YITH_WCWL' ) ) {
						?>

						<div class="yith_ywqo_wishlist_section_no_stock">

							<?php

							echo do_shortcode( '[yith_wcwl_add_to_wishlist product_id= ' . $_current_product->get_id() . ' ]' );
							?>

						</div>

						<?php

					}
				} else {

					$Quantity_in_Cart = 0;
					foreach ( WC()->cart->cart_contents as $Product_in_Cart ) {

						if ( $Product_in_Cart['product_id'] == $Child_Product_ID || $Product_in_Cart['variation_id'] == $Child_Product_ID ) {
							$Quantity_in_Cart = $Product_in_Cart['quantity'];
							break;
						}
					}

					$value            = get_post_meta( $Yith_Post_ID, 'yith_wc_quick_order_form_default_quantity_text', true );
					$default_quantity = ( is_numeric( $value ) ? $value : '1' );
					$default_quantity = apply_filters( 'yith_wc_qof_default_quantity_' . $Child_Product_ID . "_" . $Yith_Post_ID, $default_quantity );

					$Quantity_to_Add = ( ( $Stock_Quantity != 0 ) ? ( ( $Stock_Quantity - $Quantity_in_Cart == 0 ) ? 0 : $default_quantity ) : $default_quantity );

					$show_quantity = get_post_meta( $Yith_Post_ID, 'yith_wc_quick_order_form_quantity_checkbox', true );

					echo( $show_quantity ? "<input type='button' value='-' class='yith_wc_button_plus_minus yith_wc_button_minus'>" : false );
					?>
					<input <?php echo( ! $show_quantity ? "type='hidden'" : false ); ?> id="yith_wc_qof_input_number_product_<?php echo $Child_Product_ID; ?>_<?php echo $Yith_Post_ID; ?>" class="YITH_WC_QOF_Quantity_Cart" value="<?php echo apply_filters( 'woocommerce_quantity_input_min', $Quantity_to_Add, wc_get_product( $Child_Product_ID ) ); ?>" data-product_id="<?php echo $Child_Product_ID; ?>" data-yith_post_id="<?php echo $Yith_Post_ID; ?>" data-stock_quantity="<?php echo $Stock_Quantity; ?>" data-backorder_allowed="<?php echo $_current_product->backorders_allowed(); ?>"
																						type="number" placeholder="1" min="<?php echo apply_filters( 'woocommerce_quantity_input_min', 1, wc_get_product( $Child_Product_ID ) ) ?>" max="<?php echo apply_filters( 'woocommerce_quantity_input_max', '', wc_get_product( $Child_Product_ID ) ) ?>" step="<?php echo apply_filters( 'woocommerce_quantity_input_step', 1, wc_get_product( $Child_Product_ID ) ) ?>" />
					<?php

					echo( $show_quantity ? "<input type='button' value='+' class='yith_wc_button_plus_minus yith_wc_button_plus'>" : false );

					$value                  = get_post_meta( $Yith_Post_ID, 'yith_wc_quick_order_form_individual_add_to_cart_checkbox', true );
					$individual_add_to_cart = ( $value == 'no' ? 'display: none' : '' );

					?>

					<button type="submit" data-yith_post_id="<?php echo $Yith_Post_ID; ?>"
							data-quantity="1" data-product_id="<?php echo $Child_Product_ID; ?>"
							data-default_quantity="<?php echo apply_filters( 'woocommerce_quantity_input_min', $default_quantity, wc_get_product( $Child_Product_ID ) ); ?>"
							data-added-to-cart="<?php echo esc_html__( 'Added to cart!', 'yith-quick-order-forms-for-woocommerce' ); ?>"
							class="button alt YITH_WC_qof_Button_Add_to_cart_trigger" style="<?php echo $individual_add_to_cart; ?>">
						<?php echo apply_filters( 'yith_wc_qof_form_add_to_cart_button_text', esc_html__( 'Add to cart', 'yith-quick-order-forms-for-woocommerce' ) ); ?>
						<span id="yith_wc_qof_dashicon_product_<?php echo $Child_Product_ID; ?>_<?php echo $Yith_Post_ID; ?>"
							  class="dashicons dashicons-yes yith_wc_qof_dashicon_product" <?php echo( $Quantity_in_Cart == 0 ? '' : 'style="display: inline-block"' ); ?> ></span>
					</button>
					<button id="yith_wc_qof_button_product_<?php echo $Child_Product_ID; ?>_<?php echo $Yith_Post_ID; ?>"
							type="submit" data-yithtest="1" data-quantity_in_cart="<?php echo $Quantity_in_Cart; ?>"
							data-quantity="<?php echo apply_filters( 'woocommerce_quantity_input_min', $default_quantity, wc_get_product( $Child_Product_ID ) ); ?>" data-product_id="<?php echo $Child_Product_ID; ?>"
							class="button alt ajax_add_to_cart add_to_cart_button YITH_WC_qof_Button_Add_to_cart" style="display: none">
						<?php echo esc_html__( 'Add to cart', 'yith-quick-order-forms-for-woocommerce' ); ?>
					</button>

					<?php

					$quote_checkbox = get_post_meta( $Yith_Post_ID, 'yith_wc_quick_order_form_quote_button_checkbox' );

					if ( isset( $quote_checkbox ) && isset( $quote_checkbox['0'] ) && $quote_checkbox['0'] == '1' && defined( 'YITH_YWRAQ_PREMIUM' ) && function_exists( 'YITH_YWRAQ_Frontend' ) ) {
						YITH_YWRAQ_Frontend()->print_button( $_current_product->get_id() );
					}
					?>

					<?php

					if ( get_post_meta( $Yith_Post_ID, 'yith_wc_quick_order_form_stock_checkbox', true ) ) {
						if ( version_compare( $woocommerce->version, '3.0', '<' ) ) {
							if ( $Stock_Quantity != null ) {
								echo "<p class='stock in-stock'>$Stock_Quantity in stock</p>";
							}
						} else {
							echo wc_get_stock_html( ( $_product->is_type( 'variable' ) ? $_variation_product : $_product ) );
						}
					}

					if ( get_post_meta( $Yith_Post_ID, 'yith_wc_quick_order_form_atum_stock_checkbox', true ) && defined( 'ATUM_VERSION' ) ) {
						echo '<div>' . do_shortcode( '[atum_mi_product_info product_id="' . $_product->get_id() . '" no_info_message="No stock info"]' ) . '</div>';
					}


					if ( defined( 'YITH_WCWL' ) ) {
						?>

						<div class="yith_ywqo_wishlist_section_in_stock">

							<?php

							echo do_shortcode( '[yith_wcwl_add_to_wishlist product_id= ' . $_current_product->get_id() . ' ]' );
							?>

						</div>

						<?php

					}


				}

				?>

			</form>

			<?php

			if ( $_product->is_type( 'variable' ) ) {

				$variations = $_product->get_available_variations();

				$var = array();

				$array_variation_attributes = array();

				$product_attributes = $_product->get_attributes();

				$attribute_taxonomies = wc_get_attribute_taxonomies();

				foreach ( $_product->get_available_variations() as $attribute_name => $attribute_array ) {


					foreach ( $attribute_array["attributes"] as $attribute_name => $attribute ) {
						$array_variation_attributes[ $attribute_name ][ $attribute_array["variation_id"] ] = $attribute;
					}

				}

				$array_already_variation_attributes = array();

				foreach ( $array_variation_attributes as $attribute_name => $attribute_array ) {

					if ( ! isset( $product_attributes[ $attribute_name ] ) ) {
						$attribute_name = str_replace( 'attribute_', '', $attribute_name );
					}

					if ( ! isset( $product_attributes[ $attribute_name ] ) ) {
						$attribute_name = str_replace( 'pa_', '', $attribute_name );
					}

					$default_attribute_name = isset( $product_attributes[ $attribute_name ] ) ? $product_attributes[ $attribute_name ]->get_name() : '';

					if ( strpos( $default_attribute_name, 'pa_' ) !== false ) {

						$print_attribute_name = wc_attribute_label( $attribute_name );

					}

					echo "<div class='Yith_WC_QOF_Variable_Product_" . $Parent_Product_ID . "_" . $Yith_Post_ID . "'>";

					echo "<span>" . esc_attr( $print_attribute_name ) . "</span>";

					$Yith_WC_QOF_Variable_Product_select_name = "Yith_WC_QOF_Variable_Product_select_name_" . $Parent_Product_ID . "_" . $Yith_Post_ID;
					echo "<select data-product_id='$Parent_Product_ID' data-yith_post_id='$Yith_Post_ID' class='Yith_WC_QOF_Variable_Product_select' name='$Yith_WC_QOF_Variable_Product_select_name'  >";

					foreach ( $attribute_array as $variation_id => $attribute ) {


						$taxonomy_attribute_name = str_replace( 'pa_', '', $default_attribute_name );

						$taxonomy = wc_attribute_taxonomy_name( $taxonomy_attribute_name );

						if ( taxonomy_exists( $taxonomy ) ) {
							$terms     = get_terms( $taxonomy, 'slug=' . $attribute );
							$attribute = $terms[0]->name;
						}

						if ( ! isset( $array_already_variation_attributes[ $attribute_name ] ) ) {
							$array_already_variation_attributes[ $attribute_name ] = array();
						}


						if ( ! in_array( $attribute, $array_already_variation_attributes[ $attribute_name ] ) ) {

							$array_already_variation_attributes[ $attribute_name ][] = $attribute;

							if ( isset( $data_selected[ $attribute_name ] ) ) {
								if ( $data_selected[ $attribute_name ] == wp_specialchars_decode( $attribute ) ) {

									echo "<option value='$attribute_name' selected='selected'>" . $attribute . "</option>";
								} else {
									echo "<option value='$attribute_name' >" . $attribute . "</option>";
								}
							} else {
								$meta = get_post_meta( $variation_id, 'attribute_' . $attribute_name, true );
								$term = get_term_by( 'slug', $meta, $attribute_name );

								echo "<option value='$attribute_name' >" . $term->name . "</option>";

							}
						}

					}
					echo "</select>";

					echo "</div>";

				}

			}

			if ( ( get_post_meta( $Yith_Post_ID, 'yith_wc_quick_order_form_variable_price_checkbox', true ) == null || ( get_post_meta( $Yith_Post_ID, 'yith_wc_quick_order_form_variable_price_checkbox', true ) == 1 ) ) && $_product->is_type( 'variable' ) ) {
				?>

				<div>

					<?php echo $_product->get_price_html(); ?>

				</div>

				<?php
			}

			?>

		</div>

	</div>
	<?php
}
