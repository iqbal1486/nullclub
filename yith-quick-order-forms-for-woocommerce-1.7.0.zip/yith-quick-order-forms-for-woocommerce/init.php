<?php
/**
 * Plugin Name: YITH Quick Order Forms for WooCommerce Premium
 * Plugin URI: https://yithemes.com/themes/plugins/yith-quick-order-forms-for-woocommerce/
 * Description: <code><strong>YITH Quick Order Forms</strong></code> allows you to create your personal "Form" to make a list of specific products, choose what to show (name, sku, price, discount) and allow specific users to have access through the permission filter. <a href="https://yithemes.com/" target="_blank">Get more plugins for your e-commerce shop on <strong>YITH</strong></a>.
 * Author: YITH
 * Text Domain: yith-quick-order-forms-for-woocommerce
 * Version: 1.7.0
 * Author URI: http://yithemes.com/
 * WC requires at least: 4.5
 * WC tested up to: 6.0
 **/

/*
 * This source file is subject to the GNU GENERAL PUBLIC LICENSE (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.txt
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
} // Exit if accessed directly

if ( ! function_exists( 'install_premium_woocommerce_admin_notice' ) ) {
	/**
	 * Print an admin notice if woocommerce is deactivated
	 *
	 * @author Daniel Sanchez Saez <dssaez@gmail.com>
	 * @since  1.0
	 * @return void
	 * @use    admin_notices hooks
	 */
	function install_premium_woocommerce_admin_notice() { ?>
		<div class="error">
			<p><?php _ex( 'YITH WooCommerce Quick Order Forms is enabled but not effective. It requires WooCommerce in order to work.', 'Alert Message: WooCommerce require', 'yith-quick-order-forms-for-woocommerce' ); ?></p>
		</div>
		<?php
	}
}

/*
==========
  DEFINE
==========
*/
! defined( 'YITH_YWQOF_VERSION' ) && define( 'YITH_YWQOF_VERSION', '1.7.0' );
! defined( 'YITH_YWQOF_SCRIPT_VERSION' ) && define( 'YITH_YWQOF_SCRIPT_VERSION', '1.7.0' );
! defined( 'YITH_YWQOF_INIT' ) && define( 'YITH_YWQOF_INIT', plugin_basename( __FILE__ ) );
! defined( 'YITH_YWQOF_SLUG' ) && define( 'YITH_YWQOF_SLUG', 'yith-quick-order-forms-for-woocommerce' );
! defined( 'YITH_YWQOF_SECRETKEY' ) && define( 'YITH_YWQOF_SECRETKEY', 'fhwUwemR422ha6xBsXzg' );
! defined( 'YITH_YWQOF_FILE' ) && define( 'YITH_YWQOF_FILE', __FILE__ );
! defined( 'YITH_YWQOF_PATH' ) && define( 'YITH_YWQOF_PATH', plugin_dir_path( __FILE__ ) );
! defined( 'YITH_YWQOF_URL' ) && define( 'YITH_YWQOF_URL', plugins_url( '/', __FILE__ ) );
! defined( 'YITH_YWQOF_ASSETS_URL' ) && define( 'YITH_YWQOF_ASSETS_URL', YITH_YWQOF_URL . 'assets/' );
! defined( 'YITH_YWQOF_TEMPLATE_PATH' ) && define( 'YITH_YWQOF_TEMPLATE_PATH', YITH_YWQOF_PATH . 'templates/' );
! defined( 'YITH_YWQOF_OPTIONS_PATH' ) && define( 'YITH_YWQOF_OPTIONS_PATH', YITH_YWQOF_PATH . 'panel' );


/*
================================
 Plugin Framework Version Check
================================
*/
! function_exists( 'yit_maybe_plugin_fw_loader' ) && require_once( YITH_YWQOF_PATH . 'plugin-fw/init.php' );
yit_maybe_plugin_fw_loader( YITH_YWQOF_PATH );

if ( ! function_exists( 'yith_ywqof_load_text_domain' ) ) {
	/**
	 * Load Plugin Textdomanin
	 */
	function yith_ywqof_load_text_domain()
	{
		load_plugin_textdomain('yith-quick-order-forms-for-woocommerce', false, dirname(plugin_basename(__FILE__)) . '/languages/');
	}

}
add_action( 'init', 'yith_ywqof_load_text_domain' );

/*
===============================
 * Instance main plugin class
===============================
*/
if ( ! function_exists( 'YITH_YWQOF_MAIN' ) ) {

	function YITH_WC_QUICK_ORDER_FORMS_MAIN() {
		// Load required classes and functions
		require_once( YITH_YWQOF_PATH . 'includes/class.yith-wc-quick-order-forms.php' );

		return YITH_WC_Quick_Order_Forms_Main_Class::instance();
	}
}

/*
===================================
 * Instance main custom post type
===================================
*/
if ( ! function_exists( 'YITH_YWQOF_Custom_Post_Type' ) ) {
	/**
	 * Unique access to instance of YITH_WC_QUICK_ORDER_FORMS Custom_Post_Type
	 *
	 * @return YITH_WC_Quick_Order_Forms_Custom_Post_Type
	 * @since 1.0.0
	 */
	function YITH_WC_QUICK_ORDER_FORMS_Custom_Post_Type() {

        // Load required cpt class
        require_once( YITH_YWQOF_PATH . 'includes/class.yith-wc-quick-order-forms-custom-post-type.php' );

        return YITH_WC_Quick_Order_Forms_Custom_Post_Type::get_instance();

	}
}

if ( ! function_exists( 'yith_wc_quick_order_forms_install' ) ) {
	function yith_wc_quick_order_forms_install() {

		if ( ! function_exists( 'WC' ) ) {
			add_action( 'admin_notices', 'install_premium_woocommerce_admin_notice' );
		} else {
			/**
			 * Instance main plugin class
			 */
			YITH_WC_QUICK_ORDER_FORMS_MAIN();

			/**
			 * Instance the custom post type of product list
			 */
			YITH_WC_QUICK_ORDER_FORMS_Custom_Post_Type();

		}
	}
}

add_action( 'plugins_loaded', 'yith_wc_quick_order_forms_install', 11 );
