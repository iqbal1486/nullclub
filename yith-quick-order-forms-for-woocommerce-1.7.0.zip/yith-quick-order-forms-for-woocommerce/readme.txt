== YITH WooCommerce Quick Order Forms ==

Contributors: yithemes
Tags: quick order forms, woocommerce, products, themes, yit, e-commerce, shop
Requires at least: 5.4
Tested up to: 5.8
Stable tag: 1.2.18
Licence: GPLv2 or later
Licence URI: http://www.gnu.org/licences/gpl-2.0.html
Documentation: https://docs.yithemes.com/yith-quick-order-forms-for-woocommerce/

== Changelog ==
1.7.0 - RELEASED ON 03 JANUARY 2022
New: support for WooCommerce 6.1
New: support for WordPress 5.9
Update: YITH plugin framework


1.6.0 - RELEASED ON 02 DECEMBER 2021
New: support for WooCommerce 6.0
Update: YITH plugin framework


1.4.0 - RELEASED ON 07 OCTOBER 2021
New: support for WooCommerce 5.8
Update: YITH plugin framework


1.3.1 - RELEASED ON 27 SEPTEMBER 2021
Update: YITH Plugin Framework
Fix: debug info feature removed for all logged in users


1.3.0 - RELEASED ON 08 SEPTEMBER 2021
New: support for WooCommerce 5.7
Update: YITH plugin framework


1.2.19 - RELEASED ON 12 AUGUST 2021
New: support for WooCommerce 5.6
Update: YITH plugin framework


1.2.18 - RELEASED ON 14 JULY 2021
New: support for WooCommerce 5.5
New: support for WordPress 5.8
Update: YITH plugin framework

= 1.2.18 - Released on 14 July 2021 =

* New: support for WooCommerce 5.5
* New: support for WordPress 5.8
* Update: YITH plugin framework

= 1.2.17 - Released on 08 June 2021 =

* New: support for WooCommerce 5.4
* Update: YITH plugin framework
* Fix: fixed order by sku from plugin settings
* Dev: added new filter 'yith_wc_qof_show_products'

= 1.2.16 - Released on 11 May 2021 =

* New: support for WooCommerce 5.3
* Update: YITH plugin framework
* Dev: add a condition to not include the variations in the form as simple products

= 1.2.15 - Released on 12 April 2021 =

* New: support for WooCommerce 5.2
* Update: YITH plugin framework

= 1.2.14 - Released on 05 March 2021 =

* New: support for WordPress 5.7
* New: support for WooCommerce 5.1
* Update: YITH plugin framework
* Dev: added the Request a Quote button in the out of stock products and removed a shortcode included by mistake

= 1.2.13 - Released on 10 February 2021 =

* New: Support for WooCommerce 5.0
* Update: YITH plugin framework
* Dev: added the filter yith_wc_quick_order_get_price in the correct places

= 1.2.12 - Released on 02 January 2021 =

* New: Support for WooCommerce 4.9
* Update: plugin framework
* Fix: CSS for quantity field

= 1.2.11 - Released on 15 December 2020 =

* New: integration with YITH WooCommerce Minimum Maximum Quantity
* Update: language files

= 1.2.10 - Released on 30 November 2020 =

* New: Support for WooCommerce 4.8
* Update: plugin framework
* Dev: fixed an error in the widgets save

= 1.2.9 - Released on 29 October 2020 =

* New: Support for WooCommerce 4.7
* New: Support for WordPress 5.6
* Update: update plugin fw
* Dev: added new filter yith_qof_show_product_line

= 1.2.8 - Released on 02 October 2020 =

* New: Support for WooCommerce 4.6
* Update: plugin framework

= 1.2.7 - Released on 16 September 2020 =

* New: Support for WooCommerce 4.5
* Update: plugin framework
* Fix: fixed a problem with the translations
* Dev: strings escaped


= 1.2.6 - Released on 11 August 2020 =

* New: Support for WooCommerce 4.4
* New: Support for WordPress 5.5
* Update: plugin framework
* Dev: added new filter yith_wc_qof_form_add_to_cart_button_text

= 1.2.5 - Released on 07 July 2020 =

* New: Support for WooCommerce 4.3
* Update: plugin framework

= 1.2.4 - Released on 29 May 2020 =

* New: Support for WooCommerce 4.2
* Update: plugin framework
* Update: .pot file

= 1.2.3 - Released on 06 May 2020 =

* New: support WooCommerce 4.1
* Tweak: added a checkout button in the form
* Tweak: added the short description in a column and not under the product name
* Fix: fixed an issue with the quantity added to the cart
* Fix: fixed a the variation description non displayed in the form
* Dev: minor changes

= 1.2.2 - Released on 10 March 2020 =

* New: support WooCommerce 4.0
* New: support WordPress 5.4
* New: added the YITH Wishlist buttons in the form
* New: added the plugin shortcodes to the Elementor panel
* Update: updated plugin fw

= 1.2.1 - Released on 07 January 2020 =

* New: support WooCommerce 3.9
* Update: updated plugin fw
* Fix: Fix: fixed an issue with the term names using WPML

= 1.2.0 - Released on 06 November 2019 =

* New: support WooCommerce 3.8
* New: minor integration with the Atum Stock Manager plugin, now is possible to display the Atum stock info in the form
* Update: updated plugin fw
* Update: Italian language
* Update: Spanish language
* Fix: fixed the add to quote button in the variations
* Dev: completely deleted the sessions in the plugin
* Dev: added an is_object check to avoid a php warning

= 1.1.3 - Released on 05 August 2019 =

* New: support WooCommerce 3.7
* Tweak: show categories selected and remove categories from categories select
* Update: Italian language
* Update: updated plugin core
* Dev: get the term name an not the slug in the variation select

= 1.1.2 - Released on 30 May 2019 =

* New: added a new option in the form to display the product short description
* Update: Spanish language
* Update: updated plugin Framework
* Fix: fixed the role restriction
* Dev: added a new condition to fix a possible issue
* Dev: added a new condition to fix a possible issue.
* Dev: deleted sessions in the plugin

= 1.1.1 - Released on 19 February 2019 =

  * Update: updated plugin FW
  * Update: updated .pot
  * Update: Dutch language
  * Update: Italian language


= 1.1.0 - Released on 31 December 2018 =

  * New: Support WordPress 5.0.2
  * Update: updated plugin FW
  * Update: updated .pot
  * Fix: fixed query by sku


= 1.0.35 - Released on 05 December 2018 =
  * New: Integration with YITH WooCommerce Request a Quote Premium
  * Dev: added filter yith_wc_qof_frontend_responsive on $responsive_js variable
  * Tweak: avoid PHP Notices
  * Update: plugin framework
  * Update: language files

= 1.0.34 - Released on 22 October 2018 =

  * Update: plugin framework
  * Update: plugin description

= 1.0.33 - Released on 17 October 2018 =

  * New: Support to WooCommerce 3.5.0
  * Tweak: remove menu tittle for translation
  * Tweak: change parent page from yit_plugin_panel to yith_plugin_panel
  * Update: Dutch language
  * Update: plugin fw
  * Fix: prevent php notice
  * Dev: filter yith_wc_qof_frontend_responsive on ajax front page

= 1.0.32 - Released on 05 September 2018 =

  * Tweak: Filter by sku and category or tag
  * Tweak: action links
  * Tweak: improvement of templates for customizatio
  * Update: Italian language
  * Fix: show variation with html special characters
  * Fix: changing variation on the form
  * Dev: unlash the variation selected
  * Dev: cleaning logs

= 1.0.31 - Released on 14 June 2018 =

  * Tweak: Adding some css to adapt the quantity button for some themes
  * Tweak: Allowing 0 for default quantity
  * Update: documentation link of the plugin
  * Update: Spanish translation
  * Updated Dutch translation
  * Fix: change variation on the form

= 1.0.30 - Released on 3 April 2018 =

  * Tweak - Adding field to choose default quantity
  * Tweak - Adding filed to choose whether to show single add to cart or add all products to cart
  * Fix - Show forms for user roles
  * Dev - Path of the templates
  * Dev - Loading the admin and front without PHP sessions

= 1.0.29 - Released on 06 March 2018 =

  * Fix: Allow all users to see the form
  * Tweak: Setting the sorting on the form configuration

= 1.0.28 - Released on 08 February 2018 =

  * New - support to WooCommerce 3.3.0
  * Update - Spanish translation

= 1.0.27 - Released on 06 February 2018 =

  * Tweak - Adding code to translate some strings
  * Fix - Showing capital letters of attributes
  * Fix - Showing variation correctly through ajax

= 1.0.26 - Released on 19 January 2018 =

  * Tweak -  Adding option to show or not show price of variable products
  * Update - Italian translation
  * Update - Dutch translation
  * Fix - Show attributes
  * Remove - Cleaning some logs commented

= 1.0.25 - Released on 05 January 2017 =

 * Tweak - Way of displaying the attribute name
 * Update - Dutch translation
 * Update - Italian translation
 * Fix - Capitalization of the name under YITH Plugins
 * Remove - Select one option for variation

= 1.0.24 - Released on 29 December 2017 =

 * Update - Plugin-fw

= 1.0.23 - Released on 23 November 2017 =

 * Added - Apply filters to js and css files

= 1.0.22 - Released on 03 November 2017 =

 * Added - Option to show or not show quantity

= 1.0.21 - Released on 30 October 2017 =

 * Fix - Cleaning PHP Notices

= 1.0.20 - Released on 20 October 2017 =

 * Fix - Multiple forms in the same page

= 1.0.19 - Released on 19 October 2017 =

 * Add - Showing variation products of the same parent in order as in the variation product admin panel

= 1.0.18 - Released on 16 October 2017 =

 * Fix - Compatibility with WooCommerce 2.6.14 when wc_get_stock_html and show products chosen

= 1.0.17 - Released on 13 October 2017 =

 * Fix - Showing products of tags or categories selected

= 1.0.16 - Released on 5 October 2017 =

 * Update - Adding backorders functionality when adding products to the cart

= 1.0.15 - Released on 2 October 2017 =

 * Fix - Displaying variation products order by ID DESC
 * Update - Displaying categories with subcategories in the filter
 * Update - Adding two buttons "plus" and "minus" to change the amount

= 1.0.14 - Released on 29 September 2017 =

 * Fix - Searching for products in a disable group

= 1.0.13 - Released on 29 September 2017 =

 * Update - Changing order of the select variation products

= 1.0.12 - Released on 28 September 2017 =

 * Update - Add products to cart depending on the stock

= 1.0.11 - Released on 22 September 2017 =

 * Fix - Pagination
 * Fix - Setting options

= 1.0.10 - Released on 21 September 2017 =

 * Fix - License activation

= 1.0.9 - Released on 20 September 2017 =

 * Added - Auction products not showed in forms

= 1.0.8 - Released on 18 September 2017 =

 * Added - Option to show or not show stock

= 1.0.7 - Released on 08 September 2017 =

 * Update - Multiple forms in the same page

= 1.0.6 - Released on 06 September 2017 =

 * Update - Option to show or not show the search filter
 * Update - Option to show or not show the number of products

= 1.0.5 - Released on 01 September 2017 =

 * Added - language file
 * Fix  -  load text domain

= 1.0.4 - Released on 24 August 2017 =

 * Update - Ajax selector for variation products
 * Update - Showing only parent products and not the variations in the main form. Showing all the products (variables and variations) through the search filter
 * Fix - Select the attribute of the product to change the variation

= 1.0.3 - Released on 22 August 2017 =

 * Fix - Preventing from orphan children and variable products without children

= 1.0.2 - Released on 17 August 2017 =

 * Fix - search by SKU for variable products and show the image parent if they don't have it

= 1.0.1 - Released on 09 August 2017 =

 * New - Compatibility with plugin "Customize My Account Page"
 * Fix - Pagination, search filter, parent images for variable products on my "account page"

= 1.0.0 - Released on 10 July 2017 =

* First release

== Suggestions ==

If you have suggestions about how to improve YITH Quick Order Forms for WooCommerce Premium, you can [write us](mailto:plugins@yithemes.com "Your Inspiration Themes") so we can bundle them into the next release of the plugin.

== Translators ==

If you have created your own language pack, or have an update for an existing one, you can send [gettext PO and MO file](http://codex.wordpress.org/Translating_WordPress "Translating WordPress")
[use](http://yithemes.com/contact/ "Your Inspiration Themes") so we can bundle it into YITH Quick Order Forms for WooCommerce Premium.
 = Available Languages =
 * English
