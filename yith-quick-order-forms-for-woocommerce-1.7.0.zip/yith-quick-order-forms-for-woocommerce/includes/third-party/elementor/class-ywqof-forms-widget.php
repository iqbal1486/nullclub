<?php

use Elementor\Controls_Manager;
use Elementor\Widget_Button;
use ElementorPro\Modules\QueryControl\Module;

if ( ! defined ( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}


if ( ! class_exists ( 'YWQOF_Forms_Widget' ) ) {


    class YWQOF_Forms_Widget extends \Elementor\Widget_Base  {

        /**
         * Get widget name.
         */
        public function get_name() {
            return 'ywqof-forms-widget';
        }

        /**
         * Get widget title.
         */
        public function get_title() {
            return esc_html__( 'YITH Quick Order Forms', 'yith-quick-order-forms-for-woocommerce' );
        }

        /**
         * Get widget icon.
         */
        public function get_icon() {
            return 'fa fa-code';
        }

        /**
         * Get widget categories.
         */
        public function get_categories() {
            return [ 'yith' ];
        }

        /**
         * Register widget controls.
         */
        protected function _register_controls() {

            $this->start_controls_section(
                'content_section',
                [
                    'label' => esc_html__( 'Content', 'yith-quick-order-forms-for-woocommerce' ),
                    'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
                ]
            );
            
            $this->add_control(
                'section-description',
                [
                    'label' => esc_html__( 'Form description', 'yith-quick-order-forms-for-woocommerce' ),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'input_type' => 'text',
                    'placeholder' => esc_html__( 'Write a description here', 'yith-quick-order-forms-for-woocommerce' ),
                ]
            );

            $this->add_control(
                'section-form-id',
                [
                    'label' => esc_html__( 'Form ID', 'yith-quick-order-forms-for-woocommerce' ),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'input_type' => 'number',
                    'placeholder' => esc_html__( 'Write the form ID', 'yith-quick-order-forms-for-woocommerce' ),
                ]
            );

            $this->end_controls_section();

        }

        /**
         * Render widget output on the frontend.
         */
        protected function render() {

            $settings = $this->get_settings_for_display();

            $html = wp_oembed_get( $settings['section-description'] );

            $form_id= isset($settings['section-form-id']) ? $settings['section-form-id'] : '';

            echo '<div class="ywqof-forms-widget">';

            echo ( $html ) ? $html : $settings['section-description'];

            echo do_shortcode('[yith_wc_quick_order_form id=' . $form_id . ' ]');

            echo '</div>';

        }

    }











}
