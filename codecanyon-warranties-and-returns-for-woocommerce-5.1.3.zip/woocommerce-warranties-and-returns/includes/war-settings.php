<?php

	class XforWC_Warranties_Returns_Settings {

		public static $plugin;
		
		public static function init() {

			self::$plugin = array(
				'name' => 'Warranties and Returns for WooCommerce',
				'xforwc' => 'Warranties and Returns',
				'slug' => 'warranties-and-returns',
				'label' => 'warranties_and_returns',
				'image' => XforWC_Warranties_Returns::$url_path . 'assets/images/warranties-and-returns-for-woocommerce-elements.png',
				'path' => 'woocommerce-warranties-and-returns/woocommerce-warranties-and-returns',
				'version' => XforWC_Warranties_Returns::$version,
			);

			if ( isset($_GET['page'], $_GET['tab']) && ($_GET['page'] == 'wc-settings' ) && $_GET['tab'] == 'warranties_and_returns' ) {
				add_filter( 'svx_plugins_settings', __CLASS__ . '::get_settings', 50 );
			}

			if ( function_exists( 'XforWC' ) ) {
				add_filter( 'xforwc_settings', array( 'XforWC_Warranties_Returns_Settings', 'xforwc' ), 9999999161 );
				add_filter( 'xforwc_svx_get_warranties_and_returns', array( 'XforWC_Warranties_Returns_Settings', '_get_settings_xforwc' ) );
			}

			add_filter( 'svx_plugins', array( 'XforWC_Warranties_Returns_Settings', 'add_plugin' ), 0 );
		}

		public static function xforwc( $settings ) {
			$settings['plugins'][] = self::$plugin;

			return $settings;
		}

		public static function add_plugin( $plugins ) {
			$plugins[self::$plugin['label']] = array(
				'slug' => self::$plugin['label'],
				'name' => self::$plugin['xforwc']
			);

			return $plugins;
		}

		public static function _get_settings_xforwc() {
			$settings = self::get_settings( array() );
			return $settings[self::$plugin['label']];
		}

		public static function get_settings( $plugins ) {

			$presets = get_terms( 'wcwar_warranty_pre', array('hide_empty' => false) );

			$ready_presets = array(
				'' => esc_html__( 'None', 'woocommerce-warranties-and-returns' )
			);

			foreach ( $presets as $preset ) {
				$ready_presets[$preset->term_id] = $preset->name;
			}

			$pages = get_pages();

			$ready_pages = array(
				'' => esc_html__( 'None', 'woocommerce-warranties-and-returns' )
			);

			foreach ( $pages as $page ) {
				$ready_pages[$page->ID] = $page->post_title;
			}

			$plugins[self::$plugin['label']] = array(
				'slug' => self::$plugin['label'],
				'name' => esc_html( function_exists( 'XforWC' ) ? self::$plugin['xforwc'] : self::$plugin['name'] ),
				'desc' => esc_html( function_exists( 'XforWC' ) ? self::$plugin['name'] . ' v' . self::$plugin['version'] : esc_html__( 'Settings page for', 'woocommerce-warranties-and-returns' ) . ' ' . self::$plugin['name'] ),
				'link' => esc_url( 'https://xforwoocommerce.com/store/warranties-and-returns/' ),
				'ref' => array(
					'name' => esc_html__( 'Visit XforWooCommerce.com', 'woocommerce-warranties-and-returns' ),
					'url' => 'https://xforwoocommerce.com'
				),
				'doc' => array(
					'name' => esc_html__( 'Get help', 'woocommerce-warranties-and-returns' ),
					'url' => 'https://help.xforwoocommerce.com'
				),
				'sections' => array(
					'dashboard' => array(
						'name' => esc_html__( 'Dashboard', 'woocommerce-warranties-and-returns' ),
						'desc' => esc_html__( 'Dashboard Overview', 'woocommerce-warranties-and-returns' ),
					),
					'warranties' => array(
						'name' => esc_html__( 'Warranties', 'woocommerce-warranties-and-returns' ),
						'desc' => esc_html__( 'Warranties Options', 'woocommerce-warranties-and-returns' ),
					),
					'manager' => array(
						'name' => esc_html__( 'Warranty Manager', 'woocommerce-warranties-and-returns' ),
						'desc' => esc_html__( 'Warranty Manager Options', 'woocommerce-warranties-and-returns' ),
					),
					'returns' => array(
						'name' => esc_html__( 'Returns', 'woocommerce-warranties-and-returns' ),
						'desc' => esc_html__( 'Returns Options', 'woocommerce-warranties-and-returns' ),
					),
					'email' => array(
						'name' => esc_html__( 'E-Mail', 'woocommerce-warranties-and-returns' ),
						'desc' => esc_html__( 'E-Mail Options', 'woocommerce-warranties-and-returns' ),
					),
					'installation' => array(
						'name' => esc_html__( 'Installation', 'woocommerce-warranties-and-returns' ),
						'desc' => esc_html__( 'Installation Options', 'woocommerce-warranties-and-returns' ),
					),
				),
				'settings' => array(

					'wcmn_dashboard' => array(
						'type' => 'html',
						'id' => 'wcmn_dashboard',
						'desc' => '
						<img src="' . XforWC_Warranties_Returns::$url_path . 'assets/images/warranties-and-returns-for-woocommerce-shop.png" class="svx-dashboard-image" />
						<h3><span class="dashicons dashicons-store"></span> XforWooCommerce</h3>
						<p>' . esc_html__( 'Visit XforWooCommerce.com store, demos and knowledge base.', 'woocommerce-warranties-and-returns' ) . '</p>
						<p><a href="https://xforwoocommerce.com" class="xforwc-button-primary x-color" target="_blank">XforWooCommerce.com</a></p>

						<br /><hr />

						<h3><span class="dashicons dashicons-admin-tools"></span> ' . esc_html__( 'Help Center', 'woocommerce-warranties-and-returns' ) . '</h3>
						<p>' . esc_html__( 'Need support? Visit the Help Center.', 'woocommerce-warranties-and-returns' ) . '</p>
						<p><a href="https://help.xforwoocommerce.com" class="xforwc-button-primary red" target="_blank">XforWooCommerce.com HELP</a></p>
						
						<br /><hr />

						<h3><span class="dashicons dashicons-update"></span> ' . esc_html__( 'Automatic Updates', 'woocommerce-warranties-and-returns' ) . '</h3>
						<p>' . esc_html__( 'Get automatic updates, by downloading and installing the Envato Market plugin.', 'woocommerce-warranties-and-returns' ) . '</p>
						<p><a href="https://envato.com/market-plugin/" class="svx-button" target="_blank">Envato Market Plugin</a></p>
						
						<br />',
						'section' => 'dashboard',
					),

					'wcmn_utility' => array(
						'name' => esc_html__( 'Plugin Options', 'woocommerce-warranties-and-returns' ),
						'type' => 'utility',
						'id' => 'wcmn_utility',
						'desc' => esc_html__( 'Quick export/import, backup and restore, or just reset your optons here', 'woocommerce-warranties-and-returns' ),
						'section' => 'dashboard',
					),

					'war_settings_page' => array(
						'name'    => esc_html__( 'Request Page', 'woocommerce-warranties-and-returns' ),
						'type'    => 'select',
						'desc'    => esc_html__( 'Please select the page for requesting warranties. Check Documentation FAQ if the page was not created automatically.', 'woocommerce-warranties-and-returns' ),
						'id'      => 'war_settings_page',
						'options' => $ready_pages,
						'default' => '',
						'autoload' => true,
						'section' => 'installation'
					),

					'wcwar_single_action' => array(
						'name'    => esc_html__( 'Product Page Hook', 'woocommerce-warranties-and-returns' ),
						'type'    => 'text',
						'desc'    => esc_html__( 'Change default plugin initialization action on single product pages. Use actions done in your content-single-product.php file. Please enter action in the following format action_name:priority.', 'woocommerce-warranties-and-returns' ) . ' ( default: woocommerce_before_add_to_cart_form )',
						'id'      => 'wcwar_single_action',
						'default' => '',
						'autoload' => true,
						'section' => 'installation'
					),

					'wcwar_single_titles' => array(
						'name'    => esc_html__( 'Heading Size', 'woocommerce-warranties-and-returns' ),
						'type'    => 'select',
						'desc'    => esc_html__( 'Select heading size of warranty titles on single product pages.', 'woocommerce-warranties-and-returns' ),
						'id'      => 'wcwar_single_titles',
						'default' => 'h4',
						'options' => array(
							'h2' => 'H2',
							'h3' => 'H3',
							'h4' => 'H4',
							'h5' => 'H5',
							'h6' => 'H6'
						),
						'autoload' => false,
						'section' => 'installation'
					),

					'wcwar_single_mode' => array(
						'name'    => esc_html__( 'Request Page Display', 'woocommerce-warranties-and-returns' ),
						'type'    => 'select',
						'desc'    => esc_html__( 'Select display for the Warranty/Return customer post.', 'woocommerce-warranties-and-returns' ),
						'id'      => 'wcwar_single_mode',
						'default' => 'new',
						'options' => array(
							'old' => 'Old - WooThemes, Basic Themes',
							'new' => 'New - Most Supported in Premium Themes'
						),
						'autoload' => true,
						'section' => 'installation'
					),

					'wcwar_force_scripts' => array(
						'name' => esc_html__( 'Plugin Scripts', 'woocommerce-warranties-and-returns' ),
						'type' => 'checkbox',
						'desc' => esc_html__( 'Check this option to enable plugin scripts in all pages. This option fixes issues in Quick Views.', 'woocommerce-warranties-and-returns' ),
						'id'   => 'wcwar_force_scripts',
						'default' => 'no',
						'autoload' => true,
						'section' => 'installation'
					),

					'wcwar_form' => array(
						'name'    => esc_html__( 'Warranty Request Form', 'woocommerce-warranties-and-returns' ),
						'type'    => 'list-select',
						'desc'    => esc_html__( 'Use the manager to create a warranty form.', 'woocommerce-warranties-and-returns' ),
						'id'      => 'wcwar_form',
						'title'   => esc_html__( 'Field', 'woocommerce-warranties-and-returns' ),
						'options' => 'list',
						'selects' => array(
							'text' => esc_html__( 'Input', 'woocommerce-warranties-and-returns' ),
							'paragraph' => esc_html__( 'Textarea', 'woocommerce-warranties-and-returns' ),
							'checkboxes' => esc_html__( 'Checkboxes', 'woocommerce-warranties-and-returns' ),
							'radio' => esc_html__( 'Radio', 'woocommerce-warranties-and-returns' ),
							'dropdown' => esc_html__( 'Select', 'woocommerce-warranties-and-returns' ),
							'address' => esc_html__( 'Address', 'woocommerce-warranties-and-returns' ),
							'file' => esc_html__( 'File upload', 'woocommerce-warranties-and-returns' ),
						),
						'settings' => self::_build_form_fields(),
						'default' => '',
						'autoload' => false,
						'section' => 'warranties'
					),

					'wcwar_overrides' => array(
						'name' => esc_html__( 'Warranty Overrides', 'woocommerce-warranties-and-returns' ),
						'type' => 'hidden',
						'id'   => 'wcwar_overrides',
						'desc' => esc_html__( 'Set warranty overrides', 'woocommerce-warranties-and-returns' ),
						'autoload' => false,
						'section' => 'hidden',
					),

					'_wcwar_tags' => array(
						'name' => esc_html__( 'Warranty by Tag', 'woocommerce-warranties-and-returns' ),
						'type' => 'list',
						'id'   => '_wcwar_tags',
						'desc' => esc_html__( 'Add default warranty by product tag', 'woocommerce-warranties-and-returns' ),
						'autoload' => false,
						'section' => 'manager',
						'title' => esc_html__( 'Name', 'woocommerce-warranties-and-returns' ),
						'options' => 'list',
						'default' => array(),
						'settings' => array(
							'name' => array(
								'name' => esc_html__( 'Name', 'woocommerce-warranties-and-returns' ),
								'type' => 'text',
								'id' => 'name',
								'desc' => esc_html__( 'Enter name', 'woocommerce-warranties-and-returns' ),
								'default' => '',
							),
							'term' => array(
								'name' => esc_html__( 'Tag', 'woocommerce-warranties-and-returns' ),
								'type' => 'select',
								'id'   => 'term',
								'desc' => esc_html__( 'Select tag', 'woocommerce-warranties-and-returns' ),
								'options' => 'ajax:taxonomy:product_tag:has_none',
								'default' => '',
								'class' => 'svx-selectize',
							),
							'preset' => array(
								'name' => esc_html__( 'Preset', 'woocommerce-warranties-and-returns' ),
								'type' => 'select',
								'id'   => 'preset',
								'desc' => esc_html__( 'Select warranty preset', 'woocommerce-warranties-and-returns' ),
								'options' => 'ajax:taxonomy:wcwar_warranty_pre:has_none',
								'default' => '',
								'class' => 'svx-selectize',
							),
						),
					),

					'_wcwar_categories' => array(
						'name' => esc_html__( 'Warranty by Category', 'woocommerce-warranties-and-returns' ),
						'type' => 'list',
						'id'   => '_wcwar_categories',
						'desc' => esc_html__( 'Add default warranty by product category', 'woocommerce-warranties-and-returns' ),
						'autoload' => false,
						'section' => 'manager',
						'title' => esc_html__( 'Name', 'woocommerce-warranties-and-returns' ),
						'options' => 'list',
						'default' => array(),
						'settings' => array(
							'name' => array(
								'name' => esc_html__( 'Name', 'woocommerce-warranties-and-returns' ),
								'type' => 'text',
								'id' => 'name',
								'desc' => esc_html__( 'Enter name', 'woocommerce-warranties-and-returns' ),
								'default' => '',
							),
							'term' => array(
								'name' => esc_html__( 'Category', 'woocommerce-warranties-and-returns' ),
								'type' => 'select',
								'id'   => 'term',
								'desc' => esc_html__( 'Select category', 'woocommerce-warranties-and-returns' ),
								'autoload' => false,
								'section' => 'manager',
								'options' => 'ajax:taxonomy:product_cat:has_none',
								'default' => '',
								'class' => 'svx-selectize',
							),
							'preset' => array(
								'name' => esc_html__( 'Preset', 'woocommerce-warranties-and-returns' ),
								'type' => 'select',
								'id'   => 'preset',
								'desc' => esc_html__( 'Select warranty preset', 'woocommerce-warranties-and-returns' ),
								'autoload' => false,
								'section' => 'manager',
								'options' => 'ajax:taxonomy:wcwar_warranty_pre:has_none',
								'default' => '',
								'class' => 'svx-selectize',
							),
						),
					),

					'wcwar_default_warranty' => array(
						'name'    => esc_html__( 'Default Warranty', 'woocommerce-warranties-and-returns' ),
						'type'    => 'select',
						'desc'    => esc_html__( 'Products without warranties can have a default warranty. Please select warranty preset.', 'woocommerce-warranties-and-returns' ),
						'id'      => 'wcwar_default_warranty',
						'default' => '',
						'options' => $ready_presets,
						'autoload' => false,
						'section' => 'manager'
					),

					'wcwar_default_post' => array(
						'name'    => esc_html__( 'New Warranty Status', 'woocommerce-warranties-and-returns' ),
						'type'    => 'select',
						'desc'    => esc_html__( 'Select status for the newly submitted warranty request posts.', 'woocommerce-warranties-and-returns' ),
						'id'      => 'wcwar_default_post',
						'default' => 'pending',
						'options' => array(
							'draft' => esc_html__( 'Draft', 'woocommerce-warranties-and-returns' ),
							'publish' => esc_html__( 'Published', 'woocommerce-warranties-and-returns' ),
							'pending' => esc_html__( 'Pending', 'woocommerce-warranties-and-returns' )
						),
						'autoload' => false,
						'section' => 'warranties'
					),

					'wcwar_enable_multi_requests' => array(
						'name'    => esc_html__( 'Multi Requests', 'woocommerce-warranties-and-returns' ),
						'type'    => 'checkbox',
						'desc'    => esc_html__( 'Check this option to enable multi requests in the defined warranty period. New requests will available upon completing the previous requests.', 'woocommerce-warranties-and-returns' ),
						'id'      => 'wcwar_enable_multi_requests',
						'default' => 'no',
						'autoload' => false,
						'section' => 'warranties'
					),

					'wcwar_enable_guest_requests' => array(
						'name'    => esc_html__( 'Guest Requests', 'woocommerce-warranties-and-returns' ),
						'type'    => 'checkbox',
						'desc'    => esc_html__( 'Guests can access warranties using their Order ID and an E-Mail address to confirm their identity. Check this option if you want to allow guests to request warranties and returns.', 'woocommerce-warranties-and-returns' ),
						'id'      => 'wcwar_enable_guest_requests',
						'default' => 'no',
						'autoload' => false,
						'section' => 'warranties'
					),

					'wcwar_enable_admin_requests' => array(
						'name'    => esc_html__( 'Admin Warranties', 'woocommerce-warranties-and-returns' ),
						'type'    => 'checkbox',
						'desc'    => esc_html__( 'If checked admins will have the ability to create warranty requests for items without warranties.', 'woocommerce-warranties-and-returns' ),
						'id'      => 'wcwar_enable_admin_requests',
						'default' => 'yes',
						'autoload' => false,
						'section' => 'warranties'
					),

					'wcwar_email_disable' => array(
						'name'    => esc_html__( 'Show/Hide Warranty Info', 'woocommerce-warranties-and-returns' ),
						'type'    => 'checkbox',
						'desc'    => esc_html__( 'Check this option to hide warranty information in WooCommerce Order E-Mails notifications.', 'woocommerce-warranties-and-returns' ),
						'id'      => 'wcwar_email_disable',
						'default' => 'no',
						'autoload' => true,
						'section' => 'email'
					),

					'wcwar_email_desc' => array(
						'name' => esc_html__( 'Quick Email', 'woocommerce-warranties-and-returns' ),
						'type' => 'html',
						'desc' => '
						<div class="svx-option-header"><h3>' . esc_html__( 'Quick Email', 'woocommerce-warranties-and-returns' ) . '</h3></div><div class="svx-option-wrapper"><div class="svx-notice svx-info">' . esc_html__( 'Following options are related to the Warranties Quick Email manager.', 'woocommerce-warranties-and-returns' ) . '</div></div>',
						'section' => 'email',
						'id'   => 'wcwar_email_desc',
					),

					'wcwar_email_name' => array(
						'name'    => esc_html__( 'From Name', 'woocommerce-warranties-and-returns' ),
						'type'    => 'text',
						'desc'    => esc_html__( 'Enter email From Name: which should appear in quick emails.', 'woocommerce-warranties-and-returns' ),
						'id'      => 'wcwar_email_name',
						'default' => get_bloginfo( 'name' ),
						'autoload' => false,
						'section' => 'email'
					),

					'wcwar_email_address' => array(
						'name'    => esc_html__( 'Reply To', 'woocommerce-warranties-and-returns' ),
						'type'    => 'text',
						'desc'    => esc_html__( 'Enter email address that will appear as a Reply To: address in quick emails.', 'woocommerce-warranties-and-returns' ),
						'id'      => 'wcwar_email_address',
						'default' => get_bloginfo( 'admin_email' ),
						'autoload' => false,
						'section' => 'email'
					),

					'wcwar_email_bcc' => array(
						'name'    => esc_html__( 'BCC Copies', 'woocommerce-warranties-and-returns' ),
						'type'    => 'text',
						'desc'    => esc_html__( 'Enter E-Mail addresses separated by comma to send BCC copies of quick emails.', 'woocommerce-warranties-and-returns' ),
						'id'      => 'wcwar_email_bcc',
						'default' => '',
						'autoload' => false,
						'section' => 'email'
					),

					'wcwar_enable_returns' => array(
						'name'    => esc_html__( 'Enable Returns', 'woocommerce-warranties-and-returns' ),
						'type'    => 'checkbox',
						'desc'    => esc_html__( 'This option will enable the in store returns. Set your return period in which the items can be sent back by customers with a refund.', 'woocommerce-warranties-and-returns' ),
						'id'      => 'wcwar_enable_returns',
						'default' => 'no',
						'autoload' => false,
						'section' => 'returns',
						'class' => 'svx-refresh-active-tab',
					),

					'wcwar_return_form' => array(
						'name'    => esc_html__( 'Return Request Form', 'woocommerce-warranties-and-returns' ),
						'type'    => 'list-select',
						'desc'    => esc_html__( 'Use the manager to create a return form.', 'woocommerce-warranties-and-returns' ),
						'id'      => 'wcwar_return_form',
						'title'   => esc_html__( 'Field', 'woocommerce-warranties-and-returns' ),
						'options' => 'list',
						'selects' => array(
							'text' => esc_html__( 'Input', 'woocommerce-warranties-and-returns' ),
							'paragraph' => esc_html__( 'Textarea', 'woocommerce-warranties-and-returns' ),
							'checkboxes' => esc_html__( 'Checkboxes', 'woocommerce-warranties-and-returns' ),
							'radio' => esc_html__( 'Radio', 'woocommerce-warranties-and-returns' ),
							'dropdown' => esc_html__( 'Select', 'woocommerce-warranties-and-returns' ),
							'address' => esc_html__( 'Address', 'woocommerce-warranties-and-returns' ),
							'file' => esc_html__( 'File upload', 'woocommerce-warranties-and-returns' ),
						),
						'settings' => self::_build_form_fields(),
						'default' => '',
						'autoload' => false,
						'section' => 'returns',
						'condition' => 'wcwar_enable_returns:yes',
					),

					'wcwar_returns_period' => array(
						'name' => esc_html__( 'Return Limit', 'woocommerce-warranties-and-returns' ),
						'type' => 'number',
						'desc' => esc_html__( 'Number of days for returning items upon order completition. If 0 is set, items will have a lifetime return period.', 'woocommerce-warranties-and-returns' ),
						'id'   => 'wcwar_returns_period',
						'default' => 0,
						'custom_attributes' => array(
							'min' 	=> 0,
							'max' 	=> 1826,
							'step' 	=> 1
						),
						'autoload' => false,
						'section' => 'returns',
						'condition' => 'wcwar_enable_returns:yes',
					),

					'wcwar_returns_no_warranty' => array(
						'name'    => esc_html__( 'Return Without a Warranty', 'woocommerce-warranties-and-returns' ),
						'type'    => 'checkbox',
						'desc'    => esc_html__( 'If checked, returns will be available for items that have no warranty.', 'woocommerce-warranties-and-returns' ),
						'id'      => 'wcwar_returns_no_warranty',
						'default' => 'no',
						'autoload' => false,
						'section' => 'returns',
						'condition' => 'wcwar_enable_returns:yes',
					),

				)
			);

			return SevenVX()->_do_options( $plugins, self::$plugin['label'] );
		}

		public static function _build_form_fields() {
			return array(
				'text' => array(
					'name' => self::___get_title_option(),
					'desc' => self::___get_desc_option(),
					'required' => self::___get_required_option(),
				),
				'paragraph' => array(
					'name' => self::___get_title_option(),
					'desc' => self::___get_desc_option(),
					'required' => self::___get_required_option(),
				),
				'checkboxes' => array(
					'name' => self::___get_title_option(),
					'desc' => self::___get_desc_option(),
					'required' => self::___get_required_option(),
					'options' => self::___get_options(),
				),
				'radio' => array(
					'name' => self::___get_title_option(),
					'desc' => self::___get_desc_option(),
					'required' => self::___get_required_option(),
					'options' => self::___get_options(),
				),
				'dropdown' => array(
					'name' => self::___get_title_option(),
					'desc' => self::___get_desc_option(),
					'required' => self::___get_required_option(),
					'options' => self::___get_options(),
				),
				'address' => array(
					'name' => self::___get_title_option(),
					'desc' => self::___get_desc_option(),
					'required' => self::___get_required_option(),
				),
				'file' => array(
					'name' => self::___get_title_option(),
					'desc' => self::___get_desc_option(),
					'required' => self::___get_required_option(),
				),
			);
		}

		public static function ___get_title_option() {
			return array(
				'name' => esc_html__( 'Title', 'woocommerce-warranties-and-returns' ),
				'type' => 'text',
				'desc' => esc_html__( 'Use alternative title', 'woocommerce-warranties-and-returns' ),
				'id'   => 'name',
				'default' => '',
			);
		}

		public static function ___get_desc_option() {
			return array(
				'name' => esc_html__( 'Description', 'woocommerce-warranties-and-returns' ),
				'type' => 'textarea',
				'desc' => esc_html__( 'Enter filter description', 'woocommerce-warranties-and-returns' ),
				'id'   => 'desc',
				'default' => '',
			);
		}

		public static function ___get_required_option() {
			return array(
				'name' => esc_html__( 'Required', 'woocommerce-warranties-and-returns' ),
				'type' => 'checkbox',
				'desc' => esc_html__( 'Option is required', 'woocommerce-warranties-and-returns' ),
				'id'   => 'required',
				'default' => 'no',
			);
		}

		public static function ___get_options() {
			return array(
				'name' => esc_html__( 'Options', 'woocommerce-warranties-and-returns' ),
				'type' => 'list',
				'desc' => esc_html__( 'Add options', 'woocommerce-warranties-and-returns' ),
				'id'   => 'options',
				'title' => esc_html__( 'Option', 'woocommerce-warranties-and-returns' ),
				'default' => '',
				'options' => 'list',
				'settings' => array(
					'name' => array(
						'name' => esc_html__( 'Option', 'woocommerce-warranties-and-returns' ),
						'type' => 'text',
						'id' => 'name',
						'desc' => esc_html__( 'Enter option title', 'woocommerce-warranties-and-returns' ),
						'default' => '',
					),
				),
			);
		}

	}

	XforWC_Warranties_Returns_Settings::init();

