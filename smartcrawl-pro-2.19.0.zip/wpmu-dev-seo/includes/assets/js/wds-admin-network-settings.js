(function ($) {
	function init() {
	}

	$(init);
})(jQuery);
