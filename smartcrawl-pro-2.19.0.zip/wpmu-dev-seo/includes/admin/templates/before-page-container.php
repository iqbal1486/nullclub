<?php // phpcs:ignoreFile ?>
<!-- Dummy elements to throw off admin notices that would have had styling conflicts if printed inside sui-wrap -->
<div class="wrap"><h1></h1></div>