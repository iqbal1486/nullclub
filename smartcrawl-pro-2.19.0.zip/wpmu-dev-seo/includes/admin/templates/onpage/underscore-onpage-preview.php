<?php
$this->_render( 'onpage/onpage-preview', array(
	'link'        => '{{- link }}',
	'title'       => '{{- title }}',
	'description' => '{{- description }}',
) );