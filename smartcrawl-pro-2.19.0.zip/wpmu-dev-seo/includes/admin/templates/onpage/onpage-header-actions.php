<button type="button"
        data-modal-open="wds-supported-macros-modal"
        data-modal-open-focus="wds-supported-macros-modal-close-button"
        data-modal-close-focus="container"
        class="sui-button sui-button-ghost"><?php esc_html_e( 'Browse Macros', 'wds' ); ?></button>