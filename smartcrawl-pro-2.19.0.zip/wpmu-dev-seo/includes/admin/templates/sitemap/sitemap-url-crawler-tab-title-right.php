<div id="wds-ignore-all-button-placeholder">
	<!--Actual button rendered through a react portal. See crawl-report.js-->
</div>