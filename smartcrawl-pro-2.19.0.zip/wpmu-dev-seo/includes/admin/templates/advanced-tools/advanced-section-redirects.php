<?php
$is_active = ! empty( $is_active );
?>
<div class="wds-vertical-tab-section tab_url_redirection_main  <?php echo $is_active ? '' : 'hidden'; ?>"
     id="tab_url_redirection_main">
	<div id="wds-redirects-container"></div>
</div>