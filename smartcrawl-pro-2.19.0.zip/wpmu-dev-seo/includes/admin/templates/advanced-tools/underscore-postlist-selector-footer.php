<button type="button" data-modal-close
        class="sui-button sui-button-ghost">
	<?php esc_html_e( 'Cancel', 'wds' ); ?>
</button>
<button type="button" class="wds-action-button sui-button">
	<?php esc_html_e( 'Add', 'wds' ); ?>
</button>