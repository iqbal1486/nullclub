<?php

if ( ! defined( 'WPINC' ) ) {
	die;
}