<div class="wds-right">
	<span class="sui-tag sui-tag-inactive">
		<?php esc_html_e( 'No Data Available', 'wds' ); ?>
	</span>
</div>