<p>
	<span class="sui-icon-loader sui-loading" aria-hidden="true"></span>
	<small><?php esc_html_e( 'Crawl in progress ...', 'wds' ); ?></small>
	<span class="wds-box-refresh-required"></span>
</p>