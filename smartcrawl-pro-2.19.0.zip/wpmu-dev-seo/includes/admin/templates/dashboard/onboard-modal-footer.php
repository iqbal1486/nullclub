<div>
	<p><small><?php esc_html_e( 'These services will be configured with recommended settings. You can change these at any time.', 'wds' ); ?></small></p>
</div>

<button type="button" class="sui-button sui-button-blue wds-onboarding-setup">
	<?php esc_html_e( 'Get started', 'wds' ); ?>
</button>