<?php
// Rendered through react
wp_enqueue_script( Smartcrawl_Controller_Assets::CONFIGS_JS );
?>
<div id="wds-config-widget" class="wds-configs-container"></div>