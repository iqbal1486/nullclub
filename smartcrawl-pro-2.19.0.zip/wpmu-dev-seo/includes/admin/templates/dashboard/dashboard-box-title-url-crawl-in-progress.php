<?php // phpcs:ignoreFile ?>
<div class="wds-box-refresh-required"></div>
<span class="sui-icon-loader sui-loading" aria-hidden="true"></span>