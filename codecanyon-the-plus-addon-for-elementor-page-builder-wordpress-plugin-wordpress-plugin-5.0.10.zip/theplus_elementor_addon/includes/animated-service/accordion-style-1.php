<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
?>
<img class="theplus-image-accordion__image-instance loaded" src="<?php echo $featured_image;?>" alt="">
<div class="asb-content" >
	<?php echo $list_title.$list_sub_title.$description.$loop_button; ?>
</div>
	
