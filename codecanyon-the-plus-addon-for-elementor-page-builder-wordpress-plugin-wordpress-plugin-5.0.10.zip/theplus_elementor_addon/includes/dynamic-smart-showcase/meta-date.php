<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
?>
<span class="meta-date"><a href="<?php echo esc_url(get_the_permalink()); ?> "><span class="entry-date"><?php echo get_the_date(); ?></span></a></span>