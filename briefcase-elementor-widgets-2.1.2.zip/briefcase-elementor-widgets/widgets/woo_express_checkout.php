<?php
namespace Briefcase;

use Elementor;
use Elementor\Plugin;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Text_Shadow	;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Css_Filter; 
use Elementor\Icons_Manager;
use Elementor\Core\Kits\Documents\Tabs\Global_Colors;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BEW_Widget_Woo_Express_Checkout extends Widget_Base {
	
	public function get_name() {
		return 'bew-woo-express-checkout';
	}

	public function get_title() {
		return __( 'Bew Express Checkout', 'briefcase-elementor-widgets' );
	}

	public function get_icon() {
		// Upload "eicons.ttf" font via this site: http://bluejamesbond.github.io/CharacterMap/
		return 'eicon-button';
	}

	public function get_categories() {
		return [ 'briefcasewp-elements' ];
	}
	
	public function get_script_depends() {
		return [ ];
	}
	
	public function is_reload_preview_required() {
		return true;
	}
	
	protected function _register_controls() {
		
		$this->start_controls_section(
			'section_express_checkout',
			[
				'label' 		=> __( 'Express Checkout', 'briefcase-elementor-widgets' ),
			]
		);
		
		$this->add_control(
			'express_checkout_type',
			[
				'label' 		=> __( 'Express Checkout Button by ID', 'briefcase-elementor-widgets' ),
				'type' 			=> Controls_Manager::SWITCHER,
				'default' 		=> '',
				'label_on' 		=> __( 'On', 'briefcase-elementor-widgets' ),
				'label_off' 	=> __( 'Off', 'briefcase-elementor-widgets' ),
				'return_value' 	=> 'yes',				
			]
		);
				
		$this->add_control(
			'express_checkout_id',
			[
				'label' 		=> __( 'Product ID', 'briefcase-elementor-widgets' ),
				'type' 			=> Controls_Manager::TEXT,
				'placeholder' 	=> __( 'Your Product ID', 'briefcase-elementor-widgets' ),
				'condition' => [
                    'express_checkout_type' => 'yes',
                ]
					
			]
		);
				
		$this->add_control(
			'express_checkout_text',
			[
				'label' => __( 'Text', 'briefcase-elementor-widgets' ),
				'type' => Controls_Manager::TEXT,
				'default' => __( 'Fast Checkout', 'briefcase-elementor-widgets' ),
				'placeholder' => __( 'Fast Checkout', 'briefcase-elementor-widgets' ),				
			]
		);		
		
		$this->add_control(
			'express_checkout_icon',
			[
				'label' => __( 'Icon', 'elementor' ),
				'type' => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'skin' => 'inline',
				'label_block' => false,
			]
		);
		
		$this->add_control(
			'express_checkout_icon_align',
			[
				'label' => __( 'Icon Position', 'briefcase-elementor-widgets' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'left',
				'options' => [
					'left' => __( 'Before', 'briefcase-elementor-widgets' ),
					'right' => __( 'After', 'briefcase-elementor-widgets' ),
				],
				'condition' => [
					'express_checkout_icon[value]!' => '',
				],				
			]
		);

		$this->add_control(
			'express_checkout_icon_indent',
			[
				'label' => __( 'Icon Spacing', 'briefcase-elementor-widgets' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'max' => 50,
					],
				],				
				'selectors' => [
					'{{WRAPPER}} #bew-express-checkout .bew-align-icon-right i' => 'margin-left: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} #bew-express-checkout .bew-align-icon-left i' => 'margin-right: {{SIZE}}{{UNIT}};',
				],
			]
		);
		
		$this->add_control(
			'heading_express_checkout_redirect',
			[
				'label' => __( 'Redirect', 'briefcase-elementor-widgets' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',				
				
			]
		);
		
		$this->add_control(
            'express_checkout_redirect',
            [
                'label' => __('Redirect Location', 'briefcase-elementor-widgets'),
                'type'  => Controls_Manager::SELECT,
                'options' => [                    
                    'checkout' => __( 'Checkout', 'briefcase-elementor-widgets' ),
					'custom' => __( 'Custom', 'briefcase-elementor-widgets' ),	
                ],                
                'default' => 'checkout'

            ]
        );
		
		$this->add_control(
			'express_checkout_custom_redirect',
			[
				'label' => __( 'Custom Redirect Location', 'briefcase-elementor-widgets' ),
				'type' => Controls_Manager::TEXT,				
				'placeholder' => __( 'https://yourdomain.com/custom-location', 'briefcase-elementor-widgets' ),
				'description' => __( 'Enter a full Url', 'briefcase-elementor-widgets' ),
				'condition' => [
                    'express_checkout_redirect' => 'custom',
				]
			]
		);	
		
		$this->add_control(
			'express_checkout_show',
			[
				'label' => __( 'Show Express Checkout Button for', 'briefcase-elementor-widgets' ),
				'type' => Controls_Manager::SELECT,
				'multiple' => true,
				'label_block' => true,
				'default' => 'all',
				'options' => [
					'all' => __( 'All Product Types', 'briefcase-elementor-widgets' ),
					'simple' => __( 'Simple', 'briefcase-elementor-widgets' ),
					'variable' => __( 'Variable', 'briefcase-elementor-widgets' ),
				],	
			]
		);
		
						
		$this->add_control(
			'heading_express_checkout_underlines',
			[
				'label' => __( 'Underlines Button', 'briefcase-elementor-widgets' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',				
				
			]
		);
		
		$this->add_control(
			'express_checkout_underlines',
			[
				'label' 		=> __( 'Activate Style', 'briefcase-elementor-widgets' ),
				'type' 			=> Controls_Manager::SWITCHER,
				'default' 		=> '',
				'label_on' 		=> __( 'On', 'briefcase-elementor-widgets' ),
				'label_off' 	=> __( 'Off', 'briefcase-elementor-widgets' ),
				'return_value' 	=> 'yes',
			]
		);		
				
		$this->add_responsive_control(
			'position',
			[
				'label' 		=> __( 'Position', 'briefcase-elementor-widgets' ),
				'type' 			=> Controls_Manager::CHOOSE,
				'options' 	   => [
					'left' 		=> [
						'title' 	=> __( 'Left', 'bew-extras' ),
						'icon' 		=> 'eicon-text-align-left',
					],
					'center' 	=> [
						'title' 	=> __( 'Center', 'bew-extras' ),
						'icon' 		=> 'eicon-text-align-center',
					],
					'right' 	=> [
						'title' 	=> __( 'Right', 'bew-extras' ),
						'icon' 		=> 'eicon-text-align-right',
					],
					'justify' => [
						'title' => __( 'Justified', 'bew-extras' ),
						'icon' => 'eicon-text-align-justify',
					],
				],
				'default' 		=> '',
				'selectors' 	=> [
					'{{WRAPPER}} #bew-express-checkout' => 'text-align: {{VALUE}};',
				],
				'separator' => 'before',
			]
		);
								
		$this->end_controls_section();
		
		$this->start_controls_section(
			'section_express_checkout_style',
			[
				'label' => __( 'Express Checkout', 'briefcase-elementor-widgets' ),
				'tab' => Controls_Manager::TAB_STYLE,				
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 			=> 'button_express_checkout_typo',
				'selector' 		=> '{{WRAPPER}} #bew-express-checkout .express_checkout_button',
			]
		);
		
		$this->start_controls_tabs( 'tabs_button_express_checkout_style' );

		$this->start_controls_tab(
			'tab_button_express_checkout_normal',
			[
				'label' => __( 'Normal', 'briefcase-elementor-widgets' ),
			]
		);
		
		$this->add_control(
			'button_express_checkout_color',
			[
				'label' 		=> __( 'Text Color', 'briefcase-elementor-widgets' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} #bew-express-checkout .express_checkout_button' => 'color: {{VALUE}};',
					'{{WRAPPER}} .btn-underlines svg path' => 'fill: {{VALUE}};',
				],
			]
		);
		
		$this->add_control(
			'button_express_checkout_background_color',
			[
				'label' 		=> __( 'Background Color', 'briefcase-elementor-widgets' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} #bew-express-checkout .express_checkout_button' => 'background: {{VALUE}};',
				],
				
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_button_express_checkout_hover',
			[
				'label' => __( 'Hover', 'briefcase-elementor-widgets' ),
			]
		);
		
		$this->add_control(
			'button_express_checkout_color_hover',
			[
				'label' 		=> __( 'Text Color', 'briefcase-elementor-widgets' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} #bew-express-checkout .express_checkout_button:hover' => 'color: {{VALUE}};',
					'{{WRAPPER}} .btn-underlines:hover svg path' => 'fill: {{VALUE}};',
				],
			]
		);
		
		$this->add_control(
			'button_express_checkout_background_color_hover',
			[
				'label' 		=> __( 'Background Color', 'briefcase-elementor-widgets' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} #bew-express-checkout .express_checkout_button:hover' => 'background-color: {{VALUE}};',
				],
				
			]
		);

			
		$this->add_control(
			'button_express_checkout_hover_border_color',
			[
				'label' => __( 'Border Color', 'briefcase-elementor-widgets' ),
				'type' => Controls_Manager::COLOR,
				'condition' => [
					'border_border!' => '',
				],
				'selectors' => [
					'{{WRAPPER}} #bew-express-checkout .express_checkout_button:hover' => 'border-color: {{VALUE}};',
				],
				
			]
		);
		
		$this->add_control(
			'hover_express_checkout_animation',
			[
				'label' => __( 'Animation', 'briefcase-elementor-widgets' ),
				'type' => Controls_Manager::HOVER_ANIMATION,
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();
		
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'border',
				'label' => __( 'Border', 'briefcase-elementor-widgets' ),
				'placeholder' => '1px',
				'default' => '1px',
				'selector' => '{{WRAPPER}} #bew-express-checkout .express_checkout_button',
				'separator' => 'before',
				
			]
		);
		
		$this->add_control(
			'border_radius_express_checkout',
			[
				'label' => __( 'Border Radius', 'briefcase-elementor-widgets' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} #bew-express-checkout .express_checkout_button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				
			]
		);
		
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'button_express_checkout_box_shadow',
				'selector' => '{{WRAPPER}} #bew-express-checkout .express_checkout_button',
			]
		);
				
				
		$this->add_responsive_control(
			'button_express_checkout_padding',
			[
				'label' => __( 'Text Padding', 'briefcase-elementor-widgets' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} #bew-express-checkout .express_checkout_button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'separator' => 'before',	
			]
		);
		
		$this->add_responsive_control(
			'button_express_checkout_margin',
			[
				'label' => __( 'Button Margin', 'briefcase-elementor-widgets' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} #bew-express-checkout .express_checkout_button' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
					
			]
		);
		
        $this->end_controls_section();
	}
	
	protected function add_express_checkout_button() {
		global $product;
		$args = array( 'product' => $product );
		echo $this->generate_button( $args );		
	}


	public function generate_button( $args ) {
		
		$settings = $this->get_settings();	
			
		$express_checkout_show = $settings['express_checkout_show'];
		$express_checkout_text = $settings['express_checkout_text'];
		
		$default_args = array(
			'product'         => null,
			'label'           => $express_checkout_text,
			'class'           => ' bew-express-checkout',
			//'hide_in_cart'    => true,
			//'hide_outofstock' => wc_qb_option( 'hide_outofstock' ),
			'tag'             => 'link',
		);

		$args     = wp_parse_args( $args, $default_args );
		$_arg_val = array( true, 'yes', '1', 1, 'on' );

		if ( in_array( $args['hide_in_cart'], $_arg_val, true ) ) {
			$args['hide_in_cart'] = 'yes';
		} else {
			$args['hide_in_cart'] = 'no';
		}

		extract( $args );
				
		if ( $product == null ) {
			return;
		}
		$type = $product->get_type();
		if ( $express_checkout_show == null ) {
			return;
		}
		if ( ('all' != $express_checkout_show ) && ($type != $express_checkout_show ) ) {
			return;
		}
		
		$pid = $product->get_id();
		$quantity  = 1;

		$defined_class = 'wc_express_checkout_button express_checkout_button express_checkout_' . $type . ' express_checkout_' . $pid . '_button express_checkout_' . $pid . '' . $class;
		$defined_id    = 'express_checkout_' . $pid . '_button';
		$defined_attrs = ' name=""  data-product-type="' . $type . '" data-product-id="' . $pid . '" data-quantity="' . $quantity . '"';

		if ( 'yes' === $args['hide_in_cart'] ) {
			$defined_attrs .= ' style="display:none;" ';
		}

		if ( $tag == 'link' ) {
			$qty    = isset( $quantity ) ? $quantity : 1 ;
			$link_ulr  = $this->get_product_addtocartLink( $product, $qty );

			$link = array(
				'url'               => $link_ulr,
				'is_external'       => '',
				'no_follow'         => '',
				'custom_attributes' => '',
			);
			
		} 
		
		$this->add_render_attribute( 'wrapper', 'class', 'bew-button-wrapper' );

		if ( ! empty( $link ) ) {
			$this->add_link_attributes( 'button', $link );
			$this->add_render_attribute( 'button', 'class', $defined_class);
		}

		$this->add_render_attribute( 'button', 'class', ' elementor-button express-checkout-button' );
		$this->add_render_attribute( 'button', 'role', 'button' );

		if ( ! empty( $defined_id ) ) {
			$this->add_render_attribute( 'button', 'id', $defined_id );
		}

		if ( $settings['hover_animation'] ) {
			$this->add_render_attribute( 'button', 'class', 'elementor-animation-' . $settings['hover_animation'] );
		}
		
		// Create the link 
		?>
		<div class="express_checkout_container express_checkout_<?php echo $pid; ?>_container" id="express_checkout_<?php echo $pid; ?>_container" >
			<a <?php echo $this->get_render_attribute_string( 'button' ); ?> <?php echo $defined_attrs ; ?>>
				<?php $this->render_text(); ?>
			</a>
		</div>
		<?php

	}

	public function get_product_addtocartLink( $product, $qty = 1 ) {
		
		$redirect_url = $this->express_checkout_redirect( $url );
		
		if ( $product->get_type() == 'simple' ) {
			$link = $redirect_url;			
			$link = add_query_arg( 'add-to-cart', $product->get_id(), $link );
			$link = add_query_arg( 'quantity', $qty, $link );		
			
			return $link;
		}
		return false;
	}
	
	/**
	 * Function to redirect user after Fast Checkout button is submitted
	 * @return string [[Description]]
	 */
	public function express_checkout_redirect( $url ) {
			
			$settings = $this->get_settings();	
			
			$redirect = $settings['express_checkout_redirect'];
			$custom_redirect = $settings['express_checkout_custom_redirect'];
			
			if ( $redirect == 'cart' ) {
				return wc_get_cart_url();
			} elseif ( $redirect == 'checkout' ) {
				return wc_get_checkout_url();
			} elseif ( $redirect == 'custom' && wc_notice_count( 'error' ) === 0 ) {				
				if ( ! empty( $express_checkout_custom_redirect ) ) {
					wp_safe_redirect( $express_checkout_custom_redirect );
					exit;
				}
			}
		
		return $url;
	}
	
	/**
	* Get Product Data for Woo Grid Loop template
	*
	* @since 1.0.0
	*/
	public static function product_data_loop() {
			
		global $product;				
			
		// Show firts product for loop template				
		if(empty($product)){
			// Todo:: Get product from template meta field if available
				$args = array(
					'post_type' => 'product',
					'post_status' => 'publish',
					'posts_per_page' => 1
				);
				$preview_data = get_posts( $args );
				$product_data =  wc_get_product($preview_data[0]->ID);
			
				$product = $product_data;  
			}	
	}

	protected function render_text() {
		$settings = $this->get_settings_for_display();

		$migrated = isset( $settings['__fa4_migrated']['express_checkout_icon'] );
		$is_new = empty( $settings['icon'] ) && Icons_Manager::is_migration_allowed();

		if ( ! $is_new && empty( $settings['icon_align'] ) ) {
			// @todo: remove when deprecated
			// added as bc in 2.6
			//old default
			$settings['icon_align'] = $this->get_settings( 'icon_align' );
		}

		$this->add_render_attribute( [
			'content-wrapper' => [
				'class' => 'elementor-button-content-wrapper',
			],
			'icon-align' => [
				'class' => [
					'elementor-button-icon',
					'elementor-align-icon-' . $settings['express_checkout_icon_align'],
				],
			],
			'text' => [
				'class' => 'elementor-button-text',
			],
		] );

		$this->add_inline_editing_attributes( 'text', 'none' );
		?>
		<span <?php echo $this->get_render_attribute_string( 'content-wrapper' ); ?>>
			<?php if ( ! empty( $settings['icon'] ) || ! empty( $settings['express_checkout_icon']['value'] ) ) : ?>
			<span <?php echo $this->get_render_attribute_string( 'icon-align' ); ?>>
				<?php if ( $is_new || $migrated ) :
					Icons_Manager::render_icon( $settings['express_checkout_icon'], [ 'aria-hidden' => 'true' ] );
				else : ?>
					<i class="<?php echo esc_attr( $settings['icon'] ); ?>" aria-hidden="true"></i>
				<?php endif; ?>
			</span>
			<?php endif; ?>
			<span <?php echo $this->get_render_attribute_string( 'text' ); ?>><?php echo $settings['express_checkout_text']; ?></span>
		</span>
		<?php
	}

	protected function render() {
		
		$settings = $this->get_settings();
		
		$express_checkout_by_id		 			 	= (isset($settings['express_checkout_by_id']) ? $settings['express_checkout_by_id'] : null);
		$express_checkout_id_custom 	 				= $settings['express_checkout_id'];
		$express_checkout_icon_align 		    		= $settings['express_checkout_icon_align'];		
		$express_checkout_underlines					= $settings['express_checkout_underlines'];
		$express_checkout_type							= $settings['express_checkout_type'];		
		$express_checkout_text							= $settings['express_checkout_text'];
		
		// Inner classes
		$inner_classes 		= array( 'bew-express-checkout');
		
		if ( 'yes' == $express_checkout_type) {
			$inner_classes[]  = 'button-buy-now-by-id';
		}		
		if ( '' == $express_checkout_text ) {
			$inner_classes[]  = 'button-no-text';
		}		
				
		if ( 'yes' == $express_checkout_underlines) {
			$inner_classes[]  = 'btn-underlines';		
		}
			$inner_classes[]  = 'bew-align-icon-' . $express_checkout_icon_align;
						
		$inner_classes = implode( ' ', $inner_classes );		
			
			// Data for Bew Templates
				$this->product_data_loop();
					
			// Data for Elementor Pro Templates option
				global $product;
					
				if(is_string($product)){
					$product = wc_get_product();
				}
			// Fast Checkout by ID
			if ( 'yes' == $express_checkout_by_id) { 
				if ($express_checkout_id_custom != ''):
					$product_data = wc_get_product($express_checkout_id_custom);
				else:
				 // Todo:: Get product from template meta field if available
					$args = array(
						'post_type' => 'product',
						'post_status' => 'publish',
						'posts_per_page' => 1
					);
					$preview_data = get_posts( $args );
					$product_data =  wc_get_product($preview_data[0]->ID);
				endif;        
				$product = $product_data; 
			} 
			 
            		
	// Fast Checkout underlines mode		
			if ( 'yes' == $express_checkout_underlines) {
					$svg  =	'<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" preserveAspectRatio="xMidYMid" width="61" height="12" viewBox="0 0 61 12"><path d="';
					$html = 'M60.217,1.433 C45.717,2.825 31.217,4.217 16.717,5.609 C13.227,5.944 8.806,6.200 6.390,5.310 C7.803,4.196 11.676,3.654 15.204,3.216 C28.324,1.587 42.033,-0.069 56.184,0.335 C58.234,0.394 60.964,0.830 60.217,1.433 ZM50.155,5.670 C52.205,5.728 54.936,6.165 54.188,6.767 C39.688,8.160 25.188,9.552 10.688,10.943 C7.198,11.278 2.778,11.535 0.362,10.645 C1.774,9.531 5.647,8.988 9.175,8.551 C22.295,6.922 36.005,5.265 50.155,5.670 Z';
					$svg2 = '"></path></svg>';
					}	
		
	// Made the Fast Checkout button.		
		echo'<div id="bew-express-checkout">';
		
		   // Button section
		   if ( version_compare( WC()->version, '3.0.0', '>=' ) ) {
					$product_id = $product->get_id();
					$product_type = $product->get_type();
				} else {
					$product_id = $product->id;
					$product_type = $product->product_type;
				}

				$class = implode( ' ', array_filter( [
					'button bew-element-woo-buy-now-btn',
					'product_type_' . $product_type,
					$product->is_purchasable() && $product->is_in_stock() ? 'add_to_cart_button' : 'out-of-stock',
					$product->supports( 'ajax_add_to_cart' ) ? 'ajax_add_to_cart' : '',
				] ) );
		   
		   if ( ($product && $product->is_type( 'simple' ) && $product->is_purchasable() && $product->is_in_stock() && ! $product->is_sold_individually() ) || Elementor\Plugin::instance()->editor->is_edit_mode() ) {
			echo'<div class="'. esc_attr( $inner_classes ) .'">';	
			// add the Fast Checkout button					
			$this->add_express_checkout_button();			
			
			echo '</div>';
			
		   }
		   
		echo '</div>';   
	   
		// JS for update the quantity data
		if ( $product && $product->is_type( 'simple' ) && $product->is_purchasable() && $product->is_in_stock() && ! $product->is_sold_individually() ) {
		 
			wc_enqueue_js( "	
			
			jQuery( '#bew-cart .quantity .qty' ).on( 'change', function() {
				
				var qty = jQuery( this ).val(),
					express_checkout = jQuery('.express_checkout_container a'), 
					id = express_checkout.data('product-id'),		
					new_qty = qty,
					old_qty = document.querySelector('.express_checkout_container a').getAttribute('data-quantity'),		
					old_link = '?add-to-cart=' + id +'&quantity=' + old_qty,			
					new_link = '?add-to-cart=' + id + '&quantity=' + qty;	
				
				
				jQuery('.express_checkout_container a').each(function(){
						this.href = this.href.replace(old_link, new_link);
				});
					
				jQuery( '.express_checkout_container a' ).attr( 'data-quantity', new_qty);
				
			});
			" );
		
		}
	
	}

	public function on_import( $element ) {
		return Icons_Manager::on_import_migration( $element, 'icon', 'express_checkout_icon' );
	}	
	
}

Plugin::instance()->widgets_manager->register_widget_type( new BEW_Widget_Woo_Express_Checkout() );