<?php

if (!defined('ABSPATH')) die('No direct access.');

/* This file gives an example of how to use the updater class.
You will want to copy this file into your project, and adapt the parameters to suit. */

$possible_locations = array(
	dirname(__FILE__).'/class-udm-updater.php',
	dirname(__FILE__).'/vendor/davidanderson684/simba-plugin-manager-updater/class-udm-updater.php'
);

if (!class_exists('Updraft_Manager_Updater_1_5')) {
	foreach ($possible_locations as $location) {
		if (file_exists($location)) {
			require_once($location);
			break;
		}
	}
}

try {
	new Updraft_Manager_Updater_1_5('https://briefcasewp.com/', 1, 'briefcase-elementor-widgets/briefcase-elementor-widgets.php');
} catch (Exception $e) {
	error_log($e->getMessage().' at '.$e->getFile().' line '.$e->getLine());
}

// $x->updater->debug = true;
