jQuery( function( $ ) {

	'use strict';

	window.WC_Bambora_My_Payment_Methods_Handler = window.SV_WC_Payment_Methods_Handler_v5_10_12;

	$( document.body ).trigger( 'wc_bambora_my_payment_methods_handler_loaded' );

} );
