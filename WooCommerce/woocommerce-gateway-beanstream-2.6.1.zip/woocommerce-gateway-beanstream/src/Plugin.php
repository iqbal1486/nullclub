<?php
/**
 * WooCommerce Bambora Gateway
 *
 * This source file is subject to the GNU General Public License v3.0
 * that is bundled with this package in the file license.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.html
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@skyverge.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade WooCommerce Bambora Gateway to newer
 * versions in the future. If you wish to customize WooCommerce Bambora Gateway for your
 * needs please refer to http://docs.woocommerce.com/document/bambora/
 *
 * @package   WooCommerceBambora/Plugin
 * @author    SkyVerge
 * @copyright Copyright (c) 2012-2022, SkyVerge, Inc. (info@skyverge.com)
 * @license   http://www.gnu.org/licenses/gpl-3.0.html GNU General Public License v3.0
 */

namespace SkyVerge\WooCommerce\Bambora;

use SkyVerge\WooCommerce\PluginFramework\v5_10_12 as Framework;

defined( 'ABSPATH' ) or exit;

/**
 * WooCommerce Bambora Gateway main plugin class.
 *
 * @since 2.0.0
 */
class Plugin extends Framework\SV_WC_Payment_Gateway_Plugin {


	/** @var Plugin single instance of this plugin */
	protected static $instance;


	/** string version number */
	const VERSION = '2.6.1';

	/** string the plugin ID */
	const PLUGIN_ID = 'bambora';

	/** string credit card gateway class name */
	const CREDIT_CARD_GATEWAY_CLASS_NAME = '\\SkyVerge\\WooCommerce\\Bambora\\Gateway\\Credit_Card';

	/** string credit card gateway id */
	const CREDIT_CARD_GATEWAY_ID = 'bambora_credit_card';


	/**
	 * Constructs the class.
	 *
	 * @since 2.0.0
	 */
	public function __construct() {

		parent::__construct(
			self::PLUGIN_ID,
			self::VERSION,
			array(
				'text_domain'  => 'woocommerce-gateway-bambora',
				'gateways'     => [self::CREDIT_CARD_GATEWAY_ID => self::CREDIT_CARD_GATEWAY_CLASS_NAME ],
				'dependencies' => [
					'php_extensions' => 'json',
				],
				'supports'     => [
					self::FEATURE_CAPTURE_CHARGE,
					self::FEATURE_CUSTOMER_ID,
					self::FEATURE_MY_PAYMENT_METHODS,
				],
				'require_ssl'  => true,
			)
		);
	}


	/**
	 * Gets the legacy deprecated hooks and defines their replacements.
	 *
	 * @since 2.0.0
	 *
	 * @return array
	 */
	protected function get_deprecated_hooks() {

		return array(
			'wc_payment_gateway_beanstream_credit_card_form_fields' => array(
				'version' => '2.0.0',
				'removed' => false,
			),
			'wc_gateway_beanstream_merchantid' => array(
				'version'     => '2.0.0',
				'removed'     => true,
				'map'         => true,
				'replacement' => 'wc_beanstream_legacy_merchant_id',
			),
			'wc_beanstream_credit_card_legacy_hashkey' => array(
				'version'     => '2.0.0',
				'removed'     => true,
				'map'         => true,
				'replacement' => 'wc_beanstream_legacy_hash_key',
			),
		);
	}


	/**
	 * Gets the My Payment Methods handler instance.
	 *
	 * @since 2.2.8
	 *
	 * @return My_Payment_Methods
	 */
	protected function get_my_payment_methods_instance() {

		require_once( $this->get_plugin_path() . '/src/My_Payment_Methods.php' );

		return new My_Payment_Methods( $this );
	}


	/** Admin methods *********************************************************/


	/**
	 * Adds a notice when gateways are switched.
	 *
	 * @see Framework\SV_WC_Plugin::add_admin_notices()
	 *
	 * @since 2.0.0
	 */
	public function add_admin_notices() {

		parent::add_admin_notices();

		$this->maybe_add_bambora_legacy_removed_admin_notice();
	}


	/**
	 * Determines whether to display a notice concerning the removal of the legacy gateway.
	 *
	 * @since 2.6.0
	 */
	private function maybe_add_bambora_legacy_removed_admin_notice() {

		if ( 'yes' === get_option( 'wc_' . self:: PLUGIN_ID . '_legacy_active', 'no' ) ) {
			$this->add_bambora_legacy_removed_admin_notice();
		}
	}


	/**
	 * Adds a notice concerning the removal of the legacy gateway from the plugin.
	 *
	 * @since 2.6.0
	 */
	private function add_bambora_legacy_removed_admin_notice() {

		$this->get_admin_notice_handler()->add_admin_notice(
			sprintf(
				/* Translators: Placeholders: %1$s - opening <strong> HTML tag, %2$s - closing </strong> HTML tag, %3$s - opening <a> HTML link tag, %4$s - closing </a> HTML link tag, %5$s - opening <a> HTML link tag, %6$s - closing </a> HTML link tag */
				__( '%1$sHeads up!%2$s Bambora Legacy has been retired. %3$sClick here%4$s for instructions on setting up the Bambora Gateway and please %5$scontact support%6$s with any questions or concerns.', 'woocommerce-gateway-beanstream' ),
				'<strong>', '</strong>',
				'<a href="https://docs.woocommerce.com/document/bambora/#setup">', '</a>',
				'<a href="https://woocommerce.com/my-account/create-a-ticket/">', '</a>'
			),
			$this->get_gateway()->get_id_dasherized() . '-legacy-removed-notice',
			[
				'dismissible'             => true,
				'always_show_on_settings' => false,
				'notice_class'            => 'updated',
			]
		);
	}


	/**
	 * Checks whether to display the retiring legacy gateway admin notice.
	 *
	 * @TODO remove this method by version 3.0.0 or by March 2022 {FN 2021-03-26}
	 *
	 * @since 2.5.0
	 * @deprecated 2.6.0
	 */
	public function maybe_add_retiring_bambora_legacy_admin_notice() {

		wc_deprecated_function( __METHOD__, '2.6.0' );
	}


	/**
	 * Displays the retiring legacy gateway admin notice.
	 *
	 * @TODO remove this method by version 3.0.0 or by March 2022 {FN 2021-03-26}
	 *
	 * @since 2.5.0
	 * @deprecated 2.6.0
	 */
	public function add_retiring_bambora_legacy_admin_notice() {

		wc_deprecated_function( __METHOD__, '2.6.0' );
	}


	/**
	 * Checks whether to display the thank you for switching gateway notice.
	 *
	 * @TODO remove this method by version 3.0.0 or by March 2022 {FN 2021-03-26}
	 *
	 * @since 2.5.0
	 * @deprecated 2.6.0
	 */
	public function maybe_add_switched_to_bambora_gateway_admin_notice() {

		wc_deprecated_function( __METHOD__, '2.6.0' );
	}


	/**
	 * Displays the thank you for switching gateway notice.
	 *
	 * @TODO remove this method by version 3.0.0 or by March 2022 {FN 2021-03-26}
	 *
	 * @since 2.5.0
	 * @deprecated 2.6.0
	 */
	public function add_switched_to_bambora_gateway_admin_notice() {

		wc_deprecated_function( __METHOD__, '2.6.0' );
	}


	/**
	 * Handles toggling the legacy integration.
	 *
	 * @TODO remove this method by version 3.0.0 or by March 2022 {FN 2021-03-26}
	 *
	 * @internal
	 *
	 * @since 2.0.0
	 * @deprecated 2.6.0
	 */
	public function toggle_legacy() {

		wc_deprecated_function( __METHOD__, '2.6.0' );
	}


	/** Helper methods ******************************************************/


	/**
	 * Gets the main Bambora instance.
	 *
	 * Ensures only one instance is/can be loaded.
	 *
	 * @see wc_bambora()
	 *
	 * @since 2.0.0
	 *
	 * @return Plugin
	 */
	public static function instance() {

		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}


	/**
	 * Gets the plugin name.
	 *
	 * @see SV_WC_Payment_Gateway::get_plugin_name()
	 *
	 * @since 2.0.0
	 *
	 * @return string
	 */
	public function get_plugin_name() {
		return __( 'WooCommerce Bambora Gateway', 'woocommerce-gateway-bambora' );
	}


	/**
	 * Determines if TLS v1.2 is required for API requests.
	 *
	 * @see Framework\SV_WC_Plugin::require_tls_1_2()
	 *
	 * @since 2.2.4
	 *
	 * @return true
	 */
	public function require_tls_1_2() {

		return true;
	}


	/**
	 * Gets the plugin documentation URL.
	 *
	 * @see Framework\SV_WC_Plugin::get_documentation_url()
	 *
	 * @since 2.0.0
	 *
	 * @return string
	 */
	public function get_documentation_url() {

		return 'https://docs.woocommerce.com/document/bambora/';
	}


	/**
	 * Gets the plugin support URL.
	 *
	 * @see Framework\SV_WC_Plugin::get_support_url()
	 *
	 * @since 2.0.0
	 *
	 * @return string
	 */
	public function get_support_url() {

		return 'https://woocommerce.com/my-account/marketplace-ticket-form/';
	}


	/**
	 * Gets the plugin sales page URL.
	 *
	 * @since 2.0.0
	 *
	 * @return string
	 */
	public function get_sales_page_url() {

		return 'https://woocommerce.com/products/bambora/';
	}


	/**
	 * Returns __DIR__
	 *
	 * @since 2.0.0
	 *
	 * @return string
	 */
	protected function get_file() {

		return __DIR__;
	}


	/** Lifecycle methods ******************************************************/


	/**
	 * Initializes the lifecycle handler.
	 *
	 * @since 2.0.5
	 */
	protected function init_lifecycle_handler() {

		$this->lifecycle_handler = new Lifecycle( $this );
	}


}
