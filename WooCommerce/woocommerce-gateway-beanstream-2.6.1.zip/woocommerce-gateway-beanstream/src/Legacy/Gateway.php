<?php
/**
 * WooCommerce Bambora Gateway
 *
 * This source file is subject to the GNU General Public License v3.0
 * that is bundled with this package in the file license.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.html
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@skyverge.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade WooCommerce Bambora Gateway to newer
 * versions in the future. If you wish to customize WooCommerce Bambora Gateway for your
 * needs please refer to http://docs.woocommerce.com/document/bambora/
 *
 * @package   WooCommerceBambora/Gateway
 * @author    SkyVerge
 * @copyright Copyright (c) 2012-2022, SkyVerge, Inc. (info@skyverge.com)
 * @license   http://www.gnu.org/licenses/gpl-3.0.html GNU General Public License v3.0
 */

namespace SkyVerge\WooCommerce\Bambora\Legacy;

use SkyVerge\WooCommerce\PluginFramework\v5_10_12 as Framework;

defined( 'ABSPATH' ) or exit;

/**
 * Legacy Bambora (Beanstream) gateway class.
 *
 * @TODO remove this class by version 3.0.0 or by March 2022 {FN 2021-03-26}
 *
 * @since 2.0.0
 * @deprecated 2.6.0
 */
class Gateway extends Framework\SV_WC_Payment_Gateway_Direct {


	/**
	 * Constructs the gateway.
	 *
	 * @TODO remove this method by version 3.0.0 or by March 2022 {FN 2021-03-26}
	 *
	 * @since 2.0.0
	 * @deprecated 2.6.0
	 */
	public function __construct() {

		wc_deprecated_function( __CLASS__, '2.6.0' );
	}


	/**
	 * Adds the CSC gateway settings fields.
	 *
	 * @TODO remove this method by version 3.0.0 or by March 2022 {FN 2021-03-26}
	 *
	 * @since 2.0.0
	 * @deprecated 2.6.0
	 *
	 * @return array
	 */
	protected function add_csc_form_fields() {

		return [];
	}


	/**
	 * Gets the gateway form fields.
	 *
	 * @TODO remove this method by version 3.0.0 or by March 2022 {FN 2021-03-26}
	 *
	 * @since 2.0.0
	 * @deprecated 2.6.0
	 *
	 * @return array
	 */
	protected function get_method_form_fields() {

		wc_deprecated_function( __METHOD__, '2.6.0' );

		return [];
	}


	/**
	 * Gets the merchant ID.
	 *
	 * @TODO remove this method by version 3.0.0 or by March 2022 {FN 2021-03-26}
	 *
	 * @since 2.0.0
	 * @deprecated 2.6.0
	 *
	 * @return string
	 */
	public function get_merchant_id() {

		wc_deprecated_function( __METHOD__, '2.6.0' );

		return '';
	}


	/**
	 * Gets the hash key.
	 *
	 * @TODO remove this method by version 3.0.0 or by March 2022 {FN 2021-03-26}
	 *
	 * @since 2.0.0
	 * @deprecated 2.6.0
	 *
	 * @return string
	 */
	public function get_hash_key() {

		wc_deprecated_function( __METHOD__, '2.6.0' );

		return '';
	}


	/**
	 * Gets the hash algorithm.
	 *
	 * @TODO remove this method by version 3.0.0 or by March 2022 {FN 2021-03-26}
	 *
	 * @since 2.0.0
	 * @deprecated 2.6.0
	 *
	 * @return string
	 */
	public function get_hash_algorithm() {

		wc_deprecated_function( __METHOD__, '2.6.0' );

		return '';
	}


}
