<?php
/**
 * WooCommerce Bambora Gateway
 *
 * This source file is subject to the GNU General Public License v3.0
 * that is bundled with this package in the file license.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.html
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@skyverge.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade WooCommerce Bambora Gateway to newer
 * versions in the future. If you wish to customize WooCommerce Bambora Gateway for your
 * needs please refer to http://docs.woocommerce.com/document/bambora/
 *
 * @package   WooCommerceBambora/API
 * @author    SkyVerge
 * @copyright Copyright (c) 2012-2022, SkyVerge, Inc. (info@skyverge.com)
 * @license   http://www.gnu.org/licenses/gpl-3.0.html GNU General Public License v3.0
 */

namespace SkyVerge\WooCommerce\Bambora\Legacy;

use SkyVerge\WooCommerce\PluginFramework\v5_10_12 as Framework;

defined( 'ABSPATH' ) or exit;

/**
 * The base Bambora (Legacy) API class.
 *
 * @TODO remove this class by version 3.0.0 or by March 2022 {FN 2021-03-26}
 *
 * @since 2.0.0
 * @deprecated 2.6.0
 */
class API extends Framework\SV_WC_API_Base implements Framework\SV_WC_Payment_Gateway_API {


	/**
	 * Constructs the class.
	 *
	 * @TODO remove this method by version 3.0.0 or by March 2022 {FN 2021-03-26}
	 *
	 * @since 2.0.0
	 * @deprecated 2.6.0
	 */
	public function __construct() {

		wc_deprecated_function( __CLASS__, '2.6.0' );
	}


	/**
	 * Performs a credit card charge.
	 *
	 * @since 2.0.0
	 * @deprecated 2.6.0
	 *
	 * @param \WC_Order $order WooCommerce order object
	 * @return null
	 */
	public function credit_card_charge( \WC_Order $order ) {

		wc_deprecated_function( __METHOD__, '2.6.0' );

		return null;
	}


	/**
	 * Performs a credit card authorization.
	 *
	 * @TODO remove this method by version 3.0.0 or by March 2022 {FN 2021-03-26}
	 *
	 * @since 2.0.0
	 * @deprecated 2.6.0
	 *
	 * @param \WC_Order $order WooCommerce order object
	 * @return null
	 */
	public function credit_card_authorization( \WC_Order $order ) {

		wc_deprecated_function( __METHOD__, '2.6.0' );

		return null;
	}


	/**
	 * Determines if the API supports getting tokenized payment methods.
	 *
	 * @TODO remove this method by version 3.0.0 or by March 2022 {FN 2021-03-26}
	 *
	 * @since 2.0.0
	 * @deprecated 2.6.0
	 *
	 * @return false
	 */
	public function supports_get_tokenized_payment_methods() {

		wc_deprecated_function( __METHOD__, '2.6.0' );

		return false;
	}


	/**
	 * Determines if the API supports removing tokenized payment methods.
	 *
	 * @TODO remove this method by version 3.0.0 or by March 2022 {FN 2021-03-26}
	 *
	 * @since 2.0.5
	 * @deprecated 2.6.0
	 *
	 * @return false
	 */
	public function supports_update_tokenized_payment_method() {

		wc_deprecated_function( __METHOD__, '2.6.0' );

		return false;
	}


	/**
	 * Determines if the API supports removing tokenized payment methods.
	 *
	 * @TODO remove this method by version 3.0.0 or by March 2022 {FN 2021-03-26}
	 *
	 * @since 2.0.0
	 * @deprecated 2.6.0
	 *
	 * @return false
	 */
	public function supports_remove_tokenized_payment_method() {

		wc_deprecated_function( __METHOD__, '2.6.0' );

		return false;
	}


	/**
	 * Validates the response for errors before parsing the data.
	 *
	 * @TODO remove this method by version 3.0.0 or by March 2022 {FN 2021-03-26}
	 *
	 * @since 2.0.0
	 * @deprecated 2.6.0
	 *
	 * @return true
	 */
	protected function do_pre_parse_response_validation() {

		wc_deprecated_function( __METHOD__, '2.6.0' );

		return true;
	}


	/**
	 * Validates the response for errors after parsing the data.
	 *
	 * @TODO remove this method by version 3.0.0 or by March 2022 {FN 2021-03-26}
	 *
	 * @since 2.0.0
	 * @deprecated 2.6.0
	 *
	 * @return true
	 */
	protected function do_post_parse_response_validation() {

		wc_deprecated_function( __METHOD__, '2.6.0' );

		return true;
	}


	/**
	 * Builds and returns a new API request object.
	 *
	 * @TODO remove this method by version 3.0.0 or by March 2022 {FN 2021-03-26}
	 *
	 * @since 2.0.0
	 * @deprecated 2.6.0
	 *
	 * @param string $type request type to get
	 * @return API\Request
	 */
	protected function get_new_request( $type = null ) {

		wc_deprecated_function( __METHOD__, '2.6.0' );

		return new API\Request( '', '', '' );
	}


	/**
	 * Gets the order associated with the request.
	 *
	 * @TODO remove this method by version 3.0.0 or by March 2022 {FN 2021-03-26}
	 *
	 * @since 2.0.0
	 * @deprecated 2.6.0
	 *
	 * @return \WC_Order|null
	 */
	public function get_order() {

		wc_deprecated_function( __METHOD__, '2.6.0' );

		return null;
	}


	/**
	 * Gets the ID for the API.
	 *
	 * @TODO remove this method by version 3.0.0 or by March 2022 {FN 2021-03-26}
	 *
	 * @since 2.0.0
	 * @deprecated 2.6.0
	 *
	 * @return string
	 */
	protected function get_api_id() {

		wc_deprecated_function( __METHOD__, '2.6.0' );

		return '';
	}


	/**
	 * Gets the gateway object.
	 *
	 * @TODO remove this method by version 3.0.0 or by March 2022 {FN 2021-03-26}
	 *
	 * @since 2.0.0
	 * @deprecated 2.6.0
	 *
	 * @return null
	 */
	protected function get_gateway() {

		wc_deprecated_function( __METHOD__, '2.6.0' );

		return null;
	}


	/**
	 * Gets the main plugin instance.
	 *
	 * @TODO remove this method by version 3.0.0 or by March 2022 {FN 2021-03-26}
	 *
	 * @since 2.0.0
	 * @deprecated 2.6.0
	 *
	 * @return Plugin
	 */
	protected function get_plugin() {

		wc_deprecated_function( __METHOD__, '2.6.0' );

		return wc_bambora();
	}


	/**
	 * No-op: Bambora Legacy does not support captures.
	 *
	 * @TODO remove this method by version 3.0.0 or by March 2022 {FN 2021-03-26}
	 *
	 * @since 2.0.0
	 * @deprecated 2.6.0
	 *
	 * @param \WC_Order $order order object
	 */
	public function credit_card_capture( \WC_Order $order ) {

		wc_deprecated_function( __METHOD__, '2.6.0' );
	}


	/**
	 * No-op: Bambora Legacy does not support eCheck transactions.
	 *
	 * @TODO remove this method by version 3.0.0 or by March 2022 {FN 2021-03-26}
	 *
	 * @since 2.0.0
	 * @deprecated 2.6.0
	 *
	 * @param \WC_Order $order order object
	 */
	public function check_debit( \WC_Order $order ) {

		wc_deprecated_function( __METHOD__, '2.6.0' );
	}


	/**
	 * No-op: Bambora Legacy does not support refunds.
	 *
	 * @TODO remove this method by version 3.0.0 or by March 2022 {FN 2021-03-26}
	 *
	 * @since 2.0.0
	 * @deprecated 2.6.0
	 *
	 * @param \WC_Order $order order object
	 */
	public function refund( \WC_Order $order ) {

		wc_deprecated_function( __METHOD__, '2.6.0' );
	}


	/**
	 * No-op: Bambora Legacy does not support voids.
	 *
	 * @TODO remove this method by version 3.0.0 or by March 2022 {FN 2021-03-26}
	 *
	 * @since 2.0.0
	 * @deprecated 2.6.0
	 *
	 * @param \WC_Order $order order object
	 */
	public function void( \WC_Order $order ) {

		wc_deprecated_function( __METHOD__, '2.6.0' );
	}


	/**
	 * No-op: Bambora Legacy does not support tokenization.
	 *
	 * @TODO remove this method by version 3.0.0 or by March 2022 {FN 2021-03-26}
	 *
	 * @since 2.0.0
	 * @deprecated 2.6.0
	 *
	 * @param \WC_Order $order order object
	 */
	public function tokenize_payment_method( \WC_Order $order ) {

		wc_deprecated_function( __METHOD__, '2.6.0' );
	}


	/**
	 * No-op: Bambora Legacy does not support tokenization.
	 *
	 * @TODO remove this method by version 3.0.0 or by March 2022 {FN 2021-03-26}
	 *
	 * @since 2.0.5
	 * @deprecated 2.6.0
	 *
	 * @param \WC_Order $order order object
	 */
	public function update_tokenized_payment_method( \WC_Order $order ) {

		wc_deprecated_function( __METHOD__, '2.6.0' );
	}


	/**
	 * No-op: Bambora Legacy does not support tokenization.
	 *
	 * @TODO remove this method by version 3.0.0 or by March 2022 {FN 2021-03-26}
	 *
	 * @since 2.0.0
	 * @deprecated 2.6.0
	 *
	 * @param string $token payment method token
	 * @param string $customer_id unique customer ID
	 */
	public function remove_tokenized_payment_method( $token, $customer_id ) {

		wc_deprecated_function( __METHOD__, '2.6.0' );
	}


	/**
	 * No-op: Bambora Legacy does not support tokenization.
	 *
	 * @TODO remove this method by version 3.0.0 or by March 2022 {FN 2021-03-26}
	 *
	 * @since 2.0.0
	 * @deprecated 2.6.0
	 *
	 * @param string $customer_id unique customer ID
	 */
	public function get_tokenized_payment_methods( $customer_id ) {

		wc_deprecated_function( __METHOD__, '2.6.0' );
	}


}
