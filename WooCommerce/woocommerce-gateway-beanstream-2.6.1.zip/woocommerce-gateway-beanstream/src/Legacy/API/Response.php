<?php
/**
 * WooCommerce Bambora Gateway
 *
 * This source file is subject to the GNU General Public License v3.0
 * that is bundled with this package in the file license.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.html
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@skyverge.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade WooCommerce Bambora Gateway to newer
 * versions in the future. If you wish to customize WooCommerce Bambora Gateway for your
 * needs please refer to http://docs.woocommerce.com/document/bambora/
 *
 * @package   WooCommerceBambora/API
 * @author    SkyVerge
 * @copyright Copyright (c) 2012-2022, SkyVerge, Inc. (info@skyverge.com)
 * @license   http://www.gnu.org/licenses/gpl-3.0.html GNU General Public License v3.0
 */

namespace SkyVerge\WooCommerce\Bambora\Legacy\API;

use SkyVerge\WooCommerce\PluginFramework\v5_10_12 as Framework;

defined( 'ABSPATH' ) or exit;

/**
 * The Bambora Legacy API response class.
 *
 * @TODO remove this class by version 3.0.0 or by March 2022 {FN 2021-03-26}
 *
 * @since 2.0.0
 * @deprecated 2.6.0
 */
class Response implements Framework\SV_WC_Payment_Gateway_API_Authorization_Response {


	/**
	 * Constructs the class.
	 *
	 * @TODO remove this method by version 3.0.0 or by March 2022 {FN 2021-03-26}
	 *
	 * @since 2.0.0
	 * @deprecated 2.6.0
	 *
	 * @param string $raw_data URL query string with the response data
	 */
	public function __construct( $raw_data ) {

		wc_deprecated_function( __CLASS__, '2.6.0' );
	}


	/**
	 * Determines if the transaction was approved.
	 *
	 * @TODO remove this method by version 3.0.0 or by March 2022 {FN 2021-03-26}
	 *
	 * @since 2.0.0
	 * @deprecated 2.6.0
	 *
	 * @return bool
	 */
	public function transaction_approved() {

		wc_deprecated_function( __METHOD__, '2.6.0' );

		return false;
	}


	/**
	 * Determines if the transaction was held.
	 *
	 * @TODO remove this method by version 3.0.0 or by March 2022 {FN 2021-03-26}
	 *
	 * @since 2.0.0
	 * @deprecated 2.6.0
	 *
	 * @return false
	 */
	public function transaction_held() {

		wc_deprecated_function( __METHOD__, '2.6.0' );

		return false;
	}


	/**
	 * Gets the transaction result code.
	 *
	 * @TODO remove this method by version 3.0.0 or by March 2022 {FN 2021-03-26}
	 *
	 * @since 2.0.0
	 * @deprecated 2.6.0
	 *
	 * @return string
	 */
	public function get_status_code() {

		wc_deprecated_function( __METHOD__, '2.6.0' );

		return '';
	}


	/**
	 * Gets the transaction result message.
	 *
	 * @TODO remove this method by version 3.0.0 or by March 2022 {FN 2021-03-26}
	 *
	 * @since 2.0.0
	 * @deprecated 2.6.0
	 *
	 * @return string
	 */
	public function get_status_message() {

		wc_deprecated_function( __METHOD__, '2.6.0' );

		return '';
	}


	/**
	 * Gets the transaction ID.
	 *
	 * @TODO remove this method by version 3.0.0 or by March 2022 {FN 2021-03-26}
	 *
	 * @since 2.0.0
	 * @deprecated 2.6.0
	 *
	 * @return string
	 */
	public function get_transaction_id() {

		wc_deprecated_function( __METHOD__, '2.6.0' );

		return '';
	}


	/**
	 * Gets the transaction authorization code.
	 *
	 * @TODO remove this method by version 3.0.0 or by March 2022 {FN 2021-03-26}
	 *
	 * @since 2.0.0
	 * @deprecated 2.6.0
	 *
	 * @return string
	 */
	public function get_authorization_code() {

		wc_deprecated_function( __METHOD__, '2.6.0' );

		return '';
	}


	/**
	 * Gets the AVS result code.
	 *
	 * @TODO remove this method by version 3.0.0 or by March 2022 {FN 2021-03-26}
	 *
	 * @since 2.0.0
	 * @deprecated 2.6.0
	 *
	 * @return string
	 */
	public function get_avs_result() {

		wc_deprecated_function( __METHOD__, '2.6.0' );

		return '';
	}


	/**
	 * Gets the CSC validation result code.
	 *
	 * @TODO remove this method by version 3.0.0 or by March 2022 {FN 2021-03-26}
	 *
	 * @since 2.0.0
	 * @deprecated 2.6.0
	 *
	 * @return string
	 */
	public function get_csc_result() {

		wc_deprecated_function( __METHOD__, '2.6.0' );

		return '';
	}


	/**
	 * Gets the card type.
	 *
	 * @TODO remove this method by version 3.0.0 or by March 2022 {FN 2021-03-26}
	 *
	 * @since 2.0.0
	 * @deprecated 2.6.0
	 *
	 * @return string
	 */
	public function get_card_type() {

		wc_deprecated_function( __METHOD__, '2.6.0' );

		return '';
	}


	/**
	 * Gets the payment type: 'credit-card', 'echeck', etc...
	 *
	 * @TODO remove this method by version 3.0.0 or by March 2022 {FN 2021-03-26}
	 *
	 * @since 2.0.0
	 * @deprecated 2.6.0
	 *
	 * @return string
	 */
	public function get_payment_type() {

		wc_deprecated_function( __METHOD__, '2.6.0' );

		return '';
	}


	/**
	 * Gets the user-friendly message for detailed declined messages.
	 *
	 * @TODO remove this method by version 3.0.0 or by March 2022 {FN 2021-03-26}
	 *
	 * @since 2.0.0
	 * @deprecated 2.6.0
	 *
	 * @return string
	 */
	public function get_user_message() {

		wc_deprecated_function( __METHOD__, '2.6.0' );

		return '';
	}


	/**
	 * Gets the returned hash value for validation.
	 *
	 * @TODO remove this method by version 3.0.0 or by March 2022 {FN 2021-03-26}
	 *
	 * @since 2.0.0
	 * @deprecated 2.6.0
	 *
	 * @return string
	 */
	public function get_hash_value() {

		wc_deprecated_function( __METHOD__, '2.6.0' );

		return '';
	}


	/**
	 * Gets the string representation of the request data.
	 *
	 * @TODO remove this method by version 3.0.0 or by March 2022 {FN 2021-03-26}
	 *
	 * @since 2.0.0
	 * @deprecated 2.6.0
	 *
	 * @return string
	 */
	public function to_string() {

		wc_deprecated_function( __METHOD__, '2.6.0' );

		return '';
	}


	/**
	 * Gets the string representation of the response with any sensitive data masked or removed.
	 *
	 * @TODO remove this method by version 3.0.0 or by March 2022 {FN 2021-03-26}
	 *
	 * @since 2.0.0
	 * @deprecated 2.6.0
	 *
	 * @return string
	 */
	public function to_string_safe() {

		wc_deprecated_function( __METHOD__, '2.6.0' );

		return '';
	}


	/**
	 * No-op: the Bambora Legacy API does not return a CSC result.
	 *
	 * @TODO remove this method by version 3.0.0 or by March 2022 {FN 2021-03-26}
	 *
	 * @since 2.0.0
	 * @deprecated 2.6.0
	 */
	public function csc_match() {

		wc_deprecated_function( __METHOD__, '2.6.0' );
	}


}
