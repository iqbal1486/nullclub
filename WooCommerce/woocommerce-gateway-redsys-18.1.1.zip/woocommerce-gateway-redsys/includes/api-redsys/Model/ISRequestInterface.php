<?php
	if(!interface_exists('ISRequestInterface')){
		interface ISRequestInterface{
		}
	}