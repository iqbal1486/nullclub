Storefront Powerpack
===================

Adds a variety of WooCommerce specific settings to the customizer allowing you to further tailor the Storefront appearance to match your needs.

* Read all about the features [here](https://www.woocommerce.com/products/storefront-powerpack/).
* Read documentation [here](https://docs.woocommerce.com/document/storefront-powerpack/).