<?php
use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

/**
 * eWAY payment method integration
 *
 * @since 3.2.0
 */
final class WC_Gateway_EWAY_Blocks_Support extends AbstractPaymentMethodType {
	/**
	 * Name of the payment method.
	 *
	 * @var string
	 */
	protected $name = 'eway';

	/**
	 * Initializes the payment method type.
	 */
	public function initialize() {
		$this->settings = get_option( 'woocommerce_eway_settings', [] );

		add_action(
			'woocommerce_blocks_enqueue_checkout_block_scripts_before',
			function() {
				add_filter( 'woocommerce_saved_payment_methods_list', array( $this, 'add_eway_saved_payment_methods' ), 10, 1 );
			}
		);
		add_action(
			'woocommerce_blocks_enqueue_checkout_block_scripts_after',
			function () {
				remove_filter( 'woocommerce_saved_payment_methods_list', array( $this, 'add_eway_saved_payment_methods' ) );
			}
		);
	}

	/**
	 * Manually adds the customers eWAY cards to the list of cards returned
	 * by the `woocommerce_saved_payment_methods_list` filter.
	 *
	 * eWAY doesn't store customer cards in WC's payment token table so in order
	 * for them to appear on the checkout block we have to manually add them.
	 *
	 * @param array $saved_methods
	 * @return array
	 */
	public function add_eway_saved_payment_methods( $saved_methods ) {
		$saved_cards = $this->get_saved_cards();

		if ( ! $saved_cards ) {
			$saved_cards = [];
		}

		foreach ( $saved_cards as $saved_card ) {
			$saved_method = array(
				'method'     => array(
					'gateway' => 'eway',
					'last4'   => esc_html( substr( $saved_card['number'], -4 ) ),
					'brand'   => esc_html__( 'Card', 'wc-eway' ),
				),
				/* translators: 1 is the expiration month and 2 the expiration year */
				'expires'    => sprintf(
					esc_html__( '%1$s/%2$s', 'wc-eway' ),
					$saved_card['exp_month'],
					$saved_card['exp_year']
				),
				'is_default' => false,
				'actions'    => array(),
				'tokenId'    => $saved_card['id'],
			);

			$saved_methods['cc'][] = $saved_method;
		}

		return $saved_methods;
	}

	/**
	 * Returns if this payment method should be active. If false, the scripts will not be enqueued.
	 *
	 * @return boolean
	 */
	public function is_active() {
		$payment_gateways_class = WC()->payment_gateways();
		$payment_gateways       = $payment_gateways_class->payment_gateways();

		return $payment_gateways['eway']->is_available();
	}

	/**
	 * Returns an array of scripts/handles to be registered for this payment method.
	 *
	 * @return array
	 */
	public function get_payment_method_script_handles() {
		$asset_path   = WOOCOMMERCE_GATEWAY_EWAY_PATH . '/build/index.asset.php';
		$version      = WOOCOMMERCE_GATEWAY_EWAY_VERSION;
		$dependencies = [];
		if ( file_exists( $asset_path ) ) {
			$asset        = require $asset_path;
			$version      = is_array( $asset ) && isset( $asset['version'] )
				? $asset['version']
				: $version;
			$dependencies = is_array( $asset ) && isset( $asset['dependencies'] )
				? $asset['dependencies']
				: $dependencies;
		}
		wp_register_script(
			'wc-eway-blocks-integration',
			WOOCOMMERCE_GATEWAY_EWAY_URL . '/build/index.js',
			$dependencies,
			$version,
			true
		);
		wp_set_script_translations(
			'wc-eway-blocks-integration',
			'wc-eway'
		);
		return [ 'wc-eway-blocks-integration' ];
	}

	/**
	 * Returns an array of key=>value pairs of data made available to the payment methods script.
	 *
	 * @return array
	 */
	public function get_payment_method_data() {
		$show_saved_cards    = $this->get_show_saved_cards();
		$payment_method_data = [
			'title'          => $this->get_setting( 'title' ),
			'description'    => $this->get_setting( 'description' ),
			'supports'       => $this->get_supported_features(),
			'showSavedCards' => $show_saved_cards,
		];

		if ( $show_saved_cards ) {
			$payment_method_data = array_merge(
				$payment_method_data,
				[
					'manageCardsUrl' => esc_attr( apply_filters( 'wc_eway_manage_saved_cards_url', get_permalink( get_option( 'woocommerce_myaccount_page_id' ) ) ) ),
					'savedCards'     => $this->get_saved_cards(),
					'nonce'          => wp_create_nonce( 'eway_use_saved_card' ),
				]
			);
		}

		return $payment_method_data;
	}

	/**
	 * Determine if saved cards should be shown as an option.
	 *
	 * @return bool True if customers should be able to select a saved card during checkout.
	 */
	private function get_show_saved_cards() {
		return isset( $this->settings['saved_cards'] ) ? 'yes' === $this->settings['saved_cards'] : false;
	}

	/**
	 * Get saved cards data from the database.
	 *
	 * @return object[] Array of saved cards data.
	 */
	private function get_saved_cards() {
		return get_user_meta( get_current_user_id(), '_eway_token_cards', true );
	}

	/**
	 * Returns an array of supported features.
	 *
	 * @return string[]
	 */
	public function get_supported_features() {
		$payment_gateways = WC()->payment_gateways->payment_gateways();
		return $payment_gateways['eway']->supports;
	}
}
