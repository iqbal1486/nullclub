/**
 * External dependencies
 */
import { decodeEntities } from '@wordpress/html-entities';
import { __ } from '@wordpress/i18n';

/**
 * Internal dependencies
 */
import { CheckoutHandler } from './checkout-handler';
import { getEWAYServerData } from './eway-utils';

const ComponentCreditCard = ( { emitResponse, eventRegistration } ) => {
	const {
		description = '',
		manageCardsUrl = '',
		showSavedCards = false,
		savedCards = {},
	} = getEWAYServerData();

	const showManageCardsButton =
		showSavedCards &&
		manageCardsUrl &&
		( savedCards.length > 0 || Object.keys( savedCards ).length > 0 );

	return (
		<>
			<CheckoutHandler
				emitResponse={ emitResponse }
				eventRegistration={ eventRegistration }
				selectedCard="new"
			/>
			{ decodeEntities( description ) }
			{ showManageCardsButton && (
				<>
					{ ' ' }
					<a
						href={ `${ manageCardsUrl }#saved-cards` }
						rel="noreferrer"
						target="_blank"
					>
						({ __( 'Manage cards', 'wc-eway' ) })
					</a>
				</>
			) }
		</>
	);
};

export default ComponentCreditCard;
