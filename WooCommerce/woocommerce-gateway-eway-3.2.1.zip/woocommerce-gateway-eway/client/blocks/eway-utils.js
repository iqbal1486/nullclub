/**
 * External dependencies
 */
import { getSetting } from '@woocommerce/settings';

/**
 * eWAY data comes form the server passed on a global object.
 */
export const getEWAYServerData = () => {
	const ewayServerData = getSetting( 'eway_data', null );
	if ( ! ewayServerData || typeof ewayServerData !== 'object' ) {
		throw new Error( 'eWAY initialization data is not available' );
	}
	return ewayServerData;
};
