<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

// Signature on Delivery/ Delivery Confirmation
return array(
	'INT_PARCEL_SEA_OWN_PACKAGING',
	'INT_PARCEL_AIR_OWN_PACKAGING',
	'INT_PARCEL_STD_OWN_PACKAGING',
	'AUS_PARCEL_REGULAR',
	'AUS_PARCEL_EXPRESS',
);
