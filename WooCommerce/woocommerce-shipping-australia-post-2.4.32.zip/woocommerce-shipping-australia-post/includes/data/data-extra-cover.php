<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

return array(
	'INT_PARCEL_SEA_OWN_PACKAGING'             => 5000,
	'INT_PARCEL_STD_OWN_PACKAGING'             => 5000,
	'INT_PARCEL_COR_OWN_PACKAGING'             => 5000,
	'INT_PARCEL_EXP_OWN_PACKAGING'             => 5000,
	'INT_LETTER_COR_OWN_PACKAGING'             => 5000,
	'INT_LETTER_EXP_OWN_PACKAGING'             => 5000,
	'INT_PARCEL_AIR_OWN_PACKAGING'             => 500,
	'AUS_PARCEL_REGULAR'                       => 300,
	'AUS_PARCEL_COURIER'                       => 300,
	'AUS_PARCEL_EXPRESS'                       => 300,
	'AUS_SERVICE_OPTION_SIGNATURE_ON_DELIVERY' => 5000,
);
