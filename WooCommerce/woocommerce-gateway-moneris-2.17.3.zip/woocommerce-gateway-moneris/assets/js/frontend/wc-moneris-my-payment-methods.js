jQuery( document ).ready( ( $ ) => {

	'use strict';

	window.WC_Moneris_My_Payment_Methods = window.SV_WC_Payment_Methods_Handler_v5_10_12;

	$( document.body ).trigger( 'wc_moneris_my_payment_methods_handler_loaded' );

} );
