=== WooCommerce Moneris Gateway ===
Author: skyverge
Tags: woocommerce
Requires PHP: 7.0
Requires at least: 5.2
Tested up to: 5.9.2

Accept credit cards and Interac Online in WooCommerce with the Moneris Gateway

See https://docs.woocommerce.com/document/moneris/ for full documentation.

== Installation ==

1. Upload the entire 'woocommerce-gateway-moneris' folder to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress
