=== WooCommerce Twilio SMS Notifications ===
Author: skyverge
Tags: woocommerce
Requires at least: 5.2
Tested up to: 5.8.2
Requires PHP: 7.0

Send SMS order notifications to admins and customers for your WooCommerce store. Powered by Twilio :)

See http://docs.woocommerce.com/document/twilio-sms-notifications/ for full documentation.

== Installation ==

1. Upload the entire 'woocommerce-twilio-sms-notifications' folder to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress
