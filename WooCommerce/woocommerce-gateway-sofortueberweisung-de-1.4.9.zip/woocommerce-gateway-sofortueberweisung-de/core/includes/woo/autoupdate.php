<?php

$plugin_file = dirname( dirname( dirname( dirname( __FILE__ ) ) ) ) . '/woocommerce-gateway-sofortueberweisung-de.php';

if ( ! function_exists( "woothemes_queue_update" ) ) require dirname( __FILE__ ) . '/woo-functions.php';

woothemes_queue_update( plugin_basename( $plugin_file ), 'c60c90f84b58147586a71f632b3c51d5', '18701' );