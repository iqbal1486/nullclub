<?php
/**
 * Plugin Name: Sofort payment gateway
 * Plugin URI:  http://www.woothemes.com/products/sofort-payment-gateway
 * Description: Direct payment via online banking. Easy, quick and secure – without registration. Automatic data transfer and the real-time transaction notification enable a smooth payment process and a faster delivery.
 * Author: Sven Wagener
 * Version: 1.4.9
 * Author URI: http://awesome.ug
 * Text Domain: woogate
 * Domain Path: /languages/
 * WC requires at least: 2.0.0
 * WC tested up to: 5.7.1
 * Woo: 18701:c60c90f84b58147586a71f632b3c51d5
 *
 * Copyright 2021 (very@awesome.ug)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License, version 2, as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

// No direct access is allowed
if( !defined( 'ABSPATH' ) ) {
	exit;
}

require dirname(__FILE__ ) . "/core/includes/woo/autoupdate.php";

require dirname(__FILE__ ) . '/vendor/autoload.php';

if( ! class_exists( 'WooCommerce_SofortGateway' ) ) {
	/**
	 * Main class
	 *
	 * @since 1.0.0
	 */
	class WooCommerce_SofortGateway {
		/**
		 * The plugin version
		 *
		 * @since 1.0.0
		 */
		const VERSION = '1.4.7';

		/**
		 * Minimum required WP version
		 *
		 * @since 1.0.0
		 */
		const MIN_WP = '3.3.1';

		/**
		 * Minimum required Woocommerce version
		 *
		 * @since 1.0.0
		 */
		const MIN_WOO = '2.0.0';

		/**
		 * Minimum required PHP version
		 *
		 * @since 1.0.0
		 */
		const MIN_PHP = '5.6.38';

		/**
		 * Name of the plugin folder
		 *
		 * @since 1.0.0
		 */
		static private $plugin_name;

		/**
		 * Can the plugin be executed
		 *
		 * @since 1.0.0
		 */
		static private $active = false;

		/**
		 * Supported currencies
		 *
		 * @since 1.0.0
		 */
		public static $supported_currencies;

		/**
		 * Initializing Plugin
		 *
		 * @since 1.0.0
		 */
		public function __construct() {
			self::$plugin_name          = plugin_basename( __FILE__ );
			self::$supported_currencies = 'CHF,EUR,GBP,HUF,PLN';

			add_action( 'plugins_loaded', array( &$this, 'constants' ), 0 );
			add_action( 'plugins_loaded', array( &$this, 'translate' ), 0 );
			add_action( 'plugins_loaded', array( &$this, 'check_requirements' ), 0 );
			add_action( 'plugins_loaded', array( &$this, 'load' ), 1 );

			add_filter( 'plugin_row_meta', array( &$this, 'add_links' ), 10, 2 );
		}

		/**
		 * Load the core files
		 *
		 * @since 1.0.0
		 */
		public function load() {
			if ( self::$active === false ) {
				return false;
			}

			// core files
			require( WOOGATE_ABSPATH . 'core/woogate-core.php' );
		}

		/**
		 * Declare all constants
		 *
		 * @since 1.0.0
		 */
		public function constants() {
			define( 'WOOGATE_PLUGIN', self::$plugin_name );
			define( 'WOOGATE_VERSION', self::VERSION );
			define( 'WOOGATE_ABSPATH', trailingslashit( plugin_dir_path( __FILE__ ) ) );
			define( 'WOOGATE_URLPATH', trailingslashit( plugins_url( basename( plugin_dir_path( __FILE__ ) ), basename( __FILE__ ) ) ) );
		}

		/**
		 * Load the languages
		 *
		 * @since 1.0.0
		 */
		public function translate() {
			load_plugin_textdomain( 'woogate', false, dirname( self::$plugin_name ) . '/languages/' );
		}

		/**
		 * Check for required versions
		 *
		 * Checks for WP, PHP and Woocommerce versions
		 *
		 * @since 1.0.0
		 *
		 * @global string $wp_version Current WordPress version
		 */
		public function check_requirements() {
			global $wp_version;

			$error = false;

			// Woocommerce checks
			if ( ! defined( 'WOOCOMMERCE_VERSION' ) ) {
				add_action( 'admin_notices', function () { printf( WooCommerce_SofortGateway::messages( "no_woo" ), admin_url( "plugin-install.php" ) ); } );
				$error = true;
			} elseif ( version_compare( WOOCOMMERCE_VERSION, self::MIN_WOO, '>=' ) == false ) {
				add_action( 'admin_notices', function () { printf( WooCommerce_SofortGateway::messages( "min_woo" ), Woocommerce_SofortGateway::MIN_WOO, admin_url( "update-core.php" ) ); } );
				$error = true;
			}

			// WordPress check
			if ( version_compare( $wp_version, self::MIN_WP, '>=' ) == false ) {
				add_action( 'admin_notices', function () { printf( WooCommerce_SofortGateway::messages( "min_wp" ), Woocommerce_SofortGateway::MIN_WP, admin_url( "update-core.php" ) ); } );
				$error = true;
			}

			// PHP check
			if ( version_compare( PHP_VERSION, self::MIN_PHP, '>=' ) == false ) {
				add_action( 'admin_notices', function () { printf( WooCommerce_SofortGateway::messages( "min_php" ), Woocommerce_SofortGateway::MIN_PHP ); } );
				$error = true;
			}

			// Currency check
			if ( function_exists( 'get_woocommerce_currency' ) && self::check_currencies() !== true ) {
				add_action( 'admin_notices', function () { printf( WooCommerce_SofortGateway::messages( "cur_fail" ), implode( ", ", WooCommerce_SofortGateway::check_currencies() ) ); } );
			}

			self::$active = ( ! $error ) ? true : false;
		}

		/**
		 * Checks the allowed Currencies
		 *
		 * @since 1.0.0
		 *
		 * @return array|bool
		 */
		public static function check_currencies() {
			// Currencies Check
			$currencies = apply_filters( 'wc_aelia_cs_enabled_currencies', array( get_woocommerce_currency() ) );

			$page = '';
			if ( array_key_exists( 'page', $_GET ) ) {
				$page = $_GET['page'];
			}

			$tab = '';
			if ( array_key_exists( 'tab', $_GET ) ) {
				$tab = $_GET['tab'];
			}

			$section = '';
			if ( array_key_exists( 'section', $_GET ) ) {
				$section = $_GET['section'];
			}

			// If page should noz show a message, interrupt the check and gibe back true
			if ( ( $page != 'wc-settings' || $tab != 'checkout' || $section != 'woocommerce_sofortueberweisung' ) && $page != 'aelia_cs_options_page' ) {
				return true;
			}

			$supported_currencies = explode( ',', self::$supported_currencies );
			$failed_currencies    = array();

			if ( is_array( $currencies ) ) {
				foreach ( $currencies AS $currency ) {
					if ( ! in_array( $currency, $supported_currencies ) ) {
						$failed_currencies[] = $currency;
					}
				}
			}

			if ( count( $failed_currencies ) === 0 ) {
				return true;
			} else {
				return $failed_currencies;
			}
		}

		/**
		 * Hold all error messages
		 *
		 * @since 1.0.0
		 *
		 * @param $key string Error/success key
		 * @param $type string Either 'error' or 'updated'
		 *
		 * @return string Error/success message
		 */
		public static function messages( $key = 'undefined', $type = 'error' ) {
			$messages = array(
				'no_woo'   => __( 'WooCommerce Sofort Banking requires WooCommerce to be installed. <a href="%s">Download it now</a>!', 'woogate' ),
				'min_woo'  => __( 'WooCommerce Sofort Banking requires WooCommerce %s or higher. <a href="%s">Upgrade now</a>!', 'woogate' ),
				'min_wp'   => __( 'WooCommerce Sofort Banking requires WordPress %s or higher. <a href="%s">Upgrade now</a>!', 'woogate' ),
				'min_php'  => __( 'WooCommerce Sofort Banking requires PHP %s or higher. Please ask your hosting company for support.', 'woogate' ),
				'cur_fail' => __( 'WooCommerce Sofort Banking does not support the currency/currencies: %s.', 'woogate' ),
			);

			return '<div id="message" class="' . $type . '"><p>' . $messages[ $key ] . '</p></div>';
		}

		/**
		 * Add links to the plugin screen
		 *
		 * @since 1.0.0
		 */
		public function add_links( $links, $file ) {
			if ( $file == self::$plugin_name ) {
				$links[] = '<a href="' . admin_url( '/admin.php?page=wc-settings&tab=checkout&section=woocommerce_sofortueberweisung' ) . '">' . __( 'Options', 'woogate' ) . '</a>';
			}

			return $links;
		}
	}

	new WooCommerce_SofortGateway();
}