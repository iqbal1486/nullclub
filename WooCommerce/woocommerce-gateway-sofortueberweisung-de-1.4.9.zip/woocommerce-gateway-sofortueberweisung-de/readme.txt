﻿=== Sofort. Banking for Woocommerce ===
Contributors: travel-junkie, awesome-ug, inpsyde
Tags: woocommerce, e-commerce, sofortüberweisung, sofortgateway
Requires at least: WP 3.3.1, WooCommerce 1.3.2.1
Tested up to: WP 5.0.3, WooCommerce 3.5.4
Stable tag: 1.4.9

Integrates Sofort. Banking into your WooCommerce online store

== Description ==
Adds Sofort. Banking by sofort.com as a payment gateway to your WooCommerce online store.

== Installation ==
1. Download the plugin
2. Upload to wp-content/plugins/
3. Activate in the backend
4. Set the options in WooCommerce -> Payment Gateways -> Sofortgateway
5. Done!

== Languages ==
* English
* German

== Disclaimer ==

We are not responsible for any harm or wrong doing this Plugin may cause. Users are fully responsible for their own use. This Plugin is to be used WITHOUT warranty.
