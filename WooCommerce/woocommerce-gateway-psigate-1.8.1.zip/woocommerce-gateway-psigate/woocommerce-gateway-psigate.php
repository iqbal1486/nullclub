<?php
/*
 * Plugin Name: WooCommerce PsiGate Payment Gateway
 * Plugin URI: https://woocommerce.com/products/psigate-gateway/
 * Description: Allows you to use <a href="http://www.psigate.com/">PsiGate</a> payment processor with the WooCommerce plugin.
 * Version: 1.8.1
 * Author: VanboDevelops
 * Author URI: http://www.vanbodevelops.com
 * Woo: 18714:6cfa2a5e4b92169a72e91181e382ecaa
 * WC requires at least: 3.0.0
 * WC tested up to: 6.2.0
 *
 *	Copyright: (c) 2012 - 2022 VanboDevelops
 *	License: GNU General Public License v3.0
 *	License URI: http://www.gnu.org/licenses/gpl-3.0.html
 */

/**
 * Required functions
 */
if ( ! function_exists( 'woothemes_queue_update' ) ) {
	require_once( 'woo-includes/woo-functions.php' );
}

/**
 * Plugin updates
 */
woothemes_queue_update( plugin_basename( __FILE__ ), '6cfa2a5e4b92169a72e91181e382ecaa', '18714' );

if ( ! is_woocommerce_active() ) {
	return;
}

class WC_PsiGate {
	
	const MIN_PHP_VERSION = '5.6.0';
	const MIN_WC_VERSION = '2.6.0';
	/**
	 * Text domain string. Constant
	 */
	const TEXT_DOMAIN = 'wc_psigate';
	/**
	 * The plugin version
	 */
	const VERSION = '1.8.1';
	/**
	 * The files and folders version
	 * Should be changes every time there is a new class file added or one deleted
	 * @since 2.0
	 */
	const FILES_VERSION = '1.3.0';
	/**
	 * WC Logger object
	 * @var object
	 */
	private static $log;
	/**
	 * Plugin URL
	 * @var string
	 */
	private static $plugin_url;
	/**
	 * Plugin Path
	 * @var string
	 */
	private static $plugin_path;
	/**
	 * Is WC Subscriptions active
	 * @var bool
	 */
	private static $is_subscriptions_active;
	/**
	 * Hold WC Subscriptions main version
	 * @var bool
	 */
	private static $is_subscriptions_version;
	/**
	 * Is WC Pre-Orders active
	 * @var bool
	 */
	private static $is_pre_orders_active;
	/**
	 * Do we have debug mode enabled
	 * @var bool
	 */
	private static $is_debug_enabled;
	/**
	 * @var \WcPsigate\Admin\Admin
	 */
	public $admin;
	
	public function __construct() {
		$this->load_autoloader();
		
		// Add a 'Settings' link to the plugin action links
		add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), array(
			$this,
			'settings_support_link',
		), 10, 4 );
		
		add_action( 'init', array( $this, 'on_init' ) );
		add_filter( 'woocommerce_payment_gateways', array( $this, 'add_psigate_gateway' ) );
	}
	
	/**
	 * Loads the plugin autoloader
	 *
	 * @since 1.5.0
	 */
	public function load_autoloader() {
		require_once( 'includes/autoloader.php' );
		
		$loader = new \WcPsigate\Autoloader( self::plugin_path(), self::FILES_VERSION, 'includes' );
		$loader->set_include_non_namespaced_classes( false );
		$loader->register();
	}
	
	public function on_init() {
		$this->load_gateway_files();
		$this->load_text_domain();
		
		// Load the manage cards class
		$this->load_manage_cards();
		
		if ( is_admin() ) {
			$this->admin = new WcPsigate\Admin\Admin();
		}
		
		$scripts = new \WcPsigate\Scripts();
		$scripts->hooks();
	}
	
	/**
	 * Localisation
	 **/
	public function load_text_domain() {
		load_plugin_textdomain( self::TEXT_DOMAIN, false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );
	}
	
	/**
	 * Loads the manage cards functionality
	 * @since 1.6.0
	 */
	public function load_manage_cards() {
		$cards = new \WcPsigate\Tokens\Psigate_Manage_Cards( $this );
		$cards->hooks();
	}
	
	/**
	 * Add 'Settings' link to the plugin actions links
	 *
	 * @since 1.1
	 * @return array associative array of plugin action links
	 */
	public function settings_support_link( $actions, $plugin_file, $plugin_data, $context ) {
		return array_merge(
			array( 'settings' => '<a href="' . \WcPsigate\Compatibility::gateway_settings_page( 'psigate' ) . '">' . __( 'Settings', self::TEXT_DOMAIN ) . '</a>' ),
			$actions
		);
	}
	
	/**
	 * Get the correct gateway class name to load
	 *
	 * @since 1.1
	 * @return string Class name
	 */
	public static function get_gateway_class() {
		if ( self::is_pre_orders_active()
		     || self::is_subscriptions_active() ) {
			$methods = '\\WcPsigate\\Gateway_PsiGate_Addons';
		} else {
			$methods = '\\WcPsigate\\Gateway_PsiGate';
		}
		
		return $methods;
	}
	
	/**
	 * Load gateway files
	 *
	 * @since 1.1
	 */
	public function load_gateway_files() {
		
		include_once( 'includes/class-wc-compat-psigate.php' );
		include_once( 'includes/class-wc-gateway-psigate.php' );
		include_once( 'includes/tokens/class-wc-payment-token-psigate-cc.php' );
		
		if ( self::is_pre_orders_active()
		     || self::is_subscriptions_active() ) {
			include_once( 'includes/class-wc-gateway-psigate-addons.php' );
		}
	}
	
	/**
	 * Safely get POST variables
	 *
	 * @since      1.1
	 *
	 * @deprecated Use the "\WcPsigate\Helpers\Retrievers::get_post" instead
	 *
	 * @param string $name POST variable name
	 *
	 * @return string The variable value
	 */
	public static function get_post( $name, $default = '' ) {
		return \WcPsigate\Helpers\Retrievers::get_post( $name, $default );
	}
	
	/**
	 * Safely get GET variables
	 *
	 * @since      1.1
	 *
	 * @deprecated Use the "\WcPsigate\Helpers\Retrievers::get_get" instead
	 *
	 * @param string $name GET variable name
	 *
	 * @return string The variable value
	 */
	public static function get_get( $name, $default = '' ) {
		return \WcPsigate\Helpers\Retrievers::get_get( $name, $default );
	}
	
	/**
	 * Get an array field
	 *
	 * @deprecated Use the "\WcPsigate\Helpers\Retrievers::get_field" instead
	 *
	 * @param string $name    Field name
	 * @param array  $array   The array
	 * @param string $default Default value
	 *
	 * @return string
	 */
	public static function get_field( $name, $array, $default = '' ) {
		return \WcPsigate\Helpers\Retrievers::get_field( $name, $array, $default );
	}
	
	/**
	 * Add the gateway to WooCommerce
	 *
	 * @since 1.1
	 *
	 * @param array $methods
	 *
	 * @return array
	 */
	function add_psigate_gateway( $methods ) {
		$methods[] = self::get_gateway_class();
		
		return $methods;
	}
	
	/**
	 * Add debug log message
	 *
	 * @since 1.1
	 *
	 * @param string $message
	 */
	public static function add_debug_log( $message ) {
		if ( ! is_object( self::$log ) ) {
			self::$log = \WcPsigate\Compatibility::get_wc_logger();
		}
		
		if ( self::is_debug_enabled() ) {
			self::$log->add( 'psigate', $message );
		}
	}
	
	/**
	 * Check, if debug logging is enabled
	 *
	 * @since 1.2
	 * @return bool
	 */
	public static function is_debug_enabled() {
		if ( null !== self::$is_debug_enabled ) {
			return self::$is_debug_enabled;
		} else {
			$psigate = get_option( 'woocommerce_psigate_settings' );
			
			self::$is_debug_enabled = ( 'yes' == $psigate['debug'] );
			
			return self::$is_debug_enabled;
		}
	}
	
	/**
	 * Get the plugin url
	 *
	 * @since 1.1
	 * @return string
	 */
	public static function plugin_url() {
		if ( self::$plugin_url ) {
			return self::$plugin_url;
		}
		
		return self::$plugin_url = untrailingslashit( plugins_url( '/', __FILE__ ) );
	}
	
	/**
	 * Get the plugin path
	 *
	 * @since 1.1
	 * @return string
	 */
	public static function plugin_path() {
		if ( self::$plugin_path ) {
			return self::$plugin_path;
		}
		
		return self::$plugin_path = untrailingslashit( plugin_dir_path( __FILE__ ) );
	}
	
	/**
	 * Detect if WC Subscriptions is active
	 *
	 * @since 1.1
	 * @return bool True if active, False if not
	 */
	public static function is_subscriptions_active() {
		if ( is_bool( self::$is_subscriptions_active ) ) {
			return self::$is_subscriptions_active;
		}
		
		self::$is_subscriptions_active = false;
		if ( class_exists( 'WC_Subscriptions' ) || function_exists( 'wcs_order_contains_subscription' ) ) {
			self::$is_subscriptions_active = true;
		}
		
		return self::$is_subscriptions_active;
	}
	
	/**
	 * Get back the Subscriptions version.
	 *
	 * @since 1.3
	 * @return bool Main Subscriptions version number (e.i. 1, 2, 3), False, if Subscriptions is not active
	 */
	public static function get_subscriptions_version() {
		if ( null !== self::$is_subscriptions_version ) {
			return self::$is_subscriptions_version;
		}
		
		self::$is_subscriptions_version = false;
		
		if ( function_exists( 'wcs_order_contains_subscription' ) ) {
			self::$is_subscriptions_version = 2;
		} elseif ( class_exists( 'WC_Subscriptions' ) ) {
			self::$is_subscriptions_version = 1;
		}
		
		return self::$is_subscriptions_version;
	}
	
	/**
	 * Detect if Pre-Orders is active
	 *
	 * @since 1.1
	 * @return bool True if active, False if not
	 */
	public static function is_pre_orders_active() {
		if ( is_bool( self::$is_pre_orders_active ) ) {
			return self::$is_pre_orders_active;
		}
		
		self::$is_pre_orders_active = false;
		if ( class_exists( 'WC_Pre_Orders' ) ) {
			self::$is_pre_orders_active = true;
		}
		
		return self::$is_pre_orders_active;
	}
	
	/**
	 * Verify a form request action
	 *
	 * @since      1.1
	 *
	 * @deprecated Use the "\WcPsigate\Helpers\Validators::verify_request" method instead
	 *
	 * @param string $name
	 * @param string $action
	 *
	 * @throws Exception
	 */
	public static function verify_request( $name, $action ) {
		\WcPsigate\Helpers\Validators::verify_request( $name, $action );
	}
}

add_action( 'plugins_loaded', 'load_psigate_plugin' );
function load_psigate_plugin() {
	new WC_PsiGate();
}