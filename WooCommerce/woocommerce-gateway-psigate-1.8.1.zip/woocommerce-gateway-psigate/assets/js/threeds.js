/* global wc_checkout_params */
/* global wc_psigate_threeds_params */
(function ($) {

	$(document.body).on('updated_checkout', function () {
		var updateForm = $('form.checkout');
		if ('' === updateForm.prop('id')) {
			updateForm.prop('id', checkoutBypass.getFormId());
		} else {
			wc_psigate_threeds_params.formId = updateForm.prop('id');
		}

		// Needs proper setup for the checkout page
		checkoutBypass.form = checkoutBypass.getForm();
		checkoutBypass.formId = checkoutBypass.getFormId();
		checkoutBypass.bindFormSubmissions();
	});

	var checkoutBypass = {

		formId                       : false,
		threeDS                      : false,
		iframeDisplayed              : false,
		dialog                       : false,
		threeDSSucceeded             : false,
		threeDSProcessed             : false,
		challengeDialogManuallyClosed: false,
		isCheckoutBinded             : false,
		formSubmitted                : false,

		init: function () {
			checkoutBypass.formId = checkoutBypass.getFormId();
			checkoutBypass.form = checkoutBypass.getForm();

			// Init bindings if we are not on the checkout page
			if (!checkoutBypass.isCheckoutPage()) {
				checkoutBypass.bindFormSubmissions();
			}

			// Transfer the month/year to the appropriate fields
			$('body').on('focusout', '#psigate-card-expiry', function () {
				var field = $('#psigate-card-expiry');
				var expiry = $.payment.cardExpiryVal(
					field.val(),
				);

				$('.psigate_exp_month').val(expiry.month);
				$('.psigate_exp_year').val(expiry.year);
			});

			// Main error handling
			$(document.body).on('checkout_error', function () {
				checkoutBypass.threeDSProcessed = false;
			});

			// Form error handling
			$(document.body)
				.on('psigateErrored', checkoutBypass.onError)
				.on('checkout_error', checkoutBypass.resetErrors);
			$('form.woocommerce-checkout').on('change', checkoutBypass.resetErrors);
			checkoutBypass.getForm().on('change keyup', checkoutBypass.resetErrors);
		},

		/**
		 * Inits the ThreeDS object
		 */
		initThreeDS: function () {

			if (checkoutBypass.threeDS) {
				return;
			}

			var data = {
				verbose               : checkoutBypass.isScriptDev(),
				autoSubmit            : false,
				protocolVersion       : wc_psigate_threeds_params.protocol,
				eciInputId            : 'psigate_eci',
				cavvInputId           : 'psigate_cavv',
				xidInputId            : 'psigate_xid',
				protocolVersionInputId: 'psigate_protocol',
				statusInputId         : 'psigate_status',
				iframeId              : 'psigate_iframe',
				showChallenge         : true,
				timeout               : wc_psigate_threeds_params.dialogTimeout,
				prompt                : function () {
					if (checkoutBypass.iframeDisplayed) {
						return;
					}

					checkoutBypass.displayChallengeIframe();
				},
			};

			if (checkoutBypass.isTestmode()) {
				data.endpoint = wc_psigate_threeds_params.threedsUrl;
			}

			checkoutBypass.threeDS = new ThreeDS(
				checkoutBypass.formId,
				wc_psigate_threeds_params.apiKey,
				null,
				data,
			);
		},

		isPayingWithNewCard: function () {
			var el = $('input#psigate_card_new');

			return 0 === el.length || el.is(':checked');
		},

		isPayingWithCard: function () {
			var choice = $('input[name=psigate_payment_type_choice]:checked');
			if (0 < choice.length) {
				return 'cc' === choice.val() || 'card' === choice.val();
			}

			return true;
		},

		/**
		 * @since 1.7.0
		 */
		areAllRequiredFieldsValid: function () {
			var allBillingFields = $('body').find("[data-threeds-type='billing']");
			var allShippingFields = $('body').find("[data-threeds-type='shipping']");

			var areAllBillingFieldsValid = true;
			try {

				allBillingFields.each(function () {
					var el = $(this).closest('.form-row');

					if (el.hasClass('validate-required') && el.hasClass('woocommerce-invalid')) {
						areAllBillingFieldsValid = false;
					}
				});


				if (!areAllBillingFieldsValid) {
					throw {};
				}

				if ($("#ship-to-different-address-checkbox").is(':checked')) {
					var areAllShippingFieldsValid = true;
					allShippingFields.each(function () {
						var el = $(this).closest('.form-row');

						if (el.hasClass('validate-required') && el.hasClass('woocommerce-invalid')) {
							areAllShippingFieldsValid = false;
						}
					});

					if (!areAllShippingFieldsValid) {
						throw {};
					}
				}

			} catch (obj) {
				checkoutBypass.consoleLog('Not all fields are valid: ');

				checkoutBypass.submit_error('<div class="woocommerce-error">' + wc_psigate_threeds_params.il8n.requiredFieldsMessage + '</div>');
				return false;
			}
			return true;
		},

		/**
		 * Replace the WC Checkout
		 * @since 3.7.0
		 */
		bindFormSubmissions: function () {

			if (checkoutBypass.isChangePaymentMethodPage()) {
				// Remove the submit action, which adds an overlay over the form
				checkoutBypass.form.off('submit');

				checkoutBypass.form.on('submit', function (e) {
					try {
						if (!checkoutBypass.isPsigateChecked()
							|| !checkoutBypass.isPayingWithCard()
							|| !checkoutBypass.isPayingWithNewCard()
							|| true === checkoutBypass.threeDSProcessed) {
							return true;
						}

						checkoutBypass.validateCardFields(checkoutBypass.getForm());

						return true;
					} catch (error) {
						$(document.body).trigger('psigateErrored', error);
					}

					return false;
				});
				return;
			}

			// Bind the change payment method submission
			if (checkoutBypass.isPayForOrderPage() && !checkoutBypass.isChangePaymentMethodPage()) {
				// Remove the submit action, which adds an overlay over the form
				checkoutBypass.form.off('submit');

				checkoutBypass.form.on('submit', function (e) {
					try {
						if (!checkoutBypass.isPsigateChecked()
							|| !checkoutBypass.isPayingWithCard()
							|| !checkoutBypass.isPayingWithNewCard()
							|| true === checkoutBypass.threeDSProcessed) {
							// Block the page when on "Pay for order" because WC does not do it
							if (checkoutBypass.isPayForOrderPage()) {
								checkoutBypass.block(checkoutBypass.getForm());
							}

							// Stop the 3ds result pings
							checkoutBypass.threeDS.shouldContinueThreeDSPings = false;

							return true;
						}
						checkoutBypass.validateCardFields(checkoutBypass.getForm());
						checkoutBypass.block(checkoutBypass.getForm());

						// 1. Verify the 3DS
						checkoutBypass.verifyCard3DS();
					} catch (error) {
						$(document.body).trigger('psigateErrored', error);
					}

					return false;
				});
				return;
			}

			if (true === checkoutBypass.isCheckoutBinded) {
				return;
			}

			// Bind once
			checkoutBypass.isCheckoutBinded = true;

			// Normal checkout
			checkoutBypass.form.on('checkout_place_order_psigate', checkoutBypass.submitCheckoutForm);
		},

		/**
		 * Run verification
		 */
		verifyCard3DS: function () {
			checkoutBypass.initThreeDS();


			// Stop the 3ds result pings
			checkoutBypass.threeDS.shouldContinueThreeDSPings = true;

			var iframeDialog = $('body .wc-psigate-iframe-wrap');
			checkoutBypass.addIframe(iframeDialog, checkoutBypass.threeDS.options.iframeId);

			checkoutBypass.threeDS.verify(
				function (response) {
					checkoutBypass.threeDSProcessed = true;

					checkoutBypass.consoleLog('verifyCard3DS: verify-success: response: ', response);

					checkoutBypass.threeDSSucceeded = true;
					if (false !== checkoutBypass.dialog && checkoutBypass.dialog.dialog("isOpen")) {
						checkoutBypass.dialog.dialog("close");
					}

					checkoutBypass.form.trigger("submit");
				},
				function (rejected_response) {
					try {
						rejected_response = JSON.parse(rejected_response);

						checkoutBypass.consoleLog('verifyCard3DS: verify-failed: response: ', rejected_response);

						checkoutBypass.consoleLog('verifyCard3DS: verify-failed: iframeDisplayed: ', checkoutBypass.iframeDisplayed);

						if (checkoutBypass.iframeDisplayed) {
							return false;
						}

						/*
						 * - Challenge - Process transaction without 3DS
						 */
						if (rejected_response.correlationId
							&& rejected_response.transactionId
							&& !checkoutBypass.challengeDialogManuallyClosed
						) {
							checkoutBypass.consoleLog('verifyCard3DS: verify-failed: pollingResponse: ', checkoutBypass.threeDS.pollingResponse);

							// Unlock the checkout form
							checkoutBypass.unblock(checkoutBypass.form);

							checkoutBypass.submit_error('<div class="woocommerce-error">' + rejected_response.error + '</div>');
							return false;
						}

						if (!checkoutBypass.isUndefined(rejected_response.error)) {
							// Unlock the checkout form
							checkoutBypass.unblock(checkoutBypass.form);

						}
					} catch (error) {
						// Error occurred, so we want to display it and stop the form from submitting
						$(document.body).trigger('psigateErrored', error);
						return false;
					}
				},
				{
					amount: parseFloat($('.psigate_amount').val()),
				},
			);
		},

		/**
		 * Submitting the checkout form
		 *
		 * @since 1.7.0
		 *
		 * @returns {boolean}
		 */
		submitCheckoutForm: function () {
			// Global parameter preValidateFields added to verify if fields validation is needed and applicable
			try {
				if (checkoutBypass.isPayingWithNewCard()) {
					checkoutBypass.validateCardFields(checkoutBypass.getForm());
				}

				if (checkoutBypass.isPreValidateFields() && !checkoutBypass.areAllRequiredFieldsValid()) {
					checkoutBypass.consoleLog('submitCheckoutForm: Not all required fields are filed in');
					return false;
				}

				if (!checkoutBypass.isPayingWithCard() || !checkoutBypass.isPayingWithNewCard()) {
					checkoutBypass.consoleLog('submitCheckoutForm: Not paying with a card');
					return true;
				}

				checkoutBypass.consoleLog('submitCheckoutForm: 3DS threeDSProcessed: ', checkoutBypass.threeDSProcessed);
				if (true === checkoutBypass.threeDSProcessed) {
					return true;
				}

				// Block the checkout form
				checkoutBypass.block(checkoutBypass.form);

				checkoutBypass.verifyCard3DS();

				return false;
			} catch (error) {
				$(document.body).trigger('psigateErrored', error);
				return false;
			}
		},

		addIframe: function (parent, id) {
			$('#' + id).remove();
			var iframe = $('<iframe></iframe>').prop('id', id).prop('style', 'display:none');
			parent.append(iframe)
		},

		/**
		 * Displays the challenge Iframe in a modal dialog window
		 */
		displayChallengeIframe: function () {
			var iframeDialog = $('body .wc-psigate-iframe-wrap');

			// Check is it object and is it open
			if (false !== checkoutBypass.dialog && checkoutBypass.dialog.dialog("isOpen")) {
				return;
			}

			checkoutBypass.consoleLog('displayChallengeIframe: pollingResponse: ', checkoutBypass.threeDS.pollingResponse);

			if (!"methodURL" in checkoutBypass.threeDS.pollingResponse && !"AcsURL" in checkoutBypass.threeDS.pollingResponse) {
				return;
			}

			checkoutBypass.dialog = iframeDialog.dialog({
				minHeight: 400,
				minWidth : 300,
				close    : function (event, ui) {
					checkoutBypass.iframeDisplayed = false;
					checkoutBypass.challengeDialogManuallyClosed = true;
					checkoutBypass.threeDS.shouldContinueThreeDSPings = false;
					checkoutBypass.consoleLog('displayChallengeIframe: dialog-close: threeDSSucceeded: ', checkoutBypass.threeDSSucceeded);

					if (false === checkoutBypass.threeDSSucceeded) {
						checkoutBypass.unblock(checkoutBypass.form);
						checkoutBypass.submit_error('<div class="woocommerce-error">' + wc_psigate_threeds_params.il8n.verificationFailedMessage + '</div>');
					}
				},
				create   : function (event, ui) {

					checkoutBypass.challengeDialogManuallyClosed = false;

					if (parseFloat(checkoutBypass.threeDS.protocolVersion) >= 2) {
						checkoutBypass.iframeDisplayed = "methodURL" in checkoutBypass.threeDS.pollingResponse && checkoutBypass.threeDS.createIframe({
							threeDSMethodData: checkoutBypass.threeDS.pollingResponse.threeDSMethodData,
							methodURL        : checkoutBypass.threeDS.pollingResponse.methodURL,
						}, checkoutBypass.threeDS.options.iframeId);
					} else {
						checkoutBypass.iframeDisplayed = "AcsURL" in checkoutBypass.threeDS.pollingResponse && checkoutBypass.threeDS.createIframe({
							AcsURL : checkoutBypass.threeDS.pollingResponse.AcsURL,
							MD     : checkoutBypass.threeDS.pollingResponse.MD,
							PaReq  : checkoutBypass.threeDS.pollingResponse.PaReq,
							TermUrl: checkoutBypass.threeDS.pollingResponse.TermUrl,
						}, checkoutBypass.threeDS.options.iframeId);
					}

					/*
					 *  Friction
					 * - Challenge - Show Iframe in modal and wait until challenge completed. Process with 3DS
					 */
					iframeDialog.show();
				},
			});
		},

		handleUnloadEvent: function (e) {
			// Modern browsers have their own standard generic messages that they will display.
			// Confirm, alert, prompt or custom message are not allowed during the unload event
			// Browsers will display their own standard messages

			// Check if the browser is Internet Explorer
			if ((navigator.userAgent.indexOf('MSIE') !== -1) || (!!document.documentMode)) {
				// IE handles unload events differently than modern browsers
				e.preventDefault();
				return undefined;
			}

			return true;
		},

		submit_error: function (error_message) {
			$('.woocommerce-NoticeGroup-checkout, .woocommerce-error, .woocommerce-message').remove();

			checkoutBypass.form.prepend('<div class="woocommerce-NoticeGroup woocommerce-NoticeGroup-checkout">' + error_message + '</div>'); // eslint-disable-line max-len

			checkoutBypass.resetCheckoutForm();
			checkoutBypass.scroll_to_notices();

			$(document.body).trigger('checkout_error');
		},

		/**
		 * Resets the psigate displayed errors
		 */
		resetErrors: function () {
			$('.wc-psigate-error').remove();
		},

		/**
		 * Displays the psigate errors
		 * @param e
		 * @param result
		 */
		onError: function (e, result) {
			var message = result.message;
			var type = 'card' === result.form || 'check';
			checkoutBypass.resetErrors();

			var appendTo = result.appendTo || $('#psigate-cc-form');

			appendTo.after('<ul class="woocommerce_error woocommerce-error wc-psigate-error"><li>' + message + '</li></ul>');

			var errorObj = $('.wc-psigate-error');
			if (errorObj.length) {
				$('html, body').animate({
					scrollTop: (errorObj.offset().top - 200),
				}, 200);
			}
		},

		resetCheckoutForm: function () {
			checkoutBypass.form.removeClass('processing').unblock();
			checkoutBypass.form.find('.input-text, select, input:checkbox').trigger('validate').blur();
		},

		scroll_to_notices: function () {
			var scrollElement = $('.woocommerce-NoticeGroup-updateOrderReview, .woocommerce-NoticeGroup-checkout');

			if (!scrollElement.length) {
				scrollElement = checkoutBypass.form;
			}
			$.scroll_to_notices(scrollElement);
		},

		isUndefined: function (e) {
			return 'undefined' === typeof (e);
		},

		isPsigateChecked: function () {
			return $('#payment_method_psigate').is(':checked');
		},

		/**
		 * Log to console
		 * @param message
		 * @param object
		 */
		consoleLog: function (message, object) {
			object = object || {};

			if (checkoutBypass.isScriptDev()) {
				console.log(message, object);
			}
		},

		/**
		 * Is the script in development mode
		 * @returns {boolean}
		 */
		isScriptDev: function () {
			return !checkoutBypass.isUndefined(wc_psigate_threeds_params.scriptDev) && '1' === wc_psigate_threeds_params.scriptDev;
		},


		isPreValidateFields: function () {
			return !checkoutBypass.isUndefined(wc_psigate_threeds_params.preValidateFields) && '1' === wc_psigate_threeds_params.preValidateFields;
		},

		isTestmode: function () {
			return !checkoutBypass.isUndefined(wc_psigate_threeds_params.testmode) && '1' === wc_psigate_threeds_params.testmode;
		},

		processWithRejection: function () {
			return !checkoutBypass.isUndefined(wc_psigate_threeds_params.processWithRejection) && '1' === wc_psigate_threeds_params.processWithRejection;
		},

		/**
		 * Is this the add payment method page
		 * @returns {boolean}
		 */
		isAddPaymentMethodPage: function () {
			return !checkoutBypass.isUndefined(wc_psigate_threeds_params.isAddPaymentMethodPage) && '1' === wc_psigate_threeds_params.isAddPaymentMethodPage;
		},

		/**
		 * Is this the update method page
		 * @returns {boolean}
		 */
		isUpdatePaymentMethodPage: function () {
			return !checkoutBypass.isUndefined(wc_psigate_threeds_params.isUpdatePaymentMethodPage) && '1' === wc_psigate_threeds_params.isUpdatePaymentMethodPage;
		},

		/**
		 * Is this the pay for order page
		 * @returns {boolean}
		 */
		isPayForOrderPage: function () {
			return !checkoutBypass.isUndefined(wc_psigate_threeds_params.isPayForOrderPage) && '1' === wc_psigate_threeds_params.isPayForOrderPage;
		},

		/**
		 * Is this the pay for order page
		 * @returns {boolean}
		 */
		isCheckoutPayPage: function () {
			return !checkoutBypass.isUndefined(wc_psigate_threeds_params.isCheckoutPayPage) && '1' === wc_psigate_threeds_params.isCheckoutPayPage;
		},

		/**
		 * Is this the checkout page
		 * @returns {boolean}
		 */
		isCheckoutPage: function () {
			return !checkoutBypass.isUndefined(wc_psigate_threeds_params.isCheckoutPage) && '1' === wc_psigate_threeds_params.isCheckoutPage;
		},

		/**
		 * Is this change payment method page
		 * @returns {boolean}
		 */
		isChangePaymentMethodPage: function () {
			return !checkoutBypass.isUndefined(wc_psigate_threeds_params.isChangePaymentMethodPage) && '1' === wc_psigate_threeds_params.isChangePaymentMethodPage;
		},

		/**
		 * Returns the payment form element
		 * @returns {*|jQuery|HTMLElement}
		 */
		getForm: function () {
			var form = $('body #' + wc_psigate_threeds_params.formId);
			if (checkoutBypass.isAddPaymentMethodPage()) {
				form = $('body #add_payment_method');
			} else if (checkoutBypass.isPayForOrderPage()) {
				form = $('body form#order_review');
			}

			return form;
		},

		/**
		 * Returns the payment form ID
		 * @returns String
		 */
		getFormId: function () {
			var form = wc_psigate_threeds_params.formId;
			if (checkoutBypass.isAddPaymentMethodPage()) {
				form = 'add_payment_method';
			} else if (checkoutBypass.isPayForOrderPage()) {
				form = 'order_review';
			}

			return form;
		},

		/**
		 * Validates the card fields and throws a generic error for each
		 * @param form
		 */
		validateCardFields: function (form) {
			// Allow third party to validate before we do
			if (false !== $(document.body).triggerHandler('psigate_validate_card_fields', form, checkoutBypass) && checkoutBypass.isPayingWithNewCard()) {
				checkoutBypass.consoleLog('ValidateCardFields', form);

				checkoutBypass.validateCardNumber(form);
				checkoutBypass.validateCardExpiry(form);
				checkoutBypass.validateCardCvc(form);
			}
		},

		/**
		 * Validates the card number of the passed form
		 * @param form
		 */
		validateCardNumber: function (form) {
			if (!$.payment.validateCardNumber(form.find('input#psigate-card-number').val())) {
				throw new psigateError(wc_psigate_threeds_params.il8n['cardNumberNotValid'], 'card', form.find('input#psigate-card-number'));
			}
		},

		/**
		 * Validates the card expiry of the passed form
		 * @param form
		 */
		validateCardExpiry: function (form) {
			if (!$.payment.validateCardExpiry(
				$.payment.cardExpiryVal(
					form.find('input#psigate-card-expiry').val(),
				),
			)
			) {
				throw new psigateError(wc_psigate_threeds_params.il8n['cardExpiryNotValid'], 'card', form.find('input#psigate-card-expiry'));
			}
		},

		/**
		 * Validates the card cvc of the passed form
		 * @param form
		 */
		validateCardCvc: function (form) {
			// Pass the type if paying with a new card
			var type = checkoutBypass.isPayingWithNewCard() ? $.payment.cardType(form.find('input#psigate-card-number').val()) : null;

			if (!$.payment.validateCardCVC(form.find('input#psigate-card-cvc').val(), type)) {
				throw new psigateError(wc_psigate_threeds_params.il8n['cardCvcNotValid'], 'card', form.find('input#psigate-card-cvc'));
			}
		},

		block: function (el, message) {
			if (checkoutBypass.isUndefined(el)) {
				return false;
			}

			if (!checkoutBypass.isFunction(el, 'block')) {
				return;
			}

			message = !checkoutBypass.isUndefined(message) ? '<p>' + message + '</p>' : '';

			el.block({
				message   : message,
				overlayCSS: {
					background: '#fff',
					opacity   : 0.6,
				},
			});
		},

		unblock: function (el) {
			if (checkoutBypass.isUndefined(el)) {
				return false;
			}

			if (!checkoutBypass.isFunction(el, 'block')) {
				return;
			}

			el.unblock();
		},

		/**
		 * @param el
		 * @param val
		 * @returns {*|boolean|boolean}
		 */
		isFunction: function (el, val) {
			return typeof el[val] !== "undefined" && typeof el[val] === "function";
		},
	};

	var psigateError = function (message, form, element) {
		this.message = message;
		this.form = form || 'card';
		this.appendTo = element || false;
	}

	$(document).ready(function () {
		checkoutBypass.init();
	});
})(jQuery);