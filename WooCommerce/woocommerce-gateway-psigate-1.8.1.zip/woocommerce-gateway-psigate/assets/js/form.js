/* global wc_psigate_params */
(function ($) {
	$(document).ready(function () {
		var Psigate = {
			$orderReview   : $('#order_review'),
			$checkoutForm  : $('form.checkout'),
			$paymentMethods: $('.payment_methods'),
			$defaultType   : wc_psigate_params.defaultPaymentType,


			init: function () {
				$(document.body).on('update_checkout', Psigate.onUpdateCheckout);
				$(document.body).on('updated_checkout', Psigate.onUpdatedCheckout);

				Psigate.formBindField = Psigate.getBindElement();
				Psigate.wcForm = $(Psigate.formBindField);

				Psigate.wcForm.on('click', '#psigate_payment_choices_wrapper input', Psigate.switchPaymentOption);
				Psigate.wcForm.on('change', 'input[name=psigate-used-cc]', Psigate.toggleCardForm);

				// Payment methods
				Psigate.wcForm.on('change', 'input[name="payment_method"]', Psigate.onPaymentMethodChange);
				Psigate.wcForm.on('change', 'input[name="psigate_payment_type_choice"]', Psigate.onPsigateOptionChange);

				Psigate.maybeHideUseNewToken();
				Psigate.activateDefaultPaymentSelection();
				Psigate.triggerDefaultSwitcherInput();
				Psigate.toggleSaveToAccount();
			},

			/**
			 * @since
			 * @returns {string}
			 */
			getBindElement: function () {
				var el = 'form.woocommerce-checkout';
				if (Psigate.isChangePaymentMethodPage()
					|| Psigate.isPayForOrderPage()) {
					el = '#order_review';
				} else if (Psigate.isAddPaymentMethodPage()) {
					el = '#add_payment_method';
				}

				return el;
			},

			switchPaymentOption: function (e) {
				var el = $(e.target);
				var root = el.closest('.payment_method_psigate');
				var card_block = root.find('#psigate_card_description');
				var tokens_block = root.find('.woocommerce-psigate-SavedPaymentMethods-wrapper');
				var interac_block = root.find('.psigate_interac_description');

				if (el.val() == 'interac') {
					card_block.hide();
					tokens_block.hide();
					interac_block.show();
				} else {
					card_block.show();
					tokens_block.show();
					interac_block.hide()
				}

			},

			toggleCardForm: function () {
				if ($('input[name=psigate-used-cc]:checked').val() == 'new') {
					$('fieldset#psigate-cc-form').show();
				} else {
					$('fieldset#psigate-cc-form').slideUp(250);
				}
			},

			onPsigateOptionChange: function () {
				var method = Psigate.wcForm.find('#payment_method_psigate');
				var selected = $('input[name="psigate_payment_type_choice"]:checked').val();

				method.click();

				var is_checked = method.is(':checked');
				if (is_checked) {
					Psigate.showSelectedPaymentBox(selected);
				}
			},

			showSelectedPaymentBox: function (boxName) {
				var target_payment_box = $('div.payment_box.payment_method_' + boxName + '_psigate');

				if (0 < target_payment_box.length) {
					target_payment_box.slideDown();
				}
			},

			activateDefaultPaymentSelection: function () {
				var is_checked = Psigate.isGatewayChecked();
				var paymentOption = Psigate.getPaymentOption();

				if (is_checked) {
					var checkedType = $('input#payment_method_' + Psigate.$defaultType + '_psigate');

					if (0 < checkedType.length) {
						checkedType.trigger('click');
						Psigate.showSelectedPaymentBox(checkedType.val());
					} else {
						paymentOption.first().trigger('click');
						Psigate.showSelectedPaymentBox(paymentOption.first().val())
					}
				} else {
					// Hide the gateway forms when another gateway is selected
					Psigate.hideGatewayPaymentBoxes();
				}
			},

			/**
			 * Hides the gateway payment boxes
			 */
			hideGatewayPaymentBoxes: function () {
				var paymentBox = $('div.payment_box');
				paymentBox.filter(':visible').filter('.payment_box_psigate').hide();
			},

			maybeHideUseNewToken: function () {
				var tokensWrapper = Psigate.wcForm.find('.woocommerce-psigate-SavedPaymentMethods-card');
				if (0 < tokensWrapper.length && 0 === tokensWrapper.data('count')) {
					$('.woocommerce-SavedPaymentMethods-new', tokensWrapper).remove();
				}
			},

			isGatewayChecked: function () {
				return Psigate.wcForm.find('#payment_method_psigate').is(':checked');
			},

			getPaymentOption: function (selected) {
				selected = true === selected;
				var selectorChecked = selected ? ':checked' : '';

				return Psigate.wcForm.find('input[name="psigate_payment_type_choice"]' + selectorChecked);
			},

			onPaymentMethodChange: function () {
				var clicked = $(this);
				var paymentOption = Psigate.getPaymentOption(true);

				if ('psigate' != clicked.val()) {
					paymentOption.prop('checked', false);
				}
			},

			onUpdateCheckout: function () {
				var payBox = Psigate.getPaymentOption(true);
				if ('' !== payBox.val()) {
					Psigate.$defaultType = payBox.val();
				}
			},

			onUpdatedCheckout: function (data) {
				Psigate.activateDefaultPaymentSelection();
				Psigate.triggerDefaultSwitcherInput();
				Psigate.maybeHideUseNewToken();
				Psigate.toggleSaveToAccount();
			},

			triggerDefaultSwitcherInput: function () {
				if ('card' === Psigate.$defaultType) {
					Psigate.wcForm.find('#psigate_payment_choices_wrapper input#psigate_cc_choice').trigger('click');
				} else {
					Psigate.wcForm.find('#psigate_payment_choices_wrapper input#psigate_interac_online_choice').trigger('click');
				}
			},

			toggleSaveToAccount: function () {
				var createAccount = $('input#createaccount');
				if ( 0 === createAccount.length  ) {
					return;
				}

				// Hide the option and only show when the create account is checked
				$('div.psigate-create-account').hide();
				if (createAccount.is(':checked')) {
					$('div.psigate-create-account').slideDown();
				}
			},

			isUndefined: function (e) {
				return 'undefined' === typeof (e);
			},

			/**
			 * @since 1.0.0
			 * @returns {boolean}
			 */
			isAddPaymentMethodPage: function () {
				return !Psigate.isUndefined(wc_psigate_params.isAddPaymentMethodPage) && '1' === wc_psigate_params.isAddPaymentMethodPage;
			},

			/**
			 * @since 1.0.0
			 * @returns {boolean}
			 */
			isPayForOrderPage: function () {
				return !Psigate.isUndefined(wc_psigate_params.isPayForOrderPage) && '1' === wc_psigate_params.isPayForOrderPage;
			},

			/**
			 * @since 1.0.0
			 * @returns {boolean}
			 */
			isCheckoutPage: function () {
				return !Psigate.isUndefined(wc_psigate_params.isCheckoutPage) && '1' === wc_psigate_params.isCheckoutPage;
			},

			/**
			 * @since 1.0.0
			 * @returns {boolean}
			 */
			isChangePaymentMethodPage: function () {
				return !Psigate.isUndefined(wc_psigate_params.isChangePaymentMethodPage) && '1' === wc_psigate_params.isChangePaymentMethodPage;
			},
		};
		$(document).ready(function () {
			Psigate.init();
		});
	});
})(jQuery);