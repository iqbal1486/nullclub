<?php
/**
 * Interac Online description
 *
 * Override this template by copying it to yourtheme/woocommerce/checkout/psigate-interac-online-instructions.php
 *
 * @var \WcPsigate\Gateway_PsiGate $gateway The PsiGate object
 *
 * @since 1.4
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>
<div id="<?php echo esc_attr( $gateway->id ); ?>_interac_description" class="<?php echo esc_attr( $gateway->id ); ?>_interac_description" style="display:none;">
	<?php echo wpautop( wptexturize( $gateway->html_description ) ); ?>
</div>