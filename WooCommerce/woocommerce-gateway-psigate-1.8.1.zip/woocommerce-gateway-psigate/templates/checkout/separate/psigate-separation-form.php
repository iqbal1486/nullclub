<?php
/**
 * Separate payment fields for the Checks and Cards
 *
 * @since  2.1.0
 * @author VanboDevelops
 * @var \WcPsigate\Gateway_PsiGate $gateway
 * @var \WcPsigate\Payment_Form    $form
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>
	<style type="text/css">
			.methods .wc_payment_method.payment_method_psigate,
			.woocommerce-PaymentMethods .payment_method_psigate {
				display: none;
			}

			.payment_box_psigate_card,
			.payment_box_psigate_check {
				display: none;
			}
	</style>
<?php

foreach ( $form->get_form_data() as $form_data ) {
	?>

	</div></li>
<li class="wc_payment_method payment_method_<?php echo esc_attr( $form_data['slug'] ); ?>_<?php echo esc_attr( $form->get_gateway()->id ); ?>">
	<input
		id="payment_method_<?php echo esc_attr( $form_data['slug'] ); ?>_<?php echo esc_attr( $form->get_gateway()->id ); ?>"
		type="radio"
		class="input-radio"
		value="<?php echo esc_attr( $form_data['slug'] ); ?>"
		name="<?php echo esc_attr( $form->get_gateway()->id ); ?>_payment_type_choice"
		data-order_button_text="<?php echo esc_attr( $form_data['label'] ); ?>">
	<label for="payment_method_<?php echo esc_attr( $form_data['slug'] ); ?>_<?php echo esc_attr( $form->get_gateway()->id ); ?>">
		<?php
		echo $form_data['label'];
		echo $form->get_gateway()->get_payment_type_images( $form_data['slug'] );
		?>
	</label>
<div class="woocommerce-PaymentBox payment_box payment_box_psigate payment_method_<?php echo esc_attr( $form_data['slug'] ); ?>_<?php echo esc_attr( $form->get_gateway()->id ); ?>" style="display: block;">
	<?php
	if ( $form_data['description'] ) {
		echo wpautop( wptexturize( $form_data['description'] ) );
	}
	
	if ( 'interac' == $form_data['slug'] ) {
		$form->maybe_output_interac_form();
	} elseif ( 'card' == $form_data['slug'] ) {
		$form->output_card_blocks();
	} else {
		do_action( 'wc_psigate_payment_option_html', $form_data, $form );
	}
	?>
<?php }