<?php
/**
 * PsiGate Payment Form Saved Cards Template
 *
 * @version 1.6.0
 *
 * @var int                                   $gateway_id  Gateway ID
 * @var \WcPsigate\Payment_Form               $form        Gateway ID
 * @var array                                 $saved_cards Collection with saved card tokens
 * @var array|\WcPsigate\Tokens\Psigate_Token $card        Object containing all token info. Can be used as array for backward compatibility
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/*<input style="display: none !important;" type="radio" id="new" name="psigate-used-cc" style="width:auto;" <?php checked( 1, 1 ) ?> value="new" />*/

// Make sure we have the vital variables
$tokens = isset( $tokens ) && is_array( $tokens ) ? $tokens : array();

// The token type will differentiate between the two types payment forms 'card' and 'check'
$token_type = isset( $token_type ) ? $token_type : 'card';

?>
<div class="woocommerce-psigate-SavedPaymentMethods-wrapper <?php echo esc_attr( $token_type ); ?>">
	<?php if ( ! empty( $tokens ) ) { ?>
		<span class="psigate_manage_tokens help" style="text-align: right; display: block;">
			<a href="<?php echo wc_get_account_endpoint_url( 'payment-methods' ); ?>" class="button psigate-button">
				<?php echo esc_html( __( 'Manage Cards', WC_PsiGate::TEXT_DOMAIN ) ); ?>
			</a>
		</span>
	<?php } ?>
	<ul class="woocommerce-SavedPaymentMethods woocommerce-psigate-SavedPaymentMethods-<?php echo esc_attr( $token_type ); ?> wc-saved-payment-methods" data-count="<?php echo esc_attr( count( $tokens ) ) ?>">
		<?php
		/**
		 * @var \WcPsigate\Tokens\Psigate_Token $card
		 */
		$keys        = array_keys( $tokens );
		$set_checked = false;
		foreach ( $tokens as $n => $card ) { ?>
			<li class="woocommerce-psigate-SavedPaymentMethods-token">
				<label for="psigate_card_<?php echo esc_attr( $n ); ?>">
					<input id="psigate_card_<?php echo esc_attr( $n ); ?>"
					       type="radio"
					       name="psigate-used-cc"
					       value="<?php echo $card->get_id(); ?>"
					       style="width:auto;"
					       class="woocommerce-psigate-SavedPaymentMethods-tokenInput woocommerce-SavedPaymentMethods-tokenInput"
						<?php
						// Needed some solution for legacy tokens because we did not previously have is_default
						if ( $card->get_is_default() || ( end( $keys ) == $n && ! $set_checked ) ) {
							$set_checked = true;
							checked( true );
						} ?>
					/>
					<?php echo wp_kses( $card->get_display_name(), apply_filters( 'wc_psigate_label_allowed_elements', array(
						'strong' => array(),
						'em'     => array(),
						'b'      => array(),
						'i'      => array( 'class' => array() ),
						'span'   => array( 'class' => array() ),
						'img'    => array(
							'src' => array(),
							'alt' => array(),
						),
					) ) ) ?>
				</label>
			</li>
		<?php } ?>
		<li class="woocommerce-psigate-SavedPaymentMethods-<?php echo esc_attr( $token_type ); ?>-new woocommerce-SavedPaymentMethods-new" style="<?php echo empty( $tokens ) ? 'display:none;' : ''; ?>">
			<label for="psigate_card_new">
				<input id="psigate_card_new"
				       type="radio"
				       name="psigate-used-cc"
				       value="new"
				       style="width:auto;"
				       class="woocommerce-psigate-SavedPaymentMethods-tokenInput woocommerce-SavedPaymentMethods-tokenInput"
					<?php checked( $set_checked, false ); ?>
				/>
				<?php echo esc_html( __( 'Use a new payment method', WC_PsiGate::TEXT_DOMAIN ) ); ?>
			</label>
		</li>
	</ul>

	<div class="clear"></div>
</div>