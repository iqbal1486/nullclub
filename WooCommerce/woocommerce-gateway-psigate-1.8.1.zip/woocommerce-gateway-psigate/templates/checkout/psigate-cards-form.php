<?php
/**
 * Interac Online description
 *
 * Override this template by copying it to yourtheme/woocommerce/checkout/psigate-interac-online-instructions.php
 *
 * @var \WcPsigate\Gateway_PsiGate $gateway The PsiGate object
 * @var \WcPsigate\Payment_Form    $form
 *
 * @since 1.4
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>
<div id="<?php echo esc_attr( $gateway->id ); ?>_card_description" class="<?php echo esc_attr( $gateway->id ); ?>_card_description" style="display:none;">
	<?php $form->output_card_blocks(); ?>
</div>