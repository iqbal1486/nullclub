<?php
/**
 * Template displaying the radio buttons to switch between Cards and Interac Online payment
 *
 * Override this template by copying it to yourtheme/woocommerce/checkout/psigate-switch-forms.php
 *
 * @var \WcPsigate\Payment_Form    $form
 * @var \WcPsigate\Gateway_PsiGate $gateway The gateway ID
 *
 * @since 1.4
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>
<div id="<?php echo esc_attr( $form->get_gateway()->id ); ?>_payment_choices_wrapper" class="<?php echo esc_attr( $form->get_gateway()->id ); ?>_payment_choices_wrapper">
	<p><?php _e( 'How would you like to pay?', WC_PsiGate::TEXT_DOMAIN ); ?></p>
	<div class="psigate-choise-inputs">
		<label for="<?php echo esc_attr( $form->get_gateway()->id ); ?>_cc_choice">
			<input type="radio" id="<?php echo esc_attr( $form->get_gateway()->id ); ?>_cc_choice" <?php checked( 'card', $form->get_gateway()->default_payment_option ) ?> value="cc" name="<?php echo esc_attr( $form->get_gateway()->id ); ?>_payment_type_choice">
			<?php _e( 'Card', WC_PsiGate::TEXT_DOMAIN ); ?>
		</label>
		<label for="<?php echo esc_attr( $form->get_gateway()->id ); ?>_interac_online_choice">
			<input type="radio" id="<?php echo esc_attr( $form->get_gateway()->id ); ?>_interac_online_choice" <?php checked( 'interac', $form->get_gateway()->default_payment_option ) ?> value="interac" name="<?php echo esc_attr( $form->get_gateway()->id ); ?>_payment_type_choice">
			<?php _e( 'Interac Online', WC_PsiGate::TEXT_DOMAIN ); ?>
		</label>
	</div>
</div>
<style>
	.psigate-choise-inputs {
		display: flex;
		margin: 15px 0;
		align-items: center;
	}

	.psigate-choise-inputs label {
		margin-right: 20px;
	}
</style>