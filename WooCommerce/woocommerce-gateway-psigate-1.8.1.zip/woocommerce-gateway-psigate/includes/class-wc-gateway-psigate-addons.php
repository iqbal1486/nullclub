<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Backward compatible wrapper of the new namespaced gateway class
 * @since 1.6.0
 */
class WC_Gateway_PsiGate_Addons extends \WcPsigate\Gateway_PsiGate_Addons {
	public function __construct() {
		parent::__construct();
	}
}