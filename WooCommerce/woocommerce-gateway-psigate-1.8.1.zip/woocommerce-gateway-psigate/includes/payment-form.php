<?php

namespace WcPsigate;

use WcPsigate\Helpers\Page_Helpers;
use WcPsigate\Tokens\Psigate_Customer_Tokens;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Credit Card Payment Gateway
 */
class Payment_Form {
	
	protected $gateway;
	protected $tokens = array();
	protected $saved_cards = array();
	protected $show_save_customer = false;
	protected $payment_forms_to_display = array();
	protected $form_data = array();
	protected $show_saved_cards = false;
	
	/**
	 * @param \WC_Payment_Gateway $gateway
	 */
	public function __construct( \WC_Payment_Gateway $gateway ) {
		$this->gateway = $gateway;
	}
	
	/**
	 * @return \WC_Payment_Gateway|\WcPsigate\Gateway_PsiGate
	 */
	public function get_gateway() {
		return $this->gateway;
	}
	
	public function is_separated_forms() {
		return apply_filters( 'wc_psigate_separated_forms', $this->get_gateway()->separated_forms, $this->get_gateway() );
	}
	
	public function get_saved_cards() {
		return $this->saved_cards;
	}
	
	/**
	 * Set the show save customer prop.
	 * Controls the Save to account checkbox.
	 *
	 * @since 1.8.0
	 *
	 * @param $show_save_customer
	 */
	public function set_show_save_customer( $show_save_customer ) {
		$this->show_save_customer = $show_save_customer;
	}
	
	public function set_show_saved_cards( $show_saved_cards ) {
		$this->show_saved_cards = $show_saved_cards;
	}
	
	public function get_show_save_customer() {
		return $this->show_save_customer;
	}
	
	public function get_show_saved_cards() {
		return $this->show_saved_cards;
	}
	
	public function should_show_interac_block() {
		$value = false;
		if ( $this->get_gateway()->has_html_api_features()
		     && ( ! $this->get_gateway()->cart_contains_subscription()
		          && ! $this->get_gateway()->cart_contains_pre_order() )
		     && ! Page_Helpers::is_change_method_page()
		     && ! Page_Helpers::is_update_payment_method_page()
		) {
			$value = true;
		}
		
		return apply_filters( 'wc_psigate_should_show_interac', $value, $this->get_gateway() );
	}
	
	/**
	 * Outputs the payment fields for the plugin.
	 *
	 * @since 1.8.0
	 *
	 * @param $show_save_customer
	 * @param $show_saved_cards
	 */
	public function payment_fields( $show_save_customer, $show_saved_cards ) {
		$this->set_show_save_customer( $show_save_customer );
		$this->set_show_saved_cards( $show_saved_cards );
		$this->load_customer_saved_tokens();
		
		if ( $this->is_separated_forms() ) {
			$this->set_payment_forms_to_display();
			$this->output_separated_forms();
		} else {
			$this->maybe_output_form_switcher();
			$this->maybe_output_interac_form();
			$this->output_cards_form();
		}
	}
	
	public function output_separated_forms() {
		// Load the Checks form template
		wc_get_template(
			'checkout/separate/psigate-separation-form.php',
			array(
				'gateway' => $this->get_gateway(),
				'form'    => $this,
			),
			'',
			\WC_PsiGate::plugin_path() . '/templates/'
		);
	}
	
	/**
	 * Loads the payment tokens to the class props
	 *
	 * @since 1.8.0
	 *
	 * @return bool
	 */
	public function load_customer_saved_tokens() {
		// Guest has no tokens
		if ( ! is_user_logged_in() ) {
			return false;
		}
		
		// No tokens, if saving is not enabled
		if ( ! $this->get_show_saved_cards() ) {
			return false;
		}
		
		$customer_tokens = new Psigate_Customer_Tokens( get_current_user_id() );
		$this->tokens    = $customer_tokens->get_tokens();
		if ( $this->tokens ) {
			/**
			 * @var \WC_Payment_Token_Psigate_CC $token
			 */
			foreach ( $this->tokens as $n => $token ) {
				$this->saved_cards[ $n ] = $token;
			}
		}
		
		return true;
	}
	
	/**
	 * Outputs the form switcher (Card or Check)
	 *
	 * @since 1.8.0
	 */
	public function maybe_output_form_switcher() {
		// Load the Cards/Check forms switch
		if ( ! $this->get_gateway()->has_html_api_features() ) {
			return;
		}
		
		// Load the Checks form template
		wc_get_template(
			'checkout/psigate-switch-forms.php',
			array(
				'gateway' => $this->get_gateway(),
				'form'    => $this,
			),
			'',
			\WC_PsiGate::plugin_path() . '/templates/'
		);
	}
	
	/**
	 * Outputs the Checks form
	 *
	 * @since 1.8.0
	 */
	public function maybe_output_interac_form() {
		if ( ! $this->should_show_interac_block() ) {
			return;
		}
		
		// Load the checks form template
		wc_get_template(
			'checkout/psigate-interac-online-instructions.php',
			array(
				'gateway' => $this->get_gateway(),
				'form'    => $this,
			),
			'',
			\WC_PsiGate::plugin_path() . '/templates/'
		);
	}
	
	/**
	 * Outputs the Cards form
	 *
	 * @since 1.8.0
	 */
	public function output_cards_form() {
		// Load the credit card form template
		wc_get_template(
			'checkout/psigate-cards-form.php',
			array(
				'form'       => $this,
				'gateway'    => $this->get_gateway(),
				'gateway_id' => $this->get_gateway()->id,
			),
			'',
			\WC_PsiGate::plugin_path() . '/templates/'
		);
	}
	
	/**
	 * Outputs the Cards form
	 *
	 * @since 1.8.0
	 */
	public function output_card_blocks() {
		if ( ! $this->is_separated_forms() ) {
			$description = $this->get_gateway()->get_description();
			if ( $description ) {
				echo wpautop( wptexturize( $description ) ); // @codingStandardsIgnoreLine.
			}
		}
		
		$this->output_saved_payment_tokens( $this->saved_cards );
		
		// Load the credit card form template
		wc_get_template(
			'checkout/psigate-payment-form.php',
			array(
				'form'                    => $this,
				'gateway'                 => $this->get_gateway()->id,
				'gateway_id'              => $this->get_gateway()->id,
				'save_to_account_text'    => $this->get_gateway()->get_option( 'save_to_account_text' ),
				'display_save_to_account' => $this->show_save_customer,
			),
			'',
			\WC_PsiGate::plugin_path() . '/templates/'
		);
	}
	
	/**
	 * Outputs the saved payment tokens fields
	 *
	 * @since 1.8.0
	 *
	 * @param array $tokens Tokens
	 */
	public function output_saved_payment_tokens( $tokens ) {
		// Load the saved checks form template
		wc_get_template(
			'checkout/psigate-saved-cards.php',
			array(
				'gateway'    => $this->get_gateway()->id,
				'gateway_id' => $this->get_gateway()->id,
				'tokens'     => $tokens,
				'form'       => $this,
			),
			'',
			\WC_PsiGate::plugin_path() . '/templates/'
		);
	}
	
	public function get_payment_forms_to_display() {
		return $this->payment_forms_to_display;
	}
	
	public function set_payment_forms_to_display() {
		$this->payment_forms_to_display[] = 'card';
		if ( $this->should_show_interac_block() ) {
			$this->payment_forms_to_display[] = 'interac';
		}
		
		// Allow for modification
		$this->payment_forms_to_display = apply_filters( 'wc_payment_forms_to_display_psigate', $this->payment_forms_to_display, $this );
		
		$this->format_forms_data();
	}
	
	public function get_label( $form_type ) {
		if ( 'interac' == $form_type ) {
			return $this->get_gateway()->html_title;
		}
		
		return $this->get_gateway()->get_title();
	}
	
	public function get_description( $form_type ) {
		if ( 'interac' == $form_type ) {
			return $this->get_gateway()->html_description;
		}
		
		return $this->get_gateway()->get_description();
	}
	
	public function format_forms_data() {
		$forms = $this->get_payment_forms_to_display();
		
		foreach ( $forms as $form_type ) {
			$this->form_data[ $form_type ] = array(
				'slug'        => $form_type,
				'label'       => $this->get_label( $form_type ),
				'description' => $this->get_description( $form_type ),
			);
		}
	}
	
	public function get_form_data() {
		return $this->form_data;
	}
}
