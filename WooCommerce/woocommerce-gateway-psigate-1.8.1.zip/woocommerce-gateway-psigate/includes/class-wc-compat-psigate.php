<?php
/*
 * Just a shell of the Compatibility class
 *
 * Author: VanboDevelops
 * Author URI: http://www.vanbodevelops.com
 *
 *	Copyright: (c) 2012 - 2018 VanboDevelops
 *	License: GNU General Public License v3.0
 *	License URI: http://www.gnu.org/licenses/gpl-3.0.html
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WC_Compat_PsiGate {
	
	public static function __callStatic( $name, $arguments ) {
		if ( is_callable( array( '\\WcPsigate\\Compatibility', $name ) ) ) {
			return call_user_func_array( array( '\\WcPsigate\\Compatibility', $name ), $arguments );
		}
		
		return null;
	}
}