<?php

namespace WcPsigate\Tokens;

use Exception;
use WC_PsiGate;
use WcPsigate\Compatibility;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Handles the Customer Tokens.
 * Saves the WC Tokens if WC > 2.6, or saves user meta profiles, if WC < 2.6
 *
 * @since  1.6.0
 * @author VanboDevelops | Ivan Andreev
 *
 *        Copyright: (c) 2020 VanboDevelops
 *        License: GNU General Public License v3.0
 *        License URI: http://www.gnu.org/licenses/gpl-3.0.html
 */
class Psigate_Customer_Tokens {
	
	public static $is_transfer_legacy_profiles_running = false;
	public $gateway_id = 'psigate';
	public $user_id;
	
	public function __construct( $user_id ) {
		$this->user_id = (int) $user_id;
	}
	
	/**---------------------------------
	 * GETTERS
	 * -----------------------------------*/
	
	/**
	 * Returns the saved Tokens/Profiles for the Customer
	 *
	 * @since 1.6.0
	 *
	 * @return array|mixed
	 */
	public function get_tokens() {
		if ( Compatibility::is_wc_2_6() ) {
			$tokens = $this->get_customer_tokens();
		} else {
			$tokens = $this->get_user_saved_profiles();
		}
		
		return $tokens;
	}
	
	/**
	 * Returns the specific token/profile by the provided token ID.
	 *
	 * @since 1.6.0
	 *
	 * @param $token_id
	 *
	 * @throws \Exception
	 *
	 * @return \WcPsigate\Tokens\Psigate_Token|\WC_Payment_Token_Psigate_CC
	 */
	public function get_token( $token_id ) {
		$tokens = $this->get_tokens();
		
		/**
		 * @var \WcPsigate\Tokens\Psigate_Token $token
		 */
		foreach ( $tokens as $id => $token ) {
			if ( $token_id == $token->get_id() ) {
				return $tokens[ $id ];
			}
		}
		
		throw new Exception( __( 'The Token was not found.', WC_PsiGate::TEXT_DOMAIN ) );
	}
	
	/**
	 * Returns the token by the provided customer ID or token (for the WC_Payment_Token)
	 *
	 * @since 1.6.0
	 *
	 * @param string $account_id
	 *
	 * @return \WcPsigate\Tokens\Psigate_Token|false
	 */
	public function get_token_by_account_id( $account_id ) {
		$saved_cards = $this->get_tokens();
		
		/**
		 * @var \WcPsigate\Tokens\Psigate_Token $token
		 */
		foreach ( $saved_cards as $id => $token ) {
			if ( $token->get_account_id() == $account_id ) {
				return $saved_cards[ $id ];
			}
		}
		
		return false;
	}
	
	/**
	 * Returns the WC Customer tokens for the gateway
	 *
	 * @since 1.6.0
	 *
	 * @return array
	 */
	public function get_customer_tokens() {
		$tokens    = \WC_Payment_Tokens::get_customer_tokens( $this->user_id, $this->gateway_id );
		$formatted = array();
		
		// Format the tokens with a wrapper
		foreach ( $tokens as $id => $token ) {
			$formatted[ $id ] = new Psigate_Token( $token );
		}
		
		return $formatted;
	}
	
	/**
	 * Returns all profiles saved to the user meta
	 *
	 * @since 1.6.0
	 *
	 * @return mixed
	 */
	public function get_user_saved_profiles() {
		$profiles  = get_user_meta( $this->user_id, '_psigate_saved_cards', false );
		$formatted = array();
		
		// Format the profiles with a wrapper, so we can use them as WC tokens
		foreach ( $profiles as $id => $profile ) {
			$formatted[ $id ] = new Psigate_Token( $profile, $id );
		}
		
		return $formatted;
	}
	
	/**---------------------------------------------------
	 * Create method for creating new Profiles/Tokens
	 * ---------------------------------------------------*/
	
	/**
	 * Saves the Token/Profile to the customer.
	 *
	 * @since 1.6.0
	 *
	 * @param \WcPsigate\Tokens\Psigate_Token $new_token
	 *
	 * @throws Exception
	 * @return bool|false|int
	 */
	public function save_profile_or_token( Psigate_Token $new_token ) {
		if ( Compatibility::is_wc_2_6() ) {
			return $this->create_wc_token( $new_token );
		}
		
		return $this->create_legacy_profile( $new_token );
	}
	
	/**
	 * Creates a WC Credit card token, saved to the customer, using the passed data.
	 *
	 * @since 1.6.0
	 *
	 * @param \WcPsigate\Tokens\Psigate_Token $token
	 *
	 * @throws Exception
	 * @return bool|int
	 */
	public function create_wc_token( Psigate_Token $token ) {
		$new_token = new \WC_Payment_Token_Psigate_CC();
		$new_token->set_card_type( $token->get_card_type() );
		$new_token->set_expiry_month( $token->get_expiry_month() );
		$new_token->set_expiry_year( $token->get_expiry_year() );
		$new_token->set_last4( $token->get_last4() );
		$new_token->set_account_id( $token->get_account_id() );
		$new_token->set_token( $token->get_token() );
		$new_token->set_gateway_id( $token->get_gateway_id() );
		$new_token->set_user_id( $this->user_id );
		
		if ( ! $new_token->validate() ) {
			throw new Exception( __( 'The token could not be validated and created in the store.', WC_PsiGate::TEXT_DOMAIN ) );
		}
		
		return $new_token->save();
	}
	
	/**
	 * Adds the Profile to the user meta
	 *
	 * @since 1.6.0
	 *
	 * @param \WcPsigate\Tokens\Psigate_Token $new_token
	 *
	 * @return false|int
	 */
	public function create_legacy_profile( Psigate_Token $new_token ) {
		$profile = $this->build_legacy_profile_array( $new_token );
		
		return add_user_meta( $this->user_id, '_psigate_saved_cards', $profile );
	}
	
	/**---------------------------------------------------
	 * UPDATE method for updating existing Profiles/Tokens
	 * ---------------------------------------------------*/
	
	/**
	 * Updates the Profile/Token
	 *
	 * @since 1.6.0
	 *
	 * @param \WcPsigate\Tokens\Psigate_Token $new_token
	 * @param \WcPsigate\Tokens\Psigate_Token $old_token
	 *
	 * @throws \Exception
	 * @return bool|false|int
	 */
	public function update_profile_or_token( Psigate_Token $new_token, Psigate_Token $old_token ) {
		if ( Compatibility::is_wc_2_6() ) {
			return $this->update_wc_token( $new_token, $old_token );
		}
		
		return $this->update_user_legacy_profile( $new_token, $old_token );
	}
	
	/**
	 * Creates a WC Credit card token, saved to the customer, using the passed data.
	 *
	 * @since 1.6.0
	 *
	 * @param \WcPsigate\Tokens\Psigate_Token $new_token
	 * @param \WcPsigate\Tokens\Psigate_Token $old_token
	 *
	 * @throws Exception
	 * @return bool|int
	 */
	public function update_wc_token( Psigate_Token $new_token, Psigate_Token $old_token ) {
		$old_token_id = $old_token->get_id();
		if ( empty( $old_token_id ) ) {
			throw new Exception( __( 'Token could not be updated. Token ID was not provided.', WC_PsiGate::TEXT_DOMAIN ) );
		}
		
		$token = new \WC_Payment_Token_Psigate_CC( $old_token_id );
		$token->set_expiry_year( $new_token->get_expiry_year() );
		$token->set_expiry_month( $new_token->get_expiry_month() );
		$token->set_card_type( $new_token->get_card_type() );
		$token->set_last4( $new_token->get_last4() );
		$token->set_user_id( $this->user_id );
		$token->set_account_id( $new_token->get_account_id() );
		$token->set_token( $new_token->get_token() );
		
		// Validate and save the token
		if ( ! $token->validate() ) {
			throw new Exception( __( 'Token could not be updated. Token validation failed.', WC_PsiGate::TEXT_DOMAIN ) );
		}
		
		return $token->save();
	}
	
	/**
	 * Adds the Profile to the user meta
	 *
	 * @since 1.6.0
	 *
	 * @param \WcPsigate\Tokens\Psigate_Token $new_token
	 * @param \WcPsigate\Tokens\Psigate_Token $old_token
	 *
	 * @throws \Exception
	 *
	 * @return false|int
	 */
	public function update_user_legacy_profile( Psigate_Token $new_token, Psigate_Token $old_token ) {
		
		// We need an old profile to update
		if ( 0 == $old_token->get_id() ) {
			throw new Exception( __( 'Profile could not be updated. We did not receive the profile to update.', WC_PsiGate::TEXT_DOMAIN ) );
		}
		
		// We need at least the token to be passed
		$token_value = $new_token->get_token();
		if ( empty( $token_value ) ) {
			throw new Exception( __( 'Profile could not be updated. Profile customer ID was missing.', WC_PsiGate::TEXT_DOMAIN ) );
		}
		
		$old_profile = $this->build_legacy_profile_array( $old_token );
		$new_profile = $this->build_legacy_profile_array( $new_token );
		
		return update_user_meta( $this->user_id, '_psigate_saved_cards', $new_profile, $old_profile );
	}
	
	/**
	 * Builds a legacy profile array
	 *
	 * @since 1.6.0
	 *
	 * @param \WcPsigate\Tokens\Psigate_Token|\WC_Payment_Token_Psigate_CC $token
	 *
	 * @return array
	 */
	public function build_legacy_profile_array( $token ) {
		return array(
			'card_type'  => $this->format_card_type( $token->get_card_type() ),
			'serial_no'  => $token->get_token(),
			'account_id' => $token->get_account_id(),
			'last4'      => substr( $token->get_last4(), - 4 ),
			'exp_year'   => substr( $token->get_expiry_year(), - 2 ),
			'exp_month'  => $token->get_expiry_month(),
		);
	}
	
	private function format_card_type( $card_type ) {
		if ( 'MC' == $card_type ) {
			$card_type = 'mastercard';
		} else {
			$card_type = strtolower( $card_type );
		}
		
		return $card_type;
	}
	
	/**---------------------------------------------------
	 * DELETE methods for deleting existing Profiles/Tokens
	 * ---------------------------------------------------*/
	
	/**
	 * Updates the Profile/Token
	 *
	 * @since 1.6.0
	 *
	 * @param \WcPsigate\Tokens\Psigate_Token $token
	 * @param bool                            $force
	 *
	 * @throws \Exception
	 * @return bool|false|int
	 */
	public function delete_profile_token( $token, $force = false ) {
		
		if ( Compatibility::is_wc_2_6() ) {
			// The token should be deleted directly through the class and via 'woocommerce_psigate_payment_token_delete'
			if ( true === $force ) {
				$token->delete();
			}
			
			return true;
		}
		
		$profile = $this->build_legacy_profile_array( $token );
		
		return $this->delete_user_profile( $profile );
	}
	
	/**
	 * Creates a WC Credit card token, saved to the customer, using the passed data.
	 *
	 * @since 1.6.0
	 *
	 * @param $token_id
	 *
	 * @throws \Exception
	 *
	 * @return bool|int
	 */
	public function delete_wc_token( $token_id ) {
		
		if ( empty( $token_id ) ) {
			throw new Exception( __( 'Token could not be deleted. Token ID was not provided.', WC_PsiGate::TEXT_DOMAIN ) );
		}
		
		// Does not matter which class deletes the token, the process is the sames
		$token = new \WC_Payment_Token_Psigate_CC( $token_id );
		
		return $token->delete();
	}
	
	/**
	 * Deletes the billing profile from the user meta
	 *
	 * @since 1.6.0
	 *
	 * @param array $profile
	 *
	 * @throws \Exception
	 *
	 * @return false|int
	 */
	public function delete_user_profile( $profile ) {
		// We need the profile to delete
		if ( empty( $profile ) ) {
			throw new Exception( __( 'Profile could not be deleted. Profile was not provided.', WC_PsiGate::TEXT_DOMAIN ) );
		}
		
		return delete_user_meta( $this->user_id, '_psigate_saved_cards', $profile );
	}
	
	/**---------------------------------
	 * HELPERS
	 * -----------------------------------*/
	
	/**
	 * Checks and transfers legacy profiles to WC > 2.6 tokens
	 *
	 * @since 1.6.0
	 *
	 * @return bool
	 */
	public function maybe_transfer_legacy_profiles() {
		// If it is WC > 2.6 always check, if we transferred the legacy user profiles to tokens
		if ( Compatibility::is_wc_2_6() ) {
			
			// If we have profiles and we never transferred them to tokens
			if ( ! $this->are_legacy_tokens_transferred() && false === self::$is_transfer_legacy_profiles_running ) {
				$tokens = $this->get_user_saved_profiles();
				
				return $this->transfer_profiles_to_tokens( $tokens );
			}
		}
		
		return true;
	}
	
	/**
	 * Transfers Customer profiles, saved as user meta, to WC Tokens
	 *
	 * NOTE: The profiles will not be deleted from the user meta
	 * NOTE: We indicate that the transfer has happened by adding a user meta '_psigate_legacy_profiles_transferred' to each customer.
	 *
	 * @since 1.6.0
	 *
	 * @param array $tokens
	 *
	 * @return bool
	 */
	public function transfer_profiles_to_tokens( $tokens ) {
		if ( ! is_array( $tokens ) || empty( $tokens ) ) {
			$this->set_transferred_to_true();
			
			return false;
		}
		
		self::$is_transfer_legacy_profiles_running = true;
		
		/**
		 * @var \WcPsigate\Tokens\Psigate_Token $token
		 */
		foreach ( $tokens as $token ) {
			try {
				$this->create_wc_token( $token );
			}
			catch ( Exception $e ) {
			}
		}
		
		// Add a note to the user meta that we already transferred their saved profiles
		$this->set_transferred_to_true();
		
		self::$is_transfer_legacy_profiles_running = false;
		
		return true;
	}
	
	public function are_legacy_tokens_transferred() {
		return true == get_user_meta( $this->user_id, '_psigate_legacy_profiles_transferred', true );
	}
	
	/**
	 * Sets the transferred value to true, so more transfers will be performed
	 *
	 * @since 1.6.0
	 */
	public function set_transferred_to_true() {
		// Add a note to the user meta that we already transferred their saved profiles
		update_user_meta( $this->user_id, '_psigate_legacy_profiles_transferred', 'true' );
	}
}