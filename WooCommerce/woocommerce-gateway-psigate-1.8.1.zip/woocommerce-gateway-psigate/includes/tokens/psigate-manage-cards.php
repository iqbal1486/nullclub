<?php

namespace WcPsigate\Tokens;

use WC_PsiGate;
use WcPsigate\Compatibility;
use WcPsigate\Helpers\Factories;
use WcPsigate\Helpers\Retrievers;
use WcPsigate\Helpers\Validators;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Handles the Customer Tokens.
 * Saves the WC Tokens if WC > 2.6, or saves user meta profiles, if WC < 2.6
 *
 * @since  2.0
 * @author VanboDevelops | Ivan Andreev
 *
 *        Copyright: (c) 2017 VanboDevelops
 *        License: GNU General Public License v3.0
 *        License URI: http://www.gnu.org/licenses/gpl-3.0.html
 */
class Psigate_Manage_Cards {
	
	/**
	 * @var \WC_PsiGate
	 */
	protected $plugin;
	public static $running_customer_tokens_transfer = false;
	
	/**
	 * @param \WC_PsiGate $plugin
	 */
	public function __construct( WC_PsiGate $plugin ) {
		$this->plugin = $plugin;
	}
	
	/**
	 * Returns the manage tokens URL for the plugin
	 *
	 * @since 2.0
	 *
	 * @param string $type
	 *
	 * @return string
	 */
	public static function manage_tokens_url( $type = 'card' ) {
		if ( Compatibility::is_wc_2_6() ) {
			return wc_get_account_endpoint_url( 'payment-methods' );
		}
		
		return wc_get_page_permalink( 'myaccount' ) . '#psigate-saved-cards';
	}
	
	/**
	 * Loads the class hooks
	 *
	 * @since 2.0
	 */
	public function hooks() {
		if ( Compatibility::is_wc_2_6() ) {
			/**
			 * WC > 2.6 Tokens features
			 */
			add_filter( 'woocommerce_payment_methods_list_item', array(
				$this,
				'wc_get_account_saved_payment_methods_list_item',
			), 10, 2 );
			
			// Initially, check for the customer legacy profiles and transfer them to tokens
			add_filter( 'woocommerce_get_customer_payment_tokens', array(
				$this,
				'maybe_transfer_legacy_profiles_to_tokens',
			), 10, 3 );
			
			// Delete the payment method before
			add_action( 'woocommerce_psigate_payment_token_delete', array(
				$this,
				'delete_payment_token',
			), 10, 2 );
			
			if ( Compatibility::is_wc_3_1_2() ) {
				add_filter( 'woocommerce_credit_card_type_labels', array(
					$this,
					'add_payment_options_labels',
				) );
			} else {
				add_filter( 'wocommerce_credit_card_type_labels', array(
					$this,
					'add_payment_options_labels',
				) );
			}
		} else {
			// Manage Saved Cards
			add_action( 'template_redirect', array( $this, 'manage_saved_cards' ) );
			
			// Add the cards management
			add_action( 'woocommerce_after_my_account', array( $this, 'display_saved_cards' ) );
		}
	}
	
	/**
	 * Checks for and transfers the customer legacy profiles to WC Payment Tokens
	 *
	 * @since 2.0
	 *
	 * @param $tokens
	 * @param $customer_id
	 * @param $gateway_id
	 *
	 * @return array|mixed
	 */
	public function maybe_transfer_legacy_profiles_to_tokens( $tokens, $customer_id, $gateway_id ) {
		// Bail, if we already transferred the profiles
		$transferred_legacy_profiles = get_user_meta( $customer_id, '_psigate_legacy_profiles_transferred', true );
		if ( $transferred_legacy_profiles || true === Psigate_Customer_Tokens::$is_transfer_legacy_profiles_running ) {
			return $tokens;
		}
		
		$customer_tokens = new Psigate_Customer_Tokens( $customer_id );
		$customer_tokens->maybe_transfer_legacy_profiles();
		
		// After we transferred the profiles just get the tokens again
		$tokens = \WC_Payment_Tokens::get_tokens( array(
			'user_id'    => $customer_id,
			'gateway_id' => $gateway_id,
		) );
		
		return $tokens;
	}
	
	/**
	 * Manage the saved credit cards
	 *
	 * @since 1.1
	 */
	public function manage_saved_cards() {
		try {
			// Customer should be logged in
			if ( ! is_user_logged_in() ) {
				return;
			}
			
			// No need to continue, if an update is not submitted
			if ( null == Retrievers::get_field( 'psigate-delete-card', $_POST ) ) {
				return;
			}
			
			if ( '' != Retrievers::get_field( 'psigate-delete-card', $_POST ) && is_account_page() ) {
				/**
				 * @var \WcPsigate\Gateway_PsiGate $gateway
				 */
				$gateway = Factories::get_gateway( 'psigate' );
				
				// First verify the request was send from the manage card form
				Validators::verify_request( 'psigate-nonce', 'psigate-verification' );
				
				$gateway->delete_customer_card( (int) Retrievers::get_field( 'psigate-delete-card', $_POST ) );
				
				wc_add_notice( __( 'Card deleted successfully', WC_PsiGate::TEXT_DOMAIN ), 'success' );
			}
		}
		catch ( \Exception $e ) {
			wc_add_notice( $e->getMessage(), 'error' );
		}
	}
	
	/**
	 * Delete the Profile after we delete a token
	 *
	 * @since 2.0
	 *
	 * @param int                          $token_id
	 * @param \WC_Payment_Token_Psigate_CC $token
	 *
	 * @throws \Exception
	 */
	public function delete_payment_token( $token_id, $token ) {
		if ( 'psigate' === $token->get_gateway_id() ) {
			/**
			 * @var \WC_Payment_Gateway|\WcPsigate\Gateway_PsiGate $gateway
			 */
			$gateway = Factories::get_gateway( 'psigate' );
			
			try {
				// Delete profile
				$gateway->delete_customer_card( $token->get_id() );
			}
			catch ( \Exception $e ) {
				if ( function_exists( 'wc_add_notice' ) ) {
					wc_add_notice( $e->getMessage(), 'error' );
				}
			}
		}
	}
	
	/**
	 * Controls the output for credit cards on the my account page.
	 *
	 * @since 2.0
	 *
	 * @param array                           $item          Individual list item from woocommerce_saved_payment_methods_list
	 * @param \WcPsigate\Tokens\Psigate_Token $payment_token The payment token associated with this method entry
	 *
	 * @return array                           Filtered item
	 */
	function wc_get_account_saved_payment_methods_list_item( $item, $payment_token ) {
		if ( 'psigate' !== $payment_token->get_gateway_id() ) {
			return $item;
		}
		
		$card_type               = $payment_token->get_card_type();
		$item['method']['brand'] = ( ! empty( $card_type ) ? ucfirst( $card_type ) : esc_html__( 'Card', 'woocommerce' ) );
		$item['expires']         = $payment_token->get_expiry_month() . '/' . substr( $payment_token->get_expiry_year(), - 2 );
		$item['method']['last4'] = $payment_token->get_last4();
		
		return $item;
	}
	
	/**
	 * Manage the customer saved credit cards
	 *
	 * @since 1.1
	 */
	public function display_saved_cards() {
		
		// Customer should be logged in
		if ( ! is_user_logged_in() ) {
			return;
		}
		
		/**
		 * @var \WcPsigate\Gateway_PsiGate $gateway
		 */
		$gateway = Factories::get_gateway('psigate');
		
		// Don't show if the gateway is not available for use
		if ( ! $gateway->is_available() || 'no' == $gateway->save_customers ) {
			return;
		}
		
		$customer_tokens = new Psigate_Customer_Tokens(get_current_user_id());
		$saved_cards = $customer_tokens->get_user_saved_profiles();
		
		// Don't show if there are not profiles or the save customers is not enabled
		if ( ! $saved_cards  ) {
			return;
		}
		
		wc_get_template(
			'myaccount/myaccount-psigate-saved-cards.php',
			array(
				'saved_cards' => $saved_cards,
			),
			'',
			WC_PsiGate::plugin_path() . '/templates/'
		);
	}
	
	/**
	 * Adds the card types to the WC card types
	 *
	 * @since 2.0
	 *
	 * @param $labels
	 *
	 * @return mixed
	 */
	public function add_payment_options_labels( $labels ) {
		/**
		 * @var \WC_Payment_Gateway|\WcPsigate\Gateway_PsiGate_Addons $gateway
		 */
		$gateway = Factories::get_gateway( 'psigate' );
		
		foreach ( $gateway->card_options as $key => $string ) {
			if ( ! isset( $labels[ strtolower( $key ) ] ) ) {
				$labels[ strtolower( $key ) ] = $string;
			}
		}
		
		return $labels;
	}
}