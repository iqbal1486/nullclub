<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * WC Payment Token TC for TC tokens.
 * Unifies the tokens and profiles, so we can get the information in a consistent manner.
 *
 * @since  1.6.0
 * @author VanboDevelops | Ivan Andreev
 *
 *        Copyright: (c) 2020 VanboDevelops
 *        License: GNU General Public License v3.0
 *        License URI: http://www.gnu.org/licenses/gpl-3.0.html
 */
class WC_Payment_Token_Psigate_CC extends \WC_Payment_Token_CC {
	
	/** @protected string Token Type String. */
	protected $type = 'Psigate_CC';
	protected $token_type = 'card';
	
	public function __construct( $token = '' ) {
		$this->extra_data['account_id'] = '';
		parent::__construct( $token );
	}
	
	/**
	 * Returns the card type label
	 *
	 * @since 1.6.0
	 *
	 * @param $type
	 *
	 * @return string
	 */
	public function get_card_type_label( $type ) {
		$label = wc_get_credit_card_type_label( $type );
		$label = '' == $label ? _x( 'Card', 'label-unknown-card-type', WC_PsiGate::TEXT_DOMAIN ) : $label;
		
		return apply_filters( 'wc_psigate_card_type_label', $label, $type );
	}
	
	/**
	 * Get type to display to user.
	 *
	 * @since  1.6.0
	 *
	 * @param string $deprecated Deprecated since WooCommerce 3.0
	 *
	 * @return string
	 */
	public function get_display_name( $deprecated = '' ) {
		/* translators: 1: credit card type 2: last 4 digits 3: expiry month 4: expiry year */
		$display = sprintf(
			__( '%1$s ending in %2$s (expires %3$s/%4$s)', WC_PsiGate::TEXT_DOMAIN ),
			$this->get_card_type_label( $this->get_card_type() ),
			$this->get_last4(),
			$this->get_expiry_month(),
			substr( $this->get_expiry_year(), - 2 )
		);
		
		return apply_filters( 'wc_psigate_card_display_name', $display, $this );
	}
	
	/**
	 * Hook prefix
	 *
	 * @since 1.6.0
	 */
	protected function get_hook_prefix() {
		return 'woocommerce_payment_token_psigate_cc_get_';
	}
	
	/**
	 * Validate credit card payment tokens.
	 *
	 * These fields are required by all credit card payment tokens:
	 * token         - Card SerialNo
	 * account_id    - Account ID of the card
	 * expiry_month  - string Expiration date (MM) for the card
	 * expiry_year   - string Expiration date (YYYY) for the card
	 * last4         - string Last 4 digits of the card
	 *
	 * @since 1.6.0
	 *
	 * @return boolean True if the passed data is valid
	 */
	public function validate() {
		$token = $this->get_token( 'edit' );
		if ( empty( $token ) ) {
			return false;
		}
		
		if ( ! $this->get_last4( 'edit' ) ) {
			return false;
		}
		
		if ( ! $this->get_account_id( 'edit' ) ) {
			return false;
		}
		
		if ( ! $this->get_expiry_year( 'edit' ) ) {
			return false;
		}
		
		if ( ! $this->get_expiry_month( 'edit' ) ) {
			return false;
		}
		
		if ( 2 !== strlen( $this->get_expiry_year( 'edit' ) ) ) {
			return false;
		}
		
		if ( 2 !== strlen( $this->get_expiry_month( 'edit' ) ) ) {
			return false;
		}
		
		return true;
	}
	
	/**
	 * Returns the of the token
	 *
	 * @since 1.6.0
	 *
	 * @param string $context
	 *
	 * @return mixed
	 */
	public function get_account_id( $context = 'view' ) {
		if ( \WcPsigate\Compatibility::is_wc_3_0() ) {
			return $this->get_prop( 'account_id', $context );
		}
		
		return $this->get_meta( 'account_id', true );
	}
	
	/**
	 * Sets the of the token
	 *
	 * @since 1.6.0
	 *
	 * @param $value
	 */
	public function set_account_id( $value ) {
		if ( \WcPsigate\Compatibility::is_wc_3_0() ) {
			$this->set_prop( 'account_id', $value );
		} else {
			$this->add_meta_data( 'account_id', $value, true );
		}
	}
	
	/**
	 * Set the expiration year for the card (YYYY format).
	 *
	 * @since 2.6.0
	 *
	 * @param string $year Credit card expiration year.
	 */
	public function set_expiry_year( $year ) {
		// Format the year
		if ( 2 < strlen( $year ) ) {
			$this->set_expiry_year( substr( $year, - 2 ) );
		}
		
		parent::set_expiry_year( $year );
	}
	
	/**
	 * Set the card type (mastercard, visa, ...).
	 *
	 * @since 1.6.0
	 *
	 * @param string $type Credit card type (mastercard, visa, ...).
	 */
	public function set_card_type( $type ) {
		if ( 'MC' == $type ) {
			$type = 'mastercard';
		} else {
			$type = strtolower( $type );
		}
		
		parent::set_card_type( $type );
	}
	
	/**
	 * Set the last four digits.
	 * @since 1.6.0
	 *
	 * @param string $last4
	 */
	public function set_last4( $last4 ) {
		$last4 = substr( $last4, - 4 );
		
		parent::set_last4( $last4 );
	}
	
	/**
	 * Return if the method is set to be the default one
	 *
	 * @since 2.2
	 *
	 * @param string $context
	 *
	 * @return mixed
	 */
	public function get_is_default( $context = 'view' ) {
		if ( ! \WcPsigate\Compatibility::is_wc_3_0() ) {
			return $this->is_default();
		}
		
		return parent::get_is_default( $context );
	}
	
	/**
	 * Delete an object, set the ID to 0, and return result.
	 *
	 * @since  1.6.0
	 *
	 * @param bool $force_delete
	 *
	 * @return bool result
	 */
	public function delete( $force_delete = false ) {
		if ( $this->data_store ) {
			
			// Run an action before we delete a Payment Token
			do_action( 'woocommerce_psigate_payment_token_delete', $this->get_id(), $this );
			
			$this->data_store->delete( $this, array( 'force_delete' => $force_delete ) );
			$this->set_id( 0 );
			
			return true;
		}
		
		return false;
	}
}