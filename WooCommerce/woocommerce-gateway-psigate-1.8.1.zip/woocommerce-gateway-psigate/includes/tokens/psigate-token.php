<?php

namespace WcPsigate\Tokens;

use WC_PsiGate;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Wrapper for the Tokens.
 * Unifies the tokens and profiles, so we can get the information in a consistent manner.
 *
 * @since  1.6.0
 * @author VanboDevelops | Ivan Andreev
 *
 *        Copyright: (c) 2020 VanboDevelops
 *        License: GNU General Public License v3.0
 *        License URI: http://www.gnu.org/licenses/gpl-3.0.html
 */
class Psigate_Token implements \ArrayAccess {
	
	/**
	 * @var array|\WC_Payment_Token_Psigate_CC|\WC_Payment_Token
	 */
	protected $data;
	/**
	 * @var int The ID of the legacy profile
	 */
	protected $id;
	/**
	 * Is it a WC_Payment_Token
	 * @var bool
	 */
	protected $is_wc_token = false;
	protected $allowed_token_types = array(
		'Psigate_CC',
	);
	
	/**
	 * Constructor
	 *
	 * @param \WC_Payment_Token|array $token
	 * @param null|int                $id The ID is only passed when we load legacy token or we load token wrapper. Don't pass ID, if you load a WC Token
	 */
	public function __construct( $token, $id = null ) {
		$this->set_data( $token );
		
		if ( class_exists( 'WC_Payment_Token' ) ) {
			$this->is_wc_token = $this->data instanceof \WC_Payment_Token && null === $id;
		}
		
		if ( null !== $id ) {
			$this->set_id( (int) $id );
		}
	}
	
	/**
	 * Returns true, if the token is WC_Payment_Token
	 *
	 * @since 1.6.0
	 *
	 * @return bool
	 */
	public function is_wc_token() {
		return $this->is_wc_token;
	}
	
	/**
	 * Show the token display name
	 *
	 * @since 2.1
	 *
	 * @return string
	 */
	public function get_display_name() {
		if ( $this->is_wc_token ) {
			return $this->data->get_display_name();
		}
		
		$expiry_year = $this->get_expiry_year();
		if ( strlen( $expiry_year ) == 4 ) {
			$expiry_year -= 2000;
		}
		$name = sprintf(
			__( 'Card ending in %1$s (expires %2$s/%3$s)', WC_PsiGate::TEXT_DOMAIN ),
			$this->get_last4(),
			$this->get_expiry_month(),
			$expiry_year
		);
		
		return $name;
	}
	
	/**
	 * Returns the token type
	 *
	 * @since 1.6.0
	 *
	 * @return string
	 */
	public function get_type() {
		if ( $this->is_wc_token ) {
			return $this->data->get_type();
		}
		
		// If we set the type on the object load
		if ( isset( $this->data['type'] ) && in_array( $this->data['type'], $this->allowed_token_types ) ) {
			return $this->data['type'];
		}
		
		return 'Psigate_CC';
	}
	
	/**
	 * Returns the token/profile ID
	 *
	 * @since 1.6.0
	 *
	 * @return int
	 */
	public function get_id() {
		if ( $this->is_wc_token ) {
			return $this->data->get_id();
		}
		
		return $this->id;
	}
	
	/**
	 * Returns the Expiry month
	 *
	 * @since 1.6.0
	 *
	 * @param string $context
	 *
	 * @return string
	 */
	public function get_expiry_month( $context = 'view' ) {
		if ( $this->is_wc_token ) {
			return $this->data->get_expiry_month( $context );
		}
		
		$return = '';
		if ( isset( $this->data['exp_month'] ) ) {
			$return = $this->data['exp_month'];
		} elseif ( isset( $this->data['expiry_month'] ) ) {
			$return = $this->data['expiry_month'];
		}
		
		return $return;
	}
	
	public function get_exp_month( $context = 'view' ) {
		return $this->get_expiry_month( $context );
	}
	
	/**
	 * Returns the Expiry year
	 *
	 * @since 1.6.0
	 *
	 * @param string $context
	 *
	 * @return int
	 */
	public function get_expiry_year( $context = 'view' ) {
		if ( $this->is_wc_token ) {
			$expiry_year = $this->data->get_expiry_year( $context );
			
			// We need the year as YY, so if it is YYYY, trim it
			if ( strlen( $expiry_year ) == 4 ) {
				$expiry_year -= 2000;
			}
			
			return $expiry_year;
		}
		
		$return = '';
		if ( isset( $this->data['exp_year'] ) ) {
			$return = $this->data['exp_year'];
		} elseif ( isset( $this->data['expiry_year'] ) ) {
			$return = $this->data['expiry_year'];
		}
		
		return $return;
	}
	
	public function get_exp_year( $context = 'view' ) {
		return $this->get_expiry_year( $context );
	}
	
	/**
	 * Returns the user id
	 *
	 * @since 1.6.0
	 *
	 * @param string $context
	 *
	 * @return string
	 */
	public function get_user_id( $context = 'view' ) {
		if ( $this->is_wc_token ) {
			return $this->data->get_user_id( $context );
		}
		
		return isset( $this->data['user_id'] ) ? $this->data['user_id'] : 0;
	}
	
	/**
	 * Returns the gateway ID 'psigate'
	 *
	 * @since 1.6.0
	 *
	 * @param string $context
	 *
	 * @return string
	 */
	public function get_gateway_id( $context = 'view' ) {
		if ( $this->is_wc_token ) {
			return $this->data->get_gateway_id( $context );
		}
		
		return isset( $this->data['gateway_id'] ) ? $this->data['gateway_id'] : 'psigate';
	}
	
	/**
	 * Returns the card type
	 *
	 * @since 1.6.0
	 *
	 * @param string $context
	 *
	 * @return string
	 */
	public function get_card_type( $context = 'view' ) {
		if ( $this->is_wc_token ) {
			return $this->data->get_card_type( $context );
		}
		
		return isset( $this->data['card_type'] ) ? $this->data['card_type'] : '';
	}
	
	/**
	 * Returns the last 4 digits of the card
	 *
	 * @since 1.6.0
	 *
	 * @param string $context
	 *
	 * @return string
	 */
	public function get_last4( $context = 'view' ) {
		if ( $this->is_wc_token ) {
			return $this->data->get_last4( $context );
		}
		
		return isset( $this->data['last4'] ) ? $this->data['last4'] : '';
	}
	
	/**
	 * Returns the account ID
	 *
	 * @since 1.6.0
	 *
	 * @param string $context
	 *
	 * @return mixed
	 */
	public function get_account_id( $context = 'view' ) {
		if ( $this->is_wc_token ) {
			return $this->data->get_account_id( $context );
		}
		
		return isset( $this->data['account_id'] ) ? $this->data['account_id'] : '';
	}
	
	/**
	 * Returns the token (SerialNo)
	 *
	 * @since 1.6.0
	 *
	 * @param string $context
	 *
	 * @return string
	 */
	public function get_token( $context = 'view' ) {
		if ( $this->is_wc_token ) {
			return $this->data->get_token( $context );
		}
		
		return isset( $this->data['serial_no'] ) ? $this->data['serial_no'] : '';
	}
	
	/**
	 * Serial No is the token in the new token system.
	 * This is a wrapper of get token for backward compatibility
	 *
	 * @param string $context
	 *
	 * @return string
	 */
	public function get_serial_no( $context = 'view' ) {
		return $this->get_token( $context );
	}
	
	/**
	 * Returns whether the card is default method
	 *
	 * @since 1.6.0
	 *
	 * @param string $context
	 *
	 * @return bool
	 */
	public function get_is_default( $context = 'view' ) {
		if ( $this->is_wc_token ) {
			return $this->data->get_is_default( $context );
		}
		
		return isset( $this->data['is_default'] ) ? $this->data['is_default'] : false;
	}
	
	/**
	 * Delete the WC_Payment_Token
	 *
	 * @since 1.6.0
	 *
	 * @param bool $force_delete
	 *
	 * @return bool
	 */
	public function delete( $force_delete = false ) {
		if ( $this->is_wc_token ) {
			return $this->data->delete( $force_delete = false );
		}
		
		return true;
	}
	
	/*
	|--------------------------------------------------------------------------
	| Setters
	|--------------------------------------------------------------------------
	*/
	
	/**
	 * Sets the profile
	 *
	 * @since 1.6.0
	 *
	 * @param \WC_Payment_Token_Psigate_CC|\WC_Payment_Token $token
	 */
	public function set_data( $token ) {
		$this->data = $token;
	}
	
	/**
	 * Sets the ID for the legacy profile
	 *
	 * @since 1.6.0
	 *
	 * @param $id
	 */
	public function set_id( $id ) {
		$this->id = $id;
	}
	
	/*
	|--------------------------------------------------------------------------
	| ArrayAccess/Backwards compatibility.
	|--------------------------------------------------------------------------
	*/
	
	/**
	 * Getting a prop from the WC_Payment_Token or the legacy token
	 *
	 * @param string $name
	 * @param string $context
	 *
	 * @return int|string
	 */
	public function get_prop( $name, $context = 'view' ) {
		// All get methods are strictly defined,
		// if they don't exist empty string is returned
		if ( is_callable( array( $this, "get_$name" ) ) ) {
			return $this->{"get_$name"}( $context );
		}
		
		return '';
	}
	
	/**
	 * Sets a property in the WC_Payment_Token or the legacy token
	 *
	 * @param $name
	 * @param $value
	 */
	public function set_prop( $name, $value ) {
		if ( $this->is_wc_token() ) {
			if ( is_callable( array( $this->data, "set_$name" ) ) ) {
				$this->data->{"set_$name"}( $value );
			}
			
			if ( 'exp_month' == $name ) {
				$this->data->set_expiry_month( $value );
			}
			
			if ( 'exp_year' == $name ) {
				$this->data->set_expiry_year( $value );
			}
		} else {
			if ( 'token' == $name ) {
				$name = 'serial_no';
			}
			
			$this->data[ $name ] = $value;
		}
	}
	
	/**
	 * OffsetGet.
	 *
	 * @param string $offset Offset.
	 *
	 * @return mixed
	 */
	public function offsetGet( $offset ) {
		return $this->get_prop( $offset );
	}
	
	/**
	 * OffsetSet.
	 *
	 * @param string $offset Offset.
	 * @param mixed  $value  Value.
	 */
	public function offsetSet( $offset, $value ) {
		if ( is_callable( array( $this, "set_$offset" ) ) ) {
			$this->{"set_$offset"}( $value );
		}
	}
	
	/**
	 * OffsetUnset
	 *
	 * @param string $offset Offset.
	 */
	public function offsetUnset( $offset ) {
		$this->set_prop( $offset, '' );
	}
	
	/**
	 * OffsetExists.
	 *
	 * @param string $offset Offset.
	 *
	 * @return bool
	 */
	public function offsetExists( $offset ) {
		if ( is_callable( array( $this, "get_$offset" ) )
		     || 'exp_month' == $offset
		     || 'exp_year' == $offset
		) {
			return true;
		}
	}
	
	/**
	 * Magic __isset method for backwards compatibility. Legacy properties which could be accessed directly in the past.
	 *
	 * @param string $key Key name.
	 *
	 * @return bool
	 */
	public function __isset( $key ) {
		if ( is_callable( array( $this, "get_$key" ) )
		     || 'exp_month' == $key
		     || 'exp_year' == $key
		) {
			return true;
		}
	}
	
	/**
	 * Magic __get method for backwards compatibility. Maps legacy vars to new getters.
	 *
	 * @param string $key Key name.
	 *
	 * @return mixed
	 */
	public function __get( $key ) {
		return $this->get_prop( $key );
	}
}