<?php

namespace WcPsigate\Helpers;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Description
 *
 * @since  3.3.0
 * @author VanboDevelops | Ivan Andreev
 *
 *        Copyright: (c) 2018 VanboDevelops
 *        License: GNU General Public License v3.0
 *        License URI: http://www.gnu.org/licenses/gpl-3.0.html
 */
class Retrievers {
	
	/**
	 * Safely get POST variables
	 *
	 * @since 1.6.0
	 *
	 * @param string $name    POST variable name
	 * @param string $default Default value
	 *
	 * @return string The variable value
	 */
	public static function get_post( $name, $default = '' ) {
		if ( isset( $_POST[ $name ] ) ) {
			return $_POST[ $name ];
		}
		
		return $default;
	}
	
	/**
	 * Safely get GET variables
	 *
	 * @since 1.6.0
	 *
	 * @param string $name    GET variable name
	 * @param string $default Default value
	 *
	 * @return string The variable value
	 */
	public static function get_get( $name, $default = '' ) {
		if ( isset( $_GET[ $name ] ) ) {
			return $_GET[ $name ];
		}
		
		return $default;
	}
	
	/**
	 * Get an array field
	 *
	 * @since 1.6.0
	 *
	 * @param string $name    Field name
	 * @param array  $stack   The array
	 * @param string $default Default value
	 *
	 * @return string
	 */
	public static function get_field( $name, $stack, $default = '' ) {
		if ( is_array( $stack ) ) {
			if ( isset( $stack[ $name ] ) ) {
				return $stack[ $name ];
			}
		} elseif ( is_object( $stack ) ) {
			if ( isset( $stack->{$name} ) ) {
				return $stack->{$name};
			}
		}
		
		return $default;
	}
}