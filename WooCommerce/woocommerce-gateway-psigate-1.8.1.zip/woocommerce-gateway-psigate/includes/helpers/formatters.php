<?php

namespace WcPsigate\Helpers;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Description
 *
 * @since  3.3.0
 * @author VanboDevelops | Ivan Andreev
 *
 *        Copyright: (c) 2018 VanboDevelops
 *        License: GNU General Public License v3.0
 *        License URI: http://www.gnu.org/licenses/gpl-3.0.html
 */
class Formatters {
	
	/**
	 * Return the order number with stripped # or n° ( french translations )
	 *
	 * @param \WC_Order $order
	 *
	 * @return string
	 */
	public static function get_order_number( \WC_Order $order ) {
		return str_replace( array( '#', 'n°' ), '', $order->get_order_number() );
	}
	
	/**
	 * Formats and returns a the passed string
	 *
	 * @param string $string String to be formatted
	 * @param int    $limit  Limit characters of the string
	 *
	 * @return string
	 * @since 1.3
	 *
	 */
	public static function format_string( $string, $limit ) {
		if ( strlen( $string ) > $limit ) {
			$string = substr( $string, 0, ( $limit - 3 ) ) . '...';
		}
		
		return $string;
	}
	
	/**
	 * Formats an amount the way PsiGate expects it
	 *
	 * @param float $amount
	 *
	 * @return float
	 */
	public static function format_amount( $amount ) {
		return number_format( $amount, 2, '.', '' );
	}
	
	/**
	 * Remove white space from a string
	 *
	 * @param $string $string
	 *
	 * @return string
	 */
	public static function remove_white_space( $string ) {
		return str_replace( ' ', '', $string );
	}
	
	/**
	 * Format and return the expiration month and year
	 *
	 * @param string $expiration_date
	 *
	 * @return array
	 */
	public static function format_exp_date( $expiration_date ) {
		$cc_exp_date = str_replace( ' ', '', explode( '/', $expiration_date ) );
		
		return array( 'month' => $cc_exp_date[0], 'year' => $cc_exp_date[1] );
	}
}