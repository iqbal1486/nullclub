<?php

namespace WcPsigate\Helpers;

use WC_PsiGate;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Description
 *
 * @since  3.3.0
 * @author VanboDevelops | Ivan Andreev
 *
 *        Copyright: (c) 2018 VanboDevelops
 *        License: GNU General Public License v3.0
 *        License URI: http://www.gnu.org/licenses/gpl-3.0.html
 */
class Validators {
	
	/**
	 * Verify a form request action
	 *
	 * @since 1.6.0
	 *
	 * @param string $name
	 * @param string $action
	 *
	 * @throws \Exception
	 */
	public static function verify_request( $name, $action ) {
		if ( ! wp_verify_nonce( Retrievers::get_post( $name ), $action ) ) {
			throw new \Exception( __( 'Cannot verify the request, please try again.', WC_PsiGate::TEXT_DOMAIN ) );
		}
	}
	
	/**
	 * Check and validate the card fields
	 *
	 * @param mixed $cc_number    Credit card number
	 * @param mixed $cc_cvc       Card Security Code
	 * @param mixed $cc_exp_year  Expiration year
	 *
	 * @param mixed $cc_exp_month Expiration month
	 *
	 * @throws \Exception
	 *
	 * @return void
	 */
	public static function validate_card_fields( $cc_number = '', $cc_cvc = '', $cc_exp_year = '', $cc_exp_month = '' ) {
		//Check credit card number
		if ( empty( $cc_number ) ) {
			throw new \Exception( __( 'Credit Card Number Required.', WC_PsiGate::TEXT_DOMAIN ) );
		} else {
			if ( ! is_numeric( $cc_number ) || ( strlen( $cc_number ) > 19 || strlen( $cc_number ) < 12 ) ) {
				throw new \Exception( __( 'Invalid Credit Card Number length.', WC_PsiGate::TEXT_DOMAIN ) );
			}
		}
		
		//Check credit card CV2 number
		if ( empty( $cc_cvc ) ) {
			throw new \Exception( __( 'CVC number required.', WC_PsiGate::TEXT_DOMAIN ) );
		} else {
			//Check CVN
			if ( ! is_numeric( $cc_cvc ) ) {
				throw new \Exception( __( 'Invalid Card Verification Code. Only numbers are allowed.', WC_PsiGate::TEXT_DOMAIN ) );
			}
			
			if ( strlen( $cc_cvc ) > 4 || strlen( $cc_cvc ) < 3 ) {
				throw new \Exception( __( 'Invalid Card Verification Code length. The CVC has to be 3 or 4 digits long. ', WC_PsiGate::TEXT_DOMAIN ) );
			}
		}
		
		if ( empty( $cc_exp_month ) ) {
			throw new \Exception( __( 'Expiration month required.', WC_PsiGate::TEXT_DOMAIN ) );
		}
		
		if ( empty( $cc_exp_year ) ) {
			throw new \Exception( __( 'Expiration year required.', WC_PsiGate::TEXT_DOMAIN ) );
		}
		
		//Check exp date
		$current_year  = date( 'y' );
		$current_month = date( 'n' );
		if ( ! is_numeric( $cc_exp_year ) ||
		     $cc_exp_year < $current_year ||
		     $cc_exp_year > ( $current_year + 10 ) ||
		     ! is_numeric( $cc_exp_month ) ||
		     $cc_exp_month < 0 ||
		     $cc_exp_month > 12 ||
		     ( $cc_exp_year == $current_year && $cc_exp_month < $current_month )
		) {
			throw new \Exception( __( 'Invalid expiration date.', WC_PsiGate::TEXT_DOMAIN ) );
		}
	}
}