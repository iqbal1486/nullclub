<?php

namespace WcPsigate\Admin;

use WC_PsiGate;
use WcPsigate\Helpers\Factories;

/**
 * Plugin System Status
 *
 * @since      1.6.0
 */
class System_Status {
	
	public $gateway;
	public $gateway_id;
	public $plugin_license_id;
	
	public function __construct( $gateway_id, $plugin_license_id = 0 ) {
		$this->gateway_id        = $gateway_id;
		$this->plugin_license_id = $plugin_license_id;
	}
	
	/**
	 * Attach callbacks
	 *
	 * @since 3.5.0
	 */
	public function hooks() {
		add_filter( 'woocommerce_system_status_report', array( $this, 'render_system_status_items' ), 100 );
	}
	
	/**
	 * @return bool|\WC_Payment_Gateway|\WcPsigate\Gateway_PsiGate
	 */
	public function get_gateway() {
		if ( null == $this->gateway ) {
			$this->gateway = Factories::get_gateway( $this->gateway_id );
		}
		
		return $this->gateway;
	}
	
	/**
	 * Renders the Subscription information in the WC status page
	 *
	 * @since 3.5.0
	 */
	public function render_system_status_items() {
		$testmode = 'yes' == $this->get_gateway()->testmode;
		
		$status_data['wc_psigate_testmode'] = array(
			'name'      => _x( 'Sandbox', 'Label on WooCommerce -> System Status page', WC_PsiGate::TEXT_DOMAIN ),
			'label'     => 'Sandbox',
			'note'      => $testmode ? __( 'Test', WC_PsiGate::TEXT_DOMAIN ) : __( 'Live', WC_PsiGate::TEXT_DOMAIN ),
			'mark'      => $testmode ? 'error' : 'yes',
			'mark_icon' => '',
		);
		
		$status_data['wc_psigate_token_payments'] = array(
			'name'  => _x( 'Allows payment with Tokens', 'Label on WooCommerce -> System Status page', WC_PsiGate::TEXT_DOMAIN ),
			'label' => 'Allows payment with Tokens',
			'note'  => 'yes' == $this->get_gateway()->save_customers ? __( 'Yes', WC_PsiGate::TEXT_DOMAIN ) : __( 'No', WC_PsiGate::TEXT_DOMAIN ),
			'mark'  => 'yes' == $this->get_gateway()->save_customers ? 'yes' : 'error',
			
			'mark_icon' => '',
		);
		
		$status_data['wc_psigate_itemized_details'] = array(
			'name'  => _x( 'Sends Itemized Details', 'Label on WooCommerce -> System Status page', WC_PsiGate::TEXT_DOMAIN ),
			'label' => 'Sends Itemized Details',
			'note'  => $this->get_gateway()->send_xml_api_order_details ? __( 'Yes', WC_PsiGate::TEXT_DOMAIN ) : __( 'No', WC_PsiGate::TEXT_DOMAIN ),
			'mark'  => $this->get_gateway()->send_xml_api_order_details ? 'yes' : 'error',
			
			'mark_icon' => '',
		);
		
		$xml_set = '' != $this->get_gateway()->StoreID && '' != $this->get_gateway()->Passphrase;
		
		$status_data['wc_psigate_xml_setup'] = array(
			'name'  => _x( 'Configured XML API', 'Label on WooCommerce -> System Status page', WC_PsiGate::TEXT_DOMAIN ),
			'label' => 'Configured XML API',
			'note'  => $xml_set ? __( 'Yes', WC_PsiGate::TEXT_DOMAIN ) : __( 'No', WC_PsiGate::TEXT_DOMAIN ),
			'mark'  => $xml_set ? 'yes' : 'error',
			
			'mark_icon' => '',
		);
		
		if ( ! $testmode ) {
			$status_data['wc_psigate_xml_live_url'] = array(
				'name'      => _x( 'XML Live URL', 'Label on WooCommerce -> System Status page', WC_PsiGate::TEXT_DOMAIN ),
				'label'     => 'XML Live URL',
				'note'      => $this->get_gateway()->liveurl ? __( 'Yes', WC_PsiGate::TEXT_DOMAIN ) : __( 'No', WC_PsiGate::TEXT_DOMAIN ),
				'mark'      => $this->get_gateway()->liveurl ? 'yes' : 'error',
				'mark_icon' => '',
			);
		}
		
		$am_set = '' != $this->get_gateway()->acc_cid && '' != $this->get_gateway()->acc_user_id && '' != $this->get_gateway()->acc_password;
		
		$status_data['wc_psigate_am_setup'] = array(
			'name'  => _x( 'Configured AM API', 'Label on WooCommerce -> System Status page', WC_PsiGate::TEXT_DOMAIN ),
			'label' => 'Configured AM API',
			'note'  => $am_set ? __( 'Yes', WC_PsiGate::TEXT_DOMAIN ) : __( 'No', WC_PsiGate::TEXT_DOMAIN ),
			'mark'  => $am_set ? 'yes' : 'error',
			
			'mark_icon' => '',
		);
		
		if ( ! $testmode ) {
			$status_data['wc_psigate_am_live_url'] = array(
				'name'      => _x( 'AM Live URL', 'Label on WooCommerce -> System Status page', WC_PsiGate::TEXT_DOMAIN ),
				'label'     => 'AM Live URL',
				'note'      => $this->get_gateway()->live_manager_url ? __( 'Yes', WC_PsiGate::TEXT_DOMAIN ) : __( 'No', WC_PsiGate::TEXT_DOMAIN ),
				'mark'      => $this->get_gateway()->live_manager_url ? 'yes' : 'error',
				'mark_icon' => '',
			);
		}
		
		$status_data['wc_psigate_interac'] = array(
			'name'      => _x( 'Interac Enabled', 'Label on WooCommerce -> System Status page', WC_PsiGate::TEXT_DOMAIN ),
			'label'     => 'Interac Enabled',
			'note'      => $this->get_gateway()->interac_enable ? __( 'Yes', WC_PsiGate::TEXT_DOMAIN ) : __( 'No', WC_PsiGate::TEXT_DOMAIN ),
			'mark'      => $this->get_gateway()->interac_enable ? 'yes' : 'error',
			'mark_icon' => '',
		);
		
		if ( $this->get_gateway()->interac_enable ) {
			$interac_set = '' != $this->get_gateway()->html_store_key && '' != $this->get_gateway()->html_pass_phrase;
			
			$status_data['wc_psigate_interac_setup'] = array(
				'name'      => _x( 'Configured Interac API', 'Label on WooCommerce -> System Status page', WC_PsiGate::TEXT_DOMAIN ),
				'label'     => 'Configured Interac API',
				'note'      => $interac_set ? __( 'Yes', WC_PsiGate::TEXT_DOMAIN ) : __( 'No', WC_PsiGate::TEXT_DOMAIN ),
				'mark'      => $interac_set ? 'yes' : 'error',
				'mark_icon' => '',
			);
			
			if ( ! $testmode ) {
				$status_data['wc_psigate_interac_live_url'] = array(
					'name'      => _x( 'Interac Live URL', 'Label on WooCommerce -> System Status page', WC_PsiGate::TEXT_DOMAIN ),
					'label'     => 'Interac Live URL',
					'note'      => $this->get_gateway()->html_live_url ? __( 'Yes', WC_PsiGate::TEXT_DOMAIN ) : __( 'No', WC_PsiGate::TEXT_DOMAIN ),
					'mark'      => $this->get_gateway()->html_live_url ? 'yes' : 'error',
					'mark_icon' => '',
				);
			}
		}
		
		$status_data['wc_psigate_threeds'] = array(
			'name'      => _x( 'ThreeDS Enabled', 'Label on WooCommerce -> System Status page', WC_PsiGate::TEXT_DOMAIN ),
			'label'     => 'ThreeDS Enabled',
			'note'      => $this->get_gateway()->is_threeds_enabled() ? __( 'Yes', WC_PsiGate::TEXT_DOMAIN ) : __( 'No', WC_PsiGate::TEXT_DOMAIN ),
			'mark'      => $this->get_gateway()->is_threeds_enabled() ? 'yes' : 'error',
			'mark_icon' => '',
		);
		
		if ( $this->get_gateway()->is_threeds_enabled() ) {
			$status_data['wc_psigate_threeds_version'] = array(
				'name'      => _x( 'ThreeDS Version', 'Label on WooCommerce -> System Status page', WC_PsiGate::TEXT_DOMAIN ),
				'label'     => 'ThreeDS Version',
				'note'      => $this->get_gateway()->threeds_version,
				'mark'      => 'yes',
				'mark_icon' => '',
			);
			
			$status_data['wc_psigate_threeds_key'] = array(
				'name'      => _x( 'ThreeDS Key', 'Label on WooCommerce -> System Status page', WC_PsiGate::TEXT_DOMAIN ),
				'label'     => 'ThreeDS Key',
				'note'      => $this->get_gateway()->get_option( '3ds_api_key', '' ) ? __( 'Set', WC_PsiGate::TEXT_DOMAIN ) : __( 'Not Set', WC_PsiGate::TEXT_DOMAIN ),
				'mark'      => $this->get_gateway()->get_option( '3ds_api_key', '' ) ? 'yes' : 'error',
				'mark_icon' => '',
			);
			
			$status_data['wc_psigate_threeds_attempt'] = array(
				'name'      => _x( 'ThreeDS Process with Rejection', 'Label on WooCommerce -> System Status page', WC_PsiGate::TEXT_DOMAIN ),
				'label'     => 'ThreeDS Process with Rejection',
				'note'      => 'yes' === $this->get_gateway()->get_option( '3ds_process_with_rejection', 'no' ) ? __( 'Yes', WC_PsiGate::TEXT_DOMAIN ) : __( 'No', WC_PsiGate::TEXT_DOMAIN ),
				'mark'      => 'yes' === $this->get_gateway()->get_option( '3ds_process_with_rejection', 'no' ) ? 'yes' : 'error',
				'mark_icon' => '',
			);
		}
		
		$status_data['wc_psigate_forms'] = array(
			'name'      => _x( 'Forms displayed', 'Label on WooCommerce -> System Status page', WC_PsiGate::TEXT_DOMAIN ),
			'label'     => 'Forms displayed',
			'note'      => $this->get_gateway()->get_option( 'separated_forms' ),
			'mark'      => 'yes',
			'mark_icon' => '',
		);
		
		$system_status_sections = array(
			array(
				'title'   => __( 'Psigate Gateway', WC_PsiGate::TEXT_DOMAIN ),
				'tooltip' => __( 'System information about WooCommerce Psigate plugin.', WC_PsiGate::TEXT_DOMAIN ),
				'data'    => apply_filters( 'wc_psigate_system_status', $status_data ),
			),
		);
		
		foreach ( $system_status_sections as $section ) {
			$section_title   = $section['title'];
			$section_tooltip = $section['tooltip'];
			$debug_data      = $section['data'];
			
			include( WC_PsiGate::plugin_path() . '/includes/admin/views/system-status.php' );
		}
	}
	
	/**
	 * Return the currency codes that we have set merchant accounts for
	 *
	 * @param $accounts
	 *
	 * @return array
	 */
	public function get_accounts_for_currencies( $accounts ) {
		$currencies = array();
		foreach ( $accounts as $data ) {
			if ( '' == $data['account_id'] ) {
				continue;
			}
			$currencies[] = $data['account_currency'];
		}
		
		return $currencies;
	}
}
