<?php
/*
 * Main PsiGate Payment class
 *
 * Author: VanboDevelops
 * Author URI: http://www.vanbodevelops.com
 *
 *	Copyright: (c) 2012 - 2014 VanboDevelops
 *	License: GNU General Public License v3.0
 *	License URI: http://www.gnu.org/licenses/gpl-3.0.html
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Backward compatible wrapper of the new namespaced gateway class
 * @since 1.6.0
 */
class WC_Gateway_PsiGate extends \WcPsigate\Gateway_PsiGate {
	public function __construct() {
		parent::__construct();
	}
} //end PsiGate class

