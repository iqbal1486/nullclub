=== WooCommerce PsiGate Gateway ===

This plugin allows you to use PsiGate payment gateway within your WooCommerce store.

== Description ==

A plugin that allows you to extend your WooCommerce installation with the PsiGate payment processor.
Your customers will be able to pay straight from your checkout page.

This plugin was created by: vanbo.develops(Ivan Andreev)

== Installation ==

1. Upload the `woocommerce-gateway-psigate` plugin to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Navigate to `WooCommerce > Settings > Payment Gateways` to configure the PsiGate gateway settings.


== Filters ==
wc_psigate_process_refund_parameters - process refund request. Passes $parameters and $order
wc_psigate_process_credit_card_payment_parameters - Regular credit card xml request. Passed $parameters, $order
wc_psigate_process_acc_manager_payment_parameters - Account manager payment request. Passed $parameters, $order
wc_psigate_register_customer_account_parameters - Register a payment account with PsiGate request. Passed $parameters, $order
