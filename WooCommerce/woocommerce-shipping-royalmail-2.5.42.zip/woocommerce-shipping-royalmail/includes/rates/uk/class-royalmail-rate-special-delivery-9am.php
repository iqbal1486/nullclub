<?php
/**
 * Special Delivery Guaranteed by 9am rate.
 *
 * @package WC_RoyalMail/Rate
 */

/**
 * RoyalMail_Rate_Special_Delivery_9am class.
 *
 * Updated on 2022-04-04 as per https://www.royalmail.com/sites/royalmail.com/files/2022-03/royal-mail-our-prices-april-2022-v2.pdf.
 * See UK Guaranteed page 4.
 */
class RoyalMail_Rate_Special_Delivery_9am extends RoyalMail_Rate {

	/**
	 * ID/Name of rate.
	 *
	 * @var string
	 */
	protected $rate_id = 'special_delivery_9am';

	/**
	 * Pricing bands.
	 *
	 * Key is coverage / compensation for loss or damage and value is key-value
	 * array where key is weight (up to and including) and value is the price
	 * in penny.
	 *
	 * @var array
	 */
	protected $bands = array(
		'2021' => array(
			50     => array(
				100  => 2226,
				500  => 2518,
				1000 => 2729,
				2000 => 3119,
			),
			1000   => array(
				100  => 2446,
				500  => 2738,
				1000 => 2949,
				2000 => 3339,
			),
			2500 => array(
				100  => 2796,
				500  => 3088,
				1000 => 3299,
				2000 => 3689,
			),
		),
		'2022' => array(
			50     => array(
				100  => 2295,
				500  => 2595,
				1000 => 2795,
				2000 => 3395,
			),
			1000   => array(
				100  => 2515,
				500  => 2815,
				1000 => 3015,
				2000 => 3615,
			),
			2500 => array(
				100  => 2865,
				500  => 3165,
				1000 => 3365,
				2000 => 3965,
			),
		),
	);

	/**
	 * Shipping boxes.
	 *
	 * @var array
	 */
	protected $boxes = array(
		'packet' => array(
			'length'   => 610,  // Max length.
			'width'    => 460,  // Max width.
			'height'   => 460,  // Max height.
			'weight'   => 2000, // Max weight.
		),
	);

	/**
	 * Get quotes for this rate.
	 *
	 * @param  array  $items to be shipped.
	 * @param  string $packing_method the method selected.
	 * @param  string $destination Address to ship to.
	 * @return array
	 */
	public function get_quotes( $items, $packing_method, $destination ) {
		$quote    = false;
		$packages = $this->get_packages( $items, $packing_method );

		// Service not available for the following destinations.
		$excluded_destinations = array(
			'GG', // Guernsey
			'IM', // Isle of Man
			'JE', // Jersey
		);

		if( in_array( $destination, $excluded_destinations ) ) {
			return false;
		}

		if ( $packages ) {
			foreach ( $packages as $package ) {
				if ( empty( $package->id ) ) {
					// Try a tube or fail.
					if ( $package->length < 900 && $package->length + ( $package->width * 2 ) < 1040 ) {
						$package->id = 'packet';
					} else {
						return false; // Unpacked item.
					}
				}

				$this->debug( __( 'Special Delivery package 9am:', 'woocommerce-shipping-royalmail' ) . ' <pre>' . print_r( $package, true ) . '</pre>' );

				$bands   = $this->get_rate_bands();
				$matched = false;

				foreach ( $bands as $coverage => $weight_bands ) {
					if ( is_numeric( $coverage ) && $package->value > $coverage ) {
						continue;
					}
					foreach ( $weight_bands as $weight => $value ) {

						if ( is_numeric( $weight ) && $package->weight <= $weight ) {
							$quote += $value;
							$matched = true;
							break 2;
						}
					}
				}

				if ( ! $matched ) {
					return;
				}
			}
		}

		// Rates include 20% VAT.
		$quote = $quote / 1.2;
		$quote = $quote / 100;

		$quotes                         = array();
		$quotes['special-delivery-9am'] = $quote;

		return $quotes;
	}
}
