<?php
/**
 * First class rate.
 *
 * @package WC_RoyalMail/Rate
 */

/**
 * RoyalMail_Rate_Tracked_24 class.
 *
 * Up-to-date as of 2022-04-04 as per https://www.royalmail.com/sites/royalmail.com/files/2022-03/royal-mail-online-price-guide-april-2022.pdf.
 * See UK Tracked page 5.
 */
class RoyalMail_Rate_Tracked_24 extends RoyalMail_Rate {

	/**
	 * ID/Name of rate.
	 *
	 * @var string
	 */
	protected $rate_id = 'tracked_24';

	const COMPENSATION_UP_TO_VALUE = 100;

	/**
	 * Pricing bands
	 *
	 * Key is size (e.g. 'letter') and value is an array where key is weight in
	 * gram and value is the price (in penny).
	 *
	 * @var array
	 */
	protected $bands = array(
		'2020' => array(
			'large-letter'        => array(
				750 => 402,
			),
			'small-parcel-wide'   => array(
				1000 => 546,
				2000 => 780,
			),
			'small-parcel-deep'   => array(
				1000 => 546,
				2000 => 780,
			),
			'small-parcel-bigger' => array(
				1000 => 546,
				2000 => 780,
			),
			'medium-parcel'       => array(
				1000  => 846,
				2000  => 1194,
				5000  => 1800,
				10000 => 2160,
				20000 => 3360,
			),
		),
		'2022' => array(
			'large-letter'        => array(
				750 => 380,
			),
			'small-parcel-wide'   => array(
				1000 => 545,
				2000 => 545,
			),
			'small-parcel-deep'   => array(
				1000 => 545,
				2000 => 545,
			),
			'small-parcel-bigger' => array(
				1000 => 545,
				2000 => 545,
			),
			'medium-parcel'       => array(
				1000  => 795,
				2000  => 795,
				5000  => 895,
				10000 => 895,
				20000 => 1445,
			),
		),
	);

	/**
	 * Shipping boxes.
	 *
	 * @var array
	 */
	protected $boxes = array(
		'large-letter'        => array(
			'length' => 353,
			'width'  => 250,
			'height' => 25,
			'weight' => 750,
		),
		'small-parcel-wide'   => array(
			'length' => 450,
			'width'  => 350,
			'height' => 80,
			'weight' => 2000,
		),
		'small-parcel-deep'   => array(
			'length' => 350,
			'width'  => 250,
			'height' => 160,
			'weight' => 2000,
		),
		'small-parcel-bigger' => array(
			'length' => 450,
			'width'  => 350,
			'height' => 160,
			'weight' => 2000,
		),
		'medium-parcel'       => array(
			'length' => 610,
			'width'  => 460,
			'height' => 460,
			'weight' => 20000,
		),
	);

	/**
	 * Get quotes for this rate.
	 *
	 * @param  array  $items to be shipped.
	 * @param  string $packing_method the method selected.
	 * @param  string $destination Address to ship to.
	 * @return array
	 */
	public function get_quotes( $items, $packing_method, $destination, $boxes = array(), $instance_id = '' ) {
		$class_quote           = 0;
		$packages              = $this->get_packages( $items, $packing_method );
		$options               = $this->get_instance_options( $instance_id );
		$compensation_optional = ( ! empty( $options['compensation_optional'] ) && 'yes' === $options['compensation_optional'] );

		if ( $packages ) {
			foreach ( $packages as $package ) {
				if ( $package->value > self::COMPENSATION_UP_TO_VALUE && ! $compensation_optional ) {
					return false; // Max. compensation is 100.
				}

				$quote = 0;

				if ( ! $this->get_rate_bands( $package->id ) ) {
					return false; // Unpacked item.
				}

				$this->debug( __( 'RoyalMail Tracked 24:', 'woocommerce-shipping-royalmail' ) . ' <pre>' . print_r( $package, true ) . '</pre>' );

				$bands = $this->get_rate_bands( $package->id );

				$matched = false;

				foreach ( $bands as $band => $value ) {
					if ( is_numeric( $band ) && $package->weight <= $band ) {
						$quote += $value;
						$matched = true;
						break;
					}
				}

				if ( ! $matched ) {
					return null;
				}

				$class_quote += $quote;
			}
		}

		// Return pounds.
		$quotes               = array();
		$quotes['tracked-24'] = $class_quote / 100;

		return $quotes;
	}
}
