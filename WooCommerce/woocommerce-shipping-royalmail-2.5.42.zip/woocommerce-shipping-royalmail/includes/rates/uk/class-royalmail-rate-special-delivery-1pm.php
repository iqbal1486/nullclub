<?php
/**
 * Special Delivery Guaranteed by 1pm rate.
 *
 * @package WC_RoyalMail/Rate
 */

/**
 * RoyalMail_Rate_Special_Delivery_1pm class.
 *
 * Updated on 2022-04-04 as per https://www.royalmail.com/sites/royalmail.com/files/2022-03/royal-mail-our-prices-april-2022-v2.pdf.
 * See UK Guaranteed page 4.
 */
class RoyalMail_Rate_Special_Delivery_1pm extends RoyalMail_Rate {

	/**
	 * ID/Name of rate.
	 *
	 * @var string
	 */
	protected $rate_id = 'special_delivery_1pm';

	/**
	 * Pricing bands.
	 *
	 * Key is coverage / compensation for loss or damage and value is key-value
	 * array where key is weight (up to and including) and value is the price
	 * in penny.
	 *
	 * @var array
	 */
	protected $bands = array(
		'2021' => array(
			500    => array(
				100   => 685,
				500   => 765,
				1000  => 895,
				2000  => 1115,
				10000 => 2675,
				20000 => 4135,
			),
			1000   => array(
				100   => 785,
				500   => 865,
				1000  => 995,
				2000  => 1215,
				10000 => 2775,
				20000 => 4235,
			),
			2500 => array(
				100   => 985,
				500   => 1065,
				1000  => 1195,
				2000  => 1415,
				10000 => 2975,
				20000 => 4435,
			),
		),
		'2022' => array(
			500    => array(
				100   => 685,
				500   => 765,
				1000  => 895,
				2000  => 1115,
				10000 => 1545,
				20000 => 1945,
			),
			1000   => array(
				100   => 785,
				500   => 865,
				1000  => 995,
				2000  => 1215,
				10000 => 1645,
				20000 => 2045,
			),
			2500 => array(
				100   => 985,
				500   => 1065,
				1000  => 1195,
				2000  => 1415,
				10000 => 1845,
				20000 => 2245,
			),
		),
	);

	/**
	 * Shipping boxes.
	 *
	 * @var array
	 */
	protected $boxes = array(
		'packet' => array(
			'length'   => 610,   // Max length.
			'width'    => 460,   // Max width.
			'height'   => 460,   // Max height.
			'weight'   => 20000, // Max weight.
		),
	);

	/**
	 * Get quotes for this rate.
	 *
	 * @param  array  $items to be shipped.
	 * @param  string $packing_method the method selected.
	 * @param  string $destination Address to ship to.
	 * @return array
	 */
	public function get_quotes( $items, $packing_method, $destination ) {
		$quote    = false;
		$packages = $this->get_packages( $items, $packing_method );

		if ( $packages ) {
			foreach ( $packages as $package ) {
				if ( empty( $package->id ) ) {
					// Try a tube or fail.
					if ( $package->length < 900 && $package->length + ( $package->width * 2 ) < 1040 ) {
						$package->id = 'packet';
					} else {
						return false; // Unpacked item.
					}
				}

				$this->debug( __( 'Special Delivery package 1pm:', 'woocommerce-shipping-royalmail' ) . ' <pre>' . print_r( $package, true ) . '</pre>' );

				$bands   = $this->get_rate_bands();
				$matched = false;

				foreach ( $bands as $coverage => $weight_bands ) {
					if ( is_numeric( $coverage ) && $package->value > $coverage ) {
						continue;
					}
					foreach ( $weight_bands as $weight => $value ) {

						if ( is_numeric( $weight ) && $package->weight <= $weight ) {
							$quote += $value;
							$matched = true;
							break 2;
						}
					}
				}

				if ( ! $matched ) {
					return;
				}
			}
		}

		// Return pounds.
		$quotes                         = array();
		$quotes['special-delivery-1pm'] = $quote / 100;

		return $quotes;
	}
}
