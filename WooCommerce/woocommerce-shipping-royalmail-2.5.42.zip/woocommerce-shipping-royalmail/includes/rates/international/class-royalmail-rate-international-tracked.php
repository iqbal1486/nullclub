<?php
/**
 * International-Tracked rate.
 *
 * @package WC_RoyalMail/Rate
 */

/**
 * RoyalMail_Rate_International_Tracked class.
 *
 * Updated on 2022-04-04 as per https://www.royalmail.com/sites/royalmail.com/files/2022-03/royal-mail-our-prices-april-2022-v2.pdf.
 * See International Tracked page 15 - 16.
 */
class RoyalMail_Rate_International_Tracked extends RoyalMail_Rate {

	/**
	 * ID/Name of rate
	 *
	 * @var string
	 */
	protected $rate_id = 'international_tracked';

	/**
	 * List of countries that support Tracked service.
	 *
	 * @see http://www.royalmail.com/sites/default/files/Royal-Mail-International-Tracking-Signature-Services-List-April2017.pdf
	 *
	 * @since 2.5.4
	 * @version 2.5.4
	 *
	 * @var array
	 */
	protected $supported_countries = array(
		'AX',
		'AD',
		'AU',
		'AT',
		'BE',
		'BR',
		'CA',
		'HR',
		'CY',
		'DK',
		'EE',
		'FO',
		'FI',
		'FR',
		'DE',
		'GI',
		'GR',
		'GL',
		'HK',
		'HU',
		'IS',
		'IN',
		'IE',
		'IL',
		'IT',
		'LV',
		'LB',
		'LI',
		'LT',
		'LU',
		'MY',
		'MT',
		'NL',
		'NZ',
		'NO',
		'PL',
		'PT',
		'RU',
		'SM',
		'RS',
		'SG',
		'SK',
		'SI',
		'KR',
		'ES',
		'SE',
		'CH',
		'TR',
		'US',
		'VA',
	);

	/**
	 * Pricing bands - Europe, Zone 1, Zone 2, Zone 3 (previously Zone 1)
	 *
	 * @var array
	 */
	protected $bands = array(
		'2021' => array(
			'letter'                => array(
				10  => array( 675, 675, 675, 675, 675, 675 ),
				20  => array( 675, 675, 675, 675, 675, 675 ),
				100 => array( 675, 675, 675, 775, 775, 775 ),
			),
			'large-letter'          => array(
				100 => array( 865, 865, 865, 960, 965, 965 ),
				250 => array( 885, 885, 885, 1035, 1145, 1055 ),
				500 => array( 985, 985, 985, 1220, 1400, 1250 ),
				750 => array( 1025, 1025, 1025, 1405, 1680, 1450 ),
			),
			'packet'                => array(
				100  => array( 1010, 1010, 1010, 1175, 1280, 1185 ),
				250  => array( 1025, 1025, 1025, 1270, 1415, 1345 ),
				500  => array( 1170, 1170, 1170, 1635, 1855, 1810 ),
				750  => array( 1275, 1275, 1275, 1875, 2135, 2085 ),
				1000 => array( 1370, 1370, 1370, 2140, 2450, 2450 ),
				1250 => array( 1410, 1410, 1410, 2325, 2690, 2795 ),
				1500 => array( 1485, 1485, 1485, 2465, 2940, 3070 ),
				2000 => array( 1525, 1525, 1525, 2565, 3100, 3195 ),
			),
			'printed-papers' => array(
				100  => array( 1010, 1010, 1010, 1175, 1280, 1185 ),
				250  => array( 1025, 1025, 1025, 1270, 1415, 1345 ),
				500  => array( 1170, 1170, 1170, 1635, 1855, 1810 ),
				750  => array( 1275, 1275, 1275, 1875, 2135, 2085 ),
				1000 => array( 1370, 1370, 1370, 2140, 2450, 2450 ),
				1250 => array( 1410, 1410, 1410, 2325, 2690, 2795 ),
				1500 => array( 1485, 1485, 1485, 2465, 2940, 3070 ),
				2000 => array( 1525, 1525, 1525, 2565, 3100, 3195 ),
				2250 => array( 1665, 1665, 1665, 2755, 3335, 3455 ),
				2500 => array( 1805, 1805, 1805, 2945, 3570, 3715 ),
				2750 => array( 1945, 1945, 1945, 3135, 3805, 3975 ),
				3000 => array( 2085, 2085, 2085, 3325, 4040, 4235 ),
				3250 => array( 2225, 2225, 2225, 3515, 4275, 4495 ),
				3500 => array( 2365, 2365, 2365, 3705, 4510, 4755 ),
				3750 => array( 2505, 2505, 2505, 3895, 4745, 5015 ),
				4000 => array( 2645, 2645, 2645, 4085, 4980, 5275 ),
				4250 => array( 2785, 2785, 2785, 4275, 5215, 5535 ),
				4500 => array( 2925, 2925, 2925, 4465, 5450, 5795 ),
				4750 => array( 3065, 3065, 3065, 4655, 5685, 6055 ),
				5000 => array( 3205, 3205, 3205, 4845, 5920, 6315 ),
			),
		),
		'2022' => array(
			'letter'                => array(
				10  => array( 690, 690, 690, 690, 690, 690 ),
				20  => array( 690, 690, 690, 690, 690, 690 ),
				100 => array( 690, 690, 690, 775, 775, 775 ),
			),
			'large-letter'          => array(
				100 => array( 865, 865, 865, 960, 965, 965 ),
				250 => array( 885, 885, 885, 1035, 1145, 1055 ),
				500 => array( 985, 985, 985, 1220, 1400, 1250 ),
				750 => array( 1025, 1025, 1025, 1405, 1680, 1450 ),
			),
			'packet'                => array(
				100  => array(  990,  995, 1020, 1125, 1230, 1215 ),
				250  => array(  990,  995, 1020, 1220, 1365, 1345 ),
				500  => array( 1115, 1120, 1160, 1585, 1805, 1810 ),
				750  => array( 1215, 1225, 1275, 1825, 2085, 2085 ),
				1000 => array( 1310, 1320, 1390, 2090, 2400, 2440 ),
				1250 => array( 1400, 1400, 1450, 2275, 2640, 2760 ),
				1500 => array( 1400, 1400, 1530, 2415, 2890, 2760 ),
				2000 => array( 1400, 1465, 1580, 2515, 3050, 2760 ),
			),
			'printed-papers' => array(
				100  => array(  990,  995, 1020, 1125, 1230, 1215 ),
				250  => array(  990,  995, 1020, 1220, 1365, 1345 ),
				500  => array( 1115, 1120, 1160, 1585, 1805, 1810 ),
				750  => array( 1215, 1225, 1275, 1825, 2085, 2085 ),
				1000 => array( 1310, 1320, 1390, 2090, 2400, 2440 ),
				1250 => array( 1400, 1400, 1450, 2275, 2640, 2760 ),
				1500 => array( 1400, 1400, 1530, 2415, 2890, 2760 ),
				2000 => array( 1400, 1465, 1580, 2515, 3050, 2760 ),
				2250 => array( 1540, 1605, 1720, 2705, 3285, 3020 ),
				2500 => array( 1680, 1745, 1860, 2895, 3520, 3280 ),
				2750 => array( 1820, 1885, 2000, 3085, 3755, 3540 ),
				3000 => array( 1960, 2025, 2140, 3275, 3990, 3800 ),
				3250 => array( 2100, 2165, 2280, 3465, 4225, 4060 ),
				3500 => array( 2240, 2305, 2420, 3655, 4460, 4320 ),
				3750 => array( 2380, 2445, 2560, 3845, 4695, 4580 ),
				4000 => array( 2520, 2585, 2700, 4035, 4930, 4840 ),
				4250 => array( 2660, 2725, 2840, 4225, 5165, 5100 ),
				4500 => array( 2800, 2865, 2980, 4415, 5400, 5360 ),
				4750 => array( 2940, 3005, 3120, 4605, 5635, 5620 ),
				5000 => array( 3080, 3145, 3260, 4795, 5870, 5880 ),
			),
		),
	);

	/**
	 * Fixed compensation
	 *
	 * @var string
	 */
	private $compensation    = '250';

	/**
	 * Get quotes for this rate
	 *
	 * @param array $items to be shipped.
	 * @param string $packing_method the method selected.
	 * @param string $destination Address to ship to.
	 * @param array $boxes User-defined boxes.
	 * @param int $instance_id .
	 *
	 * @return array
	 */
	public function get_quotes( $items, $packing_method, $destination, $boxes = array(), $instance_id = '' ) {
		if ( ! in_array( $destination, $this->supported_countries ) ) {
			return;
		}

		$class_quote = false;

		if ( ! empty( $boxes ) ) {
			$this->boxes = array();

			foreach ( $boxes as $key => $box ) {
				$this->boxes[ $key ] = array(
					'length'     => $box['inner_length'],
					'width'      => $box['inner_width'],
					'height'     => $box['inner_height'],
					'box_weight' => $box['box_weight'],
					'weight'     => 2000,
				);
			}
		} else {
			$this->boxes = $this->international_default_box;
		}

		$zone                   = $this->get_zone( $destination );
		$printed_paper_packages = apply_filters( 'woocommerce_shipping_royal_mail_printed_papers_enabled', true, $instance_id, 'tracked', $destination, $packing_method ) ? $this->get_printed_papers_packages( $items, $destination, $packing_method ) : array();
		$regular_packages       = $this->get_packages( $items, $packing_method );
		$packages               = array_merge( $regular_packages, $printed_paper_packages );

		if ( $packages ) {
			foreach ( $packages as $package ) {

				$this->validate_package( $package );

				if ( in_array( $package->id, array( 'packet', 'printed-papers' ) ) && 900 < ( $package->length + $package->width + $package->height ) ) {
					return false; // Exceeding parcels requirement, unpacked.
				}

				if ( ! $this->get_rate_bands( $package->id ) ) {
					return false; // Unpacked item.
				}

				$this->debug( __( 'International tracked package:', 'woocommerce-shipping-royalmail' ) . ' <pre>' . print_r( $package, true ) . '</pre>' );

				$bands   = $this->get_rate_bands( $package->id );
				$quote   = 0;
				$matched = false;

				foreach ( $bands as $band => $value ) {
					if ( $package->weight <= $band ) {
						switch ( $zone ) {
							case 'EUR_1':
								$quote += $value[0];
								break;
							case 'EUR_2':
								$quote += $value[1];
								break;
							case 'EUR_3':
							case 'EU':
								$quote += $value[2];
								break;
							case '1':
								$quote += $value[3];
								break;
							case '2':
								$quote += $value[4];
								break;
							case '3':
								// Fallback to zone 1 for older prices.
								$quote += isset( $value[5] ) ? $value[5] : $value[3];
								break;
						}
						$matched = true;
						break;
					}
				}

				if ( ! $matched ) {
					return;
				}

				$class_quote  += $quote;

				if ( $package->value > 50 ) {
					$class_quote += $this->compensation;
				}
			}
		}

		// Return pounds.
		$quotes = array();
		$quotes['international-tracked'] = $class_quote / 100;

		return $quotes;
	}
}
