<?php
/**
 * Parcelforce irelandexpress rates.
 *
 * @package WC_RoyalMail/Rate
 */

/**
 * Rates for Parcelforce irelandexpress.
 *
 * Based on https://www.parcelforce.com/sites/default/files/3890_PFW_A4_Pricing_guide_AW_ONLINE_18-06-21.pdf.
 */
class RoyalMail_Rate_Parcelforce_Irelandexpress extends Parcelforce_Rate {
	/**
	 * ID/Name of rate.
	 *
	 * @var string
	 */
	protected $rate_id = 'parcelforce_irelandexpress';

	/**
	 * Pricing bands.
	 *
	 * Key is zone and value is an array where key is weight (up to) in gram
	 * and value is the price (in penny).
	 *
	 * @var array
	 */
	protected $bands = array(
		'2021' => array(
			'5' => array(
				500   => 2754, 
				1000  => 2754, 
				1500  => 2754, 
				2000  => 2754, 
				2500  => 2754, 
				3000  => 2754, 
				3500  => 2754, 
				4000  => 2754, 
				4500  => 2754, 
				5000  => 2754, 
				5500  => 2886, 
				6000  => 3018, 
				6500  => 3150, 
				7000  => 3282, 
				7500  => 3414, 
				8000  => 3546, 
				8500  => 3678, 
				9000  => 3810, 
				9500  => 3942, 
				10000 => 4074, 
				10500 => 4158, 
				11000 => 4242, 
				11500 => 4326, 
				12000 => 4410, 
				12500 => 4494, 
				13000 => 4578, 
				13500 => 4662, 
				14000 => 4746, 
				14500 => 4830, 
				15000 => 4914, 
				15500 => 5022, 
				16000 => 5130, 
				16500 => 5238, 
				17000 => 5346, 
				17500 => 5454, 
				18000 => 5562, 
				18500 => 5670, 
				19000 => 5778, 
				19500 => 5886, 
				20000 => 5994, 
				20500 => 6102, 
				21000 => 6210, 
				21500 => 6318, 
				22000 => 6426, 
				22500 => 6534, 
				23000 => 6642, 
				23500 => 6750, 
				24000 => 6858, 
				24500 => 6966, 
				25000 => 7074, 
				25500 => 7182, 
				26000 => 7290, 
				26500 => 7398, 
				27000 => 7506, 
				27500 => 7614, 
				28000 => 7722, 
				28500 => 7830, 
				29000 => 7938, 
				29500 => 8046, 
				30000 => 8154, 
			),
		),
	);

	/**
	 * Maximum inclusive compensation.
	 *
	 * @version 2.5.3
	 * @since 2.5.3
	 *
	 * @var int
	 */
	protected $maximum_inclusive_compensation = 200;

	/**
	 * Maximum total cover.
	 *
	 * @version 2.5.3
	 * @since 2.5.3
	 *
	 * @var int
	 */
	protected $maximum_total_cover = 2500;
}
