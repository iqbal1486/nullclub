<?php
/**
 * International Signed rate.
 *
 * @package WC_RoyalMail/Rate
 */

/**
 * RoyalMail_Rate_International_Signed class.
 *
 * Updated on 2022-04-04 as per https://www.royalmail.com/sites/royalmail.com/files/2022-03/royal-mail-our-prices-april-2022-v2.pdf.
 * See International Signed 17.
 */
class RoyalMail_Rate_International_Signed extends RoyalMail_Rate {

	/**
	 * ID/Name of rate
	 *
	 * @var string
	 */
	protected $rate_id = 'international_signed';

	/**
	 * List of countries that support Signed service.
	 *
	 * @see http://www.royalmail.com/sites/default/files/Royal-Mail-International-Tracking-Signature-Services-List-April2017.pdf
	 *
	 * @since 2.5.4
	 * @version 2.5.4
	 *
	 * @var array
	 */
	protected $supported_countries = array(
		'AF',
		'AL',
		'DZ',
		'AO',
		'AI',
		'AG',
		'AM',
		'AW',
		'AU',
		'AZ',
		'BS',
		'BH',
		'BD',
		'BJ',
		'BM',
		'BT',
		'BO',
		'BQ',
		'BA',
		'BW',
		'BR',
		'IO',
		'VG',
		'BN',
		'BF',
		'BI',
		'CM',
		'CV',
		'CF',
		'TD',
		'CL',
		'CN',
		'CX',
		'CO',
		'KM',
		'CG',
		'CD',
		'CR',
		'CU',
		'CW',
		'DJ',
		'DM',
		'DO',
		'EG',
		'SV',
		'GQ',
		'ER',
		'EE',
		'ET',
		'FK',
		'FJ',
		'GF',
		'PF',
		'TF',
		'GA',
		'GM',
		'GH',
		'GD',
		'GP',
		'GT',
		'GN',
		'GW',
		'GY',
		'HT',
		'HN',
		'IN',
		'IR',
		'IQ',
		'IL',
		'CI',
		'JM',
		'JO',
		'KZ',
		'KE',
		'KI',
		'KW',
		'KG',
		'LA',
		'LS',
		'LR',
		'LY',
		'MO',
		'MK',
		'MG',
		'YT',
		'MW',
		'MV',
		'ML',
		'MQ',
		'MR',
		'MU',
		'MX',
		'MN',
		'ME',
		'MS',
		'MA',
		'MZ',
		'MM',
		'NA',
		'NR',
		'NP',
		'NC',
		'NI',
		'NE',
		'NG',
		'NU',
		'KP',
		'NO',
		'OM',
		'PK',
		'PW',
		'PA',
		'PG',
		'PY',
		'PE',
		'PH',
		'PN',
		'PR',
		'QA',
		'RE',
		'RW',
		'ST',
		'SA',
		'SN',
		'SC',
		'SL',
		'SB',
		'ZA',
		'SS',
		'LK',
		'BQ',
		'SH',
		'KN',
		'LC',
		'MF',
		'SX',
		'VC',
		'SD',
		'SR',
		'SZ',
		'SY',
		'TW',
		'TJ',
		'TZ',
		'TL',
		'TG',
		'TK',
		'TN',
		'TM',
		'TC',
		'TV',
		'UA',
		'UY',
		'UZ',
		'VU',
		'VE',
		'VN',
		'WF',
		'EH',
		'WS',
		'YE',
		'ZM',
		'ZW',
	);

	/**
	 * Pricing bands - EU, ZONE 1, Zone 2.
	 *
	 * @var array
	 */
	protected $bands = array(
		'2021' => array(
			'letter'                => array(
				10  => array( 685, 685, 685, 685, 685 ),
				20  => array( 685, 685, 685, 685, 685 ),
				100 => array( 685, 685, 685, 785, 785 ),
			),
			'large-letter'          => array(
				100 => array( 875, 875, 875, 970, 980 ),
				250 => array( 920, 920, 920, 1050, 1155 ),
				500 => array( 995, 995, 995, 1230, 1410 ),
				750 => array( 1035, 1035, 1035, 1415, 1690 ),
			),
			'packet'                => array(
				100  => array( 1050, 1050, 1050, 1200, 1305 ),
				250  => array( 1065, 1065, 1065, 1295, 1440 ),
				500  => array( 1210, 1210, 1210, 1660, 1880 ),
				750  => array( 1315, 1315, 1315, 1900, 2160 ),
				1000 => array( 1410, 1410, 1410, 2165, 2475 ),
				1250 => array( 1450, 1450, 1450, 2350, 2715 ),
				1500 => array( 1505, 1505, 1505, 2490, 2965 ),
				2000 => array( 1525, 1525, 1525, 2535, 3070 ),
			),
			'printed-papers' => array(
				100  => array( 1050, 1050, 1050, 1200, 1305 ),
				250  => array( 1065, 1065, 1065, 1295, 1440 ),
				500  => array( 1210, 1210, 1210, 1660, 1880 ),
				750  => array( 1315, 1315, 1315, 1900, 2160 ),
				1000 => array( 1410, 1410, 1410, 2165, 2475 ),
				1250 => array( 1450, 1450, 1450, 2350, 2715 ),
				1500 => array( 1505, 1505, 1505, 2490, 2965 ),
				2000 => array( 1525, 1525, 1525, 2535, 3070 ),
				2250 => array( 1665, 1665, 1665, 2725, 3305 ),
				2500 => array( 1805, 1805, 1805, 2915, 3540 ),
				2750 => array( 1945, 1945, 1945, 3105, 3775 ),
				3000 => array( 2085, 2085, 2085, 3295, 4010 ),
				3250 => array( 2225, 2225, 2225, 3485, 4245 ),
				3500 => array( 2365, 2365, 2365, 3675, 4480 ),
				3750 => array( 2505, 2505, 2505, 3865, 4715 ),
				4000 => array( 2645, 2645, 2645, 4055, 4950 ),
				4250 => array( 2785, 2785, 2785, 4245, 5185 ),
				4500 => array( 2925, 2925, 2925, 4435, 5420 ),
				4750 => array( 3065, 3065, 3065, 4625, 5655 ),
				5000 => array( 3205, 3205, 3205, 4815, 5890 ),
			),
		),
		'2022' => array(
			'letter'                => array(
				10  => array( 700, 700, 700, 700, 700 ),
				20  => array( 700, 700, 700, 700, 700 ),
				100 => array( 700, 700, 700, 785, 785 ),
			),
			'large-letter'          => array(
				100 => array(  875,  875,  875,  970, 980 ),
				250 => array(  920,  920,  920, 1050, 1155 ),
				500 => array(  995,  995,  995, 1230, 1410 ),
				750 => array( 1035, 1035, 1035, 1415, 1690 ),
			),
			'packet'                => array(
				100  => array( 1080, 1095, 1150, 1250, 1355 ),
				250  => array( 1080, 1095, 1150, 1345, 1490 ),
				500  => array( 1220, 1260, 1300, 1710, 1930 ),
				750  => array( 1330, 1365, 1415, 1950, 2210 ),
				1000 => array( 1430, 1460, 1530, 2215, 2525 ),
				1250 => array( 1485, 1495, 1590, 2400, 2765 ),
				1500 => array( 1500, 1520, 1650, 2540, 3015 ),
				2000 => array( 1515, 1565, 1680, 2585, 3120 ),
			),
			'printed-papers' => array(
				100  => array( 1080, 1095, 1150, 1250, 1355 ),
				250  => array( 1080, 1095, 1150, 1345, 1490 ),
				500  => array( 1220, 1260, 1300, 1710, 1930 ),
				750  => array( 1330, 1365, 1415, 1950, 2210 ),
				1000 => array( 1430, 1460, 1530, 2215, 2525 ),
				1250 => array( 1485, 1495, 1590, 2400, 2765 ),
				1500 => array( 1500, 1520, 1650, 2540, 3015 ),
				2000 => array( 1515, 1565, 1680, 2585, 3120 ),
				2250 => array( 1655, 1705, 1820, 2775, 3355 ),
				2500 => array( 1795, 1845, 1960, 2965, 3590 ),
				2750 => array( 1935, 1985, 2100, 3155, 3825 ),
				3000 => array( 2075, 2125, 2240, 3345, 4060 ),
				3250 => array( 2215, 2265, 2380, 3535, 4295 ),
				3500 => array( 2355, 2405, 2520, 3725, 4530 ),
				3750 => array( 2495, 2545, 2660, 3915, 4765 ),
				4000 => array( 2635, 2685, 2800, 4105, 5000 ),
				4250 => array( 2775, 2825, 2940, 4295, 5235 ),
				4500 => array( 2915, 2965, 3080, 4485, 5470 ),
				4750 => array( 3055, 3105, 3220, 4675, 5705 ),
				5000 => array( 3195, 3245, 3360, 4865, 5940 ),
			),
		),
	);

	/**
	 * Get quotes for this rate
	 *
	 * @param array $items to be shipped.
	 * @param string $packing_method the method selected.
	 * @param string $destination Address to ship to.
	 * @param array $boxes User-defined boxes.
	 * @param int $instance_id .
	 *
	 * @return array
	 */
	public function get_quotes( $items, $packing_method, $destination, $boxes = array(), $instance_id = '' ) {
		if ( ! in_array( $destination, $this->supported_countries ) ) {
			return array();
		}

		if ( ! empty( $boxes ) ) {
			$this->boxes = array();

			foreach ( $boxes as $key => $box ) {
				$this->boxes[ $key ] = array(
					'length'     => $box['inner_length'],
					'width'      => $box['inner_width'],
					'height'     => $box['inner_height'],
					'box_weight' => $box['box_weight'],
					'weight'     => 2000,
				);
			}
		} else {
			$this->boxes = $this->international_default_box;
		}

		$printed_paper_packages = apply_filters( 'woocommerce_shipping_royal_mail_printed_papers_enabled', true, $instance_id, 'signed', $destination, $packing_method ) ? $this->get_printed_papers_packages( $items, $destination, $packing_method ) : array();
		$regular_packages       = $this->get_packages( $items, $packing_method );
		$packages               = array_merge( $regular_packages, $printed_paper_packages );
		$class_quote            = false;

		if ( $packages ) {
			foreach ( $packages as $package ) {
				$quote = $this->get_quote( $package, $destination );

				// Do not return a quote if one of the packages exceeds a limitation.
				if ( false === $quote ) {
					return array();
				}

				$class_quote += $quote;
			}
		}

		// Return pounds.
		$quotes = array();
		$quotes['international-signed'] = $class_quote / 100;

		return $quotes;
	}

	/**
	 * Get quote.
	 *
	 * @since 2.5.1
	 * @version 2.5.1
	 *
	 * @param array  $package     Package to ship.
	 * @param string $destination Destination.
	 *
	 * @return bool|int|void
	 */
	public function get_quote( $package, $destination ) {

		$zone = $this->get_zone( $destination );

		$this->validate_package( $package );

		if ( in_array( $package->id, array( 'packet', 'printed-papers' ) ) && 900 < ( $package->length + $package->width + $package->height ) ) {
			return false; // Exceeding parcels requirement, unpacked.
		}

		if ( ! $this->get_rate_bands( $package->id ) ) {
			return false; // Unpacked item.
		}

		$this->debug( __( 'International signed package:', 'woocommerce-shipping-royalmail' ) . ' <pre>' . print_r( $package, true ) . '</pre>' );

		$bands   = $this->get_rate_bands( $package->id );
		$quote   = 0;
		$matched = false;

		foreach ( $bands as $band => $value ) {
			if ( $package->weight <= $band ) {
				switch ( $zone ) {
					case 'EUR_1' : 
						$quote += $value[0];
						break;
					case 'EUR_2' : 
						$quote += $value[1];
						break;
					case 'EUR_3' :
					case 'EU' :
						$quote += $value[2];
						break;
					case '1' :
						$quote += $value[3];
						break;
					case '2' :
						$quote += $value[4];
						break;
				}
				$matched = true;
				break;
			}
		}

		if ( ! $matched ) {
			return;
		}
		return $quote;
	}
}
