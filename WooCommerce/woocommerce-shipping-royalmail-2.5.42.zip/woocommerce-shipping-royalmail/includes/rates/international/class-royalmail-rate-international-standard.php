<?php
/**
 * International Standard rate.
 *
 * @package WC_RoyalMail/Rate
 */

/**
 * RoyalMail_Rate_International_Standard class.
 *
 * Updated on 2022-04-04 as per https://www.royalmail.com/sites/royalmail.com/files/2022-03/royal-mail-our-prices-april-2022-v2.pdf.
 * See International Standard page 11.
 */
class RoyalMail_Rate_International_Standard extends RoyalMail_Rate {

	/**
	 * ID/Name of rate
	 *
	 * @var string
	 */
	protected $rate_id = 'international_standard';

	/**
	 * Pricing bands - Europe, Zone 1, Zone 2, Zone 3 (previously Zone 1)
	 *
	 * @var array
	 */
	protected $bands = array(
		'2021' => array(
			'letter'                => array(
				10  => array( 170, 170, 170, 170, 170, 170 ),
				20  => array( 170, 170, 170, 170, 170, 170 ),
				100 => array( 170, 170, 170, 255, 255, 255 ),
			),
			'large-letter'          => array(
				100 => array( 325, 325, 325, 420, 420, 420 ),
				250 => array( 425, 425, 425, 570, 680, 585 ),
				500 => array( 525, 525, 525, 800, 985, 830 ),
				750 => array( 625, 625, 625, 1065, 1355, 1110 ),
			),
			'packet'                => array(
				100  => array( 580, 580, 580, 715, 835, 935 ),
				250  => array( 595, 595, 595, 830, 990, 1095 ),
				500  => array( 780, 780, 780, 1210, 1450, 1660 ),
				750  => array( 905, 905, 905, 1485, 1760, 1935 ),
				1000 => array( 1020, 1020, 1020, 1765, 2085, 2300 ),
				1250 => array( 1105, 1105, 1105, 1985, 2375, 2645 ),
				1500 => array( 1210, 1210, 1210, 2210, 2685, 2920 ),
				2000 => array( 1300, 1300, 1300, 2330, 2855, 3045 ),
			),
			'printed-papers' => array(
				100  => array( 580, 580, 580, 715, 835, 935 ),
				250  => array( 595, 595, 595, 830, 990, 1095 ),
				500  => array( 780, 780, 780, 1210, 1450, 1660 ),
				750  => array( 905, 905, 905, 1485, 1760, 1935 ),
				1000 => array( 1020, 1020, 1020, 1765, 2085, 2300 ),
				1250 => array( 1105, 1105, 1105, 1985, 2375, 2645 ),
				1500 => array( 1210, 1210, 1210, 2210, 2685, 2920 ),
				2000 => array( 1300, 1300, 1300, 2330, 2855, 3045 ),
				2250 => array( 1440, 1440, 1440, 2520, 3090, 3305 ),
				2500 => array( 1580, 1580, 1580, 2710, 3325, 3565 ),
				2750 => array( 1720, 1720, 1720, 2900, 3560, 3825 ),
				3000 => array( 1860, 1860, 1860, 3090, 3795, 4085 ),
				3250 => array( 2000, 2000, 2000, 3280, 4030, 4345 ),
				3500 => array( 2140, 2140, 2140, 3470, 4265, 4605 ),
				3750 => array( 2280, 2280, 2280, 3660, 4500, 4865 ),
				4000 => array( 2420, 2420, 2420, 3850, 4735, 5125 ),
				4250 => array( 2560, 2560, 2560, 4040, 4970, 5385 ),
				4500 => array( 2700, 2700, 2700, 4230, 5205, 5645 ),
				4750 => array( 2840, 2840, 2840, 4420, 5440, 5905 ),
				5000 => array( 2980, 2980, 2980, 4610, 5675, 6165 ),
			),
		),
		'2022' => array(
			'letter'                => array(
				10  => array( 185, 185, 185, 185, 185, 185 ),
				20  => array( 185, 185, 185, 185, 185, 185 ),
				100 => array( 185, 185, 185, 255, 255, 255 ),
			),
			'large-letter'          => array(
				100 => array( 325, 325, 325, 420, 420, 420 ),
				250 => array( 325, 325, 425, 570, 680, 585 ),
				500 => array( 325, 325, 525, 800, 985, 830 ),
				750 => array( 325, 325, 625, 1065, 1355, 1110 ),
			),
			'packet'                => array(
				100  => array(  585,  595,  630,  715,  835,  935 ),
				250  => array(  585,  595,  630,  830,  990, 1095 ),
				500  => array(  750,  780,  820, 1210, 1450, 1660 ),
				750  => array(  870,  905,  955, 1485, 1760, 1935 ),
				1000 => array(  990, 1020, 1090, 1765, 2085, 2300 ),
				1250 => array( 1090, 1140, 1195, 1985, 2375, 2645 ),
				1500 => array( 1090, 1140, 1305, 2210, 2685, 2920 ),
				2000 => array( 1240, 1290, 1405, 2330, 2855, 3045 ),
			),
			'printed-papers' => array(
				100  => array(  585,  595,  630,  715,  835,  935 ),
				250  => array(  585,  595,  630,  830,  990, 1095 ),
				500  => array(  750,  780,  820, 1210, 1450, 1660 ),
				750  => array(  870,  905,  955, 1485, 1760, 1935 ),
				1000 => array(  990, 1020, 1090, 1765, 2085, 2300 ),
				1250 => array( 1090, 1140, 1195, 1985, 2375, 2645 ),
				1500 => array( 1090, 1140, 1305, 2210, 2685, 2920 ),
				2000 => array( 1240, 1290, 1405, 2330, 2855, 3045 ),
				2250 => array( 1380, 1430, 1545, 2520, 3090, 3305 ),
				2500 => array( 1520, 1570, 1685, 2710, 3325, 3565 ),
				2750 => array( 1660, 1710, 1825, 2900, 3560, 3825 ),
				3000 => array( 1800, 1850, 1965, 3090, 3795, 4085 ),
				3250 => array( 1940, 1990, 2105, 3280, 4030, 4345 ),
				3500 => array( 2080, 2130, 2245, 3470, 4265, 4605 ),
				3750 => array( 2220, 2270, 2385, 3660, 4500, 4865 ),
				4000 => array( 2360, 2410, 2525, 3850, 4735, 5125 ),
				4250 => array( 2500, 2550, 2665, 4040, 4970, 5385 ),
				4500 => array( 2640, 2690, 2805, 4230, 5205, 5645 ),
				4750 => array( 2780, 2830, 2945, 4420, 5440, 5905 ),
				5000 => array( 2920, 2970, 3085, 4610, 5675, 6165 ),
			),
		),
	);

	/**
	 * Get quotes for this rate
	 *
	 * @param array $items to be shipped.
	 * @param string $packing_method the method selected.
	 * @param string $destination Address to ship to.
	 * @param array $boxes User-defined boxes.
	 * @param int $instance_id .
	 *
	 * @return array
	 */
	public function get_quotes( $items, $packing_method, $destination, $boxes = array(), $instance_id = '' ) {
		$standard_quote = false;

		if ( ! empty( $boxes ) ) {
			$this->boxes = array();

			foreach ( $boxes as $key => $box ) {
				$this->boxes[ $key ] = array(
					'length'     => $box['inner_length'],
					'width'      => $box['inner_width'],
					'height'     => $box['inner_height'],
					'box_weight' => $box['box_weight'],
					'weight'     => 2000,
				);
			}
		} else {
			$this->boxes = $this->international_default_box;
		}

		$zone                   = $this->get_zone( $destination );
		$options                = $this->get_instance_options( $instance_id );
		$compensation_optional  = ( ! empty( $options['compensation_optional'] ) && 'yes' === $options['compensation_optional'] );
		$printed_paper_packages = apply_filters( 'woocommerce_shipping_royal_mail_printed_papers_enabled', true, $instance_id, 'standard', $destination, $packing_method ) ? $this->get_printed_papers_packages( $items, $destination, $packing_method ) : array();
		$regular_packages       = $this->get_packages( $items, $packing_method );
		$packages               = array_merge( $regular_packages, $printed_paper_packages );

		if ( $packages ) {
			foreach ( $packages as $package ) {
				if ( $package->value > 20 && ! $compensation_optional ) {
					return false; // Max. compensation is 20.
				}

				$this->validate_package( $package );

				if ( in_array( $package->id, array( 'packet', 'printed-papers' ) ) && 900 < ( $package->length + $package->width + $package->height ) ) {
					return false; // Exceeding parcels requirement, unpacked.
				}

				if ( ! $this->get_rate_bands( $package->id ) ) {
					return false; // Unpacked item.
				}

				$this->debug( __( 'International package:', 'woocommerce-shipping-royalmail' ) . ' <pre>' . print_r( $package, true ) . '</pre>' );

				$bands   = $this->get_rate_bands( $package->id );
				$quote   = 0;
				$matched = false;

				foreach ( $bands as $band => $value ) {
					if ( $package->weight <= $band ) {
						switch ( $zone ) {
							case 'EUR_1':
								$quote += $value[0];
								break;
							case 'EUR_2':
								$quote += $value[1];
								break;
							case 'EUR_3':
							case 'EU':
								$quote += $value[2];
								break;
							case '1':
								$quote += $value[3];
								break;
							case '2':
								$quote += $value[4];
								break;
							case '3':
								// Fallback to zone 1 for older prices.
								$quote += isset( $value[5] ) ? $value[5] : $value[3];
								break;
						}
						$matched = true;
						break;
					}
				}

				if ( ! $matched ) {
					return;
				}

				$standard_quote += $quote;
			}
		}

		// Return pounds.
		$quotes = array();
		$quotes['international-standard'] = $standard_quote / 100;

		return $quotes;
	}
}
