<?php
/**
 * International Economy rate.
 *
 * @package WC_RoyalMail/Rate
 */

/**
 * RoyalMail_Rate_International_Economy class.
 *
 * Updated on 2022-04-04 as per https://www.royalmail.com/sites/royalmail.com/files/2022-03/royal-mail-our-prices-april-2022-v2.pdf.
 * See International Economy 19.
 */
class RoyalMail_Rate_International_Economy extends RoyalMail_Rate {

	/**
	 * ID/Name of rate
	 *
	 * @var string
	 */
	protected $rate_id = 'international_economy';

	/**
	 * Pricing bands
	 *
	 * Key is size (e.g. 'letter') and value is an array where key is weight in
	 * gram and value is the price (in penny).
	 *
	 * @var array
	 */
	protected $bands = array(
		'2021' => array(
			'letter'       => array(
				10  => 145,
				20  => 145,
				100 => 155,
			),
			'large-letter' => array(
				100 => 300,
				250 => 400,
				500 => 490,
				750 => 590,
			),
			'packet'       => array(
				100  => 485,
				250  => 520,
				500  => 745,
				750  => 870,
				1000 => 950,
				1250 => 1055,
				1500 => 1165,
				1750 => 1280,
				2000 => 1295,
			),
		),
		'2022' => array(
			'letter'         => array(
				10  => 160,
				20  => 160,
				100 => 160,
			),
			'large-letter'   => array(
				100 => 320,
				250 => 460,
				500 => 530,
				750 => 635,
			),
			'packet'         => array(
				100  => 505,
				250  => 540,
				500  => 775,
				750  => 905,
				1000 => 1045,
				1250 => 1160,
				1500 => 1285,
				1750 => 1425,
				2000 => 1425,
			),
			'printed-papers' => array(
				100  => 505,
				250  => 540,
				500  => 775,
				750  => 905,
				1000 => 1045,
				1250 => 1160,
				1500 => 1285,
				1750 => 1425,
				2000 => 1425,
				2250 => 1575,
				2500 => 1725,
				2750 => 1875,
				3000 => 2025,
				3250 => 2175,
				3500 => 2325,
				3750 => 2475,
				4000 => 2625,
				4250 => 2775,
				4500 => 2925,
				4750 => 3075,
				5000 => 3225,
			),
		),
	);

	/**
	 * Get quotes for this rate.
	 *
	 * @param array  $items to be shipped.
	 * @param string $packing_method selected.
	 * @param string $destination address.
	 * @param array  $boxes User-defined boxes.
	 * @param int $instance_id.
	 *
	 * @return array
	 */
	public function get_quotes( $items, $packing_method, $destination, $boxes = array(), $instance_id = '' ) {
		$class_quote  = false;
		if ( ! empty( $boxes ) ) {
			$this->boxes = array();

			foreach ( $boxes as $key => $box ) {
				$this->boxes[ $key ] = array(
					'length'     => $box['inner_length'],
					'width'      => $box['inner_width'],
					'height'     => $box['inner_height'],
					'box_weight' => $box['box_weight'],
					'weight'     => 2000,
				);
			}
		} else {
			$this->boxes = $this->international_default_box;
		}

		if ( in_array( $destination, $this->get_all_european_countries() ) ) {
			foreach ( $this->bands as $year => $bands_group ) {
				unset( $this->bands[ $year ]['letter'], $this->boxes['letter'] );
			}
		}

		$zone                  = $this->get_zone( $destination );
		$packages              = $this->get_packages( $items, $packing_method );
		$options               = $this->get_instance_options( $instance_id );
		$compensation_optional = ( ! empty( $options['compensation_optional'] ) && 'yes' === $options['compensation_optional'] );

		if ( $packages ) {
			foreach ( $packages as $package ) {
				if ( $package->value > 20 && ! $compensation_optional ) {
					return false; // Max. compensation is 20.
				}

				$this->validate_package( $package );

				if ( 'packet' === $package->id && 900 < ( $package->length + $package->width + $package->height ) ) {
					return false; // Exceeding parcels requirement, unpacked.
				}

				if ( ! $this->get_rate_bands( $package->id ) ) {
					return false; // Unpacked item.
				}

				$this->debug( __( 'Economy package:', 'woocommerce-shipping-royalmail' ) . ' <pre>' . print_r( $package, true ) . '</pre>' );

				$bands   = $this->get_rate_bands( $package->id );
				$quote   = 0;
				$matched = false;

				foreach ( $bands as $band => $value ) {
					if ( $package->weight <= $band ) {
						$quote += $value;
						$matched = true;
						break;
					}
				}

				if ( ! $matched ) {
					return;
				}

				$class_quote += $quote;
			}
		}

		// Return pounds.
		$quotes = array();
		$quotes['international-economy'] = $class_quote / 100;

		return $quotes;
	}
}
