<?php
/**
 * International-Tracked-and-Signed rate.
 *
 * @package WC_RoyalMail/Rate
 */

/**
 * RoyalMail_Rate_International_Tracked_Signed class.
 *
 * Updated on 2022-04-04 as per https://www.royalmail.com/sites/royalmail.com/files/2022-03/royal-mail-our-prices-april-2022-v2.pdf.
 * See International Tracked & Signed page 13.
 */
class RoyalMail_Rate_International_Tracked_Signed extends RoyalMail_Rate {

	/**
	 * ID/Name of rate
	 *
	 * @var string
	 */
	protected $rate_id = 'international_tracked_signed';

	/**
	 * List of countries that support Tracked and Signed service.
	 *
	 * @see http://www.royalmail.com/sites/default/files/Royal-Mail-International-Tracking-Signature-Services-List-April2017.pdf
	 *
	 * @since 2.5.4
	 * @version 2.5.4
	 *
	 * @var array
	 */
	protected $supported_countries = array(
		'AX',
		'AD',
		'AR',
		'AT',
		'BB',
		'BY',
		'BE',
		'BZ',
		'BG',
		'KH',
		'CA',
		'KY',
		'CK',
		'HR',
		'CY',
		'CZ',
		'DK',
		'EC',
		'FO',
		'FI',
		'FR',
		'GE',
		'DE',
		'GI',
		'GR',
		'GL',
		'HK',
		'HU',
		'IS',
		'ID',
		'IE',
		'IT',
		'JP',
		'LV',
		'LB',
		'LI',
		'LT',
		'LU',
		'MY',
		'MT',
		'MD',
		'NL',
		'NZ',
		'PL',
		'PT',
		'RO',
		'RU',
		'SM',
		'RS',
		'SG',
		'SK',
		'SI',
		'KR',
		'ES',
		'SE',
		'CH',
		'TH',
		'TO',
		'TT',
		'TR',
		'UG',
		'AE',
		'US',
		'VA',
	);

	/**
	 * Pricing bands - Europe, Zone 1, Zone 2, Zone 3 (previously Zone 1)
	 *
	 * @var array
	 */
	protected $bands = array(
		'2021' => array(
			'letter'                => array(
				10  => array( 685, 685, 685, 685, 685, 685 ),
				20  => array( 685, 685, 685, 685, 685, 685 ),
				100 => array( 685, 685, 685, 785, 785, 785 ),
			),
			'large-letter'          => array(
				100 => array( 875, 875, 875, 970, 980, 975 ),
				250 => array( 920, 920, 920, 1050, 1155, 1065 ),
				500 => array( 995, 995, 995, 1230, 1410, 1260 ),
				750 => array( 1035, 1035, 1035, 1415, 1690, 1460 ),
			),
			'packet'                => array(
				100  => array( 1050, 1050, 1050, 1200, 1305, 1385 ),
				250  => array( 1065, 1065, 1065, 1295, 1440, 1545 ),
				500  => array( 1210, 1210, 1210, 1660, 1880, 2085 ),
				750  => array( 1315, 1315, 1315, 1900, 2160, 2285 ),
				1000 => array( 1410, 1410, 1410, 2165, 2475, 2650 ),
				1250 => array( 1450, 1450, 1450, 2350, 2715, 2995 ),
				1500 => array( 1505, 1505, 1505, 2490, 2965, 3270 ),
				2000 => array( 1525, 1525, 1525, 2535, 3070, 3320 ),
			),
			'printed-papers' => array(
				100  => array( 1050, 1050, 1050, 1200, 1305, 1385 ),
				250  => array( 1065, 1065, 1065, 1295, 1440, 1545 ),
				500  => array( 1210, 1210, 1210, 1660, 1880, 2085 ),
				750  => array( 1315, 1315, 1315, 1900, 2160, 2285 ),
				1000 => array( 1410, 1410, 1410, 2165, 2475, 2650 ),
				1250 => array( 1450, 1450, 1450, 2350, 2715, 2995 ),
				1500 => array( 1505, 1505, 1505, 2490, 2965, 3270 ),
				2000 => array( 1525, 1525, 1525, 2535, 3070, 3320 ),
				2250 => array( 1665, 1665, 1665, 2725, 3305, 3580 ),
				2500 => array( 1805, 1805, 1805, 2915, 3540, 3840 ),
				2750 => array( 1945, 1945, 1945, 3105, 3775, 4100 ),
				3000 => array( 2085, 2085, 2085, 3295, 4010, 4360 ),
				3250 => array( 2225, 2225, 2225, 3485, 4245, 4620 ),
				3500 => array( 2365, 2365, 2365, 3675, 4480, 4880 ),
				3750 => array( 2505, 2505, 2505, 3865, 4715, 5140 ),
				4000 => array( 2645, 2645, 2645, 4055, 4950, 5400 ),
				4250 => array( 2785, 2785, 2785, 4245, 5185, 5660 ),
				4500 => array( 2925, 2925, 2925, 4435, 5420, 5920 ),
				4750 => array( 3065, 3065, 3065, 4625, 5655, 6180 ),
				5000 => array( 3205, 3205, 3205, 4815, 5890, 6440 ),
			),
		),
		'2022' => array(
			'letter'                => array(
				10  => array( 700, 700, 700, 700, 700, 700 ),
				20  => array( 700, 700, 700, 700, 700, 700 ),
				100 => array( 700, 700, 700, 785, 785, 785 ),
			),
			'large-letter'          => array(
				100 => array(  875,  875,  875,  970,  980,  975 ),
				250 => array(  920,  920,  920, 1050, 1155, 1065 ),
				500 => array(  995,  995,  995, 1230, 1410, 1260 ),
				750 => array( 1035, 1035, 1035, 1415, 1690, 1460 ),
			),
			'packet'                => array(
				100  => array( 1080, 1095, 1150, 1250, 1355, 1435 ),
				250  => array( 1080, 1095, 1150, 1345, 1490, 1595 ),
				500  => array( 1220, 1260, 1300, 1710, 1930, 2135 ),
				750  => array( 1330, 1365, 1415, 1950, 2210, 2335 ),
				1000 => array( 1430, 1460, 1530, 2215, 2525, 2700 ),
				1250 => array( 1485, 1495, 1590, 2400, 2765, 3045 ),
				1500 => array( 1500, 1520, 1650, 2540, 3015, 3320 ),
				2000 => array( 1515, 1565, 1680, 2585, 3120, 3370 ),
			),
			'printed-papers' => array(
				100  => array( 1080, 1095, 1150, 1250, 1355, 1435 ),
				250  => array( 1080, 1095, 1150, 1345, 1490, 1595 ),
				500  => array( 1220, 1260, 1300, 1710, 1930, 2135 ),
				750  => array( 1330, 1365, 1415, 1950, 2210, 2335 ),
				1000 => array( 1430, 1460, 1530, 2215, 2525, 2700 ),
				1250 => array( 1485, 1495, 1590, 2400, 2765, 3045 ),
				1500 => array( 1500, 1520, 1650, 2540, 3015, 3320 ),
				2000 => array( 1515, 1565, 1680, 2585, 3120, 3370 ),
				2250 => array( 1655, 1705, 1820, 2775, 3355, 3630 ),
				2500 => array( 1795, 1845, 1960, 2965, 3590, 3890 ),
				2750 => array( 1935, 1985, 2100, 3155, 3825, 4150 ),
				3000 => array( 2075, 2125, 2240, 3345, 4060, 4410 ),
				3250 => array( 2215, 2265, 2380, 3535, 4295, 4670 ),
				3500 => array( 2355, 2405, 2520, 3725, 4530, 4930 ),
				3750 => array( 2515, 2565, 2660, 3915, 4765, 5190 ),
				4000 => array( 2635, 2685, 2800, 4105, 5000, 5450 ),
				4250 => array( 2775, 2825, 2940, 4295, 5235, 5710 ),
				4500 => array( 2915, 2965, 3080, 4485, 5470, 5970 ),
				4750 => array( 3055, 3105, 3220, 4675, 5705, 6230 ),
				5000 => array( 3195, 3245, 3360, 4865, 5940, 6490 ),
			),
		),
	);

	/**
	 * Fixed compensation
	 *
	 * @var string
	 */
	private $compensation    = '250';

	/**
	 * Get quotes for this rate.
	 *
	 * @since 2.5.4
	 * @version 2.5.4
	 *
	 * @param  array  $items to be shipped.
	 * @param  string $packing_method the method selected.
	 * @param  string $destination Address to ship to.
	 * @param  array  $boxes User-defined boxes.
	 * @param int $instance_id.
	 *
	 * @return array
	 */
	public function get_quotes( $items, $packing_method, $destination, $boxes = array(), $instance_id = '' ) {
		if ( ! in_array( $destination, $this->supported_countries ) ) {
			return array();
		}

		$class_quote = false;

		if ( ! empty( $boxes ) ) {
			$this->boxes = array();

			foreach ( $boxes as $key => $box ) {
				$this->boxes[ $key ] = array(
					'length'     => $box['inner_length'],
					'width'      => $box['inner_width'],
					'height'     => $box['inner_height'],
					'box_weight' => $box['box_weight'],
					'weight'     => 2000,
				);
			}
		} else {
			$this->boxes = $this->international_default_box;
		}

		$zone                   = $this->get_zone( $destination );
		$printed_paper_packages = apply_filters( 'woocommerce_shipping_royal_mail_printed_papers_enabled', true, $instance_id, 'tracked-signed', $destination, $packing_method ) ? $this->get_printed_papers_packages( $items, $destination, $packing_method ) : array();
		$regular_packages       = $this->get_packages( $items, $packing_method );
		$packages               = array_merge( $regular_packages, $printed_paper_packages );

		if ( $packages ) {
			foreach ( $packages as $package ) {

				$this->validate_package( $package );

				if ( in_array( $package->id, array( 'packet', 'printed-papers' ) ) && 900 < ( $package->length + $package->width + $package->height ) ) {
					return false; // Exceeding parcels requirement, unpacked.
				}

				if ( ! $this->get_rate_bands( $package->id ) ) {
					return false; // Unpacked item.
				}

				$this->debug( __( 'International tracked and signed package:', 'woocommerce-shipping-royalmail' ) . ' <pre>' . print_r( $package, true ) . '</pre>' );

				$bands   = $this->get_rate_bands( $package->id );
				$quote   = 0;
				$matched = false;

				foreach ( $bands as $band => $value ) {
					if ( $package->weight <= $band ) {
						switch ( $zone ) {
							case 'EUR_1':
								$quote += $value[0];
								break;
							case 'EUR_2':
								$quote += $value[1];
								break;
							case 'EUR_3':
							case 'EU':
								$quote += $value[2];
								break;
							case '1':
								$quote += $value[3];
								break;
							case '2':
								$quote += $value[4];
								break;
							case '3':
								// Fallback to zone 1 for older prices.
								$quote += isset( $value[5] ) ? $value[5] : $value[3];
								break;
						}
						$matched = true;
						break;
					}
				}

				if ( ! $matched ) {
					return;
				}

				$class_quote  += $quote;

				if ( $package->value > 50 ) {
					$class_quote += $this->compensation;
				}
			}
		}

		// Return pounds.
		$quotes = array();
		$quotes['international-tracked-signed'] = $class_quote / 100;

		return $quotes;
	}
}
