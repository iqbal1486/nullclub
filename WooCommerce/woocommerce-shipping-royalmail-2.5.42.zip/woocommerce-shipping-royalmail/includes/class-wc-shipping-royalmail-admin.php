<?php
/**
 * Admin handler class.
 *
 * @package WC_Shipping_Royalmail
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Admin handler.
 */
class WC_Shipping_Royalmail_Admin {

	const META_KEY_PRINTED_PAPERS = '_shipping-royalmail-printed-papers';

	const META_KEY_BOOK = '_shipping-royalmail-book';

	const LABEL_PRINTED_PAPERS = 'Printed Papers';

	const LABEL_BOOK = 'Book';

	public function __construct() {
		add_action( 'woocommerce_product_options_dimensions', array( $this, 'product_options' ) );
		add_action( 'woocommerce_process_product_meta', array( $this, 'process_product_meta' ) );
		add_action( 'woocommerce_variation_options_dimensions', array($this,'variation_options'), 10, 3 );
		add_action( 'woocommerce_save_product_variation', array( $this, 'process_product_variation_meta' ), 10, 2 );
	}

	public function product_options() {

		// Printed Papers option
		woocommerce_wp_checkbox( array(
			'id'          => self::META_KEY_PRINTED_PAPERS,
			'label'       => sprintf( __( '%s', 'woocommerce-shipping-royalmail' ), self::LABEL_PRINTED_PAPERS ),
			'description' => sprintf( __( 'Use %s rates to ship package', 'woocommerce-shipping-royalmail' ), self::LABEL_PRINTED_PAPERS ),
			'desc_tip'    => true,
		) );

		// Book option
		woocommerce_wp_checkbox( array(
			'id'          => self::META_KEY_BOOK,
			'label'       => sprintf( __( '%s', 'woocommerce-shipping-royalmail' ), self::LABEL_BOOK ),
			'description' => sprintf( __( 'This product is a %1$s. Only %1$ss can be sent to the Republic of Ireland with Printed Papers rates.', 'woocommerce-shipping-royalmail' ), strtolower( self::LABEL_BOOK ) ),
			'desc_tip'    => true,
		) );
	}

	public function variation_options( $loop, array $variation_data, WP_Post $variation ) {

		// Printed Papers option
		woocommerce_wp_checkbox( array(
			'id'            => 'variable_' . self::META_KEY_PRINTED_PAPERS . $loop,
			'name'          => 'variable_' . self::META_KEY_PRINTED_PAPERS . '[' . $loop . ']',
			'label'         => sprintf( __( '%s', 'woocommerce-shipping-royalmail' ), self::LABEL_PRINTED_PAPERS ),
			'description'   => sprintf( __( 'Use %s rates to ship package', 'woocommerce-shipping-royalmail' ), self::LABEL_PRINTED_PAPERS ),
			'desc_tip'      => true,
			'wrapper_class' => 'form-row form-row-last hide_if_variation_virtual',
			'value'         => get_post_meta( $variation->ID, self::META_KEY_PRINTED_PAPERS, true ),
		) );

		// Book option
		woocommerce_wp_checkbox( array(
			'id'            => 'variable_' . self::META_KEY_BOOK . $loop,
			'name'          => 'variable_' . self::META_KEY_BOOK . '[' . $loop . ']',
			'label'         => sprintf( __( '%s', 'woocommerce-shipping-royalmail' ), self::LABEL_BOOK ),
			'description'   => sprintf( __( 'This product is a %1$s. Only %1$ss can be sent to the Republic of Ireland with Printed Papers rates.', 'woocommerce-shipping-royalmail' ), strtolower( self::LABEL_BOOK ) ),
			'desc_tip'      => true,
			'wrapper_class' => 'form-row form-row-last hide_if_variation_virtual',
			'value'         => get_post_meta( $variation->ID, self::META_KEY_BOOK, true ),
		) );
	}

	/**
	 * Save custom fields
	 *
	 * @param int $post_id
	 */
	public function process_product_meta( $post_id ) {

		// Save Printed Papers value
		if ( ! empty( $_POST[ self::META_KEY_PRINTED_PAPERS ] ) ) {
			update_post_meta( $post_id, self::META_KEY_PRINTED_PAPERS, 'yes' );
		} else {
			delete_post_meta( $post_id, self::META_KEY_PRINTED_PAPERS );
		}

		// Save Book value
		if ( ! empty( $_POST[ self::META_KEY_BOOK ] ) ) {
			update_post_meta( $post_id, self::META_KEY_BOOK, 'yes' );
		} else {
			delete_post_meta( $post_id, self::META_KEY_BOOK );
		}
	}

	/**
	 * Save variation custom fields
	 *
	 * @param int $post_id
	 * @param int $loop
	 */
	public function process_product_variation_meta( $post_id, $loop ) {

		// Save Printed Papers value
		if ( ! empty( $_POST[ 'variable_' . self::META_KEY_PRINTED_PAPERS ][ $loop ] ) ) {
			update_post_meta( $post_id, self::META_KEY_PRINTED_PAPERS, 'yes' );
		} else {
			delete_post_meta( $post_id, self::META_KEY_PRINTED_PAPERS );
		}

		// Save Book value
		if ( ! empty( $_POST[ 'variable_' . self::META_KEY_BOOK ][ $loop ] ) ) {
			update_post_meta( $post_id, self::META_KEY_BOOK, 'yes' );
		} else {
			delete_post_meta( $post_id, self::META_KEY_BOOK );
		}
	}

}
