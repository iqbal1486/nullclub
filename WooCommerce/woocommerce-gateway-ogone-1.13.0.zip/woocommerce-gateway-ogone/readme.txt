=== WooCommerce Ingenico (Ogone Platform) ===
Author: skyverge
Tags: woocommerce
Requires PHP: 7.0
Requires at least: 5.2
Tested up to: 5.6

Accept payments in WooCommerce with the Ingenico (Ogone Platform) gateway

See https://docs.woocommerce.com/document/ogone/ for full documentation.

== Installation ==

1. Upload the entire 'woocommerce-gateway-ogone' folder to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress
