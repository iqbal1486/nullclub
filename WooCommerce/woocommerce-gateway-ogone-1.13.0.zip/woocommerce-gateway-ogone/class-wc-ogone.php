<?php
/**
 * WooCommerce Ingenico (Ogone Platform)
 *
 * This source file is subject to the GNU General Public License v3.0
 * that is bundled with this package in the file license.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.html
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@skyverge.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade WooCommerce Ingenico (Ogone Platform) to newer
 * versions in the future. If you wish to customize WooCommerce Ingenico (Ogone Platform) for your
 * needs please refer to http://docs.woocommerce.com/document/ogone/
 *
 * @author    SkyVerge
 * @copyright Copyright (c) 2011-2020, SkyVerge, Inc.
 * @license   http://www.gnu.org/licenses/gpl-3.0.html GNU General Public License v3.0
 */

use SkyVerge\WooCommerce\PluginFramework\v5_10_3 as Framework;

/**
 * Ogone main plugin class.
 *
 * @since 1.2
 */
class WC_Ogone extends Framework\SV_WC_Plugin {


	/** version number */
	const VERSION = '1.13.0';

	/** @var \WC_Ogone single instance of this plugin */
	protected static $instance;

	/** plugin id */
	const PLUGIN_ID = 'ogone';

	/** string class name to load as gateway */
	const GATEWAY_CLASS_NAME = 'WC_Gateway_Ogone';

	/** @var string the gateway ID */
	const GATEWAY_ID = 'ogone';

	/** @var Framework\SV_WC_Payment_Gateway payment gateway instance */
	protected $gateway;


	/**
	 * Initializes the plugin.
	 *
	 * @since 1.2
	 */
	public function __construct() {

		parent::__construct(
			self::PLUGIN_ID,
			self::VERSION,
			[
				'text_domain'  => 'woocommerce-gateway-ogone',
				'dependencies' => [
					'php_extensions' => [ 'hash' ],
				],
			]
		);

		$this->includes();

		// watch for the configure-complus message to be dismissed
		add_action( 'wc_' . $this->get_id(). '_dismiss_message', [ $this, 'message_dismissed' ], 10, 2 );
	}


	/**
	 * Includes required files.
	 *
	 * @since 1.2
	 */
	public function includes() {

		// load gateway class
		require_once( $this->get_plugin_path() . '/includes/class-wc-gateway-ogone.php' );

		// add gateway to WC Payment Methods
		add_filter( 'woocommerce_payment_gateways', [ $this, 'load_gateway' ] );
	}


	/**
	 * Initializes the lifecycle handler.
	 *
	 * @since 1.12.0
	 */
	protected function init_lifecycle_handler() {

		require_once( $this->get_plugin_path() . '/includes/Lifecycle.php' );

		$this->lifecycle_handler = new \SkyVerge\WooCommerce\Ogone\Lifecycle( $this );
	}


	/**
	 * Adds WePay to the list of available payment gateways
	 *
	 * @internal
	 *
	 * @since 1.2
	 *
	 * @param array $gateways
	 * @return array $gateways
	 */
	public function load_gateway( $gateways ) {

		$gateways[] = $this->get_gateway();

		return $gateways;
	}


	/**
	 * Gets the identified gateway object.
	 *
	 * @since 1.12.0
	 *
	 * @param string $gateway_id optional gateway identifier, defaults to first gateway, which will be the credit card gateway in plugins with support for both credit cards and echecks
	 * @return SV_WC_Payment_Gateway the gateway object
	 */
	public function get_gateway( $gateway_id = null ) {

		if ( ! $this->gateway ) {
			$gateway_class_name = self::GATEWAY_CLASS_NAME;
			$this->gateway      = new $gateway_class_name();
		}

		return $this->gateway;
	}


	/**
	 * Checks if the configure-complus message needs to be rendered.
	 *
	 * @internal
	 *
	 * @since 1.3.7
	 */
	public function add_delayed_admin_notices() {

		parent::add_delayed_admin_notices();

		if ( ! $this->is_complus_configured() ) {

			$message = sprintf(
				/* translators: Placeholders: %1$s - <strong>, %2$s - </strong> */
				__( '%1$sWooCommerce Ingenico (Ogone Platform) - Action Required:%2$s to ensure your ability to process payments is not interrupted, please log on to your Ingenico Backoffice and go to Configuration &gt; Technical Information &gt; Transaction feedback.  Below "Dynamic e-Commerce parameters" add "COMPLUS" to the Selected list if it is not already there.  Save those settings, then mark this message as "complete".', 'woocommerce-gateway-ogone' ),
				'<strong>', '</strong>'
			);

			$this->get_admin_notice_handler()->add_admin_notice( $message, 'configure-complus' );
		}
	}


	/**
	 * Determines if the COMPLUS parameter has been certified to have been configured.
	 *
	 * @internal
	 *
	 * @since 1.2
	 *
	 * @return bool
	 */
	public function is_complus_configured() {

		return (bool) get_option( 'wc_ogone_complus_configured', false );
	}


	/**
	 * If the Configure COMPLUS message has been cleared, flags the corresponding DB setting.
	 *
	 * @internal
	 *
	 * @since 1.2
	 *
	 * @param string $message_id message ID
	 * @param int $user_id user ID
	 */
	public function message_dismissed( $message_id, $user_id ) {

		if ( 'configure-complus' === $message_id ) {

			update_option( 'wc_ogone_complus_configured', true );
		}
	}


	/**
	 * Gets the gateway settings option name for the identified gateway.
	 *
	 * @since 1.2
	 *
	 * @param string $gateway_id
	 * @return string the gateway settings option name
	 */
	protected function get_gateway_settings_name( $gateway_id ) {

		return 'woocommerce_' . $gateway_id . '_settings';
	}


	/**
	 * Gets the settings array for the identified gateway.
	 *
	 * @since 1.2
	 *
	 * @param string $gateway_id gateway identifier
	 * @return array settings array
	 */
	public function get_gateway_settings( $gateway_id ) {

		return get_option( $this->get_gateway_settings_name( $gateway_id ) );
	}


	/**
	 * Gets the gateway configuration URL.
	 *
	 * @since 1.3
	 *
	 * @param string|null $plugin_id the plugin identifier
	 * @return string plugin settings URL
	 */
	public function get_settings_url( $plugin_id = null ) {

		return $this->get_payment_gateway_configuration_url();
	}


	/**
	 * Determines if the current screen is the gateway settings page.
	 *
	 * @since 1.3
	 *
	 * @return bool
	 */
	public function is_plugin_settings() {

		return $this->is_payment_gateway_configuration_page();
	}


	/**
	 * Gets the admin configuration URL for the gateway.
	 *
	 * @since 1.12.0
	 *
	 * @return string admin configuration url for the gateway
	 */
	public function get_payment_gateway_configuration_url() {

		return admin_url( 'admin.php?page=wc-settings&tab=checkout&section=' . self::GATEWAY_ID );
	}


	/**
	 * Determines if the current page is the admin configuration page.
	 *
	 * @since 1.12.0
	 *
	 * @return bool
	 */
	public function is_payment_gateway_configuration_page() {

		return isset( $_GET['page'], $_GET['tab'], $_GET['section'] )
			&& 'wc-settings'    === $_GET['page']
			&& 'checkout'       === $_GET['tab']
			&& self::GATEWAY_ID === $_GET['section'];
	}


	/**
	 * Gets the plugin name, localized.
	 *
	 * @since 1.3
	 *
	 * @return string the plugin name
	 */
	public function get_plugin_name() {

		return __( 'WooCommerce Ingenico (Ogone Platform)', 'woocommerce-gateway-ogone' );
	}


	/**
	 * Gets __FILE__.
	 *
	 * @since 1.3
	 *
	 * @return string the full path and filename of the plugin file
	 */
	protected function get_file() {

		return __FILE__;
	}


	/**
	 * Gets the plugin documentation URL.
	 *
	 * @since 1.3
	 *
	 * @return string documentation URL
	 */
	public function get_documentation_url() {

		return 'https://docs.woocommerce.com/document/ogone/';
	}


	/**
	 * Gets the plugin support URL.
	 *
	 * @since 1.6.0
	 *
	 * @return string
	 */
	public function get_support_url() {

		return 'https://woocommerce.com/my-account/marketplace-ticket-form/';
	}


	/**
	 * Gets the plugin sales page URL.
	 *
	 * @since 1.12.0
	 *
	 * @return string
	 */
	public function get_sales_page_url() {

		return 'https://woocommerce.com/products/ogone/';
	}


	/**
	 * Main Ogone Instance ensures only one instance is/can be loaded.
	 *
	 * @since 1.4.0
	 *
	 * @return \WC_Ogone
	 */
	public static function instance() {

		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}


}


/**
 * Returns the One True Instance of Ogone.
 *
 * @since 1.4.0
 *
 * @return \WC_Ogone
 */
function wc_ogone() {

	return WC_Ogone::instance();
}

// fire it up!
wc_ogone();
