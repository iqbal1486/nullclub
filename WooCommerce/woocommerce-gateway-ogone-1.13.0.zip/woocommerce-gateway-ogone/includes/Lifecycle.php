<?php
/**
 * WooCommerce Ingenico (Ogone Platform)
 *
 * This source file is subject to the GNU General Public License v3.0
 * that is bundled with this package in the file license.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.html
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@skyverge.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade WooCommerce Ingenico (Ogone Platform) to newer
 * versions in the future. If you wish to customize WooCommerce Ingenico (Ogone Platform) for your
 * needs please refer to http://docs.woocommerce.com/document/ogone/
 *
 * @author    SkyVerge
 * @copyright Copyright (c) 2011-2020, SkyVerge, Inc.
 * @license   http://www.gnu.org/licenses/gpl-3.0.html GNU General Public License v3.0
 */

namespace SkyVerge\WooCommerce\Ogone;

use SkyVerge\WooCommerce\PluginFramework\v5_10_3 as Framework;

defined( 'ABSPATH' ) or exit;

/**
 * Plugin lifecycle handler.
 *
 * @since 1.12.0
 *
 * @method \WC_Ogone get_plugin()
 */
class Lifecycle extends Framework\Plugin\Lifecycle {


	/**
	 * Lifecycle constructor.
	 *
	 * @since 1.12.0
	 *
	 * @param \WC_Ogone $plugin
	 */
	public function __construct( $plugin ) {

		parent::__construct( $plugin );

		$this->upgrade_versions = [
			'1.3',
		];
	}


	/**
	 * Updates to version 1.3
	 *
	 * @since 1.12.0
	 */
	protected function upgrade_to_1_3() {
		global $wpdb;

		$wpdb->query( "UPDATE {$wpdb->usermeta} SET meta_key='_wc_plugin_framework_{$this->get_id()}_dismissed_messages' WHERE meta_key='_wc_payment_gateway_{$this->get_plugin()->get_id()}_dismissed_messages'" );
	}


}
