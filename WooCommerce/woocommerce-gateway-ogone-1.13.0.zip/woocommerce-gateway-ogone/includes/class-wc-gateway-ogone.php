<?php
/**
 * WooCommerce Ingenico (Ogone Platform)
 *
 * This source file is subject to the GNU General Public License v3.0
 * that is bundled with this package in the file license.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.html
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@skyverge.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade WooCommerce Ingenico (Ogone Platform) to newer
 * versions in the future. If you wish to customize WooCommerce Ingenico (Ogone Platform) for your
 * needs please refer to http://docs.woocommerce.com/document/ogone/
 *
 * @author    SkyVerge
 * @copyright Copyright (c) 2011-2020, SkyVerge, Inc.
 * @license   http://www.gnu.org/licenses/gpl-3.0.html GNU General Public License v3.0
 */

defined( 'ABSPATH' ) or exit;

use SkyVerge\WooCommerce\PluginFramework\v5_10_3 as Framework;

/**
 * Ogone extends default WooCommerce Payment Gateway class.
 *
 * @since 1.2
 */
class WC_Gateway_Ogone extends \WC_Payment_Gateway {


	/** @var object the parent plugin class */
	private $plugin;

	/** @var string the configured environment one of 'test' or 'prod' */
	private $version;

	/** @var string the configured PSP ID */
	private $pspid;

	/** @var string the configured secret SHA-IN */
	private $sha_in;

	/** @var string the configured secret SHA-OUT */
	private $sha_out;

	/** @var string the configured template page */
	private $template_page;

	/** @var string configuration option: 4 options for debug mode - off, checkout, log, both */
	private $debug_mode;


	/**
	 * Loads the payment gateway and related settings.
	 *
	 * @see \WC_Payment_Gateway::__construct()
	 *
	 * @since 1.2
	 */
	public function __construct() {

		$this->plugin       = wc_ogone();

		$this->id                 = \WC_Ogone::GATEWAY_ID;
		$this->method_title       = __( 'Ingenico (Ogone Platform)', 'woocommerce-gateway-ogone' );
		$this->method_description = __( 'Allow customers to pay securely with their credit card and bank account via Ingenico ePayments.', 'woocommerce-gateway-ogone' );

		$this->supports = array( 'products' );

		// enable fields so payment method icons show up
		$this->has_fields = true;

		$this->icon = apply_filters( 'WC_Ogone_icon', $this->get_plugin()->get_plugin_url() . '/assets/images/ogone.png' );

		// Load the form fields
		$this->init_form_fields();

		// Load the settings
		$this->init_settings();

		// Define user set variables
		foreach ( $this->settings as $setting_key => $setting ) {
			$this->$setting_key = $setting;
		}

		// Hooks
		add_action( 'woocommerce_api_wc_gateway_ogone', array( $this, 'process_response' ) );

		// Save settings
		if ( is_admin() ) {
			add_action( 'woocommerce_update_options_payment_gateways_' . $this->get_id(), array( $this, 'process_admin_options' ) );
		}

	}


	/**
	 * Initializes the Gateway Settings Form Fields.
	 *
	 * @see \WC_Settings_API::init_form_fields()
	 *
	 * @since 1.2
	 */
	public function init_form_fields() {

		$this->form_fields = array(

			'enabled' => array(
				'title'   => __( 'Enable/Disable', 'woocommerce-gateway-ogone' ),
				'type'    => 'checkbox',
				'label'   => __( 'Enable Ingenico', 'woocommerce-gateway-ogone' ),
				'default' => 'yes',
			),

			'version' => array(
				'title'       => __( 'Testing', 'woocommerce-gateway-ogone' ),
				'type'        => 'select',
				'description' => __( 'Select if you want to use the testing gateway or not.', 'woocommerce-gateway-ogone' ),
				'options'     => array( 'test' => 'Yes', 'prod' => 'No' ),
				'default'     => '',
			),

			'title' => array(
				'title'       => __( 'Title', 'woocommerce-gateway-ogone' ),
				'type'        => 'text',
				'description' => __( 'This controls the title which the user sees during checkout.', 'woocommerce-gateway-ogone' ),
				'default'     => __( 'Ingenico (Ogone Platform)', 'woocommerce-gateway-ogone' ),
			),

			'description' => array(
				'title'       => __( 'Description', 'woocommerce-gateway-ogone' ),
				'type'        => 'textarea',
				'description' => __( 'This controls the description which the user sees during checkout.', 'woocommerce-gateway-ogone' ),
				'default'     => __( 'Pay via Ingenico payment service.', 'woocommerce-gateway-ogone' ),
			),

			'pspid' => array(
				'title'       => __( 'Ingenico PSPID', 'woocommerce-gateway-ogone' ),
				'type'        => 'text',
				'description' => __( 'Please enter your Ingenico PSPID; this is needed in order to take payment.', 'woocommerce-gateway-ogone' ),
			),

			'sha_in' => array(
				'title'       => __( 'SHA-IN', 'woocommerce-gateway-ogone' ),
				'type'        => 'password',
				'description' => __( 'Please enter your SHA-IN; this is needed in order to take payment.', 'woocommerce-gateway-ogone' ),
			),

			'sha_out' => array(
				'title'       => __( 'SHA-OUT', 'woocommerce-gateway-ogone' ),
				'type'        => 'password',
				'description' => __( 'Please enter your SHA-OUT; this is needed in order to take payment.', 'woocommerce-gateway-ogone' ),
			),

			'template_page' => array(
				'title'       => __( 'Template Page', 'woocommerce-gateway-ogone' ),
				'type'        => 'text',
				'description' => __( 'Optional URL of a dynamic template page to customize the design of the Ingenico payment pages. The URL must be on this server and contain the full path. ', 'woocommerce-gateway-ogone' ),
			),

			'debug_mode' => array(
				'title'       => __( 'Debug Mode', 'woocommerce-gateway-ogone' ),
				'type'        => 'select',
				'desc_tip'    => __( 'Show Detailed Error Messages and API requests / responses on the checkout page and/or save them to the log for debugging purposes.', 'woocommerce-gateway-ogone' ),
				'default'     => 'off',
				'options' => array(
					'off'      => __( 'Off', 'woocommerce-gateway-ogone' ),
					'checkout' => __( 'Show on Checkout Page', 'woocommerce-gateway-ogone' ),
					'log'      => __( 'Save to Log', 'woocommerce-gateway-ogone' ),
					'both'     => __( 'Both', 'woocommerce-gateway-ogone' )
				),
			),

		);

	}


	/**
	 * Checks if this gateway is enabled and configured.
	 *
	 * @see \WC_Payment_Gateway::is_available()
	 *
	 * @since 1.2
	 */
	public function is_available() {

		return "yes" === $this->enabled && $this->pspid && $this->sha_in && $this->sha_out;
	}


	/**
	 * Returns the SHA signature for the given set of params.
	 *
	 * @since 1.2
	 *
	 * @param array $params associative array of name/value pairs to generate a signature for
	 * @param string $sha_pass_phrase the SHA pass phrase
	 * @return string SHA signature for $params
	 */
	private function sha_sign( $params, $sha_pass_phrase ) {

		// decode any SHA-in/out characters that were encoded by sanitize_text_field()
		$sha_pass_phrase = htmlspecialchars_decode( $sha_pass_phrase );

		// we need params to be ordered alphabetically
		ksort( $params );

		$sha_string = '';

		foreach ( $params as $key => $value ) {
			$sha_string .= $key . '=' . $value . $sha_pass_phrase;
		}

		return strtoupper( hash( 'sha256', $sha_string ) );

	}

	/**
	 * Processes the payment by redirecting the customer to the Ingenico hosted payment page.
	 *
	 * @see \WC_Payment_Gateway::process_payment()
	 *
	 * @since 1.2
	 *
	 * @param int $order_id order identifier
	 * @return array
	 */
	public function process_payment( $order_id ) {

		$order = wc_get_order( $order_id );

		// order total in pennies
		$amount = number_format( $order->get_total(), 2, '.', '' ) * 100;

		// SHA signature
		$sha_sign_params = array(
			'PSPID'        => $this->pspid,
			'ORDERID'      => $order->get_id(),
			'CURRENCY'     => $order->get_currency(),
			'AMOUNT'       => $amount,
			'LANGUAGE'     => get_locale() ?: 'en_US',
			'ACCEPTURL'    => add_query_arg( [ 'wc-api' => 'wc_gateway_ogone' ], $order->get_checkout_order_received_url() ),
			'DECLINEURL'   => $order->get_cancel_order_url_raw(),
			'ORIG'         => 'SVWOO',
		);

		// empty values break the SHASIGN
		if ( $order->get_billing_first_name( 'edit' ) || $order->get_billing_last_name( 'edit' ) ) {
			$sha_sign_params['CN'] = $order->get_formatted_billing_full_name();
		}
		if ( $billing_email = $order->get_billing_email( 'edit' ) ) {
			$sha_sign_params['EMAIL'] = $billing_email;
		}
		if ( $billing_address_1 = $order->get_billing_address_1( 'edit' ) ) {
			$sha_sign_params['OWNERADDRESS'] = $billing_address_1;
		}
		if ( $billing_postcode = $order->get_billing_postcode( 'edit' ) ) {
			$sha_sign_params['OWNERZIP'] = $billing_postcode;
		}
		if ( $billing_city = $order->get_billing_city( 'edit' ) ) {
			$sha_sign_params['OWNERTOWN'] = $billing_city;
		}
		if ( $billing_country = $order->get_billing_country( 'edit' ) ) {
			$sha_sign_params['OWNERCTY'] = $billing_country;
		}
		if ( $billing_phone = $order->get_billing_phone( 'edit' ) ) {
			$sha_sign_params['OWNERTELNO'] = $billing_phone;
		}
		if ( $this->template_page ) {
			$sha_sign_params['TP'] = $this->template_page;
		}

		// add the COMPLUS param and use the order number, if the admin has certified it to be configured
		if ( $this->get_plugin()->is_complus_configured() ) {

			$sha_sign_params['ORDERID'] = ltrim( $order->get_order_number(), __( '#', 'hash before order number', 'woocommerce-gateway-ogone' ) );
			$sha_sign_params['COMPLUS'] = $order->get_id();

		}

		// request parameters include the SHA signed parameters, plus the signature itself
		// The documentation shows a POST being used, but this does seem to work as a GET, though it does result in a pretty long query string
		$request_params = array_merge( $sha_sign_params, array(
			'SHASign' => $this->sha_sign( $sha_sign_params, $this->sha_in ),
		) );

		WC()->cart->empty_cart();

		$this->add_debug_message( sprintf( __( "Request URI: %s\nRequest Params: %s", 'woocommerce-gateway-ogone' ), 'https://secure.ogone.com/ncol/' . $this->version . '/orderstandard_utf8.asp', print_r( $request_params, true ) ), 'message', true );

		return array(
			'result'   => 'success',
			'redirect' => add_query_arg( urlencode_deep( $request_params ), 'https://secure.ogone.com/ncol/' . $this->version . '/orderstandard_utf8.asp' )
		);
	}


	/**
	 * Checks the response from Ingenico:
	 *
	 * + `orderID` - Order number
	 * + `STATUS`  - transaction status
	 * + `PAYID`   - Payment reference in Ingenico system
	 * + `NCERROR` - Error code (0 = success)
	 * + `COMPLUS` - The WooCommerce order id (optional)
	 * + `CARDNO`  - Masked credit card number (optional)
	 * + `BRAND`   - Card brand (optional)
	 * + `ED`      - Card expiry date (optional)
	 * + `SHASIGN` - SHA signature calculated by Ingenico (if SHA-OUT configured)
	 *
	 * Full list of status codes can be found by logging into the Ingenico
	 * backoffice and going to: Support > Integration & user manuals >
	 * User Guides > List of the payment statuses and error codes
	 *
	 * @internal
	 *
	 * @since 1.2
	 */
	public function process_response() {

		$this->add_debug_message( sprintf( __( "Response Params: %s", 'woocommerce-gateway-ogone' ), print_r( $_REQUEST, true ) ), 'message', true );

		// Check if all required variables are set
		if ( isset( $_REQUEST['orderID'], $_REQUEST['STATUS'], $_REQUEST['PAYID'], $_REQUEST['NCERROR'], $_REQUEST['SHASIGN'] ) ) {

			// setup the sha sign parameters to be all returned dynamic e-commerce parameters
			$sha_sign_params = $_REQUEST;

			/**
			 * Filters the list of parameters to exclude from the SHA sign
			 *
			 * @since 1.2
			 *
			 * @param array $sha_sign_params_exclude list of parameters to exclude from the SHA sign
			 * @param array $sha_sign_params associative array of all params
			 */
			$sha_sign_params_exclude = apply_filters( 'wc_ogone_response_sha_sign_params_exclude', array( 'key', 'wc-api', 'page_id', 'order-received', 'SHASIGN', 'lang', 'woocommerce-login-nonce', 'woocommerce-reset-password-nonce', '_wpnonce' ), $sha_sign_params );

			foreach ( $sha_sign_params_exclude as $exclude_key ) {
				unset( $sha_sign_params[ $exclude_key ] );
			}

			// remove empty parameters from the SHA sign
			foreach ( $sha_sign_params as $key => $value ) {
				if ( '' === $value ) {
					unset( $sha_sign_params[ $key ] );
				} elseif ( strtoupper( $key ) !== $key ) {
					unset( $sha_sign_params[ $key ] );
					$sha_sign_params[ strtoupper( $key ) ] = $value;
				}
			}

			foreach ( $sha_sign_params as $key => $value ) {
				$sha_sign_params[ $key ] = stripslashes( $value );
			}

			// card info, if available
			$account_last_four = '';
			$card_type         = '';
			$exp_month         = '';
			$exp_year          = '';

			// optional card parameters: card number, brand, expiry date
			if ( isset( $_REQUEST['CARDNO'] ) && $_REQUEST['CARDNO'] ) {
				$account_last_four = substr( $_REQUEST['CARDNO'], -4 );
			}

			if ( isset( $_REQUEST['BRAND'] ) && $_REQUEST['BRAND'] ) {
				$card_type = $_REQUEST['BRAND'];
			}

			if ( isset( $_REQUEST['ED'] ) && $_REQUEST['ED'] ) {
				$exp_month = substr( $_REQUEST['ED'], 0, 2 );
				$exp_year  = '20' . substr( $_REQUEST['ED'], -2 );
			}

			// retrieve the order id
			if ( isset( $_REQUEST['COMPLUS'] ) && $_REQUEST['COMPLUS'] ) {
				// new and improved COMPLUS mode
				$order_id = $_REQUEST['COMPLUS'];
			} else {
				// legacy mode
				$order_id = $_REQUEST['orderID'];
			}

			$order = wc_get_order( $order_id );

			// couldn't find order: COMPLUS issue most likely
			if ( ! $order || ! $order->get_id() ) {

				$log_message = sprintf( __( 'ERROR: Unable to find order with id %s.' ), $order_id );

				// plugin settings are expecting COMPLUS parameter, but this is not configured in the Ingenico backoffice settings
				if ( $this->get_plugin()->is_complus_configured() && ! isset( $_REQUEST['COMPLUS'] ) ) {
					$log_message .= '  ' . sprintf( __( 'Please ensure that COMPLUS is a selected under "Dynamic e-Commerce parameters" in the Ingenico backoffice, as described in the plugin documentation: %s', 'woocommerce-gateway-ogone' ), 'http://docs.woocommerce.com/document/ogone/#setup-transaction-feedback' );
				}

				// log the error to disk
				$this->get_plugin()->log( $log_message, $this->get_id() );

				// find the order by URL endpoint, but don't trust it
				global $wp;

				$order = wc_get_order( $wp->query_vars['order-received'] );

				if ( $order ) {

					$order_note = sprintf(
						/* translators: Placeholders: %1$s - order ID, %2$s - documentation URL */
						__( 'Possible successful transaction response received, but unable to find order with id "%1$s", please confirm the order in the Ingenico Backoffice.  Possible configuration error: please ensure that COMPLUS is a selected under "Dynamic e-Commerce parameters" in the Ingenico backoffice, as described in the plugin documentation: %2$s', 'woocommerce-gateway-ogone' ),
						$order_id,
						'http://docs.woocommerce.com/document/ogone/#setup-transaction-feedback'
					);

					$this->mark_order_as_held( $order, $order_note );
					wp_redirect( $this->get_return_url( $order ) );
					exit;
				}

				wp_redirect( $this->get_return_url() );
				exit;
			}

			// default redirect destination
			$redirect_url = $order->get_checkout_payment_url( true );

			// Proceed only if SHA signature is correct
			if ( $_REQUEST['SHASIGN'] == $this->sha_sign( $sha_sign_params, $this->sha_out ) ) {

				// SHA signature succeeded
				switch ( $_REQUEST['STATUS'] ) {

					case 0:
					case 1:
						// Real error or payment cancelled
						/* translators: Placeholders: %1$s - transaction status, %2$s - error code, %3$s - transaction ID */
						$order_note = sprintf( __( 'Status: %1$s. Error code: %2$s.  Transaction ID %3$s', 'woocommerce-gateway-ogone' ), strtolower( $_REQUEST['STATUS'] ), strtolower( $_REQUEST['NCERROR'] ), strtolower( $_REQUEST['PAYID'] ) );
						$this->mark_order_as_failed( $order, $order_note );
					break;

					case 2:
						// Real error - authorization refused
						/* translators: Placeholders: %1$s - transaction status, %2$s - error code, %3$s - transaction ID */
						$order_note = sprintf( __( 'Authorization refused with status: %1$s and error code: %2$s.  Transaction ID %3$s', 'woocommerce-gateway-ogone' ), strtolower( $_REQUEST['STATUS'] ), strtolower( $_REQUEST['NCERROR'] ), strtolower( $_REQUEST['PAYID'] ) );
						$this->mark_order_as_failed( $order, $order_note );
					break;

					case 3:
						$order_note = __( 'Payment processing was refused by the acquirer whilst the payment had been authorised beforehand. This can be due to a technical error or to the expiration of the autorisation. You must therefore call the acquirer\'s helpdesk to find out the actual result of this transaction.', 'woocommerce-gateway-ogone' );
						$this->mark_order_as_held( $order, $order_note );
					break;

					case 5:
					case 9:
						// Success
						$redirect_url = $this->get_return_url( $order );

						// verify order has not already been completed
						if ( ! $order->needs_payment() ) {

							$this->add_debug_message( sprintf( __( "Order %s is already paid for.", 'woocommerce-gateway-ogone' ), $order->get_order_number() ) );
							break;
						}

						// Mark payment as complete
						$order->payment_complete();

						// compose the order note
						if ( 5 == $_REQUEST['STATUS'] ) {
							$order_note = __( 'Ingenico authorization approved', 'woocommerce-gateway-ogone' );
						} else {
							$order_note = __( 'Ingenico charge approved', 'woocommerce-gateway-ogone' );
						}

						if ( $account_last_four && $card_type && $exp_month && $exp_year ) {
							/* translators: Placeholders: %1$s - credit card type, %2$s - last 4 digits of credit card, %3$s - credit card expiration date MM/YY */
							$order_note .= ': ' . sprintf( __( '%1$s ending in %2$s (expires %3$s)', 'woocommerce-gateway-ogone' ), $card_type, $account_last_four, $exp_month . '/' . $exp_year );
						}

						$order_note .= '.  ' . sprintf( __( '(Transaction ID %s)', 'woocommerce-gateway-ogone' ), $_REQUEST['PAYID'] );

						// Add order note
						$order->add_order_note( $order_note );
					break;

					case 52:
						// authorization not known
						$redirect_url = $this->get_return_url( $order );
						$order_note = sprintf( __( 'Authorization not known, please review this order.  Transaction ID %s', 'woocommerce-gateway-ogone' ), $_REQUEST['PAYID'] );
						$this->mark_order_as_held( $order, $order_note );
					break;

					case 92:
						// payment uncertain
						$redirect_url = $this->get_return_url( $order );
						$order_note = sprintf( __( 'Payment uncertain, please review this order.  Transaction ID %s', 'woocommerce-gateway-ogone' ), $_REQUEST['PAYID'] );
						$this->mark_order_as_held( $order, $order_note );
					break;

					default:
						// Other error
						/* translators: Placeholders: %1$s - request status, %2$s - error code, %3$s - transaction ID */
						$order_note = sprintf( __( 'Status: %1$s. Error code: %2$s. Transaction ID %3$s.', 'woocommerce-gateway-ogone' ), strtolower( $_REQUEST['STATUS'] ), strtolower( $_REQUEST['NCERROR'] ), strtolower( $_REQUEST['PAYID'] ) );
						$this->mark_order_as_failed( $order, $order_note );
					break;
				}

				// add order meta
				$order->update_meta_data( '_pay_id', $_REQUEST['PAYID'] );
				$order->update_meta_data( '_wc_' . $this->get_id() . '_environment', $this->is_test_environment() ? 'test' : 'production' );

				if ( $account_last_four ) {
					$order->update_meta_data('_wc_' . $this->get_id() . '_account_four', $account_last_four );
				}

				if ( $exp_month && $exp_year ) {
					$order->update_meta_data( '_wc_' . $this->get_id() . '_card_expiry_date', $exp_year . '-' . $exp_month );
				}

				if ( $card_type ) {
					$order->update_meta_data( '_wc_' . $this->get_id() . '_card_type', $card_type );
				}

				$order->save_meta_data();

			} else {

				// SHA signature check failed
				$order_note = sprintf( __( 'SHA signature check failed. Transaction ID: %s.', 'woocommerce-gateway-ogone' ), strtolower( $_REQUEST['PAYID'] ) );

				/* translators: Placeholders: %1$s - <a>, %2$s - </a> */
				$order_note .= '  ' . sprintf( __( 'Please ensure that the Ingenico plugin is configured with the exact same SHA-OUT setting from the Ingenico backoffice, as described in the %1$splugin documentation%2$s', 'woocommerce-gateway-ogone' ), '<a href="http://docs.woocommerce.com/document/ogone/#setup-sha-in">', '</a>' );

				$this->mark_order_as_failed( $order, $order_note );
			}

			wp_redirect( $redirect_url );
			exit;
		}

		if ( isset( $_REQUEST['key'], $_REQUEST['wc-api'] ) ) {
			// This likely indicates that the "I would like to receive transaction feedback parameters on the redirection URLs." ogone account setting isn't checked
			global $wp;

			$order = wc_get_order( $wp->query_vars['order-received'] );

			if ( $order ) {

				if ( $order->needs_payment() ) {

					$order_note = __( 'Possible successful transaction response received, but missing required feedback parameters.  Please verify that the "I would like to receive transaction feedback parameters on the redirection URLs." setting is enabled in your Ingenico account, found under Configuration > Technical Information > Transaction Feedback', 'woocommerce-gateway-ogone' );

					$this->mark_order_as_held( $order, $order_note );
				}

				wp_redirect( $this->get_return_url( $order ) );
			}
		}
	}


	/**
	 * Marks the given order as failed and set the order note.
	 *
	 * @since 1.2
	 *
	 * @param \WC_Order $order the order
	 * @param string $error_message a message to display inside the "Payment Failed" order note
	 */
	protected function mark_order_as_failed( $order, $error_message ) {

		/* translators: Placeholders: %1$s - payment method title, %2$s - error message */
		$order_note = sprintf( __( '%1$s Payment Failed (%2$s)', 'woocommerce-gateway-ogone' ), $this->get_method_title(), $error_message );

		// Mark order as failed if not already set, otherwise, make sure we add the order note so we can detect when someone fails to check out multiple times
		if ( ! $order->has_status( 'failed' ) ) {
			$order->update_status( 'failed', $order_note );
		} else {
			$order->add_order_note( $order_note );
		}

		$this->add_debug_message( $error_message, 'error' );

		wc_add_notice( __( 'An error occurred, please try again or try an alternate form of payment.', 'woocommerce-gateway-ogone' ), 'error' );
	}


	/**
	 * Mark the given order as 'on-hold', set an order note and display a message to the customer
	 *
	 * @since 1.0
	 *
	 * @param \WC_Order $order the order
	 * @param string $message a message to display within the order note
	 */
	protected function mark_order_as_held( $order, $message ) {

		/* translators: Placeholders: %1$s - payment method title, %2$s - on-hold message */
		$order_note = sprintf( __( '%1$s Transaction Held for Review (%2$s)', 'woocommerce-gateway-ogone' ), $this->get_method_title(), $message );

		// mark order as held
		if ( ! $order->has_status( 'on-hold' ) ) {
			$order->update_status( 'on-hold', $order_note );
		} else {
			$order->add_order_note( $order_note );
		}

		$this->add_debug_message( $message, 'message', true );

		// we don't have control over the "Thank you. Your order has been received." message shown on the "Thank You" page.  Yet
		wc_add_notice( __( 'Your order has been received and is being reviewed.  Thank you for your business.', 'woocommerce-gateway-ogone' ) );
	}


	/**
	 * Adds debug messages to the page as a WC message/error, and/or to the WC Error log
	 *
	 * @since 1.2
	 *
	 * @param string $message message to add
	 * @param string $type how to add the message, options are: 'message' (styled as WC message), 'error' (styled as WC Error)
	 * @param bool $set_message sets any WC messages/errors provided so they appear on the next page load, useful for displaying messages on the thank you page
	 */
	protected function add_debug_message( $message, $type = 'message', $set_message = false ) {

		// do nothing when debug mode is off or no message
		if ( ( 'off' === $this->debug_off() || ! $message ) && ! $this->is_test_environment() ) {
			return;
		}

		// add debug message to woocommerce->errors/messages if checkout or both is enabled
		if ( $this->debug_checkout() ) {

			if ( 'message' === $type ) {

				wc_add_notice( str_replace( "\n", "<br/>", htmlspecialchars( $message ) ) );

			} else {

				// defaults to error message
				wc_add_notice( str_replace( "\n", "<br/>", htmlspecialchars( $message ) ), 'error' );
			}
		}

		// add log message to WC logger if log/both is enabled
		if ( $this->debug_log() ) {
			$this->get_plugin()->log( $message, $this->get_id() );
		}
	}


	/**
	 * Gets the parent plugin object.
	 *
	 * @since 1.2
	 *
	 * @return \WC_Ogone the parent plugin object
	 */
	public function get_plugin() {

		return $this->plugin;
	}


	/**
	 * Gets the gateway id.
	 *
	 * @since 1.2
	 *
	 * @return string gateway id
	 */
	public function get_id() {

		return $this->id;
	}


	/**
	 * Gets the admin method title.
	 *
	 * @since 1.2
	 *
	 * @see \WC_Settings_API::$method_title
	 *
	 * @return string method title
	 */
	public function get_method_title() {

		return $this->method_title;
	}


	/**
	 * Determines if all debugging is disabled.
	 *
	 * @since 1.2
	 *
	 * @return bool
	 */
	public function debug_off() {

		return 'off' === $this->debug_mode;
	}


	/**
	 * Determines if debug logging is enabled.
	 *
	 * @since 1.2
	 *
	 * @return bool
	 */
	public function debug_log() {

		return 'log' === $this->debug_mode || 'both' === $this->debug_mode;
	}


	/**
	 * Determines if checkout debugging is enabled.
	 *
	 * This will cause debugging statements to be displayed on the checkout/pay pages.
	 *
	 * @since 1.2
	 *
	 * @return bool
	 */
	public function debug_checkout() {

		return 'checkout' === $this->debug_mode || 'both' === $this->debug_mode;
	}


	/**
	 * Determines if gateway is in testing mode.
	 *
	 * @since 1.3.7
	 *
	 * @return bool
	 */
	public function is_test_environment() {

		return 'test' === $this->version;
	}


}
