=== WooCommerce Paytrail Gateway ===
Author: skyverge
Tags: woocommerce
Requires PHP: 7.0
Requires at least: 5.2
Tested up to: 5.5.3

Accept payment in WooCommerce with the Paytrail gateway

== Installation ==

 * Upload the plugin files to the '/wp-content/plugins/' directory
 * Activate the plugin through the 'Plugins' menu in WordPress
 * Go to your WooCommerce payment gateway settings page and enable/configure the gateway
