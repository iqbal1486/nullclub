<?php
/**
 * WooCommerce Paytrail Gateway
 *
 * This source file is subject to the GNU General Public License v3.0
 * that is bundled with this package in the file license.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.html
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@skyverge.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade WooCommerce Paytrail Gateway to newer
 * versions in the future. If you wish to customize WooCommerce Paytrail Gateway for your
 * needs please refer to http://docs.woocommerce.com/document/woocommerce-paytrail/
 *
 * @author    SkyVerge
 * @copyright Copyright (c) 2011-2020, SkyVerge, Inc. (info@skyverge.com)
 * @license   http://www.gnu.org/licenses/gpl-3.0.html GNU General Public License v3.0
 */

defined( 'ABSPATH' ) or exit;

use SkyVerge\WooCommerce\PluginFramework\v5_10_2 as Framework;

/**
 * The API request object.
 *
 * @since 2.0.0
 */
class WC_Paytrail_API_Request extends Framework\SV_WC_API_JSON_Request {


	/**
	 * Construct the request.
	 *
	 * @since 2.0.0
	 */
	public function __construct() {

		$this->path = '/api-payment/create';
	}


	/**
	 * Set the parameters for a new payment.
	 *
	 * @since 2.0.0
	 * @param \WC_Order $order The order object
	 * @param string $locale The payment form locale
	 * @param string $return_url The return URL on successful payment
	 * @param bool $extended_info Whether to send extended transaction info or just the order total
	 */
	public function set_payment_params( \WC_Order $order, $locale, $return_url, $extended_info = false ) {

		$params = [
			'orderNumber' => substr( $order->get_order_number(), 0, 64 ),
			'currency'    => $order->get_currency(),
			'locale'      => $locale,
			'urlSet'      => [
				'success'      => add_query_arg( 'order_id', $order->get_id(), $return_url ),
				'failure'      => $order->get_cancel_order_url_raw(),
				'notification' => add_query_arg( 'notification', 'payment', $return_url ),
			],
		];

		// If transactions should include extended information, add it
		if ( $extended_info ) {

			$params['orderDetails'] = [
				'includeVat' => 1,
				'contact'    => $this->get_formatted_contact( $order ),
				'products'   => $this->get_formatted_items( $order ),
			];

		// Otherwise, just send along the order total
		} else {

			$params['price'] = $order->payment_total;
		}

		/**
		 * Filter the hosted pay page parameters.
		 *
		 * @since 2.0.0
		 * @param array $params Form parameters in name => value format
		 * @param \WC_Order $order The order object
		 * @param \WC_Gateway_Paytrail $gateway The gateway instance
		 */
		$params = apply_filters( 'wc_paytrail_payment_params', $params, $order, $this );

		$this->data = $params;
	}


	/**
	 * Gets the order items formatted for the Paytrail API.
	 *
	 * @since 2.0.0
	 *
	 * @param \WC_Order $order
	 * @return array
	 */
	protected function get_formatted_items( \WC_Order $order ) {

		/**
		 * Filters the number of decimal places to round to for the VAT rate.
		 *
		 * @since 2.2.1
		 *
		 * @param int $decimal_places number of decimal places
		 */
		$vat_decimal_places = (int) apply_filters( 'wc_paytrail_vat_decimal_places', 2 );

		$items = array();

		// Add the product costs
		foreach ( $order->get_items() as $item ) {

			if ( ! $item['qty'] ) {
				continue;
			}

			// Calculate tax percentage
			$line_tax_total = $order->get_item_total( $item, false, false );
			$tax_percentage = $line_tax_total ? ( $order->get_item_tax( $item, false ) / $line_tax_total ) * 100 : 0;

			$product = $item->get_product();

			$items[] = array(
				'title'    => $item['name'],
				'code'     => $product->get_sku() ? substr( $product->get_sku(), 0, 16 ) : '',
				'amount'   => $item['qty'],
				'price'    => wc_format_decimal( $order->get_item_total( $item, true ), 2 ),
				'vat'      => number_format( (float) $tax_percentage, $vat_decimal_places ), // we can't use wc_format_decimal() here as it won't allow zero decimal places
				'discount' => '0.00',
				'type'     => 1,
			);
		}

		// Add the shipping costs
		foreach ( $order->get_shipping_methods() as $method ) {

			$taxes = $method['taxes']['total'];

			// Calculate tax percentage
			$total          = $method['cost'];
			$tax_total      = array_sum( maybe_unserialize( $taxes ) );
			$tax_percentage = ( $tax_total && $total ) ? ( $tax_total / $total ) * 100 : 0;

			$items[] = array(
				'title'    => $method['name'],
				'code'     => substr( $method['method_id'], 0, 16 ),
				'amount'   => 1,
				'price'    => wc_format_decimal( $total + $tax_total, 2 ),
				'vat'      => number_format( (float) $tax_percentage, $vat_decimal_places ),
				'discount' => '0.00',
				'type'     => 2,
			);
		}

		// Add any fees
		foreach ( $order->get_fees() as $fee ) {

			// Calculate tax rate
			$line_tax_total = $order->get_item_total( $fee, false, false );
			$tax_percentage = $line_tax_total ? ( $order->get_item_tax( $fee, false ) / $line_tax_total ) * 100 : 0;

			$items[] = array(
				'title'    => $fee['name'],
				'amount'   => 1,
				'price'    => wc_format_decimal( $order->get_line_total( $fee, true ), 2 ),
				'vat'      => number_format( (float) $tax_percentage, $vat_decimal_places ),
				'discount' => '0.00',
				'type'     => 1,
			);
		}

		/**
		 * Filter the order line items for payment.
		 *
		 * @since 2.0.0
		 * @param array $items {
		 *     The order line items.
		 *
		 *     @type string $title    Item title (product name, fee name, ect...)
		 *     @type string $code     Item code (SKU or other unique ID)
		 *     @type int    $amount   Item quantity
		 *     @type float  $price    Total item cost
		 *     @type float  $vat      Item tax
		 *     @type float  $discount Discount amount. Unused.
		 *     @type int    $type     Item type. 1 = standard, 2 = shipping, 3 = handling
		 * }
		 */
		return apply_filters( 'wc_paytrail_payment_order_items', $items );
	}


	/**
	 * Gets the order contact formatted for the Paytrail API.
	 *
	 * @since 2.0.0
	 *
	 * @param \WC_Order $order
	 * @return array
	 */
	protected function get_formatted_contact( \WC_Order $order ) {

		$postcode = $order->get_billing_postcode( 'edit' );

		$contact = [
			'telephone'   => Framework\SV_WC_Helper::str_truncate( $order->get_billing_phone( 'edit' ), 64 ),
			'email'       => $order->get_billing_email( 'edit' ),
			'firstName'   => Framework\SV_WC_Helper::str_truncate( $order->get_billing_first_name( 'edit' ), 64 ),
			'lastName'    => Framework\SV_WC_Helper::str_truncate( $order->get_billing_last_name( 'edit' ), 64 ),
			'companyName' => Framework\SV_WC_Helper::str_truncate( $order->get_billing_company( 'edit' ), 128 ),
			'address'     => [
				'street'       => Framework\SV_WC_Helper::str_truncate( $order->get_billing_address_1( 'edit' ), 128 ),
				'postalCode'   => empty( $postcode ) ? '-' : Framework\SV_WC_Helper::str_truncate( $postcode, 16 ),
				'postalOffice' => Framework\SV_WC_Helper::str_truncate( $order->get_billing_city( 'edit' ), 16 ),
				'country'      => $order->get_billing_country( 'edit' ),
			],
		];

		/**
		 * Filter the order contact for payment.
		 *
		 * @since 2.0.0
		 * @param array $contact
		 */
		return apply_filters( 'wc_paytrail_payment_contact', $contact );
	}


}
