<?php
/**
 * WooCommerce Paytrail Gateway
 *
 * This source file is subject to the GNU General Public License v3.0
 * that is bundled with this package in the file license.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.html
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@skyverge.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade WooCommerce Paytrail Gateway to newer
 * versions in the future. If you wish to customize WooCommerce Paytrail Gateway for your
 * needs please refer to http://docs.woocommerce.com/document/woocommerce-paytrail/
 *
 * @package   WC-Gateway-Paytrail/Gateway
 * @author    SkyVerge
 * @copyright Copyright (c) 2011-2020, SkyVerge, Inc. (info@skyverge.com)
 * @license   http://www.gnu.org/licenses/gpl-3.0.html GNU General Public License v3.0
 */

namespace SkyVerge\WooCommerce\Paytrail;

defined( 'ABSPATH' ) or exit;

use SkyVerge\WooCommerce\PluginFramework\v5_10_2 as Framework;

/**
 * Lifecycle handler.
 *
 * @since 2.4.0
 *
 * @method \WC_Paytrail get_plugin()
 */
class Lifecycle extends Framework\Plugin\Lifecycle {


	/**
	 * Lifecycle constructor.
	 *
	 * @since 2.4.1
	 *
	 * @param \WC_Paytrail $plugin
	 */
	public function __construct( $plugin )  {

		parent::__construct( $plugin );

		$this->upgrade_versions = [
			'1.2.0',
			'2.0.0',
		];
	}


	/**
	 * Performs installation tasks.
	 *
	 * @since 2.4.0
	 */
	protected function install() {

		if ( get_option( 'woocommerce_suomen_verkkomaksut_settings' ) ) {

			// versions prior to 1.2 were named differently and did not set a db version option
			$this->upgrade( '1.1.0' );
		}
	}


	/**
	 * Updates to version 1.2.0
	 *
	 * @since 2.4.1
	 */
	protected function upgrade_to_1_2_0() {

		$settings = get_option( 'woocommerce_suomen_verkkomaksut_settings', [] );

		if ( isset( $settings['title'], $settings['description'] ) ) {
			$settings['title']       = str_ireplace( 'Suomen Verkkomaksut', 'Paytrail', $settings['title'] );
			$settings['description'] = str_ireplace( 'Suomen Verkkomaksut', 'Paytrail', $settings['description'] );
		}

		delete_option( 'woocommerce_suomen_verkkomaksut_settings' );
		update_option( 'woocommerce_paytrail_settings', $settings );
	}


	/**
	 * Updates to version 2.0.0
	 *
	 * @since 2.4.1
	 */
	protected function upgrade_to_2_0_0() {
		global $wpdb;

		// upgrade the settings

		$settings = get_option( 'woocommerce_paytrail_settings', [] );

		if ( isset( $settings['debug'] ) ) {

			$settings['debug_mode'] = ( 'yes' === $settings['debug'] ) ? 'log' : 'off';

			unset( $settings['debug'] );
		}

		update_option( 'woocommerce_paytrail_settings', $settings );

		$this->get_plugin()->log( 'Settings updated' );

		// upgrade the order meta

		$rows = $wpdb->update( $wpdb->postmeta, [ 'meta_key' => '_wc_paytrail_trans_id' ], [ 'meta_key' => '_wc_paytrail_transaction_id' ] );

		$this->get_plugin()->log( sprintf( '%d orders updated for transaction ID meta', $rows ) );
	}


}
