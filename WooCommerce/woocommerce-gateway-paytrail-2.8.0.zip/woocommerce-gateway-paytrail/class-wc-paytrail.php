<?php
/**
 * WooCommerce Paytrail Gateway
 *
 * This source file is subject to the GNU General Public License v3.0
 * that is bundled with this package in the file license.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.html
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@skyverge.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade WooCommerce Paytrail Gateway to newer
 * versions in the future. If you wish to customize WooCommerce Paytrail Gateway for your
 * needs please refer to http://docs.woocommerce.com/document/woocommerce-paytrail/
 *
 * @author    SkyVerge
 * @copyright Copyright (c) 2011-2020, SkyVerge, Inc. (info@skyverge.com)
 * @license   http://www.gnu.org/licenses/gpl-3.0.html GNU General Public License v3.0
 */

defined( 'ABSPATH' ) or exit;

use SkyVerge\WooCommerce\PluginFramework\v5_10_2 as Framework;

/**
 * WooCommerce Paytrail main class.
 *
 * @since 1.0
 */
class WC_Paytrail extends Framework\SV_WC_Payment_Gateway_Plugin {


	/** string version number */
	const VERSION = '2.8.0';

	/** @var \WC_Paytrail single instance of this plugin */
	protected static $instance;

	/** string plugin ID */
	const PLUGIN_ID = 'paytrail';

	/** string gateway ID */
	const GATEWAY_ID = 'paytrail';

	/** string gateway class name */
	const GATEWAY_CLASS_NAME = 'WC_Gateway_Paytrail';


	/**
	 * Setup main plugin class
	 *
	 * @since 2.0.0
	 */
	public function __construct() {

		parent::__construct(
			self::PLUGIN_ID,
			self::VERSION,
			array(
				'gateways'    => array( self::GATEWAY_ID => self::GATEWAY_CLASS_NAME ),
				'currencies'  => array( 'EUR' ),
				'text_domain' => 'woocommerce-gateway-paytrail',
			)
		);

		$this->includes();
	}


	/**
	 * Loads any required files.
	 *
	 * @internal
	 *
	 * @since 2.0.0
	 */
	public function includes() {

		// The gateway
		require_once( $this->get_plugin_path() . '/includes/class-wc-gateway-paytrail.php' );
	}


	/**
	 * Builds the lifecycle handler instance.
	 *
	 * @since 2.4.0
	 */
	protected function init_lifecycle_handler() {

		require_once( $this->get_plugin_path() . '/includes/Lifecycle.php' );

		$this->lifecycle_handler = new SkyVerge\WooCommerce\Paytrail\Lifecycle( $this );
	}


	/**
	 * Returns deprecated/removed hooks.
	 *
	 * @since 2.0.0
	 *
	 * @return array
	 */
	protected function get_deprecated_hooks() {

		return array(
			'valid_paytrail_payment' => array(
				'version'     => '2.0.0',
				'removed'     => true,
			),
		);
	}


	/**
	 * Returns the main Paytrail instance.
	 *
	 * Ensures only one instance is/can be loaded.
	 *
	 * @since 2.0.0
	 *
	 * @return \WC_Paytrail
	 */
	public static function instance() {

		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}


	/**
	 * Returns the plugin name, localized.
	 *
	 * @since 2.0.0
	 *
	 * @return string the plugin name
	 */
	public function get_plugin_name() {

		return __( 'WooCommerce Paytrail', 'woocommerce-gateway-paytrail' );
	}


	/**
	 * Gets the plugin documentation URL.
	 *
	 * @since 2.0.0
	 *
	 * @return string
	 */
	public function get_documentation_url() {

		return 'https://docs.woocommerce.com/document/suomen-verkkomaksut/';
	}


	/**
	 * Gets the plugin support URL.
	 *
	 * @since 2.0.0
	 *
	 * @return string
	 */
	public function get_support_url() {

		return 'https://woocommerce.com/my-account/marketplace-ticket-form/';
	}


	/**
	 * Gets the plugin sales page URL.
	 *
	 * @since 2.4.0
	 *
	 * @return string
	 */
	public function get_sales_page_url() {

		return 'https://woocommerce.com/products/woocommerce-paytrail/';
	}


	/**
	 * Returns __FILE__.
	 *
	 * @since 2.0.0
	 *
	 * @return string the full path and filename of the plugin file
	 */
	protected function get_file() {
		return __FILE__;
	}


}


/**
 * Returns the One True Instance of Paytrail.
 *
 * @since 2.0.0
 *
 * @return \WC_Paytrail
 */
function wc_paytrail() {

	return \WC_Paytrail::instance();
}
