# WooCommerce GoCardless Gateway

This is a feature plugin for accepting payments via [GoCardless](https://gocardless.com/).

## Dependencies

-   WooCommerce

## Development

### Install dependencies & build

-   `npm install`

Use `npm run build` to create .zip archive with extension files for testing on other sites.

## Setup

Install the following plugins on your dev site:

-   WooCommerce

## Test account setup

You can create a user on [gocardless.com](https://gocardless.com) for live transactions and [on the sandbox](https://manage-sandbox.gocardless.com/) for test transactions. When you first set up a site, you’ll be prompted to create a user for the correct GoCardless environment when setting up the webhooks.
