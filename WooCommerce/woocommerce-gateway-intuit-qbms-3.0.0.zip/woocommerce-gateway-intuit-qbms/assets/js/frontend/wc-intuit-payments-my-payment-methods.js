jQuery( function ( $ ) {

	'use strict';

	window.WC_Intuit_Payments_My_Payment_Methods_Handler = window.SV_WC_Payment_Methods_Handler_v5_10_4;

	$( document.body ).trigger( 'wc_intuit_payments_my_payment_methods_handler_loaded' );

} );
