=== WooCommerce Intuit Payments Gateway ===
Author: skyverge
Tags: woocommerce
Requires PHP: 7.0
Requires at least: 5.2
Tested up to: 5.6.2

Accept credit cards in WooCommerce with the Intuit Payments or Legacy QBMS gateway

See https://docs.woocommerce.com/document/woocommerce-intuit-qbms/ for full documentation.

== Installation ==

1. Upload the entire 'woocommerce-gateway-intuit-qbms' folder to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress
