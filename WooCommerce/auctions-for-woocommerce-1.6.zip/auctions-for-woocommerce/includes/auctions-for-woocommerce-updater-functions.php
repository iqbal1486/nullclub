<?php
/**
 * Auctions for WooCommerce Updates
 *
 * Functions for updating data, used by the background updater.
 *
 * @package WooCommerce/Functions
 * @version 2.0.0
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

