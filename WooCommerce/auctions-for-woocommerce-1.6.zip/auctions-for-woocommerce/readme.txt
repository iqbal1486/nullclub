= Auctions for WooCommerce =
Author: WPInstitut https://wpinstitut.com/

Documentation: https://wpinstitut.com/auctions-for-woocommerce-documentation/
Tags: wordpress auctions, woocommerce auctions, simple wordpress auctions, auctions, auction plugin, wordpress auction plugin, woocommerce auction plugin, simple auction


Requires at least:	4.0

== Description ==
Auctions for WooCommerce is a plugin for a plugin :) Since WooCommerce is popular we decided that it would be neat to extend it with auction features. 
We wanted to make it easy to use but also to include all auction features so you get a powerful auction solution which is easily setup and customized.
With our auction plugin you can setup WordPress auction website and start auctions in less than 30 minutes (assuming you have payment processor account ready).


= License =

Unless otherwise specified, all the theme files, scripts and images are licensed under GNU General Public Licemse.