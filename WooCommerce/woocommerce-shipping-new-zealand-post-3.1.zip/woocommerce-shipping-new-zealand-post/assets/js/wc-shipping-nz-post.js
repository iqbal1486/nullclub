jQuery(document).ready(function(){
	var select_field = '#woocommerce_new_zealand_post_nz_post_api_type';
	jQuery(document).on('change',select_field,function(e){
		manange_api_type(jQuery(this).val());
	});
	manange_api_type(jQuery(select_field).val());


	jQuery('.price_tag').keypress(function(event) {
		if (event.which != 46 && (event.which < 47 || event.which > 59))
		{
			event.preventDefault();
			if ((event.which == 46) && ($(this).indexOf('.') != -1)) {
				event.preventDefault();
			}
		}
	});
});	

function manange_api_type(api_type) {
	if ('rate_finder' == api_type) {
			jQuery('.shipping_options_api_input').parents('tr').hide();
			jQuery('.rate_finder_api_input').parents('tr').show();
		} else {
			jQuery('.shipping_options_api_input').parents('tr').show();
			jQuery('.rate_finder_api_input').parents('tr').hide();
		}
}