<?php
if ( ! class_exists( 'WC_Abstract_Privacy' ) ) {
	return;
}

class WC_Shipping_New_Zealand_Post_Privacy extends WC_Abstract_Privacy {
	/**
	 * Constructor
	 */
	public function __construct() {
		parent::__construct( __( 'New Zealand Post', 'woocommerce-shipping-new-zealand-post' ) );
	}

	/**
	 *
	 * Gets the message of the privacy to display.
	 */
	public function get_privacy_message() {

		/* translators: %s: docs link */
		return wpautop( sprintf( __( 'By using this extension, you may be storing personal data or sharing data with an external service. <a href="%s" target="_blank">Learn more about how this works, including what you may want to include in your privacy policy.</a>', 'woocommerce-shipping-new-zealand-post' ), 'https://docs.woocommerce.com/document/privacy-shipping/#woocommerce-shipping-new-zealand-post' ) );
	}
}

new WC_Shipping_New_Zealand_Post_Privacy();
