<?php

/**
 * WC_Boxpack_Item class.
 */
class WC_Boxpack_Item {

	public $weight;
	public $height;
	public $width;
	public $length;
	public $volume;
	public $value;
	public $meta;

	/**
	 *
	 * __construct function.
	 *
	 * @return void
	 */
	public function __construct( $length, $width, $height, $weight, $value = '', $meta = array() ) {
		$dimensions = array( $length, $width, $height );

		sort( $dimensions );

		$this->length = floatval( $dimensions[2] );
		$this->width  = floatval( $dimensions[1] );
		$this->height = floatval( $dimensions[0] );

		$this->volume = floatval( $width * $height * $length );
		$this->weight = floatval( $weight );
		$this->value  = $value;
		$this->meta   = $meta;
	}

	/**
	 *
	 * Get_volume function.
	 *
	 * @return void
	 */
	public function get_volume() {
		return $this->volume;
	}

	/**
	 *
	 * Get_height function.
	 *
	 * @return void
	 */
	public function get_height() {
		return $this->height;
	}

	/**
	 *
	 * Get_width function.
	 *
	 * @return void
	 */
	public function get_width() {
		return $this->width;
	}

	/**
	 *
	 * Get_width function.
	 *
	 * @return void
	 */
	public function get_length() {
		return $this->length;
	}

	/**
	 *
	 * Get_width function.
	 *
	 * @return void
	 */
	public function get_weight() {
		return $this->weight;
	}

	/**
	 *
	 * Get_value function.
	 *
	 * @return void
	 */
	public function get_value() {
		return $this->value;
	}

	/**
	 *
	 * Get_meta function.
	 *
	 * @return void
	 */
	public function get_meta( $key = '' ) {
		if ( $key ) {
			if ( isset( $this->meta[ $key ] ) ) {
				return $this->meta[ $key ];
			} else {
				return null;
			}
		} else {
			return array_filter( (array) $this->meta );
		}
	}
}
