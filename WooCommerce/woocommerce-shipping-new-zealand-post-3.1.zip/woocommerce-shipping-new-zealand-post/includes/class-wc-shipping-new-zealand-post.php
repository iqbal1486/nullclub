<?php
/**
 * WC_Shipping_New_Zealand_Post class.
 *
 * @extends WC_Shipping_Method
 */
class WC_Shipping_New_Zealand_Post extends WC_Shipping_Method {

	public $unit_weight;
	public $unit_dimension;

	private $endpoints = array(
		// 'domestic'      => 'http://api.nzpost.co.nz/ratefinder/domestic/rating/v2',
		// 'international' => 'http://api.nzpost.co.nz/ratefinder/international.json',

		'domestic'        => 'https://api.nzpost.co.nz/shippingoptions/2.0/domestic',
		'international'   => 'https://api.nzpost.co.nz/shippingoptions/2.0/international',

	);

	private $default_api_type = 'rate_finder';

	private $services = array();

	private $services_list = array(
		'rate_finder' => array(
			// Domestic
			'parcel_post'               => 'ParcelPost',
			'parcel_post_fast'          => 'ParcelPost Fast',
			'parcel_post_tracked'       => 'ParcelPost Tracked',
			'parcel_post_tracked_zonal' => 'ParcelPost Tracked Zonal',
			'courier'                   => 'Courier',

			// New rates
				'STD' => 'Standard Parcel',
			'TRK' => 'Tracked Parcel',
			'COU' => 'Courier',
			'COS' => 'Courier & Signature',

			// International
				'TIEX'                => 'International Express Courier',
			'TIEC'                => 'International Economy Courier',
			'TIALP'               => 'International Air',
			'TIASPC'              => 'International Air Small Parcel',
		),
		'shipping_option' => array(
			// Domestic
			'parcel_post'               => 'ParcelPost',
			'parcel_post_fast'          => 'ParcelPost Fast',
			'parcel_post_tracked'       => 'ParcelPost Tracked',
			'parcel_post_tracked_zonal' => 'ParcelPost Tracked Zonal',
			'courier'                   => 'Courier',

			// New rates
				'STD' => 'Standard Parcel',
			'TRK' => 'Tracked Parcel',
			'COU' => 'Courier',
			'COS' => 'Courier & Signature',

			'3HRA' => '3 HOUR SERVICE AKL',
			'P65A' => 'PACE 65',
			'PX5A' => 'PACE 105',


			// International
				'TIEX'                => 'International Express Courier',
			'TIEC'                => 'International Economy Courier',
			'TIALP'               => 'International Air',
			'TIALP7'              => 'Air Parcel (Thermal)',
			'TIAS'            => 'Air Small Parcel (Thermal)',
			'TIASRR'              => 'Air Satchel Tracked (Sig)',
			'TIASPP'              => 'Air Satchel',
			'TIASPD'              => 'Air Satchel - Documents',
			'TIASP7'              => 'Air Small Parcel (Thermal)',
			'TIEC7'           => 'Courier (Thermal)',
			'TIECDA' => 'Courier DIA',
			'TDEAUS' => 'eParcel - Sig. with ATL',
			'TDEAUN' => 'eParcel - Sig. No ATL',
			'TDEAUD' => 'eParcel Dangerous Goods	',
			'TDEAUT' => 'eParcel - Tracked	',
			'TDEAUU' => 'eParcel - Untracked	',
			'TDEAT6' => 'eParcel - Tracked (6x4)	',
			'TIIECX'              => 'Courier Exemption',
			'TIECCH'              => 'Courier China',
			'TIECCN'              => 'GoChina',
			'TIECC7'              => 'GoChina (Thermal)',
			'TIEXDT'              => 'Express Courier (DDTP)',
			'TIALPR'              => 'Air Parcel (R)',
			'TIECRI'              => 'Courier (R)',
			'TIEXRI'              => 'Express Courier (R)',
			'TEXPRE'              => 'Air Satchel Tracked - Item/Kilo',
			'TEXPRX'              => 'Air Satchel Tracked - Item/Kilo (X)',
			'TEXPRA'              => 'Air Satchel Tracked',
			'TEXPAX'              => 'Air Satchel Tracked (X)',
			'TPASIA'              => 'Air Satchel Tracked (Asia) - Item/Kilo',
			'TPASIK'              => 'Air Satchel Tracked (Asia)',

			// Domestic
				'CPOLP'               => 'CP Online Parcel',
			'CFF'                 => 'Freight Forward Overnight',
			'CPOLE'               => 'CP Online Economy',
			'CPOLCT1'             => 'CP Online W/Island',
			'CPOLCT2'             => 'CP Online I/Island',
			'CPOLCT3'             => 'CP Online N/W',
			'CPOLCT4'             => 'CP Online Interisland Economy',
			'CPOLTPA5'             => 'Courierpost Online Trackpak A5',
			'CPOLTPA4'             => 'Courierpost Online Trackpak A4',
			'CPOLTPDL '            => 'Courierpost Online Trackpak DL',
			'CPOLTPA4B' => 'Courierpost Online Trackpak A4 (A4-sized bag with bubble wrap)',
			'CPOLTPA5B' => 'Courierpost Online Trackpak A5 (A5-sized bag with bubble wrap)',
			'CPOLTPFS' => 'Courierpost Online Trackpak FS (Foolscap-sized bag)',
			'CPOLTPLF' => 'Courierpost Online Trackpak LF (Lineflow-sized bag)',
			'CPOLTPCDL' => 'Courierpost Online Eco Trackpak DL (DL envelope-sized bag (cardboard))',
			'CPOLTPCA5' => 'Courierpost Online Eco Trackpak A5 (A5-sized bag (cardboard))',
			'CPOLTPCFS' => 'Courierpost Online Eco Trackpak FS (Foolscap-sized bag (cardboard))',
			'CPOLTPXL' => 'Courierpost Online Trackpak XL (Extra large-sized bag)',
			'CPOLPPS' => 'Courierpost Online Perishable Goods (Service for perishable goods like chilled foods.)',
		),
	);

	private $found_rates;
	private $rate_cache;

	/**
	 * __construct function.
	 *
	 * @return void
	 */
	public function __construct( $instance_id = 0 ) {
		$this->id                 = 'new_zealand_post';
		$this->instance_id        = absint( $instance_id );
		$this->method_title       = __( 'New Zealand Post', 'woocommerce-shipping-new-zealand-post' );
		$this->method_description = __( 'The New Zealand Post extension obtains rates dynamically from the New Zealand Post API during cart/checkout.', 'woocommerce-shipping-new-zealand-post' );
		$this->supports           = array(
			'shipping-zones',
			'instance-settings',
			'settings',
		);
		$this->unit_weight = get_option( 'woocommerce_weight_unit' );
		$this->unit_dimension = get_option( 'woocommerce_dimension_unit' );

		$this->init();
	}

	/**
	 * Is Available function.
	 *
	 * @param array $package
	 * @return bool
	 */
	public function is_available( $package ) {
		if ( empty( $package['destination']['country'] ) ) {
			return false;
		}

		return apply_filters( 'woocommerce_shipping_' . $this->id . '_is_available', true, $package );
	}

	/**
	 * Initialize settings
	 *
	 * @version 1.3.0
	 * @since 1.3.0
	 * @return void
	 */
	private function set_settings() {
		// Define user set variables
		$this->title           = $this->get_option( 'title', $this->method_title );
		$this->origin          = $this->get_option( 'origin', '' );
		$this->api_key         = $this->get_option( 'api_key', '' );
		$this->gst_on_shipping_price  = $this->get_option( 'gst_on_shipping_price', 'price_excluding_gst' );
		$this->packing_method  = $this->get_option( 'packing_method', 'per_item' );
		$this->boxes           = $this->get_option( 'boxes', array() );
		$this->custom_services = $this->get_option( 'services', array() );
		$this->offer_rates     = $this->get_option( 'offer_rates', 'all' );
		$this->debug           = $this->get_option( 'debug_mode' ) ? $this->get_option( 'debug_mode' ) : 'no';
		$this->debug           = 'yes' === $this->debug ? true : false;
		$this->postage_type    = $this->get_option( 'postage_type', 'postage_only' );
		$this->domestic_shipping_surchage = $this->get_option( 'domestic_shipping_surchage', '' );
		$this->international_shipping_surchage = $this->get_option( 'international_shipping_surchage', '' );

		// creating variables for auth 2 headers for curl request
		$this->oauth_token_url = 'https://oauth.nzpost.co.nz/as/token.oauth2';
		$this->consumer_key    = $this->get_option( 'client_id', '' );
		$this->consumer_secret = $this->get_option( 'client_secret', '' );
		$this->user_name       = $this->get_option( 'user_name', '' );
		$this->nz_post_account_number       = $this->get_option( 'nz_post_account_number', '' );

		if ( $this->default_api_type == $this->get_option( 'nz_post_api_type' ) ) {
			$this->endpoints = array(
				'domestic'      => 'http://api.nzpost.co.nz/ratefinder/domestic/rating/v2',
				'international' => 'http://api.nzpost.co.nz/ratefinder/international.json',
			);
		}

		$this->services = $this->services_list[ $this->get_option( 'nz_post_api_type', 'rate_finder' ) ];
	}

	/**
	 * Init function.
	 *
	 * @return void
	 */
	private function init() {
		// Load the settings.
		$this->init_form_fields();
		$this->set_settings();
		add_action( 'woocommerce_update_options_shipping_' . $this->id, array( $this, 'process_admin_options' ) );
		add_action( 'woocommerce_update_options_shipping_' . $this->id, array( $this, 'clear_transients' ) );

	}

	/**
	 * Process settings on save
	 *
	 * @since 3.4.0
	 * @version 3.4.0
	 * @return void
	 */
	public function process_admin_options() {
		parent::process_admin_options();

		$this->set_settings();
	}

	/**
	 * Output a message
	 */
	public function debug( $message, $type = 'notice' ) {
		if ( $this->debug ) {
			wc_add_notice( $message, $type );
		}
	}


	/**
	 * Generate_token_nzpost
	 *
	 * @return void
	 */
	public function generate_token_nzpost() {
		$token = '';
		// api url to create auth token
		$requestUrl = $this->oauth_token_url . '?grant_type=client_credentials&client_id=' . $this->consumer_key . '&client_secret=' . $this->consumer_secret;

		$response = wp_remote_post(
			$requestUrl,
			array(
				'timeout'          => 70,
				'sslverify'        => 0,
			)
		);

		return $response['body'];
	}

	/**
	 * Generate_services_html function.
	 *
	 * @return void
	 */
	public function generate_services_html() {
		ob_start();
		?>
		<tr valign="top" id="service_options">
			<th scope="row" class="titledesc"><?php esc_html_e( 'Services', 'woocommerce-shipping-new-zealand-post' ); ?></th>
			<td class="forminp">
				<table class="new_zealand_post_services widefat">
					<thead>
						<th class="sort">&nbsp;</th>
						<th><?php esc_html_e( 'Service Code(s)', 'woocommerce-shipping-new-zealand-post' ); ?></th>
						<th><?php esc_html_e( 'Name', 'woocommerce-shipping-new-zealand-post' ); ?></th>
						<th><?php esc_html_e( 'Enabled', 'woocommerce-shipping-new-zealand-post' ); ?></th>
						<th>
							<?php
							/* translators: %s: currency symbol */
							echo sprintf( esc_html_e( 'Price Adjustment (%s)', 'woocommerce-shipping-new-zealand-post' ), esc_html_e( get_woocommerce_currency_symbol(), 'woocommerce-shipping-new-zealand-post' ) );
							?>
						</th>
						<th><?php esc_html_e( 'Price Adjustment (%)', 'woocommerce-shipping-new-zealand-post' ); ?></th>
					</thead>
					<tbody>
						<?php
							$sort = 0;
							$this->ordered_services = array();
						foreach ( $this->services as $code => $name ) {

							if ( isset( $this->custom_services[ $code ]['order'] ) ) {
								$sort = $this->custom_services[ $code ]['order'];
							}

							while ( isset( $this->ordered_services[ $sort ] ) ) {
								$sort++;
							}

							$this->ordered_services[ $sort ] = array( $code, $name );

							$sort++;
						}

							ksort( $this->ordered_services );

						foreach ( $this->ordered_services as $value ) {
							$code = $value[0];
							$name = $value[1];
							?>
								<tr>
									<td class="sort">
									<input type="hidden" class="order" name="new_zealand_post_service[<?php echo esc_html_e( $code, 'woocommerce-shipping-new-zealand-post' ); ?>][order]" value="<?php echo isset( $this->custom_services[ $code ]['order'] ) ? esc_html_e( $this->custom_services[ $code ]['order'], 'woocommerce-shipping-new-zealand-post' ) : ''; ?>" /></td>
									<td><strong><?php echo esc_html_e( $code, 'woocommerce-shipping-new-zealand-post' ); ?></strong></td>
									<td><input type="text" name="new_zealand_post_service[<?php echo esc_html_e( $code, 'woocommerce-shipping-new-zealand-post' ); ?>][name]" placeholder="<?php echo esc_html_e( $name, 'woocommerce-shipping-new-zealand-post' ); ?> (<?php echo esc_html_e( $this->title, 'woocommerce-shipping-new-zealand-post' ); ?>)" value="<?php echo isset( $this->custom_services[ $code ]['name'] ) ? esc_html_e( $this->custom_services[ $code ]['name'], 'woocommerce-shipping-new-zealand-post' ) : ''; ?>" size="50" /></td>
									<td><input type="checkbox" name="new_zealand_post_service[<?php echo esc_html_e( $code, 'woocommerce-shipping-new-zealand-post' ); ?>][enabled]" <?php checked( ( ! isset( $this->custom_services[ $code ]['enabled'] ) || ! empty( $this->custom_services[ $code ]['enabled'] ) ), true ); ?> /></td>
									<td><input type="text" name="new_zealand_post_service[<?php echo esc_html_e( $code, 'woocommerce-shipping-new-zealand-post' ); ?>][adjustment]" placeholder="N/A" value="<?php echo isset( $this->custom_services[ $code ]['adjustment'] ) ? esc_html_e( $this->custom_services[ $code ]['adjustment'], 'woocommerce-shipping-new-zealand-post' ) : ''; ?>" size="4" /></td>
									<td><input type="text" name="new_zealand_post_service[<?php echo esc_html_e( $code, 'woocommerce-shipping-new-zealand-post' ); ?>][adjustment_percent]" placeholder="N/A" value="<?php echo isset( $this->custom_services[ $code ]['adjustment_percent'] ) ? esc_html_e( $this->custom_services[ $code ]['adjustment_percent'], 'woocommerce-shipping-new-zealand-post' ) : ''; ?>" size="4" /></td>
								</tr>
								<?php
						}
						?>
					</tbody>
				</table>
			</td>
		</tr>
		<?php
		return ob_get_clean();
	}

	/**
	 * Generate_box_packing_html function.
	 *
	 * @return void
	 */
	public function generate_box_packing_html() {
		ob_start();
		?>
		<tr valign="top" id="packing_options">
			<th scope="row" class="titledesc"><?php esc_html_e( 'Box Sizes', 'woocommerce-shipping-new-zealand-post' ); ?></th>
			<td class="forminp">
				<style type="text/css">
					.new_zealand_post_boxes td, .new_zealand_post_services td {
						vertical-align: middle;
						padding: 4px 7px;
					}
					.new_zealand_post_boxes th, .new_zealand_post_services th {
						padding: 9px 7px;
					}
					.new_zealand_post_boxes td input {
						margin-right: 4px;
					}
					.new_zealand_post_boxes .check-column {
						vertical-align: middle;
						text-align: left;
						padding: 0 7px;
					}
					.new_zealand_post_services th.sort {
						width: 16px;
					}
					.new_zealand_post_services td.sort {
						cursor: move;
						width: 16px;
						padding: 0 16px;
						cursor: move;
						background: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAHUlEQVQYV2O8f//+fwY8gJGgAny6QXKETRgEVgAAXxAVsa5Xr3QAAAAASUVORK5CYII=) no-repeat center;
					}
				</style>
				<table class="new_zealand_post_boxes widefat">
					<thead>
						<tr>
							<th class="check-column"><input type="checkbox" /></th>
							<th><?php esc_html_e( 'Name', 'woocommerce-shipping-new-zealand-post' ); ?></th>
							<th><?php esc_html_e( 'Outer Length', 'woocommerce-shipping-new-zealand-post' ); ?></th>
							<th><?php esc_html_e( 'Outer Width', 'woocommerce-shipping-new-zealand-post' ); ?></th>
							<th><?php esc_html_e( 'Outer Height', 'woocommerce-shipping-new-zealand-post' ); ?></th>
							<th><?php esc_html_e( 'Inner Length', 'woocommerce-shipping-new-zealand-post' ); ?></th>
							<th><?php esc_html_e( 'Inner Width', 'woocommerce-shipping-new-zealand-post' ); ?></th>
							<th><?php esc_html_e( 'Inner Height', 'woocommerce-shipping-new-zealand-post' ); ?></th>
							<th><?php esc_html_e( 'Box Weight', 'woocommerce-shipping-new-zealand-post' ); ?></th>
							<th><?php esc_html_e( 'Max Weight', 'woocommerce-shipping-new-zealand-post' ); ?></th>
						</tr>
					</thead>
					<tfoot>
						<tr>
							<th colspan="3">
								<a href="#" class="button plus insert"><?php esc_html_e( 'Add Box', 'woocommerce-shipping-new-zealand-post' ); ?></a>
								<a href="#" class="button minus remove"><?php esc_html_e( 'Remove selected box(es)', 'woocommerce-shipping-new-zealand-post' ); ?></a>
							</th>
							<th colspan="7">
								<small class="description"><?php esc_html_e( 'Items will be packed into these boxes depending based on item dimensions and volume. Outer dimensions will be passed to NZ Post, whereas inner dimensions will be used for packing. Items not fitting into boxes will be packed individually.', 'woocommerce-shipping-new-zealand-post' ); ?></small>
							</th>
						</tr>
					</tfoot>
					<tbody id="rates">
						<?php
						if ( $this->boxes ) {
							foreach ( $this->boxes as $key => $box ) {
								?>
									<tr>
										<td class="check-column"><input type="checkbox" /></td>
										<td><input type="text" size="10" name="boxes_name[<?php echo esc_html_e( $key, 'woocommerce-shipping-new-zealand-post' ); ?>]" value="<?php echo isset( $box['name'] ) ? esc_attr( $box['name'] ) : ''; ?>" /></td>
										<td><input type="text" size="5" name="boxes_outer_length[<?php echo esc_html_e( $key, 'woocommerce-shipping-new-zealand-post' ); ?>]" value="<?php echo esc_attr( $box['outer_length'] ); ?>" />mm</td>
										<td><input type="text" size="5" name="boxes_outer_width[<?php echo esc_html_e( $key, 'woocommerce-shipping-new-zealand-post' ); ?>]" value="<?php echo esc_attr( $box['outer_width'] ); ?>" />mm</td>
										<td><input type="text" size="5" name="boxes_outer_height[<?php echo esc_html_e( $key, 'woocommerce-shipping-new-zealand-post' ); ?>]" value="<?php echo esc_attr( $box['outer_height'] ); ?>" />mm</td>
										<td><input type="text" size="5" name="boxes_inner_length[<?php echo esc_html_e( $key, 'woocommerce-shipping-new-zealand-post' ); ?>]" value="<?php echo esc_attr( $box['inner_length'] ); ?>" />mm</td>
										<td><input type="text" size="5" name="boxes_inner_width[<?php echo esc_html_e( $key, 'woocommerce-shipping-new-zealand-post' ); ?>]" value="<?php echo esc_attr( $box['inner_width'] ); ?>" />mm</td>
										<td><input type="text" size="5" name="boxes_inner_height[<?php echo esc_html_e( $key, 'woocommerce-shipping-new-zealand-post' ); ?>]" value="<?php echo esc_attr( $box['inner_height'] ); ?>" />mm</td>
										<td><input type="text" size="5" name="boxes_box_weight[<?php echo esc_html_e( $key, 'woocommerce-shipping-new-zealand-post' ); ?>]" value="<?php echo esc_attr( $box['box_weight'] ); ?>" />g</td>
										<td><input type="text" size="5" name="boxes_max_weight[<?php echo esc_html_e( $key, 'woocommerce-shipping-new-zealand-post' ); ?>]" value="<?php echo esc_attr( $box['max_weight'] ); ?>" placeholder="20" />g</td>
									</tr>
									<?php
							}
						}
						?>
					</tbody>
				</table>
				<script type="text/javascript">

					jQuery(window).load(function(){

						jQuery('#woocommerce_new_zealand_post_packing_method').change(function(){

							if ( jQuery(this).val() == 'box_packing' )
								jQuery('#packing_options').show();
							else
								jQuery('#packing_options').hide();

							if ( jQuery(this).val() == 'weight' )
								jQuery('#woocommerce_new_zealand_post_max_weight').closest('tr').show();
							else
								jQuery('#woocommerce_new_zealand_post_max_weight').closest('tr').hide();

						}).change();

						jQuery('.new_zealand_post_boxes .insert').click( function() {
							var $tbody = jQuery('.new_zealand_post_boxes').find('tbody');
							var size = $tbody.find('tr').size();
							var code = '<tr class="new">\
									<td class="check-column"><input type="checkbox" /></td>\
									<td><input type="text" size="10" name="boxes_name[' + size + ']" /></td>\
									<td><input type="text" size="5" name="boxes_outer_length[' + size + ']" />mm</td>\
									<td><input type="text" size="5" name="boxes_outer_width[' + size + ']" />mm</td>\
									<td><input type="text" size="5" name="boxes_outer_height[' + size + ']" />mm</td>\
									<td><input type="text" size="5" name="boxes_inner_length[' + size + ']" />mm</td>\
									<td><input type="text" size="5" name="boxes_inner_width[' + size + ']" />mm</td>\
									<td><input type="text" size="5" name="boxes_inner_height[' + size + ']" />mm</td>\
									<td><input type="text" size="5" name="boxes_box_weight[' + size + ']" />g</td>\
									<td><input type="text" size="5" name="boxes_max_weight[' + size + ']" placeholder="20" />g</td>\
								</tr>';

							$tbody.append( code );

							return false;
						} );

						jQuery('.new_zealand_post_boxes .remove').click(function() {
							var $tbody = jQuery('.new_zealand_post_boxes').find('tbody');

							$tbody.find('.check-column input:checked').each(function() {
								jQuery(this).closest('tr').hide().find('input').val('');
							});

							return false;
						});

						// Ordering
						jQuery('.new_zealand_post_services tbody').sortable({
							items:'tr',
							cursor:'move',
							axis:'y',
							handle: '.sort',
							scrollSensitivity:40,
							forcePlaceholderSize: true,
							helper: 'clone',
							opacity: 0.65,
							placeholder: 'wc-metabox-sortable-placeholder',
							start:function(event,ui){
								ui.item.css('background-color','#f6f6f6');
							},
							stop:function(event,ui){
								ui.item.removeAttr('style');
								new_zealand_post_services_row_indexes();
							}
						});

						function new_zealand_post_services_row_indexes() {
							jQuery('.new_zealand_post_services tbody tr').each(function(index, el){
								jQuery('input.order', el).val( parseInt( jQuery(el).index('.new_zealand_post_services tr') ) );
							});
						};

					});

				</script>
			</td>
		</tr>
		<?php
		return ob_get_clean();
	}

	/**
	 * Validate_box_packing_field function.
	 *
	 * @param mixed $key
	 * @return void
	 */
	public function validate_box_packing_field( $key ) {
		if ( wp_verify_nonce( 'test', 'wc_none' ) ) {
				return true;
		}
		if ( ! isset( $_POST['boxes_outer_length'] ) ) {
			return;
		}

		$boxes_name         = isset( $_POST['boxes_name'] ) ? array_map( 'sanitize_text_field', $_POST['boxes_name'] ) : array();
		$boxes_outer_length = isset( $_POST['boxes_outer_length'] ) ? array_map( 'sanitize_text_field', $_POST['boxes_outer_length'] ) : array();
		$boxes_outer_width  = isset( $_POST['boxes_outer_width'] ) ? array_map( 'sanitize_text_field', $_POST['boxes_outer_width'] ) : array();
		$boxes_outer_height = isset( $_POST['boxes_outer_height'] ) ? array_map( 'sanitize_text_field', $_POST['boxes_outer_height'] ) : array();
		$boxes_inner_length = isset( $_POST['boxes_inner_length'] ) ? array_map( 'sanitize_text_field', $_POST['boxes_inner_length'] ) : array();
		$boxes_inner_width  = isset( $_POST['boxes_inner_width'] ) ? array_map( 'sanitize_text_field', $_POST['boxes_inner_width'] ) : array();
		$boxes_inner_height = isset( $_POST['boxes_inner_height'] ) ? array_map( 'sanitize_text_field', $_POST['boxes_inner_height'] ) : array();
		$boxes_box_weight   = isset( $_POST['boxes_box_weight'] ) ? array_map( 'sanitize_text_field', $_POST['boxes_box_weight'] ) : array();
		$boxes_max_weight   = isset( $_POST['boxes_max_weight'] ) ? array_map( 'sanitize_text_field', $_POST['boxes_max_weight'] ) : array();

		$boxes = array();

		for ( $i = 0; $i < count( $boxes_outer_length ); $i ++ ) {

			if ( $boxes_outer_length[ $i ] && $boxes_outer_width[ $i ] && $boxes_outer_height[ $i ] ) {

				$outer_dimensions = array_map( 'floatval', array( $boxes_outer_length[ $i ], $boxes_outer_height[ $i ], $boxes_outer_width[ $i ] ) );
				$inner_dimensions = array_map( 'floatval', array( $boxes_inner_length[ $i ], $boxes_inner_height[ $i ], $boxes_inner_width[ $i ] ) );

				sort( $outer_dimensions );
				sort( $inner_dimensions );

				$outer_length = $outer_dimensions[2];
				$outer_height = $outer_dimensions[0];
				$outer_width  = $outer_dimensions[1];

				$inner_length = $inner_dimensions[2];
				$inner_height = $inner_dimensions[0];
				$inner_width  = $inner_dimensions[1];

				if ( empty( $inner_length ) || $inner_length > $outer_length ) {
					$inner_length = $outer_length;
				}

				if ( empty( $inner_height ) || $inner_height > $outer_height ) {
					$inner_height = $outer_height;
				}

				if ( empty( $inner_width ) || $inner_width > $outer_width ) {
					$inner_width = $outer_width;
				}

				$weight = floatval( $boxes_max_weight[ $i ] );

				$boxes[] = array(
					'name'         => wc_clean( $boxes_name[ $i ] ),
					'outer_length' => $outer_length,
					'outer_width'  => $outer_width,
					'outer_height' => $outer_height,
					'inner_length' => $inner_length,
					'inner_width'  => $inner_width,
					'inner_height' => $inner_height,
					'box_weight'   => floatval( $boxes_box_weight[ $i ] ),
					'max_weight'   => $weight,
				);
			}
		}

		return $boxes;
	}

	/**
	 * Validate_services_field function.
	 *
	 * @param mixed $key
	 * @return void
	 */
	public function validate_services_field( $key ) {
		if ( wp_verify_nonce( 'test', 'wc_none' ) ) {
				return true;
		}
		$services         = array();
		$posted_services  = isset( $_POST['new_zealand_post_service'] ) ? map_deep( $_POST['new_zealand_post_service'], 'sanitize_text_field' ) : '';

		foreach ( $posted_services as $code => $settings ) {

			$services[ $code ] = array(
				'name'                  => wc_clean( $settings['name'] ),
				'order'                 => wc_clean( $settings['order'] ),
				'enabled'               => isset( $settings['enabled'] ) ? true : false,
				'adjustment'            => wc_clean( $settings['adjustment'] ),
				'adjustment_percent'    => str_replace( '%', '', wc_clean( $settings['adjustment_percent'] ) ),
			);

		}

		return $services;
	}

	/**
	 * Clear_transients function.
	 *
	 * @return void
	 */
	public function clear_transients() {
		delete_transient( 'wc_nz_post_quotes' );
	}

	/**
	 * Init_form_fields function.
	 *
	 * @return void
	 */
	public function init_form_fields() {
		$this->instance_form_fields = array(
			'title'            => array(
				'title'           => __( 'Method Title', 'woocommerce-shipping-new-zealand-post' ),
				'type'            => 'text',
				'description'     => __( 'This controls the title which the user sees during checkout.', 'woocommerce-shipping-new-zealand-post' ),
				'default'         => __( 'New Zealand Post', 'woocommerce-shipping-new-zealand-post' ),
			),
			'origin'           => array(
				'title'           => __( 'Origin Postcode', 'woocommerce-shipping-new-zealand-post' ),
				'type'            => 'text',
				'description'     => __( 'Enter the postcode for the <strong>sender</strong>.', 'woocommerce-shipping-new-zealand-post' ),
				'default'         => '',
			),
			'rates'           => array(
				'title'           => __( 'Rates and Services', 'woocommerce-shipping-new-zealand-post' ),
				'type'            => 'title',
				'description'     => __( 'The following settings determine the rates you offer your customers.', 'woocommerce-shipping-new-zealand-post' ),
			),
			'gst_on_shipping_price'  => array(
				'title'           => __( 'GST on Shipping Prices', 'woocommerce-shipping-new-zealand-post' ),
				'type'            => 'select',
				'default'         => 'price_excluding_gst',
				'class'           => 'gst_on_shipping_price',
				'options'         => array(
					'price_excluding_gst'    => __( 'Add shipping prices excluding GST', 'woocommerce-shipping-new-zealand-post' ),
					'price_including_gst'       => __( 'Add shipping prices including GST', 'woocommerce-shipping-new-zealand-post' ),
				),
			),
			'packing_method'  => array(
				'title'           => __( 'Parcel Packing Method', 'woocommerce-shipping-new-zealand-post' ),
				'type'            => 'select',
				'default'         => '',
				'class'           => 'packing_method',
				'options'         => array(
					'per_item'       => __( 'Default: Pack items individually', 'woocommerce-shipping-new-zealand-post' ),
					'box_packing'    => __( 'Recommended: Pack into boxes with weights and dimensions', 'woocommerce-shipping-new-zealand-post' ),
				),
			),
			'boxes'  => array(
				'type'            => 'box_packing',
			),
			'offer_rates'   => array(
				'title'           => __( 'Offer Rates', 'woocommerce-shipping-new-zealand-post' ),
				'type'            => 'select',
				'description'     => '',
				'default'         => 'all',
				'options'         => array(
					'all'         => __( 'Offer the customer all returned rates', 'woocommerce-shipping-new-zealand-post' ),
					'cheapest'    => __( 'Offer the customer the cheapest rate only, anonymously', 'woocommerce-shipping-new-zealand-post' ),
				),
			),
			'services'  => array(
				'type'            => 'services',
			),
			'postage_type' => array(
				'title'           => __( 'Postage Type', 'woocommerce-shipping-new-zealand-post' ),
				'type'            => 'select',
				'default'         => 'postage_only',
				'options'         => array(
					'postage_only'     => __( 'Returns rate without packaging fee', 'woocommerce-shipping-new-zealand-post' ),
					'postage_included' => __( 'Returns rate with packaging fee', 'woocommerce-shipping-new-zealand-post' ),
					''                 => __( 'Any', 'woocommerce-shipping-new-zealand-post' ),
				),
			),
		);

		$this->form_fields = array(
			'api'           => array(
				'title'           => __( 'API Settings', 'woocommerce-shipping-new-zealand-post' ),
				'type'            => 'title',
				'description'     => __( 'Your API access details are obtained from the NZ Post website after signing up.', 'woocommerce-shipping-new-zealand-post' ),
			),
			'nz_post_api_type'           => array(
				'title'           => __( 'NZ Post API Type', 'woocommerce-shipping-new-zealand-post' ),
				'type'            => 'select',
				'options'            => array(
					'rate_finder' => 'RateFinder API',
					'shipping_option' => 'ShippingOption API',
				),
				'placeholder'     => '',
			),
			'client_id'           => array(
				'title'           => __( 'Client ID', 'woocommerce-shipping-new-zealand-post' ),
				'type'            => 'text',
				'default'         => '',
				'placeholder'     => '',
				'class'         => 'shipping_options_api_input',

			),
			'client_secret'           => array(
				'title'           => __( 'Client Secret', 'woocommerce-shipping-new-zealand-post' ),
				'type'            => 'text',
				'default'         => '',
				'placeholder'     => '',
				'class'         => 'shipping_options_api_input',

			),
			'api_key'           => array(
				'title'           => __( 'Api Key', 'woocommerce-shipping-new-zealand-post' ),
				'type'            => 'text',
				'default'         => '',
				'placeholder'     => '',
				'class'         => 'rate_finder_api_input',
			),
			'user_name'           => array(
				'title'           => __( 'Username', 'woocommerce-shipping-new-zealand-post' ),
				'type'            => 'text',
				'default'         => '',
				'placeholder'     => '',
				'class'         => 'shipping_options_api_input',

			),
			'nz_post_account_number'           => array(
				'title'           => __( 'NZ Post Account Number', 'woocommerce-shipping-new-zealand-post' ),
				'type'            => 'number',
				'default'         => '',
				'placeholder'     => '',
				'class'         => 'shipping_options_api_input',

			),
			'debug_mode'  => array(
				'title'           => __( 'Debug Mode', 'woocommerce-shipping-new-zealand-post' ),
				'label'           => __( 'Enable debug mode', 'woocommerce-shipping-new-zealand-post' ),
				'type'            => 'checkbox',
				'default'         => 'yes',
				'description'     => __( 'Enable debug mode to show debugging information on your cart/checkout.', 'woocommerce-shipping-new-zealand-post' ),
			),
			'domestic_shipping_surchage'           => array(
				'title'           => __( 'Domestic shipping surchage', 'woocommerce-shipping-new-zealand-post' ),
				'type'            => 'text',
				'default'         => '',
				'placeholder'     => '',
				'class'         => 'price_tag',
			),
			'international_shipping_surchage'           => array(
				'title'           => __( 'International shipping surchage', 'woocommerce-shipping-new-zealand-post' ),
				'type'            => 'text',
				'default'         => '',
				'placeholder'     => '',
				'class'         => 'price_tag',
			),
			/*
			 'state_region'  => array(
				'title'           => __( 'Disable State\Region search in calculate shipping form', 'woocommerce-shipping-new-zealand-post' ),
				'label'           => __( 'Disable State\Region', 'woocommerce-shipping-new-zealand-post' ),
				'type'            => 'checkbox',
				'default'         => 'no',
				'description'     => __( 'By default checkbox is unchecked', 'woocommerce-shipping-new-zealand-post' )
			), */
		);
	}

	/**
	 * Is the postcode rural?
	 * NZ Post recommended this logic to determine if an address is rural.
	 *
	 * @return boolean
	 */
	public function is_rural( $postcode ) {
		$rural  = false;
		$first  = substr( $postcode, 0, 1 );
		$second = substr( $postcode, 1, 1 );
		$third  = substr( $postcode, 2, 1 );

		if ( in_array( $first, array( 1, 6, 8 ) ) ) {
			if ( 9 === $second && in_array( $third, array( 7, 8, 9 ) ) ) {
				$rural = true;
			}
		} else {
			if ( in_array( $third, array( 7, 8, 9 ) ) ) {
				$rural = true;
			}
		}

		return $rural;
	}


	/**
	 * Calculate shipping cost.
	 *
	 * @since 1.0.0
	 * @version 1.3.3
	 *
	 * @param array $package Pakcage to ship.
	 * @return void
	 */
	public function calculate_shipping( $package = array() ) {
		// $this->debug('calculate_shipping');
		global $woocommerce;
		if ( $this->default_api_type == $this->get_option( 'nz_post_api_type' ) ) {
			$this->shipping_calculate_with_rate_finder( $package );

		} else {
			$this->shipping_calculate_with_shipping_option( $package );
		}

		if ( 'NZ' === $package['destination']['country'] ) {
			$price = $this->domestic_shipping_surchage;
			if ( $price > 0 ) {
				$woocommerce->cart->add_fee( __( 'Domestic shipping surchage', 'woocommerce' ), $price );
			}
		} else {
			$price = $this->international_shipping_surchage;
			if ( $price > 0 ) {
				$woocommerce->cart->add_fee( __( 'International shipping surchage', 'woocommerce' ), $price );
			}
		}

	}

	/**
	 * Prepare_rate function.
	 *
	 * @param mixed $rate_code
	 * @param mixed $rate_id
	 * @param mixed $rate_name
	 * @param mixed $rate_cost
	 * @return void
	 */
	private function prepare_rate( $rate_code, $rate_id, $rate_name, $rate_cost, $package_request = '' ) {
		// Name adjustment
		if ( ! empty( $this->custom_services[ $rate_code ]['name'] ) ) {
			$rate_name = $this->custom_services[ $rate_code ]['name'];
		}

		// Cost adjustment %
		if ( ! empty( $this->custom_services[ $rate_code ]['adjustment_percent'] ) ) {
			$rate_cost = $rate_cost + ( $rate_cost * ( floatval( $this->custom_services[ $rate_code ]['adjustment_percent'] ) / 100 ) );
		}

		// Cost adjustment
		if ( ! empty( $this->custom_services[ $rate_code ]['adjustment'] ) ) {
			$rate_cost = $rate_cost + floatval( $this->custom_services[ $rate_code ]['adjustment'] );
		}

		// Enabled check
		if ( isset( $this->custom_services[ $rate_code ] ) && empty( $this->custom_services[ $rate_code ]['enabled'] ) ) {
			return;
		}

		// Merging
		if ( isset( $this->found_rates[ $rate_id ] ) ) {
			$rate_cost = $rate_cost + $this->found_rates[ $rate_id ]['cost'];
			$packages  = 1 + $this->found_rates[ $rate_id ]['packages'];
		} else {
			$packages = 1;
		}

		// Sort
		if ( isset( $this->custom_services[ $rate_code ]['order'] ) ) {
			$sort = $this->custom_services[ $rate_code ]['order'];
		} else {
			$sort = 999;
		}
		$this->found_rates[ $rate_id ] = array(
			'id'       => $rate_id,
			'label'    => $rate_name,
			'cost'     => $rate_cost,
			'sort'     => $sort,
			'packages' => $packages,
		);

		// $this->debug( 'found_rates: <pre>' . print_r( $this->found_rates, true ) . '</pre>' );
	}

	/**
	 * Get_response function.
	 *
	 * @param mixed $endpoint
	 * @param mixed $request
	 * @return void
	 */
	private function get_response( $endpoint, $request ) {
		$tokenHeader = '';
		$tokenType = '';
		$tokenValue = $this->generate_token_nzpost();

		$request = trim( $request );

		$tokenArr = json_decode( $tokenValue );

		$this->debug( 'Auth Token Response: <pre> ' . print_r( $tokenArr, true ) . '</pre>' );
		// if(!empty($tokenArr) && !array_key_exists('error',$tokenArr)){
			$tokenHeader = $tokenArr->access_token;
			$tokenType = $tokenArr->token_type;
		// }

		$this->debug( 'Auth Token Value: <pre> ' . print_r( $tokenHeader, true ) . '</pre>' );
		 // $request = 'weight=10&height=10&length=10&width=10&value=45&format=json&pickup_postcode=90035&pickup_city=Los+Angeles&country_code=US';
		// $fp = fopen("000AAA_get_request.txt", "a");
		// fwrite( $fp, PHP_EOL . PHP_EOL . 'Endpoint: ==>'.print_r($endpoint,1).'<=='. PHP_EOL .'Request: ==>'.print_r($request,1).'<==' );
		// $this->debug( 'REQUEST Aray: <pre>' . print_r( $request, true ) . '</pre>' );
		$response = wp_remote_get(
			$endpoint . '?' . $request,
			array(
				'timeout'           => 70,
				'sslverify'         => 0,
				'headers'   => array(
					'Authorization' => $tokenType . ' ' . $tokenHeader,
					'user_name'     => $this->user_name,
					'client_id'     => $this->consumer_key,
				),

			)
		);
		$this->debug( 'My endpoint: <pre> ' . print_r( $endpoint, true ) . '</pre>' );
		// fwrite( $fp, PHP_EOL . 'Response: ==>'.print_r($response['body'],1).'<==' );
		// fclose($fp);

		$response = json_decode( $response['body'] );

		// Store result in case the request is made again
		$this->rate_cache[ md5( $request ) ] = $response;

		$this->debug( 'NZ Post REQUEST: <pre>' . print_r( htmlspecialchars( $request ), true ) . '</pre>' );
		$this->debug( 'NZ Post RESPONSE: <pre>' . print_r( $response, true ) . '</pre>' );

		return $response;
	}

	/**
	 * Sort_rates function.
	 *
	 * @param mixed $a
	 * @param mixed $b
	 * @return void
	 */
	public function sort_rates( $a, $b ) {
		if ( $a['sort'] == $b['sort'] ) {
			return 0;
		}
		return ( $a['sort'] < $b['sort'] ) ? -1 : 1;
	}

	/**
	 * Get_request function.
	 *
	 * @param mixed $package
	 * @return void
	 */
	private function get_request( $package ) {
		$endpoint = 'https://api.nzpost.co.nz/parceladdress/2.0/domestic/addresses/';
		$countries_obj = new WC_Countries();
		$countries_array = $countries_obj->get_countries();
		$country_states_array = $countries_obj->get_states();
		$address = $package['destination']['address'] . ' ' . $package['destination']['address_2'];
		$city = $package['destination']['city'];
		$state = $package['destination']['state'];
		$country = $package['destination']['country'];
		$postcode = $package['destination']['postcode'];

		/*
		 $fp = fopen("000AAA_package.txt", "a");
		fwrite( $fp, PHP_EOL . PHP_EOL .'START ===========>'. PHP_EOL .print_r($package,1) );
		fclose($fp); */

		// Get the country name:
		$country_name = $countries_array[ $country ];

		// Get the state name:
		// $state_name = @ $country_states_array[$country][$state];

		/*
		 $ignoreRegion = $this->get_option( 'state_region', '' );
		if ( !empty($ignoreRegion) && ( $ignoreRegion === 'yes' || $ignoreRegion == '1' ) ) {
			$request = 'q='.trim($address).' ' .trim($city) .' '. trim($postcode).'&count=5';
		} else {
			$request = 'q='.trim($address).' ' .trim($city) .', ' .trim($state_name).' '. trim($postcode).'&count=5';
		} */

		$request = 'q=' . trim( $address ) . ' ' . trim( $city ) . ' ' . trim( $postcode ) . '&count=5';
		$this->debug( 'Address query: <pre>' . print_r( $request, true ) . '</pre>' );
		$response = $this->get_response( $endpoint, $request );

		if ( isset( $response->addresses[0] ) ) {
			$dpid = @ $response->addresses[0]->dpid;
		} else {
			$dpid = '';
		}

		// Prepare the request for the next NZ Post API call:

		$store_address_2   = trim( get_option( 'woocommerce_store_address_2' ) );
		$store_city        = trim( get_option( 'woocommerce_store_city' ) );
		if ( ! empty( $this->origin ) ) {
			$store_postcode    = str_replace( ' ', '', strtoupper( $this->origin ) );
		} else {
			$store_postcode    = trim( get_option( 'woocommerce_store_postcode' ) );
		}
		$request = array(
			'format'          => 'json',
		);

		if ( 'NZ' === $package['destination']['country'] ) {
			if ( ! empty( $store_address_2 ) ) {
				$request['pickup_suburb']  = $store_address_2;
			} else {
				$request['pickup_city']  = $store_city;
			}
			$request['pickup_postcode'] = $store_postcode;
		}

		switch ( $package['destination']['country'] ) {
			case 'NZ':
				// $request['delivery_dpid']  = str_replace( ' ', '', strtoupper( $package['destination']['postcode'] ) );
				$request['delivery_dpid']  = $dpid;
				break;
			default:
				$request['country_code'] = $package['destination']['country'];
				break;
		}

		return $request;
	}

	/**
	 * Get_request function.
	 *
	 * @return void
	 */
	private function get_package_requests( $package ) {

		$requests = array();

		// Choose selected packing
		switch ( $this->packing_method ) {
			case 'box_packing':
				$requests = $this->box_shipping( $package );
				break;
			case 'per_item':
			default:
				$requests = $this->per_item_shipping( $package );
				break;
		}

		return $requests;
	}

	/**
	 * Per_item_shipping function.
	 *
	 * @param mixed $package
	 * @return void
	 */
	private function per_item_shipping( $package ) {
		$requests = array();

		// Get weight of order
		foreach ( $package['contents'] as $item_id => $values ) {

			if ( ! $values['data']->needs_shipping() ) {
				/* translators: #%d: item id */
				$this->debug( sprintf( __( 'Product #%d is virtual. Skipping.', 'woocommerce-shipping-new-zealand-post' ), $item_id ) );
				continue;
			}

			if ( ! $values['data']->get_weight() || ! $values['data']->get_length() || ! $values['data']->get_height() || ! $values['data']->get_width() ) {
				/* translators: #%d: item id */
				$this->debug( sprintf( __( 'Product #%d is missing weight/dimensions. Aborting.', 'woocommerce-shipping-new-zealand-post' ), $item_id ), 'error' );
				return;
			}

			$dimensions = array( $values['data']->get_length(), $values['data']->get_height(), $values['data']->get_width() );
			sort( $dimensions );

			$parcel                          = array();

			if ( 'NZ' === $package['destination']['country'] ) {
				$this->debug( 'NZ' );
				if ( $this->default_api_type == $this->get_option( 'nz_post_api_type' ) ) {
					$weight = $this->convert_weight( $values['data']->get_weight(), 'g' );
					$height = $this->convert_dimension( $values['data']->get_height(), 'mm' );
					$length = $this->convert_dimension( $values['data']->get_length(), 'mm' );
					$width  = $this->convert_dimension( $values['data']->get_width(), 'mm' );

					$parcel['weight_in_grams']       = $weight;
					$parcel['height_in_millimetres'] = $height;
					$parcel['width_in_millimetres']  = $length;
					$parcel['length_in_millimetres'] = $width;

				} else {

					$weight = $this->convert_weight( $values['data']->get_weight() );
					$height = $this->convert_dimension( $values['data']->get_height(), 'cm' );
					$length = $this->convert_dimension( $values['data']->get_length(), 'cm' );
					$width  = $this->convert_dimension( $values['data']->get_width(), 'cm' );

					$parcel['weight'] = $weight;
					$parcel['height'] = ( round( $height ) <= 0 ) ? 1 : round( $height );
					$parcel['width'] = ( round( $width ) <= 0 ) ? 1 : round( $width );
					$parcel['length'] = ( round( $length ) <= 0 ) ? 1 : round( $length );
				}
				// $this->debug( 'dimensions <pre>' . print_r( $parcel, true ) . '</pre>' );

				$parcel['postage_type']  = $this->postage_type;
				$parcel['envelope_size'] = 'ALL';

			} else {

				$weight = $this->convert_weight( $values['data']->get_weight() );
				$height = $this->convert_dimension( $values['data']->get_height(), 'mm' );
				$length = $this->convert_dimension( $values['data']->get_length(), 'mm' );
				$width  = $this->convert_dimension( $values['data']->get_width(), 'mm' );

				$parcel['weight'] = $weight;
				$parcel['height'] = $height;
				$parcel['width'] = $width;
				$parcel['length'] = $length;
				$parcel['thickness'] = $length;
			}

			$parcel['value']                 = $values['data']->get_price();

			for ( $i = 0; $i < $values['quantity']; $i ++ ) {
				$requests[] = $parcel;
			}
		}

		return $requests;
	}

	/**
	 * Box_shipping function.
	 *
	 * @param mixed $package
	 * @return void
	 */
	private function box_shipping( $package ) {
		$requests = array();

		if ( ! class_exists( 'WC_Boxpack' ) ) {
			include_once 'box-packer/class-wc-boxpack.php';
		}

		$boxpack = new WC_Boxpack();

		/*
		 $fp = fopen("000box_shipping--this--boxes.txt", "a");
		fwrite( $fp, PHP_EOL . PHP_EOL . '====>'. PHP_EOL .print_r($this->boxes,1));
		fclose($fp); */

		// Define boxes
		foreach ( $this->boxes as $key => $box ) {

			$newbox = $boxpack->add_box( $box['outer_length'], $box['outer_width'], $box['outer_height'], $box['box_weight'] );

			$newbox->set_id( $key );
			$newbox->set_inner_dimensions( $box['inner_length'], $box['inner_width'], $box['inner_height'] );

			if ( $box['max_weight'] ) {
				$newbox->set_max_weight( $box['max_weight'] );
			}
		}

		/*
		 $fp = fopen("000box_shipping--package[contents].txt", "a");
		fwrite( $fp, PHP_EOL . PHP_EOL . '====>'. PHP_EOL .print_r($package['contents'],1));
		fclose($fp); */

		// Add items
		foreach ( $package['contents'] as $item_id => $values ) {

			if ( ! $values['data']->needs_shipping() ) {
				$this->debug( sprintf( __( 'Product # is virtual. Skipping.', 'woocommerce-shipping-new-zealand-post' ), $item_id ) );
				continue;
			}

			if ( $values['data']->get_length() && $values['data']->get_height() && $values['data']->get_width() && $values['data']->get_weight() ) {

				$dimensions = array( $values['data']->get_length(), $values['data']->get_height(), $values['data']->get_width() );

				for ( $i = 0; $i < $values['quantity']; $i ++ ) {
					$boxpack->add_item(
						round( wc_get_dimension( $dimensions[2], 'mm' ) ),
						round( wc_get_dimension( $dimensions[1], 'mm' ) ),
						round( wc_get_dimension( $dimensions[0], 'mm' ) ),
						wc_get_weight( $values['data']->get_weight(), 'g' ),
						$values['data']->get_price()
					);
				}
			} else {
				wc_add_notice( sprintf( __( 'Product # is missing dimensions. Aborting.', 'woocommerce-shipping-new-zealand-post' ), $item_id ), 'error' );
				return;
			}
		}

		// Pack it
		$boxpack->pack();

		// Get packages
		$packed_packages = $boxpack->get_packages();

		/*
		 $fp = fopen("000box_shipping--packed_packages.txt", "a");
		fwrite( $fp, PHP_EOL . PHP_EOL . '====>'. PHP_EOL .print_r($packed_packages,1));
		fclose($fp); */

		foreach ( $packed_packages as $packed_package ) {

			$dimensions = array( $packed_package->length, $packed_package->width, $packed_package->height );

			sort( $dimensions );

			$parcel                          = array();
			if ( 'NZ' === $package['destination']['country'] ) {
				if ( $this->default_api_type == $this->get_option( 'nz_post_api_type' ) ) {
					$this->debug( 'domestic' );
					$weight = $this->convert_weight( $values['data']->get_weight(), 'g' );
					$height = $this->convert_dimension( $values['data']->get_height(), 'mm' );
					$length = $this->convert_dimension( $values['data']->get_length(), 'mm' );
					$width  = $this->convert_dimension( $values['data']->get_width(), 'mm' );

					$parcel['weight_in_grams']       = $weight;
					$parcel['height_in_millimetres'] = $height;
					$parcel['width_in_millimetres']  = $length;
					$parcel['length_in_millimetres'] = $width;

				} else {
					$this->debug( 'shippingoptions' );
					$weight = $this->convert_weight( $values['data']->get_weight() );
					$height = $this->convert_dimension( $values['data']->get_height(), 'cm' );
					$length = $this->convert_dimension( $values['data']->get_length(), 'cm' );
					$width  = $this->convert_dimension( $values['data']->get_width(), 'cm' );

					$parcel['weight'] = $weight;
					$parcel['height'] = ( round( $height ) <= 0 ) ? 1 : round( $height );
					$parcel['width'] = ( round( $width ) <= 0 ) ? 1 : round( $width );
					$parcel['length'] = ( round( $length ) <= 0 ) ? 1 : round( $length );
					$parcel['postage_type']          = $this->postage_type;
					$parcel['envelope_size'] = 'ALL';
				}
			} else {
				$weight = $this->convert_weight( $values['data']->get_weight() );
				$height = $this->convert_dimension( $values['data']->get_height(), 'mm' );
				$length = $this->convert_dimension( $values['data']->get_length(), 'mm' );
				$width  = $this->convert_dimension( $values['data']->get_width(), 'mm' );

				$parcel['weight'] = $weight;
				$parcel['height'] = $height;
				$parcel['width'] = $width;
				$parcel['thickness'] = $length;
				$parcel['length'] = $length;
			}
			$parcel['value'] = $packed_package->value;

			$requests[] = $parcel;
		}

		/*
		 $fp = fopen("000box_shipping--requestsWithParcelsFinal.txt", "a");
		fwrite( $fp, PHP_EOL . PHP_EOL . '====>'. PHP_EOL .print_r($requests,1));
		fclose($fp); */

		return $requests;
	}

	public function convert_weight( $weight, $convert_unit = '' ) {
		switch ( $convert_unit ) {
			case 'g':
				$weight = wc_get_weight( $weight, 'g', $this->unit_weight );
				break;
			case 'lbs':
				$weight = wc_get_weight( $weight, 'lbs', $this->unit_weight );
				break;
			case 'oz':
				$weight = wc_get_weight( $weight, 'oz', $this->unit_weight );
				break;
			default:
				$weight = wc_get_weight( $weight, $this->unit_weight );
		}
		return $weight;
	}

	public function convert_dimension( $dimension, $convert_unit = '' ) {
		switch ( $convert_unit ) {
			case 'm':
				$dimension = wc_get_dimension( $dimension, 'm', $this->unit_dimension );
				break;
			case 'mm':
				$dimension = wc_get_dimension( $dimension, 'mm', $this->unit_dimension );
				break;
			case 'in':
				$dimension = wc_get_dimension( $dimension, 'in', $this->unit_dimension );
				break;
			case 'yd':
				$dimension = wc_get_dimension( $dimension, 'yd', $this->unit_dimension );
				break;
			default:
				$dimension = wc_get_dimension( $dimension, $this->unit_dimension );
		}
		return $dimension;
	}

	public function shipping_calculate_with_shipping_option( $package = array() ) {
		$this->found_rates = array();
		$this->rate_cache  = get_transient( 'wc_nz_post_quotes' );
		$package_requests  = $this->get_package_requests( $package );
		$this->debug( 'Received package <pre>' . print_r( $package_requests, true ) . '</pre>' );
		$endpoint          = 'NZ' === $package['destination']['country'] ? $this->endpoints['domestic'] : $this->endpoints['international'];

		$this->debug( 'endpoints : ' . $endpoint );

		$this->debug( __( 'NZ Post debug mode is on - to hide these messages, turn debug mode off in the settings.', 'woocommerce-shipping-new-zealand-post' ) );

		if ( $package_requests ) {

			$whitelisted_addons = apply_filters( 'woocommerce_shipping_' . $this->id . '_whitelisted_addons', array( 'RURALD', 'SIGREQ' ) );

			// $fp = fopen("000AAA_get_request.txt", "a");
			// fwrite( $fp, PHP_EOL . PHP_EOL . 'Endpoint: ==>'.print_r($whitelisted_addons,1));
			// fclose($fp);
			// if (!empty($this->get_option( 'nz_post_account_number', '' )) && ( 'NZ' !== $package['destination']['country'] )) {
				// $package_requests[0]['account_number'] = $this->get_option( 'nz_post_account_number', '' );
			// }
			foreach ( $package_requests as $key => $package_request ) {

				$request  = http_build_query(
					/**
					 * Filter request parameters that get sent to NZ Post API.
					 *
					 * @since 1.3.3
					 * @version 1.3.3
					 *
					 * @param array  $request Request parameters.
					 * @param object $this    Instance of shipping method.
					 */
					apply_filters(
						'woocommerce_shipping_new_zealand_post_api_request',
						array_merge( $package_request, $this->get_request( $package ) ),
						$this
					),
					'',
					'&'
				);
				// $this->debug( 'get_request <pre>' . print_r( $package , true ) . '</pre>' );
				$this->debug( 'send_request <pre>' . print_r( $request, true ) . '</pre>' );
				// $request = "weight=0.01&height=0&width=10&length=10&envelope_size=ALLpickup_suburb=St+Heliers&pickup_postcode=0612&delivery_dpid=1396134";
				$response = $this->get_response( $endpoint, $request );

				// echo '<pre>'; print_r($response); echo '</pre>'; exit;
				if ( isset( $response->services ) && is_array( $response->services ) ) {
					// $this->debug( 'srvices <pre>' . print_r( $this->services , true ) . '</pre>' );
					// Loop our known services
					foreach ( $this->services as $code => $name ) {

						$rate_code    = $code;
						$rate_id      = $this->id . ':' . $rate_code;
						$rate_name    = $name . ' (' . __( 'NZ Post', 'woocommerce-shipping-new-zealand-post' ) . ') ';
						$product_cost = 0;
						$rate_cost    = null;

						if ( 'NZ' === $package['destination']['country'] ) {
							foreach ( $response->services as $product ) {
								/*
								 if ( isset( $product->price_excluding_gst ) ) {
									$product_cost = $product->price_excluding_gst;
								} */
								if ( 'price_including_gst' == $this->gst_on_shipping_price ) {
									if ( $product->service_code == $code && ( is_null( $rate_cost ) || $product->price_including_gst < $rate_cost ) ) {
										$rate_cost = $product_cost + $product->price_including_gst;

										if ( $product->addons ) {
											foreach ( $product->addons as $addon ) {
												if ( in_array( $addon->addon_code, $whitelisted_addons ) ) {
													if ( $addon->mandatory || $this->is_rural( $package['destination']['postcode'] ) ) {
														$rate_cost += $addon->price_including_gst;
													}
												}
											}
										}
									}
								} else {
									if ( $product->service_code == $code && ( is_null( $rate_cost ) || $product->price_excluding_gst < $rate_cost ) ) {
										$rate_cost = $product_cost + $product->price_excluding_gst;

										if ( $product->addons ) {
											foreach ( $product->addons as $addon ) {
												if ( in_array( $addon->addon_code, $whitelisted_addons ) ) {
													if ( $addon->mandatory || $this->is_rural( $package['destination']['postcode'] ) ) {
														$rate_cost += $addon->price_excluding_gst;
													}
												}
											}
										}
									}
								}
							}
						} else {
							// $this->debug( 'response->services <pre>' . print_r( $response->services , true ) . '</pre>' );
							foreach ( $response->services as $product ) {
								if ( 'price_including_gst' == $this->gst_on_shipping_price ) {
									if ( isset( $product->price_including_gst ) ) {
										$product_cost = $product->price_including_gst;
									}
									if ( $product->service_code == $code && ( $product->price_including_gst < $rate_cost || is_null( $rate_cost ) ) ) {
										if ( isset( $product->price ) ) {
												$rate_cost = $product_cost + $product->price;
										} else {
											$rate_cost = $product_cost;
										}
									}
								} else {
									if ( isset( $product->price_excluding_gst ) ) {
										$product_cost = $product->price_excluding_gst;
									}

									if ( $product->service_code == $code && ( $product->price_excluding_gst < $rate_cost || is_null( $rate_cost ) ) ) {
										if ( isset( $product->price ) ) {
												$rate_cost = $product_cost + $product->price;
										} else {
											$rate_cost = $product_cost;
										}
									}
								}
							}
						}

						if ( $rate_cost ) {
							$this->prepare_rate( $rate_code, $rate_id, $rate_name, $rate_cost, $package_request );
						}
					} // foreach ( $this->services as $code => $name )

				} // if ( isset( $response->services ) && is_array( $response->services ) )

			} // foreach ( $package_requests as $key => $package_request )

		} // if ( $package_requests )

		// Set transient
		// set_transient( 'wc_nz_post_quotes', $this->rate_cache, YEAR_IN_SECONDS );

		/*
		 $fp = fopen("000calculate_shipping--this--found_rates.txt", "a");
		fwrite( $fp, PHP_EOL . PHP_EOL . '====>'. PHP_EOL .print_r($this->found_rates,1));
		fclose($fp); */

		// Ensure rates were found for all packages
		if ( $this->found_rates ) {
			foreach ( $this->found_rates as $key => $value ) {
				if ( $value['packages'] < count( $package_requests ) ) {
					unset( $this->found_rates[ $key ] );
				}
			}
		}

		// Add rates
		if ( $this->found_rates ) {

			if ( 'all' === $this->offer_rates ) {

				uasort( $this->found_rates, array( $this, 'sort_rates' ) );

				foreach ( $this->found_rates as $key => $rate ) {
					$this->add_rate( $rate );
				}
			} else {

				$cheapest_rate = '';

				foreach ( $this->found_rates as $key => $rate ) {
					if ( ! $cheapest_rate || $cheapest_rate['cost'] > $rate['cost'] ) {
						$cheapest_rate = $rate;
					}
				}

				$cheapest_rate['label'] = $this->title;

				$this->add_rate( $cheapest_rate );
			}
		}
	}

	public function shipping_calculate_with_rate_finder( $package = array() ) {
		$this->debug( 'shipping_calculate_with_rate_finder' . $this->gst_on_shipping_price );

		$this->found_rates = array();
		$this->rate_cache  = get_transient( 'wc_nz_post_quotes' );
		$package_requests  = $this->get_package_requests( $package );
		$endpoint          = 'NZ' === $package['destination']['country'] ? $this->endpoints['domestic'] : $this->endpoints['international'];

		$this->debug( __( 'NZ Post debug mode is on - to hide these messages, turn debug mode off in the settings.', 'woocommerce-shipping-new-zealand-post' ) );

		if ( $package_requests ) {

			$whitelisted_addons = apply_filters( 'woocommerce_shipping_' . $this->id . '_whitelisted_addons', array( 'RURALD', 'SIGREQ' ) );

			foreach ( $package_requests as $key => $package_request ) {

				$request  = http_build_query(
					/**
					 * Filter request parameters that get sent to NZ Post API.
					 *
					 * @since 1.3.3
					 * @version 1.3.3
					 *
					 * @param array  $request Request parameters.
					 * @param object $this    Instance of shipping method.
					 */
					apply_filters(
						'woocommerce_shipping_new_zealand_post_api_request',
						array_merge( $package_request, $this->get_rate_finder_request( $package ) ),
						$this
					),
					'',
					'&'
				);

				$response = $this->get_rate_finder_response( $endpoint, $request );

				// $this->debug('responce products =>'.json_encode($response->products));
				if ( isset( $response->products ) && is_array( $response->products ) ) {

					// Loop our known services
					foreach ( $this->services as $code => $name ) {

						$rate_code    = $code;
						$rate_id      = $this->id . ':' . $rate_code;
						$rate_name    = $name . ' (' . __( 'NZ Post', 'woocommerce-shipping-new-zealand-post' ) . ')';
						$product_cost = 0;
						$rate_cost    = null;

						if ( 'NZ' === $package['destination']['country'] ) {
							foreach ( $response->products as $product ) {
								if ( 'price_including_gst' == $this->gst_on_shipping_price ) {
									if ( isset( $product->price_including_gst ) ) {
										$product_cost = $product->price_including_gst;
									}
									foreach ( $product->services as $service ) {
										if ( $service->service_type == $code && ( $service->price_including_gst < $rate_cost || is_null( $rate_cost ) ) ) {
											$rate_cost = $product_cost + $service->price_including_gst;

											if ( $service->addons ) {
												foreach ( $service->addons as $addon ) {
													if ( in_array( $addon->addon_type, $whitelisted_addons ) ) {
														if ( $addon->mandatory || $this->is_rural( $package['destination']['postcode'] ) ) {
															$rate_cost += $addon->price_including_gst;
														}
													}
												}
											}
										}
									}
								} else {
									if ( isset( $product->price_excluding_gst ) ) {
										$product_cost = $product->price_excluding_gst;
									}

									foreach ( $product->services as $key => $service ) {
										if ( $service->service_type == $code && ( $service->price_excluding_gst < $rate_cost || is_null( $rate_cost ) ) ) {
											$rate_cost = $product_cost + $service->price_excluding_gst;

											if ( $service->addons ) {
												foreach ( $service->addons as $addon ) {
													if ( in_array( $addon->addon_type, $whitelisted_addons ) ) {
														if ( $addon->mandatory || $this->is_rural( $package['destination']['postcode'] ) ) {
															// echo '<br/>' . $key . '<=>' .$rate_cost;
															$rate_cost += $addon->price_excluding_gst;
														}
													}
												}
											}
										}
									}
								}
							}
						} else {
							foreach ( $response->products as $service ) {
								if ( 'price_including_gst' == $this->gst_on_shipping_price ) {
									if ( isset( $product->price_including_gst ) ) {
										$product_cost = $product->price_including_gst;
									}

									if ( $service->service_code == $code && ( $service->price < $rate_cost || is_null( $rate_cost ) ) ) {
										// $rate_cost = $product_cost + $service->price;
										$rate_cost = $product_cost + $service->price_including_gst;
									}
								} else {
									if ( isset( $product->price_excluding_gst ) ) {
										$product_cost = $product->price_excluding_gst;
									}

									if ( $service->service_code == $code && ( $service->price < $rate_cost || is_null( $rate_cost ) ) ) {
										$rate_cost = $product_cost + $service->price;
									}
								}
							}
						}

						if ( $rate_cost ) {
							$this->prepare_rate( $rate_code, $rate_id, $rate_name, $rate_cost, $package_request );
						}
					}
				}
			}
		}

		// Set transient
		set_transient( 'wc_nz_post_quotes', $this->rate_cache, YEAR_IN_SECONDS );

		// Ensure rates were found for all packages
		if ( $this->found_rates ) {
			foreach ( $this->found_rates as $key => $value ) {
				if ( $value['packages'] < count( $package_requests ) ) {
					unset( $this->found_rates[ $key ] );
				}
			}
		}

		// Add rates
		if ( $this->found_rates ) {

			if ( 'all' === $this->offer_rates ) {

				uasort( $this->found_rates, array( $this, 'sort_rates' ) );

				foreach ( $this->found_rates as $key => $rate ) {
					$this->add_rate( $rate );
				}
			} else {

				$cheapest_rate = '';

				foreach ( $this->found_rates as $key => $rate ) {
					if ( ! $cheapest_rate || $cheapest_rate['cost'] > $rate['cost'] ) {
						$cheapest_rate = $rate;
					}
				}

				$cheapest_rate['label'] = $this->title;

				$this->add_rate( $cheapest_rate );
			}
		}
	}

	/**
	 * Get_rate_finder_request function.
	 *
	 * @param mixed $package
	 * @return void
	 */
	private function get_rate_finder_request( $package ) {

		$request = array(
			'api_key'         => $this->api_key,
			'format'          => 'json',
			'source_postcode' => str_replace( ' ', '', strtoupper( $this->origin ) ),
		);
		$this->debug( 'Source Postcode: <pre>' . print_r( $request, true ) . '</pre>' );

		switch ( $package['destination']['country'] ) {
			case 'NZ':
				$request['dest_postcode']  = str_replace( ' ', '', strtoupper( $package['destination']['postcode'] ) );
				break;
			default:
				$request['country_code'] = $package['destination']['country'];
				break;
		}

		return $request;
	}

	/**
	 * Get_rate_finder_response function.
	 *
	 * @param mixed $endpoint
	 * @param mixed $request
	 * @return void
	 */
	private function get_rate_finder_response( $endpoint, $request ) {
		if ( isset( $this->rate_cache[ md5( $request ) ] ) ) {

			$response = $this->rate_cache[ md5( $request ) ];

		} else {

			$response = wp_remote_get(
				$endpoint . '?' . $request,
				array(
					'timeout'          => 70,
					'sslverify'        => 0,
				)
			);

			$response = json_decode( $response['body'], true );

			// Store result in case the request is made again
			$this->rate_cache[ md5( $request ) ] = $response;
		}

		$this->debug( 'NZ Post REQUEST: <pre>' . print_r( htmlspecialchars( $request ), true ) . '</pre>' );
		$this->debug( 'NZ Post RESPONSE: <pre>' . print_r( $response, true ) . '</pre>' );

		return $response;
	}
}
