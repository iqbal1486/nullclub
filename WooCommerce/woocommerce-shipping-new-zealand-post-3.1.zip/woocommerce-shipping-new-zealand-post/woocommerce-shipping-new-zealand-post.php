<?php
/**
 * Plugin Name: WooCommerce New Zealand Post
 * Plugin URI: https://woocommerce.com/products/new-zealand-post/
 * Description: Obtain parcel shipping rates dynamically via the New Zealand Post API for your orders.
 * Version: 3.1
 * Author: WooCommerce
 * Author URI: https://woocommerce.com
 * WC tested up to: 6.1
 * WC requires at least: 2.6
 * Tested up to: 5.9
 *
 * Woo: 182743:abc0f4817f77ef47c666d6bbf1b6e7df
 *
 * Copyright: 2009-2017 WooCommerce.
 * License: GNU General Public License v3.0
 * License URI: http://www.gnu.org/licenses/gpl-3.0.html
 *
 * @package WC_Shipping_NZ_Post
 */

add_filter( 'woocommerce_cart_no_shipping_available_html', 'change_noship_message', 0 );
add_filter( 'woocommerce_no_shipping_available_html', 'change_noship_message', 0 );


function change_noship_message( $a = null ) {
	print "Address/Shipping not found - You can confirm your shipping address at <a href='https://www.nzpost.co.nz/tools/address-postcode-finder/' target='_blank'>NZ Post Address Locator</a> and then retry. If it is not available, please contact NZ Post to add your address to their database.";
}

/**
 * Required functions.
 */
if ( ! function_exists( 'woothemes_queue_update' ) ) {
	require_once( 'woo-includes/woo-functions.php' );
}

/**
 * Plugin updates
 */
woothemes_queue_update( plugin_basename( __FILE__ ), 'abc0f4817f77ef47c666d6bbf1b6e7df', '182743' );


/**
 *
 * Chack API settings and update if needed according current viersion.
 */
function check_api_settings() {

	delete_transient( 'wc_nz_post_quotes' );

	$settings = get_option( 'woocommerce_new_zealand_post_settings' );
	if ( isset( $settings['api_key'] ) && ! isset( $settings['client_id'] ) ) {
		$settings['nz_post_api_type'] = 'rate_finder';
		update_option( 'woocommerce_new_zealand_post_settings', $settings );
	} elseif ( isset( $settings['api_key'] ) && ! isset( $settings['client_id'] ) ) {
		$settings['nz_post_api_type'] = 'shipping_option';
		update_option( 'woocommerce_new_zealand_post_settings', $settings );
	}
}

	register_activation_hook( __FILE__, 'check_api_settings' );

define( 'WC_SHIPPING_NEW_ZEALAND_POST_INIT_VERSION', '3.0.0' );

class WC_Shipping_New_Zealand_Post_Init {
	/**
	 *
	 * Plugin's version.
	 *
	 * @since 1.3.0
	 *
	 * @var string
	 */
	public $version;

	/**
	 *
	 * Class Instance
	 *
	 * @var object
	 * */
	private static $instance;

	/**
	 *
	 * Get the class instance
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 *
	 * Initialize the plugin's public actions
	 */
	public function __construct() {
		$this->version = WC_SHIPPING_NEW_ZEALAND_POST_INIT_VERSION;

		if ( class_exists( 'WC_Shipping_Method' ) ) {
			add_action( 'admin_init', array( $this, 'maybe_install' ), 5 );
			add_action( 'init', array( $this, 'load_textdomain' ) );
			add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), array( $this, 'plugin_links' ) );
			add_action( 'woocommerce_shipping_init', array( $this, 'includes' ) );
			add_filter( 'woocommerce_shipping_methods', array( $this, 'add_method' ) );
			add_action( 'admin_notices', array( $this, 'environment_check' ) );
			add_action( 'admin_notices', array( $this, 'upgrade_notice' ) );
			add_action( 'wp_ajax_new_zealand_post_dismiss_upgrade_notice', array( $this, 'dismiss_upgrade_notice' ) );
			add_action( 'admin_enqueue_scripts', array( $this, 'nz_post_scripts' ) );

		} else {
			add_action( 'admin_notices', array( $this, 'wc_deactivated' ) );
		}
	}

	/**
	 *
	 * Environment_check function.
	 */
	public function environment_check() {
		if ( version_compare( WC_VERSION, '2.6.0', '<' ) ) {
			return;
		}

		$general_tab_link = admin_url(
			add_query_arg(
				array(
					'page'    => 'wc-settings',
					'tab'     => 'general',
				),
				'admin.php'
			)
		);

		if ( 'NZD' !== get_woocommerce_currency() ) {
			/* translators: %s: tab link */
			echo '<div class="error"><p>' . wp_kses( sprintf( __( 'New Zealand Post requires that the <a href="%s">currency</a> is set to NZ Dollars.', 'woocommerce-shipping-new-zealand-post' ), esc_url( $general_tab_link ) ), array( 'a' => array( 'href' => array() ) ) ) . '</p>
			</div>';
		}

		if ( 'NZ' !== WC()->countries->get_base_country() ) {
			/* translators: %s: tab link */
			echo '<div class="error"><p>' . wp_kses( sprintf( __( 'New Zealand Post requires that the <a href="%s">base country/region</a> is set to New Zealand.', 'woocommerce-shipping-new-zealand-post' ), esc_url( $general_tab_link ) ), array( 'a' => array( 'href' => array() ) ) ) . '</p>
			</div>';
		}
	}

	/**
	 *
	 * Woocommerce_init_shipping_table_rate function.
	 *
	 * @since 1.3.0
	 * @version 1.3.0
	 * @return void
	 */
	public function includes() {
		if ( version_compare( WC_VERSION, '2.6.0', '<' ) ) {
			include_once( dirname( __FILE__ ) . '/includes/class-wc-shipping-new-zealand-post-deprecated.php' );
		} else {
			include_once( dirname( __FILE__ ) . '/includes/class-wc-shipping-new-zealand-post.php' );
		}
		include_once( dirname( __FILE__ ) . '/includes/class-wc-shipping-new-zealand-post-privacy.php' );
	}

	/**
	 *
	 * Add New Zealand Post shipping method to WC
	 *
	 * @param mixed $methods
	 * @return void
	 */
	public function add_method( $methods ) {
		if ( version_compare( WC_VERSION, '2.6.0', '<' ) ) {
			$methods[] = 'WC_Shipping_New_Zealand_Post';
		} else {
			$methods['new_zealand_post'] = 'WC_Shipping_New_Zealand_Post';
		}

		return $methods;
	}

	/**
	 *
	 * Localisation
	 */
	public function load_textdomain() {
		load_plugin_textdomain( 'woocommerce-shipping-new-zealand-post', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );
	}

	/**
	 *
	 * Plugin page links
	 */
	public function plugin_links( $links ) {
		$plugin_links = array(
			'<a href="http://support.woothemes.com/">' . __( 'Support', 'woocommerce-shipping-new-zealand-post' ) . '</a>',
			'<a href="http://docs.woothemes.com/document/new-zealand-post-shipping/">' . __( 'Docs', 'woocommerce-shipping-new-zealand-post' ) . '</a>',
		);

		return array_merge( $plugin_links, $links );
	}

	/**
	 *
	 * WooCommerce not installed notice
	 */
	public function wc_deactivated() {
		/* translators: %s: link */
		echo '<div class="error"><p>' . sprintf( esc_html_e( 'WooCommerce New Zealand Post Shipping requires %s to be installed and active.', 'woocommerce-shipping-new-zealand-post' ), '<a href="https://woocommerce.com" target="_blank">WooCommerce</a>' ) . '</p></div>';
	}

	/**
	 *
	 * Checks the plugin version
	 *
	 * @since 1.3.0
	 * @version 1.3.0
	 * @return bool
	 */
	public function maybe_install() {
		// only need to do this for versions less than 1.3.0 to migrate
		// settings to shipping zone instance
		$doing_ajax = defined( 'DOING_AJAX' ) && DOING_AJAX;
		if ( ! $doing_ajax
			 && ! defined( 'IFRAME_REQUEST' )
			 && version_compare( WC_VERSION, '2.6.0', '>=' )
			 && version_compare( get_option( 'wc_new_zealand_post_version' ), '1.3.0', '<' ) ) {

			$this->install();

		}

		return true;
	}

	/**
	 *
	 * Update/migration script
	 *
	 * @since 1.3.0
	 * @version 1.3.0
	 *
	 * @return bool
	 */
	public function install() {
		// get all saved settings and cache it
		$new_zealand_post_settings = get_option( 'woocommerce_new_zealand_post_settings', false );

		// settings exists
		if ( $new_zealand_post_settings ) {
			global $wpdb;

			// unset un-needed settings
			unset( $new_zealand_post_settings['enabled'] );
			unset( $new_zealand_post_settings['availability'] );
			unset( $new_zealand_post_settings['countries'] );

			// first add it to the "rest of the world" zone when no New Zealand Post
			// instance.
			if ( ! $this->is_zone_has_new_zealand_post( 0 ) ) {
				$wpdb->query( $wpdb->prepare( "INSERT INTO {$wpdb->prefix}woocommerce_shipping_zone_methods ( zone_id, method_id, method_order, is_enabled ) VALUES ( %d, %s, %d, %d )", 0, 'new_zealand_post', 1, 1 ) );
				// add settings to the newly created instance to options table
				$instance = $wpdb->insert_id;
				add_option( 'woocommerce_new_zealand_post_' . $instance . '_settings', $new_zealand_post_settings );
			}
			update_option( 'woocommerce_new_zealand_post_show_upgrade_notice', 'yes' );
		}
		update_option( 'wc_new_zealand_post_version', $this->version );
	}

	/**
	 *
	 * Show the user a notice for plugin updates
	 *
	 * @since 1.3.0
	 */
	public function upgrade_notice() {
		$show_notice = get_option( 'woocommerce_new_zealand_post_show_upgrade_notice' );

		if ( 'yes' !== $show_notice ) {
			return;
		}

		$query_args = array(
			'page' => 'wc-settings',
			'tab' => 'shipping',
		);
		$zones_admin_url = add_query_arg( $query_args, get_admin_url() . 'admin.php' );
		?>
		<div class="notice notice-success is-dismissible wc-new-zealand-post-notice">

			<p>
			<?php
			/* translators: %1$shere%2$s: zone admin url */
			echo sprintf( esc_html_e( 'New Zealand Post now supports shipping zones. The zone settings were added to a new New Zealand Post method on the "Rest of the World" Zone. See the zones %1$shere%2$s ', 'woocommerce-shipping-new-zealand-post' ), '<a href="' . esc_html_e( $zones_admin_url ) . '">', '</a>' );
			?>
			</p>
		</div>

		<script type="application/javascript">
			jQuery( '.notice.wc-new-zealand-post-notice' ).on( 'click', '.notice-dismiss', function () {
				wp.ajax.post('new_zealand_post_dismiss_upgrade_notice');
			});
		</script>
		<?php
	}

	/**
	 *
	 * Turn of the dismisable upgrade notice.
	 *
	 * @since 1.3.0
	 */
	public function dismiss_upgrade_notice() {
		update_option( 'woocommerce_new_zealand_post_show_upgrade_notice', 'no' );
	}

	/**
	 *
	 * Helper method to check whether given zone_id has New Zealand Post method instance.
	 *
	 * @since 1.3.0
	 *
	 * @param int $zone_id Zone ID
	 *
	 * @return bool True if given zone_id has New Zealand Post method instance
	 */
	public function is_zone_has_new_zealand_post( $zone_id ) {
		global $wpdb;

		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(instance_id) FROM {$wpdb->prefix}woocommerce_shipping_zone_methods WHERE method_id = 'new_zealand_post' AND zone_id = %d", $zone_id ) ) > 0;
	}

	public function nz_post_scripts() {

		wp_enqueue_script( 'nz_post_script', plugin_dir_url( __FILE__ ) . 'assets/js/wc-shipping-nz-post.js', array( 'jquery' ), '1.0' );
	}
}

add_action( 'plugins_loaded', array( 'WC_Shipping_New_Zealand_Post_Init', 'get_instance' ), 0 );
