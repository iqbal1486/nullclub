<?php
$recipient_email    = "info@signvision.ch"; //recepient
$from_email         = "noreply@signvision.ch"; //from email using site domain.


if(!isset($_SERVER['HTTP_X_REQUESTED_WITH']) AND strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) != 'xmlhttprequest') {
    die('Sorry Request must be Ajax POST'); //exit script
}

if($_POST){
    
    $name    = filter_var($_POST["req_name"], FILTER_SANITIZE_STRING); //capture sender name
    $fname    = filter_var($_POST["req_fname"], FILTER_SANITIZE_STRING); //capture sender name
    $email   = filter_var($_POST["req_mail"], FILTER_SANITIZE_STRING); //capture sender email
    $street   = filter_var($_POST["req_street"], FILTER_SANITIZE_STRING);
    $city   = filter_var($_POST["req_city"], FILTER_SANITIZE_STRING);
    $phone        = filter_var($_POST["req_phone"], FILTER_SANITIZE_STRING);
    $message        = filter_var($_POST["req_msg"], FILTER_SANITIZE_STRING); //capture message
	
	
	$fenster_body = "";
	$attachments = [];
	if(isset($_POST["fenster"])){
		
		foreach($_POST["fenster"] as $uid => $fenster){
			
			
			
			    $fenster_body .=  "Fenster ID (fuer Bilder): " .$uid."\n";
			    $fenster_body .=  "Glas Breite CM: " .$fenster['glas_breite']."\n";
			    $fenster_body .=  "Glas Hoehe CM: " .$fenster['glas_hoehe']."\n";
			    $fenster_body .=  "Verglasung: " .$fenster['verglasung']."\n";
			    $fenster_body .=  "Ausrichtung: " .$fenster['ausrichtung']."\n";
			    $fenster_body .=  "Lage: " .$fenster['lage']."\n";
			    $fenster_body .=  "Wunsch: " .$fenster['wunsch']."\n";
			    $fenster_body .=  "Einsatzort: " .$fenster['einsatzort']."\n";
			    $fenster_body .=  "Anzahl: " .$fenster['anzahl']."\n";
			    $fenster_body .=  "\n--------------------------\n\n";

    
			
				
		}
	}
	
	
	  //php validation, exit outputting json string
    if(strlen($name)<4){
        print json_encode(array('type'=>'error', 'text' => 'Bitte füllen Sie alle Pflichtfelder aus!'));
        exit;
    }
    if(strlen($fname)<4){
        print json_encode(array('type'=>'error', 'text' => 'Bitte füllen Sie alle Pflichtfelder aus!'));
        exit;
    }
    if(!filter_var($email, FILTER_VALIDATE_EMAIL)){ //email validation
        print json_encode(array('type'=>'error', 'text' => 'Bitte füllen Sie alle Pflichtfelder aus!'));
        exit;
    }
    if(!$street){ //check for valid numbers in phone number field
        print json_encode(array('type'=>'error', 'text' => 'Bitte füllen Sie alle Pflichtfelder aus!'));        exit;
    }
    if( ! $city){ //check emtpy subject
        print json_encode(array('type'=>'error', 'text' => 'Bitte füllen Sie alle Pflichtfelder aus!'));
        exit;
    }
    if( ! $phone){ //check emtpy subject
        print json_encode(array('type'=>'error', 'text' => 'Bitte füllen Sie alle Pflichtfelder aus!'));
        exit;
    }
    if(strlen($message)<3){ //check emtpy message
        print json_encode(array('type'=>'error', 'text' => 'Bitte füllen Sie alle Pflichtfelder aus!'));
        exit;
    }



	
	
    
    
 
  
    
    $file_count = count($attachments['name']); //count total files attached
    $boundary = md5("signvision.ch"); 
    
    //construct a message body to be sent to recipient
    $message_body =  "Offertanfrage von $fname $name\n\n";

    $message_body .=  "Vorname: $fname\n";
    $message_body .=  "Nachname: $name\n";
    
    if($_POST["req_company"]) $message_body .=  "Firma: " . $_POST["req_company"] . "\n";
    
    $message_body .=  "E-Mail: $email\n";
    $message_body .=  "Telefon: $phone\n";
    $message_body .=  "Strasse/Nr.: $street\n";
    $message_body .=  "PLZ/Ort: $city\n\n\n";
    
        $message_body .=  "Bemerkungen:\n";
    $message_body .=  "$message\n";
    $message_body .=  "------------------------------\n\n\n";
    
    
    $message_body .=  "Fenster:\n";
    $message_body .=  "--------------------\n";
    $message_body .=  $fenster_body;
    
if(isset($_FILES) && count($_FILES)){//if attachment exists
        //header
        $headers = "MIME-Version: 1.0\r\n"; 
        $headers .= "From:".$from_email."\r\n"; 
        $headers .= "Reply-To: ".$sender_email."" . "\r\n";
        $headers .= "Content-Type: multipart/mixed; boundary = $boundary\r\n\r\n"; 
        
        //message text
        $body = "--$boundary\r\n";
  		$body .= "Content-type: text/plain; charset=utf-8\r\n";
  
        $body .= "Content-Transfer-Encoding: base64\r\n\r\n"; 
        $body .= chunk_split(base64_encode($message_body)); 
        
        


   
        //attachments
        foreach($_FILES as $key => $atachment){    
	        
	        $file_count = count($atachment['name']);
	        
	           //attachments
	        for ($x = 0; $x < $file_count; $x++){       
	            
	            if(!empty($atachment['name'][$x])){
	                
	                if($atachment['error'][$x]>0) //exit script and output error if we encounter any
	                {
	                    $mymsg = array( 
	                    1=>"The uploaded file exceeds the upload_max_filesize directive in php.ini", 
	                    2=>"The uploaded file exceeds the MAX_FILE_SIZE directive that was specified in the HTML form", 
	                    3=>"The uploaded file was only partially uploaded", 
	                    4=>"No file was uploaded", 
	                    6=>"Missing a temporary folder" ); 
	                    print  json_encode( array('type'=>'error',$mymsg[$atachment['error'][$x]]) ); 
	                    exit;
	                }
	                
	                //get file info
	                $file_name = $key.'-' .$atachment['name'][$x];
	                $file_size = $atachment['size'][$x];
	                $file_type = $atachment['type'][$x];
	                
	                //read file 
	                $handle = fopen($atachment['tmp_name'][$x], "r");
	                $content = fread($handle, $file_size);
	                fclose($handle);
	                $encoded_content = chunk_split(base64_encode($content)); //split into smaller chunks (RFC 2045)
	                
	                $body .= "--$boundary\r\n";
	                $body .="Content-Type: $file_type; name=".$file_name."\r\n";
	                $body .="Content-Disposition: attachment; filename=".$file_name."\r\n";
	                $body .="Content-Transfer-Encoding: base64\r\n";
	                $body .="X-Attachment-Id: ".rand(1000,99999)."\r\n\r\n"; 
	                $body .= $encoded_content; 
	            }
        	}
        }
        
        		

       
    

    }else{ //send plain email otherwise
       $headers = "From:".$from_email."\r\n".
        "Reply-To: ".$email. "\n" .
        "X-Mailer: PHP/" . phpversion();
        $body = $message_body;
    }
        
    $sentMail = mail($recipient_email, "Offertanfrage von $fname $name", $body, $headers);
    if($sentMail) //output success or failure messages
    {       
        print json_encode(array('type'=>'done', 'text' => 'Vielen Dank für Ihre Anfrage. Wir werden uns umgehend mit Ihnen in Verbindung setzen.'));
        exit;
    }else{
        print json_encode(array('type'=>'error', 'Bitte füllen Sie alle Pflichtfelder aus!'));
        exit;
    }
}