<?php get_header("single");?>




    
    <section class=" odd has-breadcrumb">
	    
	    <div class="row hideOnMobile">
		    
		    <div class="col col-100">
		    <nav class="kw-breadcrumb-menu">
   <a href="/" class="kw-breadcrumb-menu__home"></a>
  
     
   <div class="kw-breadcrumb-menu__item">
      <div class="kw-breadcrumb-menu__block is-active">
         <div class="kw-breadcrumb-menu__title "><span>Suche</span></div>
      </div>
   </div>
</nav>

   </div>
		    
	    </div>
	    
	    <div id="newsArchive">
	    <div class="row ">
		    	<?php 
global $wp_query;
$published_postsData =   $GLOBALS['wp_query'];
$published_posts =   $published_postsData->post_count;

?>			

<h2><?php echo ($published_posts == 1 ? $published_posts . ' Suchergebnis' : $published_posts . ' Suchergebnisse'); ?></h2>


<div class="col col-75 fr ">
<div class="">



      <?php while ( have_posts() ) : the_post();?>
      
      <article> 
	      <h3><a href="<?php the_permalink(); ?>"><?php relevanssi_the_title(); ?></a></h3>
	      
      <?php (relevanssi_the_excerpt()); ?>
      <p><a href="<?php the_permalink(); ?>">» weiterlesen</a></p>
      </article>
    <?php endwhile; ?>
   
</div></div><aside class="col col-25">
		

		 	<form method="get" class="quick-search light" action="/">
							<input type="text" class="form-element rounded border light" placeholder="Suchbergiff ..." value="<?php 
echo urldecode($published_postsData->query["s"]); ?>" name="s">
							<button type="submit">OK</button>
							
						</form>	</aside></div></div></section>
    
    <?php get_footer();?>