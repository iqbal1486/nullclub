<?php get_header();?>

      <?php while ( have_posts() ) : the_post();?>

	      
	        <?php
	
	// check if the flexible content field has rows of data
	if( have_rows('pagebuilder') ):
	
	 	// loop through the rows of data
	    while ( have_rows('pagebuilder') ) : the_row();
	
			// check current row layout
	        if( get_row_layout() == 'kopfbild' ): ?>
	        
	        	
			      <div id="stage">
						<div class="scroll-downs"><div class="mousey"><div class="scroller"></div></div></div>
						
						<div id="caption-holder">
							<div id="caption" class="animated animatedFadeInUp fadeInUp">
								<small><?php the_sub_field("subline"); ?></small>
								<span><?php the_sub_field("headline"); ?> </span>
								
							</div>
						</div>
						<div class="staging-image">
							<?php
								
								$img = get_sub_field("hintergrund"); 
								$img_mobile = get_sub_field("hintergrund_mobile"); 
								echo '<img src="' . $img["url"] . '" alt="signvision.ch – ' . get_sub_field("headline") . '" class="desktopStage">';
								
								
								if($img_mobile){
									
									echo '<img src="' . $img_mobile["url"] . '" alt="signvision.ch – ' . get_sub_field("headline") . '" class="mobileStage">';
								}else{
									
								echo '<img src="' . $img["url"] . '" alt="signvision.ch – ' . get_sub_field("headline") . '" class="mobileStage">';
								}
								
								
								?>

						</div>
						
					</div>
    
				
					        
 <?php 
		        
		         elseif( get_row_layout() == 'video' ): ?>
		         
<script src="https://player.vimeo.com/api/player.js"></script>



	        
    <section class="video-component c" id="<?php the_sub_field("anker"); ?>">
	   

	  <div class="row animated "><div class="col col-100 "> <div class="embed-container video-comp-ajax" id="video-comp-ajax" data-sound="true" data-vimeo-id="<?php the_sub_field("videoid"); ?>"></div>
	    
	    <span class="pauseHandler"></span>
	    <div class="hide-this">
	    <div href="#" class="show-video">
		    <small><?php the_sub_field("subline"); ?></small><br>
		    <?php the_sub_field("headline"); ?>
		    <span class="rounded-btn primary"><span class="icon video  light"></span></span>
		    
	    </div>
	    <span class="mask"></span>
	  <!-- <?php $img = get_sub_field("hintergrund"); 
						echo '<img src="' . $img["url"] . '"  alt="signvision.ch – ' . get_sub_field("headline") . '">';?>-->
	    </div>	    </div>	    </div>
	    
    </section>
    
     <?php 
		        
		         elseif( get_row_layout() == 'video-player' ): ?>
		         
<script src="https://player.vimeo.com/api/player.js"></script>



	        
    <section class="video-component c <?php the_sub_field("hintergrund"); ?>" id="<?php the_sub_field("anker"); ?>">
	     
	  <div class="row animated "><div class="col col-100 ">
	  <div class="responsive-video">
		  <iframe src="<?php the_sub_field("videoid"); ?>" width="640" height="233" frameborder="0" allow="autoplay; fullscreen" allowfullscreen></iframe>
		  
	  </div>  </div></div>  </section>
    


	        		
	        <?php    elseif( get_row_layout() == 'slider' ): ?>
	        
	        	
			      <div id="stage">
						
						<div class="scroll-downs"><div class="mousey"><div class="scroller"></div></div></div>
						<?php if( have_rows('slides') ): ?>
			 
				 <div class="slides">
<?php	
	 	// loop through the rows of data
	    while ( have_rows('slides') ) : the_row(); ?>
	    
	    <div class="slide">

<?php if(get_sub_field("link")): ?>
<a href="<?php the_sub_field("link"); ?>" class="slides-link"></a>
	
<?php endif; ?>
						<div class="caption-holder <?php the_sub_field("kreis-position"); ?>">
							<div class="caption animated animatedFadeInUp fadeInUp">
								<small><em><?php the_sub_field("subline"); ?></em></small>
								<span><em><?php the_sub_field("headline"); ?></em></span>
								
							</div>
						</div>
						<div class="staging-image">
							<?php
								
								$img = get_sub_field("hintergrund"); 
								$img_mobile = get_sub_field("hintergrund_mobile"); 
								echo '<img src="' . $img["url"] . '" alt="signvision.ch – ' . get_sub_field("headline") . '" class="desktopStage">';
								
								
								if($img_mobile){
									
									echo '<img src="' . $img_mobile["url"] . '" alt="signvision.ch – ' . get_sub_field("headline") . '" class="mobileStage">';
								}else{
									
								echo '<img src="' . $img["url"] . '" alt="signvision.ch – ' . get_sub_field("headline") . '" class="mobileStage">';
								}
								
								
								?>

						</div>
						
					</div>
    <?php endwhile; ?>
				 </div>
				 <?php endif; ?>
				 
			      </div>
				
				
	        		
	        <?php 
		        
		         elseif( get_row_layout() == 'teaser' ): ?>
	        
			        <section class="teas odd <?php the_sub_field("hintergrund"); ?>-bg">	
					    <div class="row animated">
						    <div class="col  offset-15 col-70">
							    <h1><small>Signvision</small><?php the_sub_field("headline"); ?></h1>
								<?php the_sub_field("teaser"); ?>
						    </div>
						</div>
				    </section>
		    
		     <?php 
			     
			     
			     elseif(get_row_layout() == 'list'): ?>
			     
			         <section class="<?php the_sub_field("hintergrund"); ?><?php echo (get_sub_field("bild_oder_zufalliger_mitarbeiter") !== "Bild") ? ' nopaddbot has-person-image': ''; ?>">
	    <div class="row animated">
		    <h2><?php the_sub_field("headline"); ?></h2>
		    
		    <div class="col col-50 fr">
			    <?php if( have_rows('liste') ): ?>
			    
			    <ul class="tickbox<?php echo (get_sub_field("bild_oder_zufalliger_mitarbeiter") !== "Bild"  ? "" : " nopadd"); ?>">
<?php	
	 	// loop through the rows of data
	    while ( have_rows('liste') ) : the_row();
	    
	    ?>
				    <li>
				    	<div class="list-icon">
					    	<span class="icon tick"></span>
				    	</div>
				    	<div class="list-content"><?php the_sub_field("bezeichnung"); ?></div>
					</li>
				 
				 <?php endwhile; ?>  
				   
			</ul>
				<?php if(get_sub_field("link") && get_sub_field("linkbezeichnung")): ?>
				  <div class="button-group space-top tal">
						<a href="<?php the_sub_field("link"); ?>" class="button rounded primary"><?php the_sub_field("linkbezeichnung"); ?></a>
					</div>
				
				<?php endif; ?>
			<?php endif; ?>
		    </div><div class="col col-50 tcenter">
			   
			   <?php if(get_sub_field("bild_oder_zufalliger_mitarbeiter") !== "Bild"): 
			   
			   $args = array(
    'post_type'=>'ansprechpartner', 
    'orderby'=>'rand', 
    'posts_per_page'=>'1'
  );

  $testimonials=new WP_Query($args);

  while ($testimonials->have_posts()) : $testimonials->the_post(); 

?>

   <?php the_post_thumbnail("full"); ?>
    
    <?php

endwhile; wp_reset_postdata();


?>



			   
			   
			   <?php else: ?>
			   		<p><?php $img = get_sub_field("bild"); 
						echo '<img src="' . $img["url"] . '" class="fit-80" alt="signvision.ch – ' . get_sub_field("headline") . '">';?>
					</p>
								
								
				<?php endif; ?>
		    </div>
		</div>
    </section>
			     
			     
			     
			    <?php
				    
				    
				    elseif(get_row_layout() == 'vorteile'): ?>
			         <section class="<?php the_sub_field("hintergrund"); ?><?php echo (get_sub_field("abstand_bereinigen") ? ' clear' : ''); ?>">
		
					    <h2><?php the_sub_field("headline"); ?></h2>
				      
					    
			
					
					  <?php if( have_rows('vorteile_loop') ): ?>
			    
			  <div class="row mlr col-list animated">
					
<?php	
	 	// loop through the rows of data
	    while ( have_rows('vorteile_loop') ) : the_row();
	    
	    ?>
				    	<div class="col col-1-3">
						<div class="col-inner ">
				<figure class="icon-holder">
					<?php
								$img = get_sub_field("bild"); 
								echo '<img src="' . $img["url"] . '" class="fit-80" alt="signvision.ch – ' . get_sub_field("bezeichnung") . '">';
								?>
				</figure>
				<h3><?php the_sub_field("bezeichnung"); ?></h3>
				<p><?php the_sub_field("inhalt"); ?></p>
			</div></div>
				 
				 <?php endwhile; ?>  
				   
			
					</div>
			<?php endif; ?>
			
			
			
			
			
			    </section>




			
			     
			    <?php
		        
		    
		       elseif( get_row_layout() == 'footer-image' ): ?>
			   		
			   		<?php
						$bgimg = get_sub_field("hintergrund"); 
					?>
		            <section id="footer-img" data-bg="<?php echo $bgimg["url"]; ?>">
					    <div class="row">
						    <div class="col col-70 offset-15 teas white">
							    <h2><?php the_sub_field("headline"); ?></h2>
							    <?php the_sub_field("inhalt"); ?>
							    
							    <div class="button-group space-top">
								    <a href="<?php the_sub_field("link"); ?>" class="button rounded primary"><?php the_sub_field("linkbezeichnung"); ?></a>
							    </div>
						    </div>
						</div>
				    </section>
					  
					
			
	          <?php 
		       
		       elseif( get_row_layout() == 'aktuelles-home' ): ?>
			   		
			   		
			   		<section class=" odd">
			   		 	<h2><?php the_sub_field("headline"); ?></h2>
					    
					    
			   		 	<div class="row  ">  	
				   		 	
				   		 	<?php $args = array( 'post_type' => 'post', 'posts_per_page' => 3 );
								   $args['meta_query'][] = array('key' => "home", 'value' => 1);
								   $loop = new WP_Query( $args );
								
								while ( $loop->have_posts() ) : $loop->the_post(); ?>	
													
																		
										
										
										<div class="col col-1-3 ">
											<div class="news <?php echo (get_field("top-news") ? (has_post_thumbnail() ? ' hasImage top' : ' top') :  (has_post_thumbnail() ? ' hasImage breaking' : ' special')); ?>">
					
					<a href="<?php the_permalink(); ?>" class="news-hover"></a>			
					
					<?php if(has_post_thumbnail()): ?>
					
						<figure>
						<?php the_post_thumbnail(); ?>
						</figure>
					
					<?php endif; ?>	
						<span class="cat"><?php $cats = []; foreach((get_the_category()) as $category){
        $cats[] = $category->name;
        } echo implode(", ", $cats);	?></span>
					<h3><?php the_title(); ?></h3>
											<?php the_excerpt(); ?>
							<span class="spcr"></span>				

				</div></div>
									
										
										
									
    <?php endwhile; wp_reset_postdata(); ?> 
							
			   		 	</div>
			   		</section>
					  <?php
		       
		       elseif( get_row_layout() == 'aktuelles' ): ?>
			   		
			   		
			   		<section class="transform-no-bottom transform-white">
			   		 	<h2><?php the_sub_field("headline"); ?></h2>
					    
					    
			   		 	<div class="row calculateHeight ">  	
				   		 	
				   		 	<?php
					   		 	if( get_sub_field('beitraege') ):

					
								 	// loop through the rows of data
								    foreach(get_sub_field('beitraege') as $post) :  setup_postdata($post);
					
										?>
										
										
										<div class="col col-1-3 ">
											<div class="news odd <?php echo (get_field("top-news") ? (has_post_thumbnail() ? ' hasImage top' : ' top') :  (has_post_thumbnail() ? ' hasImage breaking' : ' special')); ?>">
	<span class="date"><?php echo get_the_date(); ?></span>
					
					<a href="<?php the_permalink(); ?>" class="news-hover"></a>			
					
					<?php if(has_post_thumbnail()): ?>
					
						<figure>
						<?php the_post_thumbnail(); ?>
						</figure>
					
					<?php endif; ?>	
						
					<h3><?php the_title(); ?></h3>
											<?php the_excerpt(); ?>
											<span class="cat"><?php $cats = []; foreach((get_the_category()) as $category){
        $cats[] = $category->name;
        } echo implode(", ", $cats);	?></span>

				</div></div>
									
										
										<?php
									endforeach;  wp_reset_postdata();
								endif; ?>
							
			   		 	</div>
			   		</section>
					  
					
					
	          <?php 
		        
		         elseif( get_row_layout() == 'content_transform' ):
		          $uniqid = uniqid(time());
		         
		         $colorclass = (get_sub_field("hintergrund") == "white" || get_sub_field("hintergrund") == "odd") ? 'primary' : 'white '; // bordered
		         $colorclass2 = (get_sub_field("hintergrund") == "white" || get_sub_field("hintergrund") == "odd") ? 'primary' : 'white';
		         
		         
		         if($nachfolgende_elemente_erst_bei_klick_sichtbar){
			         ?>
			         
			             <section data-show-js="show-more-<?php echo $nachfolgende_elemente_id; ?>" id="<?php echo (get_sub_field("anker") ? get_sub_field("anker") : sanitize_title(get_sub_field("headline"))); ?>" class="transform colored-<?php the_sub_field("hintergrund"); ?><?php echo (get_sub_field("gerader_abschluss") ? ' onlyBottom' : ''); ?><?php echo (get_sub_field("gerader_abschluss_oben") ? ' onlyTop' : ''); ?> hidden">
		<?php
			         
		         }else{
			         ?>
			         
			             <section id="<?php echo (get_sub_field("anker") ? get_sub_field("anker") : sanitize_title(get_sub_field("headline"))); ?>" class="transform colored-<?php the_sub_field("hintergrund"); ?><?php echo (get_sub_field("gerader_abschluss") || get_sub_field("nachfolgende_elemente_erst_bei_klick_sichtbar") ? ' onlyBottom' : ''); ?><?php echo (get_sub_field("gerader_abschluss_oben") ? ' onlyTop' : ''); ?>">
		
			         <?php
		         } ?>
		<h2><?php the_sub_field("headline"); ?></h2>
	    <div class="row mlr animated">
		    
		    
		    <div class="carousel-component">
			    
			    <ul>
				    
				    <li class="c">
				    <?php if(get_sub_field("bildposition")  == "left"): ?>
				    	<div class="col col-45">
					    	<figure>
					    	<?php
								$img = get_sub_field("bild"); 
								echo '<img src="' . $img["url"] . '" alt="signvision.ch – ' . get_sub_field("headline") . '">';
								?>
					    	</figure>
				    	</div>
				    	<div class="col col-50  offset-5">
				    	<?php else: ?>
				    	<div class="col col-45 fr">
					    	<figure>
					    		
					    		<?php
								$img = get_sub_field("bild"); 
								echo '<img src="' . $img["url"] . '" alt="signvision.ch – ' . get_sub_field("headline") . '">';
								?>
					    	</figure>
				    	</div>
				    	
				    	
				    	<div class="col col-50  offset-r-5">
				    	<?php endif; ?>
				    	
					    	
					    	<h3><small><?php the_sub_field("subline"); ?></small><?php the_sub_field("textline"); ?></h3>
					    	<?php the_sub_field("inhalt"); ?>
					    	
					    	<?php if(get_sub_field("mehr_inhalt")): ?>
					    		<?php if(get_sub_field("text_interner_link_oder_externer_link") == "Text"): ?>
					    		<div class="show-more" id="show-more-<?php echo $uniqid; ?>">
						    		<?php the_sub_field("mehr_inhalt_text"); ?>
					    		</div>
					    		<div class="button-group space-ml-top">
							    	<a href="#show-more-<?php echo $uniqid; ?>" class="button rounded <?php echo $colorclass; ?> js-show-more" data-read-more="Mehr dazu" data-read-less="Weniger anzeigen">Mehr dazu</a>
							    	<!--a href="" class="button rounded white ml bordered">Zu den Branchen</a-->
						    	</div>
					    	
					    	
								<?php elseif(get_sub_field("text_interner_link_oder_externer_link") == "interner Link"): ?>
						    		<div class="button-group space-ml-top">
								    	<a href="<?php the_sub_field("interner_link"); ?>" class="button rounded <?php echo $colorclass; ?>"><?php the_sub_field("linkbezeichnung"); ?></a>
								    	<!--a href="" class="button rounded white ml bordered">Zu den Branchen</a-->
							    	</div>
								<?php elseif(get_sub_field("text_interner_link_oder_externer_link") == "externer Link"): ?>
						    		<div class="button-group space-ml-top">
								    	<a href="<?php the_sub_field("externer_link"); ?>" target="_blank" class="button rounded <?php echo $colorclass; ?>"><?php the_sub_field("linkbezeichnung"); ?></a>
								    	<!--a href="" class="button rounded white ml bordered">Zu den Branchen</a-->
							    	</div>
								<?php endif; ?>
					    	
					    	
					    	
					    	
					    	
					    	<?php endif; ?>
					    	
				    	</div>
				    	
				    	
				    </li>	 				    
				    
				    
				    
			    </ul>
			    
		    </div>
		    
		    
		    
		    
		    
	    </div>
	    </section>
					  
					
					
    
	
	        		
	        <?php 
		        
		        
		        

		        
		        
		        
		        
		        
		        
		        
		        endif;
	
	    endwhile;
	
	else :
	
	    // no layouts found
	
	endif;
	
	?>     
            <?php endwhile; ?>
   
   
    
    <?php get_footer();?>