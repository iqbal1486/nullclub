
 <!DOCTYPE html>
<!--[if IE 7]>
<html class="ie ie7" lang="de-DE" prefix="og: http://ogp.me/ns#">
<![endif]-->
<!--[if IE 8]>
<html class="ie ie8" lang="de-DE" prefix="og: http://ogp.me/ns#">
<![endif]-->
<!--[if !(IE 7) | !(IE 8)  ]><!-->
<html lang="de-DE" prefix="og: http://ogp.me/ns#">
<!--<![endif]-->
<head>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width,initial-scale=1.0,user-scalable=0">
  <title><?php wp_title();?></title>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-57301791-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
 
  gtag('config', 'UA-57301791-1');
</script>

<link href="<?php bloginfo( 'template_directory' ); ?>/static/css/_app.css" rel="stylesheet">
		<link href="<?php bloginfo( 'template_directory' ); ?>/static/css/_vendor.css" rel="stylesheet">
		<link href="<?php bloginfo( 'template_directory' ); ?>/static/css/_animate.css" rel="stylesheet">
		<link href="<?php bloginfo( 'template_directory' ); ?>/static/css/_responsive.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Open+Sans:400,400i,600,600i,700" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=PT+Serif+Caption:400,400i" rel="stylesheet">

  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-status-bar-style" content="black">
  <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
  
  

  <link rel="apple-touch-icon" href="/apple-touch-icon.png" />
  <link rel="apple-touch-icon" sizes="57x57" href="/apple-touch-icon-57x57.png" />
  <link rel="apple-touch-icon" sizes="72x72" href="/apple-touch-icon-72x72.png" />
  <link rel="apple-touch-icon" sizes="76x76" href="/apple-touch-icon-76x76.png" />
  <link rel="apple-touch-icon" sizes="114x114" href="/apple-touch-icon-114x114.png" />
  <link rel="apple-touch-icon" sizes="120x120" href="/apple-touch-icon-120x120.png" />
  <link rel="apple-touch-icon" sizes="144x144" href="/apple-touch-icon-144x144.png" />
  <link rel="apple-touch-icon" sizes="152x152" href="/apple-touch-icon-152x152.png" />
  <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon-180x180.png" />
  <!--[if IE]>
      <script src="https://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->



<script src="https://player.vimeo.com/api/player.js"></script>


<?php wp_head(); 
	



?>
	<?php 
	if( have_rows('pagebuilder') ):
	
	 	// loop through the rows of data
	    while ( have_rows('pagebuilder') ) : the_row();
	
			if( get_row_layout() == 'kopfbild' ): 
	        
	        	
								$img = get_sub_field("hintergrund"); 
								$img_mobile = get_sub_field("hintergrund_mobile"); 
								
								
								if($img_mobile["url"]){
									echo '<meta property="og:image" content="' . $img_mobile["url"] . '" /> ' . "\n";
	
								}else{
									echo '<meta property="og:image" content="' . $img["url"] . '" /> ' . "\n";
	
								}
								
			endif;
			
			
		endwhile;
	
	endif;
	
?>
							
								
								





</head>
<body <?php body_class(($post->post_parent == 459 ? 'ref' : '')); ?>>
	<div id="wrapper">
<header>
	
			<div id="brand">
				<a href="/sonnenschutz/">
					<img class="fit" src="<?php bloginfo( 'template_directory' ); ?>/static/media/brand-sv.png" alt="<?php bloginfo("name"); ?>">
					
				</a>
			</div>
			<div class="hamburger hamburger--spring js-hamburger">
					<div class="hamburger-box">
						<div class="hamburger-inner"></div>
					</div>
				</div><div class="multipage">
					<a href="/werbetechnik">Werbetechnik 
<svg version="1.1" id="Ebene_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="0 0 61.2 60.6" style="enable-background:new 0 0 61.2 60.6;" xml:space="preserve">
<path d="M33,32.3l17.2-17.2v10.1c0,0.9,0.7,1.6,1.6,1.6s1.6-0.7,1.6-1.6v-14c0-0.9-0.7-1.6-1.6-1.6h-14c-0.9,0-1.6,0.7-1.6,1.6
	s0.7,1.6,1.6,1.6h10.1L30.7,30c-0.3,0.3-0.5,0.7-0.5,1.1s0.2,0.8,0.5,1.1C31.3,32.9,32.4,32.9,33,32.3z"/>
<path d="M47.9,35.5c-0.9,0-1.6,0.7-1.6,1.6v11c0,0.8-0.6,1.4-1.4,1.4h-30c-0.8,0-1.4-0.6-1.4-1.4v-30c0-0.8,0.6-1.4,1.4-1.4h11
	c0.9,0,1.6-0.7,1.6-1.6s-0.7-1.6-1.6-1.6h-11c-2.5,0-4.6,2.1-4.6,4.6v30c0,2.6,2.1,4.6,4.6,4.6h30c2.6,0,4.6-2.1,4.6-4.6v-11
	C49.5,36.3,48.8,35.5,47.9,35.5z"/>
</svg></a>

				</div>
			<nav>
			
						<?php
							
							wp_nav_menu();

?>	</nav>
	
		</header>
		
			
			
			<nav id="mobile-menu" class="c">
			
						<?php
							
							wp_nav_menu(["menu" => "Mobile-Menu"]);

?>	</nav>
		
		
		<?php
			
			$parents = get_post_ancestors( $post->ID );
		
			 if(in_array(2081, $parents)): ?>
		<div id="products-nav">
			<div class="row">
<nav class="c">
			
							
							<ul>
<?php wp_list_pages( array( 'title_li' => '' , 'parent' => $post->post_parent) ); ?>
</ul>

</nav>
			</div>
			
			
		</div>
		
		<?php endif; ?>
		<div id="subnavi">
			<div class="row">
<nav class="c">
			
						<?php
							
							wp_nav_menu(["menu" => "Produkte"]);

?>	</nav>
			</div>
		</div>
		
		
		
		<div id="subnavi-about">
			<div class="row">
<nav class="c">
			
						<?php
							
							wp_nav_menu(["menu" => "Über uns"]);

?>	</nav>
			</div>
		</div>
		
		