<?php get_header("single");?>




    
    <section class=" odd">
	    	    
	    <div id="newsArchive">
	    <div class="row ">
		    <div id="category-menu">
			    <ul>
					    <?php $categories =  wp_list_categories( array(
					        'orderby'    => 'name',
					        'show_option_all' => 'Alle',
					        'title_li' => '',
					        'echo' => false,
					        'show_count' => false,
					    ) );
					    
					    
					    
					    
					    
if(strpos($categories,'current-cat') == false) { // check if the class exists
    // add the class to the All item if it doesn't exist
    $categories = str_replace('cat-item-all', 'cat-item-all current-cat', $categories);
}
				
				echo $categories; 	    
					    
					     ?> 
					</ul>
		    	<h2>Blog</h2>
		    </div>
<div class="row">



      <?php $i = $x = 0; while ( have_posts() ) : the_post();?>
      <?php if($i==3){
	      $i = 0;
				echo '<div class="clearer desktop"></div>';	
				}
				
				 if($x==2){
	      $x = 0;
				echo '<div class="clearer tablet"></div>';	
				}
				
				
				?>
      
      <div class="col col-1-3 ">
											<div class="news <?php echo (get_field("top-news") ? (has_post_thumbnail() ? ' hasImage top' : ' top') :  (has_post_thumbnail() ? ' hasImage breaking' : ' special')); ?>">
			
					<a href="<?php the_permalink(); ?>" class="news-hover"></a>			
					
					<?php if(has_post_thumbnail()): ?>
					
						<figure>
						<?php the_post_thumbnail(); ?>
						</figure>
					
					<?php endif; ?>	
						<span class="cat"><?php $cats = []; foreach((get_the_category()) as $category){
        $cats[] = $category->name;
        } echo implode(", ", $cats);	?></span>
					<h3><?php the_title(); ?></h3>
											<?php the_excerpt(); ?>
							<span class="spcr"></span>		
							
									

				</div></div>
				
				
				
				<?php $i++; $x++; endwhile; ?>
   
</div>
</div></div></section>
    
    <?php get_footer();?>