

		<script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
		<script src="<?php bloginfo("template_directory");?>/static/js/app-min.js"></script>
		<script src="<?php bloginfo("template_directory");?>/static/js/kreativwolke-min.js"></script>
		
		
		<?php wp_footer(); ?>


  </body>
</html>