<?php get_header();?>

  <script>
							   
							       var contentString ="";
							       
							       </script>
      <?php
	      
	      $nachfolgende_elemente_erst_bei_klick_sichtbar = false;
	      
	       while ( have_posts() ) : the_post();?>

	      
	        <?php
	
	// check if the flexible content field has rows of data
	if( have_rows('pagebuilder') ):
	
	 	// loop through the rows of data
	    while ( have_rows('pagebuilder') ) : the_row();
	
			// check current row layout
			
			$uid = 1; 


	        if( get_row_layout() == 'offertformular' ): ?>
	        
	        
	<div class="tooltip_templates">
								<span id="tooltip-groesse"><img src="/sonnenschutz/wp-content/uploads/2018/09/popup-groessen.jpg"></span>
								<span id="tooltip-groesse-2"><img src="/sonnenschutz/wp-content/uploads/2018/09/popup-groessen.jpg"></span>
								<span id="tooltip-lage"><img src="/sonnenschutz/wp-content/uploads/2018/09/popup-fenster.jpg"></span>
								<span id="tooltip-verglasung"><img src="/sonnenschutz/wp-content/uploads/2018/09/popup-verglasung.jpg"></span>
							</div>


	        <form method="post" accept-charset="utf-8" action="<?php bloginfo("template_directory");?>/ajax.php" id="offertanfrage-form" data-id="<?php echo $uid; ?>">
				<section class="white c offertanfrage" id="offertanfrage">
					<div class="row">
						<div class="col offset-10 col-80">
							<div class="col col-1-1">
								<h3>Angaben Fenster</h3>
							</div>
							<div class="input-field col col-1-4">
								<label>GLAS BREITE CM <span class="tooltip" data-tooltip-content="#tooltip-groesse">i</span></label>
								<input type="text" name="fenster[<?php echo $uid; ?>][glas_breite]" value="">
							</div>
							
						


							<div class="input-field col col-1-4">
								<label>GLAS HÖHE CM <span class="tooltip" data-tooltip-content="#tooltip-groesse-2">i</span></label>
								<input type="text" name="fenster[<?php echo $uid; ?>][glas_hoehe]" value="">
							</div>
							
							
							
							
							<div class="input-field col col-1-4">
								<label>VERGLASUNG <span class="tooltip" data-tooltip-content="#tooltip-verglasung">i</span></label>
								<span class="select-style">
									<select name="fenster[<?php echo $uid; ?>][verglasung]">
										<option value="">Bitte auswählen</option>
										<option value="1-fach">1-fach</option>	
										<option value="2-fach">2-fach</option>	
										<option value="3-fach">3-fach</option>									</select>
								</span>
							</div>
							<div class="input-field col col-1-4">
								<label>AUSRICHTUNG</label>
								<span class="select-style">
									<select name="fenster[<?php echo $uid; ?>][ausrichtung]">
										<option value="">Bitte auswählen</option>
										<option value="Südost">Südost</option>
					                  <option value="Süd">Süd</option>
					                  <option value="Südwest">Südwest</option>
					                  <option value="West">West</option>
					                  <option value="Nordwest">Nordwest</option>
					                  <option value="Nord">Nord</option>
					                  <option value="Nordost">Nordost</option>
					                  <option value="Ost">Ost</option>
									</select>
								</span>
							</div>
							<div class="input-field col col-1-4">
								<label>LAGE <span class="tooltip" data-tooltip-content="#tooltip-lage">i</span></label>
								<span class="select-style">
									<select name="fenster[<?php echo $uid; ?>][lage]">
										<option value="">Bitte auswählen</option>
										<option value="Fassadenfenster">Fassadenfenster</option>
										<option value="Dachfenster">Dachfenster</option>
										<option value="Glastrennwände">Glastrennwände</option>
									</select>
								</span>
							</div>
							
							
							<div class="input-field col col-1-4">
								<label>WUNSCH</label>
								<span class="select-style">
									<select name="fenster[<?php echo $uid; ?>][wunsch]">
										<option value="">kein Bedürfnis</option>
										<option value="Hitzeschutz">Hitzeschutz</option>
										<option value="UV-Schutz">UV-Schutz</option>
                  						<option value="Blendschutz">Blendschutz</option>
                 						<option value="Splitterschutz">Splitterschutz</option>
                 						<option value="Einbruchschutz">Einbruchschutz</option>
                 						<option value="Sichtschutz">Sichtschutz</option>
									</select>
								</span>
							</div>
							
							
							<div class="input-field col col-1-4">
								<label>EINSATZORT</label>
								<span class="select-style">
									<select name="fenster[<?php echo $uid; ?>][einsatzort]">
										<option value="">Bitte auswählen</option>
										<option value="Büro">Büro</option>
										<option value="Privat">Privat</option>
										<option value="Gewerbe">Gewerbe</option>
									</select>
								</span>
							</div>
							<div class="input-field col col-1-4">
								<label>ANZAHL</label>
								<input type="text" name="fenster[<?php echo $uid; ?>][anzahl]" value="">
							</div>
							<br clear="all">
							
							<div class="input-field col col-3-4">
								<label>BEMERKUNGEN</label>
								<textarea name="fenster[<?php echo $uid; ?>][bemerkungen]"></textarea>
							</div>
							
							
							<div class="input-field col col-1-4">
								<label>FOTOS (MAX. 3)</label>
									<input type="file" name="1[]" id="file-1" class="inputfile inputfile-1" data-multiple-caption="{count} Fotos ausgewählt" multiple />
									<label for="file-1"> <span>Fotos auswählen</span></label>
							</div>
							
							<br clear="all">
							<div class="col col-1-1">
								<div class="add-window"><span>+</span> WEITERE FENSTER</div>
							</div>
							
						</div>
					</div>
				</section>
				
				<script id="form-offerte" type="text/template">
					<section class="white c offertanfrage" id="offertanfrage">
				<div class="row">
						<div class="col offset-10 col-80">
							
							<div class="input-field col col-1-4">
								<label>GLAS BREITE CM</label>
								<input type="text" name="fenster[{{fenster}}][glas_breite]" value="">
							</div>
							
						


							<div class="input-field col col-1-4">
								<label>GLAS HÖHE CM</label>
								<input type="text" name="fenster[{{fenster}}][glas_hoehe]" value="">
							</div>
							
							
							
							
							<div class="input-field col col-1-4">
								<label>VERGLASUNG</label>
								<span class="select-style">
									<select name="fenster[{{fenster}}][verglasung]">
										<option value="">Bitte auswählen</option>
										<option value="1-fach">1-fach</option>	
										<option value="2-fach">2-fach</option>	
										<option value="3-fach">3-fach</option>									</select>
								</span>
							</div>
							<div class="input-field col col-1-4">
								<label>AUSRICHTUNG</label>
								<span class="select-style">
									<select name="fenster[{{fenster}}][ausrichtung]">
										<option value="">Bitte auswählen</option>
										<option value="Südost">Südost</option>
					                  <option value="Sued">Süd</option>
					                  <option value="Suedwest">Südwest</option>
					                  <option value="West">West</option>
					                  <option value="Nordwest">Nordwest</option>
					                  <option value="Nord">Nord</option>
					                  <option value="Nordost">Nordost</option>
					                  <option value="Ost">Ost</option>
									</select>
								</span>
							</div>
							<div class="input-field col col-1-4">
								<label>LAGE</label>
								<span class="select-style">
									<select name="fenster[{{fenster}}][lage]">
										<option value="">Bitte auswählen</option>
										<option value="Fassadenfenster">Fassadenfenster</option>
										<option value="Dachfenster">Dachfenster</option>
										<option value="Glastrennwände">Glastrennwände</option>
									</select>
								</span>
							</div>
							
							
							<div class="input-field col col-1-4">
								<label>WUNSCH</label>
								<span class="select-style">
									<select name="fenster[{{fenster}}][wunsch]">
										<option value="">kein Bedürfnis</option>
										<option value="Hitzeschutz">Hitzeschutz</option>
										<option value="UV-Schutz">UV-Schutz</option>
                  						<option value="Blendschutz">Blendschutz</option>
                 						<option value="Splitterschutz">Splitterschutz</option>
                 						<option value="Einbruchschutz">Einbruchschutz</option>
                 						<option value="Sichtschutz">Sichtschutz</option>
									</select>
								</span>
							</div>
							
							
							<div class="input-field col col-1-4">
								<label>EINSATZORT</label>
								<span class="select-style">
									<select name="fenster[{{fenster}}][einsatzort]">
										<option value="">Bitte auswählen</option>
										<option value="Buero">Büro</option>
										<option value="Privat">Privat</option>
										<option value="Gewerbe">Gewerbe</option>
									</select>
								</span>
							</div>
							<div class="input-field col col-1-4">
								<label>ANZAHL</label>
								<input type="text" name="fenster[{{fenster}}][anzahl]" value="">
							</div>
							<br clear="all">
							
							<div class="input-field col col-3-4">
								<label>BEMERKUNGEN</label>
								<textarea name="fenster[{{fenster}}][bemerkungen]"></textarea>
							</div>
							
							
							<div class="input-field col col-1-4">
								<label>FOTOS (MAX. 3)</label>
									<input type="file" name="{{fenster}}[]" id="file{{fenster}}" class="inputfile inputfile-1 inputfile{{fenster}}" data-multiple-caption="{count} Fotos ausgewählt" multiple />
									<label for="file{{fenster}}"> <span>Fotos auswählen</span></label>
							</div>
							
							<br clear="all">
							<div class="col col-1-1">
								<div class="add-window"><span>+</span> WEITERE FENSTER</div>
							</div>
							
						</div>
					</div>
				</section>
					
				</script>
				
				
				<section class="odd gray c" id="offertanfrage">
					<div class="row">
							
							
						<div class="col offset-10 col-80">
							<div class="col col-1-1"><h3>Kontaktangaben</h3></div>
   <div class="col col-50 input-field" >
      
<label>FIRMA</label>
<input type="text" name="req_company" value="" size="40"></div>
   
   <p><br clear="all"></p>
   <div class="col col-50 input-field">
<label>VORNAME*</label>
<input type="text" name="req_fname" data-required="true" value="" size="40"  ></div>
 
   <div class="col col-50 input-field">
<label>NACHNAME*</label>
<input type="text" name="req_name" data-required="true" value="" size="40"></div>
 
   <div class="col col-50 input-field">
	   
<label>STRASSE/Nr*</label>
<input type="text" name="req_street" data-required="true" value="" size="40"  ></div>
  
   <div class="col col-50 input-field">
<label>PLZ/ORT*</label>
<input type="text" name="req_city" data-required="true" value="" size="40"  ></div>
  
   <div class="col col-50 input-field">
 
<label>PLZ / ORT MONTAGE (falls abweichend)</label>
<input type="text" name="req_city_montage" value="" size="40"></div>
   
   <p><br clear="all"></p>
      <div class="col col-50 input-field">
<label>E-MAIL*</label>
<input type="text" name="req_mail" data-required="true" value="" size="40"  ></div>
   <div class="col col-50 input-field">
	   
<label>TELEFON*</label>
<input type="text" name="req_phone" data-required="true" value="" size="40"  ></div>
  
   <div class="col col-100 input-field">
      
<label>MITTEILUNG*</label>
<textarea name="req_msg" data-required="true" cols="40" rows="10" ></textarea>
      <p><small>* PFLICHTFELDER</small></p>
   </div>
 <div class="agree">
								Alle Informationen zum Umgang mit Ihren Daten entnehmen Sie unserer <a href="/datenschutz">Datenschutzerklärung.</a>
							</div>
							 <div class="col col-100"> <div id="contact_results"></div></div>
    <div class="col col-100"><input type="submit" value="Offerte anfordern" class="button big primary rounded">


</div>
					</div>
				</section>
				
			
			
	        </form>




			<?php elseif( get_row_layout() == 'statement' ): ?>
	        
	        	
			     
    
					 <section class="ref-component c">
	    <div class="statement-hover">
	  <div class="row"  >
	   <div id="speaker">
		   <p><small>Statement</small></p>
		   <p><em><?php the_sub_field("Statement"); ?></em></p>

<p><?php the_sub_field("name"); ?></p>
		    
	    </div>
	    </div>
	    </div>
	   <?php
								$img = get_sub_field("hintergrund"); 
								
								echo '<img src="' . $img["url"] . '" alt="signvision.ch – ' . get_sub_field("headline") . '" class="desktopStage">';
								
								
								
								?>
	    
	    
    </section> 
    
	        		
	        
		            <?php 
		        
		        elseif(get_row_layout() == "unterseiten-auflistung"):
		        
		        
		      
		        ?>
		        
		          <section class=" <?php the_sub_field("hintergrund"); ?>">	
					    <div class="row animated">
						    <div class="col col-100">
							    <h1><small><?php the_title(); ?></small><?php the_sub_field("headline"); ?></h1>
								
        <div class="product-list-ov">
								<?php 
								if ( have_rows("beziehungen") ) {
    while( have_rows("beziehungen")) { the_row();
	    
	    $icon = null;
        $idpage =  get_sub_field("seite"); 
        if(get_the_post_thumbnail_url($idpage, 'large')){
	        $_img = get_the_post_thumbnail_url($idpage, 'large');
	            if( have_rows('pagebuilder', $idpage) ):
	
 	// loop through the rows of data
    while ( have_rows('pagebuilder', $idpage) ) : the_row();

		if( get_row_layout() == 'kopfbild' ):
        
			$icon = get_sub_field("icon");	
			
        	
        endif;
		
	endwhile;
endif;			
	        
	        
        }else{
	         if( have_rows('pagebuilder', $idpage) ):
	
 	// loop through the rows of data
    while ( have_rows('pagebuilder', $idpage) ) : the_row();

		if( get_row_layout() == 'kopfbild' ):
        
			$icon = get_sub_field("icon");	
			$img = get_sub_field("hintergrund");  
			$_img = $img["sizes"]["large"]; 
		
        	
        endif;
		
	endwhile;
endif;			


        }
        
       
        
        ?><div class="product-list">
	        
	        <?php 
	        ?>
	        <a href="<?php echo get_the_permalink($idpage); ?>">
		        <span class="picon"><img src="<?php echo $icon["url"]; ?>" alt="<?php echo $icon["alt"]; ?>"></span>
	      	  <span class="rounding"><span class="title"><?php echo get_the_title($idpage); ?></span><span class="hover-product-link" style="background: url(<?php echo $_img; ?>); background-size: cover;"></span><span class="hover-product-opac"></span></span>
	        </a>
	        
	        <div class="productText">
		        <?php the_sub_field("beschreibung"); ?>
	        </div>
        </div><?php
    }
  
}


?>
        </div>		
								
								
						    </div>
						</div>
				    </section>
		        
		        
		        
	        <?php 




	        elseif( get_row_layout() == 'bild1500px' ): ?>
	        
	        	 <div class=" row">
						


						<div class="col col-1-1 gridimg">
							<?php
								
								$img = get_sub_field("hintergrund"); 
								$img_mobile = get_sub_field("hintergrund_mobile"); 
								echo '<img src="' . $img["url"] . '" alt="signvision.ch – ' . get_sub_field("headline") . '" class="desktopStage">';
								
								
								if($img_mobile){
									
									echo '<img src="' . $img_mobile["url"] . '" alt="signvision.ch – ' . get_sub_field("headline") . '" class="mobileStage">';
								}else{
									
								echo '<img src="' . $img["url"] . '" alt="signvision.ch – ' . get_sub_field("headline") . '" class="mobileStage">';
								}
								
								
								?>

						</div>
						
   
				 </div>
				 
				 
<?php
	        elseif( get_row_layout() == 'kopfbild' ): ?>
	        
	        	 <div id="stage">
						
<div class="scroll-downs"><div class="mousey"><div class="scroller"></div></div></div>
	

<?php if(get_sub_field("kreis_zentriert") && get_sub_field("kreis-position") == "mitte"): ?>

	<div class="caption-holder <?php the_sub_field("kreis-position"); ?>">
							<div class="caption animated animatedFadeInUp fadeInUp">
								<div class="icon">
									<img src="<?php $img = get_sub_field("icon"); echo $img["url"]; ?>">
								</div>
								<span><em><?php the_sub_field("kreis_zentriert"); ?></em></span>
								
							</div>
						</div>

						<?php elseif(get_sub_field("headline") && get_sub_field("subline")): ?>
						<div class="caption-holder <?php the_sub_field("kreis-position"); ?>">
							<div class="caption animated animatedFadeInUp fadeInUp">
								<small><em><?php the_sub_field("subline"); ?></em></small>
								<span><em><?php the_sub_field("headline"); ?></em></span>
								
							</div>
						</div>
						
<?php endif;


						?>
						<div class="staging-image" class="c">
							<?php
								
								$img = get_sub_field("hintergrund"); 
								$img_mobile = get_sub_field("hintergrund_mobile"); 
								echo '<img src="' . $img["url"] . '" alt="signvision.ch – ' . get_sub_field("headline") . '" class="desktopStage">';
								
								
								if($img_mobile){
									
									echo '<img src="' . $img_mobile["url"] . '" alt="signvision.ch – ' . get_sub_field("headline") . '" class="mobileStage">';
								}else{
									
								echo '<img src="' . $img["url"] . '" alt="signvision.ch – ' . get_sub_field("headline") . '" class="mobileStage">';
								}
								
								
								?>

						</div>
						
   
				 </div>
				 
				 
    
					
					<?php    elseif( get_row_layout() == 'slider' ): ?>
	        
	        	
			      <div id="stage">
						<div class="scroll-downs"><div class="mousey"><div class="scroller"></div></div></div>
						<?php if( have_rows('slides') ): ?>
			 
				 <div class="slides">
<?php	
	 	// loop through the rows of data
	    while ( have_rows('slides') ) : the_row(); ?>
	    
	    <div class="slide">

<?php if(get_sub_field("link")): ?>
<a href="<?php the_sub_field("link"); ?>" class="slides-link"></a>
	
<?php endif; ?>
						<div class="caption-holder <?php the_sub_field("kreis-position"); ?>">
							<div class="caption animated animatedFadeInUp fadeInUp">
								<small><em><?php the_sub_field("subline"); ?></em></small>
								<span><em><?php the_sub_field("headline"); ?></em></span>
								
							</div>
						</div>
						<div class="staging-image">
							<?php
								
								$img = get_sub_field("hintergrund"); 
								$img_mobile = get_sub_field("hintergrund_mobile"); 
								echo '<img src="' . $img["url"] . '" alt="signvision.ch – ' . get_sub_field("headline") . '" class="desktopStage">';
								
								
								if($img_mobile){
									
									echo '<img src="' . $img_mobile["url"] . '" alt="signvision.ch – ' . get_sub_field("headline") . '" class="mobileStage">';
								}else{
									
								echo '<img src="' . $img["url"] . '" alt="signvision.ch – ' . get_sub_field("headline") . '" class="mobileStage">';
								}
								
								
								?>

						</div>
						
					</div>
    <?php endwhile; ?>
				 </div>
				 <?php endif; ?>
				 
			      </div>
				
				
	        	
		        <?php    elseif( get_row_layout() == 'gallery' ): ?>
	        
	        	<section class="<?php the_sub_field("hintergrund"); ?>">
		        	
		        	<div class="row animated dark">
						
						<?php if( have_rows('gallery') ): ?>
			 
				 <div class="gallery"><ul class="owl-carousel owl-theme">
<?php	
	 	// loop through the rows of data
	    while ( have_rows('gallery') ) : the_row(); ?>
	    
	  
		  <li><img src="<?php $img = get_sub_field("bild"); echo $img["url"]; ?>"></li>						
		  
    <?php endwhile; ?>
				 </ul>
				 <?php endif; ?>
				 
			      </div>
				</section>
				
	        		
	        <?php 
		        
		            elseif( get_row_layout() == 'kopfbilder' ): ?>
	        
	        	
			      <div id="stage">
						
						<?php if( have_rows('kopfbilder') ): ?>
			 
				 <div class="flexContainer c">
<?php	
	 	// loop through the rows of data
	    while ( have_rows('kopfbilder') ) : the_row();  $img = get_sub_field("hintergrund");  ?>
	    
	  
						  <div style="background: url(<?php echo $img["url"]; ?>) center center no-repeat; background-size:  120% auto;">	
					</div>	
    <?php endwhile; ?>
				 </div>
				 <?php endif; ?>
				 
			      </div>
				
				
	        		
	        <?php 
		        
		        

	        		
		        
		         elseif( get_row_layout() == 'text' ): ?>
	        
			        <section id="<?php echo (get_sub_field("anker") ? get_sub_field("anker") : sanitize_title(get_sub_field("headline"))); ?>" class="textbox <?php the_sub_field("hintergrund"); ?>">	
					    <div class="row animated">
						    <div class="col offset-10 col-80">
							    <h2><?php the_sub_field("headline"); ?></h2>
								<div class="col col-1-1"><?php the_sub_field("inhalt"); ?></div>
						    </div>
						</div>
				    </section>

<?php

 elseif( get_row_layout() == 'text_zweispaltig' ): ?>
	        
			        <section id="<?php echo (get_sub_field("anker") ? get_sub_field("anker") : sanitize_title(get_sub_field("headline"))); ?>" class="textbox <?php the_sub_field("hintergrund"); ?>">	
					    <div class="row animated">
						    <div class="col offset-10 col-80">
							    <h2><?php the_sub_field("headline"); ?></h2>
							    
								<div class="col col-1-1">	<?php the_sub_field("einleitung"); ?></div>
								<div class="col col-1-2">
									<?php the_sub_field("inhalt_links"); ?>
								</div>
								<div class="col col-1-2">
								<?php the_sub_field("inhalt_rechts"); ?>
								</div>
						    </div>
						</div>
				    </section>
		        
 <?php  elseif( get_row_layout() == 'teaser' ): ?>
	        
			        <section class="teas <?php the_sub_field("hintergrund"); ?>">	
					    <div class="row animated">
						    <div class="col offset-15 col-70">
							    <h1><small><?php the_title(); ?></small><?php the_sub_field("headline"); ?></h1>
								<?php the_sub_field("teaser"); ?>
						    </div>
						</div>
				    </section>
		        
 <?php 
	 elseif( get_row_layout() == 'teaser_kontakt' ): ?>
	        
			        <section class="teas <?php the_sub_field("hintergrund"); ?>">	
					    <div class="row animated">
						    <div class="col offset-15 col-70">
							    <h1><small><?php the_title(); ?></small><?php the_sub_field("headline"); ?></h1>
								<?php the_sub_field("teaser"); ?>
								
								<div id="rkontaktcols" class="row mw">
									<div class="col col-70 offset-20">
								<div class="col col-1-2"><h4>Kontaktdaten</h4><?php the_sub_field("anschrift"); ?></div>
								<div class="col col-1-2"><h4>Öffnungszeiten</h4><?php the_sub_field("offnungszeiten"); ?></div>	</div></div>
						    </div>
						</div>
				    </section>
		        
 <?php 
		           elseif( get_row_layout() == 'text_zentriert' ): ?>
	        
			        <section id="<?php echo (get_sub_field("anker") ? get_sub_field("anker") : sanitize_title(get_sub_field("headline"))); ?>" class="tac <?php echo (get_sub_field("kein_abstand_nach_unten") ? ' nopaddbot ' : ''); ?><?php the_sub_field("hintergrund"); ?>">	
					    <div class="row animated">
						    <div class="col offset-15 col-70">
							    <h1><?php the_sub_field("headline"); ?></h1>
								<?php the_sub_field("teaser"); ?>
						    </div>
						</div>
				    </section>
		        
 <?php 
 elseif( get_row_layout() == 'kontakt' ): ?>
	        
			        <section id="contact" class="contactform <?php the_sub_field("hintergrund"); ?>">	
					     <h2><?php the_sub_field("headline"); ?></h2>
					     
					     <div class="row animated">
						    <div class="col offset-15 col-70 tac">
							   
								<?php the_sub_field("teaser"); ?>
						    </div>
						   
						   <?php if(get_sub_field("kontakt-text")): ?>
						   
						   <script>
							   
							        contentString = '<?php echo str_replace( array( "\n", "\r" ), array( "\\n", "\\r" ), get_sub_field("kontakt-text") ); ?>';
            
            </script>
						   
						   <?php endif; ?>
						   <div class="col offset-10 col-80">
						    
						    	<?php echo do_shortcode('[contact-form-7 id="348" title="Kontaktformular"]'); ?>
						   </div>
						</div>
				    </section>
				    
				    <section class="mapping">
					     <div id="map-holder">
							   
								  <div id="map" data-latitude="<?php the_sub_field("latitude"); ?>" data-longitude="<?php the_sub_field("longitude"); ?>"></div>
							    
							    
						    </div></section>
		        
 <?php 
		        
		         elseif( get_row_layout() == 'video' ): ?>
		         



	        
    <section class="video-component c" id="<?php the_sub_field("anker"); ?>">
	    <div class="embed-container <?php echo (! is_page(2268) ? 'ratio16x9' : '');?> video-comp-ajax" id="video-comp-ajax-<?php the_sub_field("videoid"); ?>" data-vimeo-id="<?php the_sub_field("videoid"); ?>"></div>
	    

	    <span class="pauseHandler"></span>
	    <div class="hide-this">
	    <div href="#" class="show-video">
		    <small><?php the_sub_field("subline"); ?></small><br>
		    <?php the_sub_field("headline"); ?>
		    <span class="rounded-btn primary"><span class="icon video  light"></span></span>
		    
	    </div>
	    <span class="mask"></span>
	  <!-- <?php $img = get_sub_field("hintergrund"); 
						echo '<img src="' . $img["url"] . '"  alt="signvision.ch – ' . get_sub_field("headline") . '">';?>-->
	    </div>
	    
    </section>
    
     <?php 
		        
		         elseif( get_row_layout() == 'video-player' ): ?>
		         
<script src="https://player.vimeo.com/api/player.js"></script>



	        
    <section class="video-component c <?php the_sub_field("hintergrund"); ?>" id="<?php the_sub_field("anker"); ?>">
	  <div class="row animated "><div class="col-100 col">
	  <div class="responsive-video">
		  <iframe src="<?php the_sub_field("videoid"); ?>" width="640" height="233" frameborder="0" allow="autoplay; fullscreen" allowfullscreen></iframe>
		  
	  </div>  </div></div>  </section>
    

		     <?php 
			     
			     
			     elseif( get_row_layout() == 'kontaktperson'): ?>
			     
			     
			      <section class="contactperson <?php the_sub_field("hintergrund"); ?>">
	    <div class="row animated ">
		    
		    
		    
				    <?php if(get_sub_field("bildposition")  == "left"): ?>
		    
			
			
			<div class="col col-40 offset-r-10 fr contact-data-entry">
						
			
		    
			
				<?php the_sub_field("kontaktdaten"); ?>
			</div>	
			
			<div class="col col-45">
				<figure class="person"><?php $img = get_sub_field("bild"); 
						echo '<img src="' . $img["url"] . '" class="fit-80" alt="signvision.ch – ' . get_sub_field("headline") . '">';?></figure>
			</div>
			<?php else: ?>
			<div class="col col-40 offset-10 contact-data-entry">
						
			
		    
			
				<?php the_sub_field("kontaktdaten"); ?>
			</div>	

			<div class="col col-45">
				<figure class="person"><?php $img = get_sub_field("bild"); 
						echo '<img src="' . $img["url"] . '" class="fit-80" alt="signvision.ch – ' . get_sub_field("headline") . '">';?></figure>
			</div>
			
						
			<?php endif; ?>
			
				
		</div>
    </section>
<?php elseif(get_row_layout() == 'link-box'): ?>

			      <section class="odd linkbox">
		    <h2><?php the_sub_field("headline"); ?></h2>
	     <?php if( have_rows('boxen') ): ?>
		      
	    <div class="row animated">
		    <ul class="overview-component">
<?php	
	 	// loop through the rows of data
	    while ( have_rows('boxen') ) : the_row();
	    
	    ?>
	    
	      <li>
			    	<a href="<?php the_sub_field("link"); ?>" class="scroll-link"></a>
			    	<span class="title"><?php $img = get_sub_field("icon"); 
						echo '<img src="' . $img["url"] . '" class="fit-80" alt="signvision.ch – ' . get_sub_field("headline") . '">';?><br><?php the_sub_field("beschreibung"); ?></span>
			    	<span class="read-more"><span class=" button rounded white"><?php the_sub_field("linkbezeichnung"); ?></span></span>
			    	<span class="mask"></span>
			    	
			    	<?php $img = get_sub_field("bild"); 
						echo '<img src="' . $img["url"] . '" class="fit-80" alt="signvision.ch – ' . get_sub_field("headline") . '">';?>
			    </li>
			   			  

				 
				 <?php endwhile; ?>  
		    </ul>	  
		


    <?php endif; ?>
</div>

    </section>


			     <?php elseif(get_row_layout() == 'komplexe_auflistung'): ?>
			     
			     
			 
		     <?php if( have_rows('list_loop') ): ?>
			      <section class="odd">
		    <?php if(get_sub_field("headline")): ?><h2><?php the_sub_field("headline"); ?></h2><?php endif; ?>
		      
	    <div class="row animated">
		    <ul class="overview-component">
<?php	
	 	// loop through the rows of data
	    while ( have_rows('list_loop') ) : the_row();
	    
	    ?>
	    
	      <li>
			    	<a href="#<?php echo sanitize_title(get_sub_field("subline")); ?>" class="scroll-link"></a>
			    	<span class="title"><?php the_sub_field("subline"); ?></span>
			    	<span class="read-more"><span class=" button rounded white">Mehr</span></span>
			    	<span class="mask"></span>
			    	
			    	<?php $img = get_sub_field("bild"); 
						echo '<img src="' . $img["url"] . '" class="fit-80" alt="signvision.ch – ' . get_sub_field("headline") . '">';?>
			    </li>
			   			  

				 
				 <?php endwhile; ?>  
		    </ul>	  
		</div>

    </section>


    <?php endif; ?>


 <?php if( have_rows('list_loop') ): ?>
		  <section class="clear nopad">
	
		<div class="row full image-text-revert-component">

<?php	$i = 1;
	 	// loop through the rows of data
	    while ( have_rows('list_loop') ) : the_row();
	    
	    
	    if($i%2):
	    ?>
	    <div class="col col-100 listholder" id="<?php echo sanitize_title(get_sub_field("subline")); ?>">
				<div class="col col-50 image c">
					<?php $img = get_sub_field("bild"); 
						echo '<img src="' . $img["url"] . '" class="fit-80" alt="signvision.ch – ' . get_sub_field("headline") . '">';?>
				</div>
				<div class="col col-50 text">
					<div class="textwrapper">
						<h3><small><?php the_sub_field("headline"); ?></small><?php the_sub_field("subline"); ?></h3>
					<?php the_sub_field("inhalt"); ?>	
					
						<?php if(get_sub_field("link") && get_sub_field("linkbezeichnung")): ?>
				  <div class="button-group space-top">
						<a href="<?php the_sub_field("link"); ?>" class="button rounded primary"><?php the_sub_field("linkbezeichnung"); ?></a>
					</div>
				
				<?php endif; ?>		
					</div>		    


				</div>
			</div>

			 <?php else: ?>
			 
			 
			    <div class="col col-100 odd listholder" id="<?php echo sanitize_title(get_sub_field("subline")); ?>">
				<div class="col col-50 image c fr">
					<?php $img = get_sub_field("bild"); 
						echo '<img src="' . $img["url"] . '" class="fit-80" alt="signvision.ch – ' . get_sub_field("headline") . '">';?>
				</div>
				<div class="col col-50 text">
					<div class="textwrapper">
						<h3><small><?php the_sub_field("headline"); ?></small><?php the_sub_field("subline"); ?></h3>
					<?php the_sub_field("inhalt"); ?>	
					
						<?php if(get_sub_field("link") && get_sub_field("linkbezeichnung")): ?>
				  <div class="button-group space-top">
						<a href="<?php the_sub_field("link"); ?>" class="button rounded primary"><?php the_sub_field("linkbezeichnung"); ?></a>
					</div>
				
				<?php endif; ?>		
					</div>		    


				</div>
			</div>





			 <?php endif; ?>  			  

				 
				 <?php $i++; endwhile; ?>  
		    
		</div>

    </section>


    <?php endif; ?>
    

	<?php elseif(get_row_layout() == 'referenzen'): ?>
  <section id="success-stories" class="<?php the_sub_field("hintergrund"); ?><?php echo (get_sub_field("abstand_bereinigen") ? ' cleaner' : ''); ?>">
		    <h2><?php the_sub_field("headline"); ?></h2>
		    
		    
		 <div class="row ">  	
	    	 <div class=" col-90 offset-5 carousel-component-three referenzen dark">
			    
			       
				      <?php if( have_rows('referenzen_loop') ): ?>
			    
			    
				
<?php	
	 	// loop through the rows of data
	    while ( have_rows('referenzen_loop') ) : the_row(); ?>
					<div class="col col-1-3 ">
											<div class="news odd ">
					<a href="<?php echo (get_sub_field("link_oder_pdf") == "PDF" ? get_sub_field("pdf") : get_sub_field("link")); ?>" class="news-hover"></a>	
								<figure class="c">
								<?php $img = get_sub_field("bild"); 
						echo '<img src="' . $img["url"] . '" alt="signvision.ch – ' . get_sub_field("titel") . '">';?>
								</figure>	
								
								<span class="hover-info">	<span>
							<h3><?php the_sub_field("titel"); ?></h3>
							<hr>
							<p><?php the_sub_field("beschreibung"); ?></p>
								</span></span>
							
														
							
							
						</div>	
									
					 </div>
					
					<?php endwhile; ?>
			    
			    <?php endif;?>
	    	 </div>
		 </div>
  </section>
			     <?php
			      
			     elseif(get_row_layout() == 'accordion-component'): $bg = get_sub_field("hintergrund"); ?>
			     
			         <section  id="<?php echo (get_sub_field("anker") ? get_sub_field("anker") : sanitize_title(get_sub_field("headline"))); ?>" class="<?php the_sub_field("hintergrund"); ?>">
	    <div class="row animated">
		    <h2><?php the_sub_field("headline"); ?></h2>
		    
			    
			    
			    
	    <div class="row mlr  animated">
		    
		    <div class="col col-90 offset-5">
				<div class="row mw animatedFadeInUp fadeInUp">
				<?php if(get_sub_field("teaser")): ?>
					<div class="accordion-teaser">
						<?php the_sub_field("teaser"); ?>
					</div>
				
				<?php endif; ?>
	            
	            
	              <?php if( have_rows('accordion') ): ?>
			    
			     <div class="accordion<?php echo ($bg == "white" ? ' light' : ''); ?>">
            <dl>
<?php	
	 	// loop through the rows of data
	    while ( have_rows('accordion') ) : the_row();
	    
	    ?>
	      <dt>
                <a href="" aria-expanded="false" data-accordname="<?php the_sub_field("bezeichnung"); ?>" aria-controls="accordion-<?php echo md5(get_sub_field("bezeichnung")); ?>" class="accordion-title accordionTitle js-accordionTrigger"><span><?php the_sub_field("bezeichnung"); ?></span></a>
              </dt>
             <dd class="accordion-content accordionItem is-collapsed" id="accordion-<?php echo md5(get_sub_field("bezeichnung")); ?>" aria-hidden="true">
               <?php the_sub_field("inhalt"); ?>

	
				
				
				<?php if(get_sub_field("linktyp") == "externer Link" && get_sub_field("externer_link")): ?>
					    	
					    	<p><a href="<?php the_sub_field("externer_link"); ?>" target="_blank" class="button  rounded white"><?php the_sub_field("linkbezeichnung"); ?></a></p>
					    	
					    	<?php elseif(get_sub_field("linktyp") == "interner Link" && get_sub_field("interner_link")): ?>
					    	
					    		<p><a href="<?php the_sub_field("interner_link"); ?>"   class="button  rounded white "><?php the_sub_field("linkbezeichnung"); ?></a></p>
					    	
					    	
					    	<?php elseif(get_sub_field("linktyp") == "Datei" && get_sub_field("datei")): ?>
					    	
					    		<p><a href="<?php the_sub_field("datei"); ?>"   class="button ispdf bordered white rounded  "><?php the_sub_field("linkbezeichnung"); ?></a></p>
					    	
					    	<?php endif; ?>
						


              </dd>
				
				
			

				 <?php endwhile; ?>  
				   
		
				
				     </dl>
          </div>
			<?php endif; ?>
			
			
            




             
                     
 





				</div>
			</div>



		</div>



			  
    </section>
			  <?php
				  
				       elseif(get_row_layout() == 'tab-component'):  ?>
			     
			         <section id="<?php echo (get_sub_field("anker") ? get_sub_field("anker") : sanitize_title(get_sub_field("headline"))); ?>"  class="<?php the_sub_field("hintergrund"); ?>">
	    <div class="row animated">
		 <?php if(get_sub_field("headline")): ?>
			<h2><?php the_sub_field("headline"); ?></h2>
		<?php endif; ?>
			    
			    
			    
	   
	              <?php if( have_rows('tabs') ): ?>
			    <div class="col-80 offset-10">
			 
			
	<ul class="tabs">	 
<?php	
	 	// loop through the rows of data
	  $i = 0;  while ( have_rows('tabs') ) : the_row();
	    
	    ?>
	    
	            

		<li class="tab-link<?php echo($i == 0 ? ' current' : ''); ?>" data-tabname="<?php the_sub_field("bezeichnung"); ?>" data-tab="tab-<?php echo md5(get_sub_field("bezeichnung")); ?>"><?php the_sub_field("bezeichnung"); ?></li>
	
				 <?php $i++; endwhile; ?>  
	</ul>

			<?php endif; 
			
	             if( have_rows('tabs') ): 

	  $i = 0;  while ( have_rows('tabs') ) : the_row();
	    ?>
	    
	    
	    <div id="tab-<?php echo md5(get_sub_field("bezeichnung")); ?>" class="tabbed-content<?php echo($i == 0 ? ' current' : ''); ?>">
		 <?php the_sub_field("inhalt"); ?>

	<?php if(get_sub_field("link") && get_sub_field("linkbezeichnung")): ?>
				  <div class="button-group space-top tal">
						<a href="<?php the_sub_field("link"); ?>" class="button mt rounded white opacity"><?php the_sub_field("linkbezeichnung"); ?></a>
					</div>
				
				<?php endif; ?> 			
	</div>
	
	               
				
				
			

				 <?php $i++;  endwhile; 
					  endif; ?>
			
			
            




             
                     
 



		</div>
		</div>



			  
    </section>
			  <?php


			     elseif(get_row_layout() == 'list'): ?>
			     
			         <section  id="<?php echo (get_sub_field("anker") ? get_sub_field("anker") : sanitize_title(get_sub_field("headline"))); ?>" class="<?php the_sub_field("hintergrund"); ?><?php echo (get_sub_field("bild_oder_zufalliger_mitarbeiter") !== "Bild") ? ' nopaddbot has-person-image': ''; ?>">
	    <div class="row animated listcomp">
		    <h2><?php the_sub_field("headline"); ?></h2>
		   
		    <div class="col col-50 fr">
			    <?php if( have_rows('liste') ): ?>
			    
			    <ul class="tickbox<?php echo (get_sub_field("bild_oder_zufalliger_mitarbeiter") ? "" : " nopadd"); ?>">
<?php	
	 	// loop through the rows of data
	    while ( have_rows('liste') ) : the_row();
	    
	    ?>
				    <li>
				    	<div class="list-icon">
					    	<span class="icon tick"></span>
				    	</div>
				    	<div class="list-content"><?php the_sub_field("bezeichnung"); ?></div>
					</li>
				 
				 <?php endwhile; ?>  
				   
			</ul>
				<?php if(get_sub_field("link") && get_sub_field("linkbezeichnung")): ?>
				  <div class="button-group space-top tal">
						<a href="<?php the_sub_field("link"); ?>" class="button rounded primary"><?php the_sub_field("linkbezeichnung"); ?></a>
					</div>
				
				<?php endif; ?>
			<?php endif; ?>
		    </div>
		    
		     <div class="col col-50 tcenter">
			   
			   <?php if(get_sub_field("bild_oder_zufalliger_mitarbeiter") !== "Bild"): 
			   
			   $args = array(
    'post_type'=>'ansprechpartner', 
    'orderby'=>'rand', 
    'posts_per_page'=>'1'
  );

  $testimonials=new WP_Query($args);

  while ($testimonials->have_posts()) : $testimonials->the_post(); 

?>

   <?php the_post_thumbnail("full"); ?>
    
    <?php

endwhile; wp_reset_postdata();


?>



			   
			   
			   <?php else: ?>
			   		<p><?php $img = get_sub_field("Bild"); 
						echo '<img src="' . $img["url"] . '" class="fit-80" alt="signvision.ch – ' . get_sub_field("headline") . '">';?>
					</p>
								
								
				<?php endif; ?>
		    </div>
		</div>
    </section>
			     
			
				<?php 
					
					 elseif(get_row_layout() == 'support-box'): ?>     
			     
			     
			      <section  id="<?php echo (get_sub_field("anker") ? get_sub_field("anker") : sanitize_title(get_sub_field("headline"))); ?>" class=" <?php the_sub_field("hintergrund"); ?><?php echo (get_sub_field("abstand_bereinigen") ? ' cleaner' : ''); ?>">
	    <div class="row animated">
					    <h2><?php the_sub_field("headline"); ?></h2>
		    <div class="row">
			    
			     <div class=" col-90 offset-5 carousel-component-three support-boxes">
			    	  <?php if( have_rows('boxen') ): ?>
			    
			 <ul class="primary-three-col-comp">		
<?php	
	 	// loop through the rows of data
	    while ( have_rows('boxen') ) : the_row();
	    
	    ?>
			   
				    
				
				    
				 
				     <li class="c ">
					    	<figure><?php $img = get_sub_field("bild"); 
						echo '<img src="' . $img["url"] . '" class="fit-80" alt="signvision.ch – ' . get_sub_field("headline") . '">';?>

					    	</figure>
					    	<h3><?php the_sub_field("beschreibung"); ?></h3>
					    
					    	
					    	
						    	<a href="<?php the_sub_field("link"); ?>"  class="button rounded white  rounded"><?php the_sub_field("linkbezeichnung"); ?></a>
				    	
				    
				    	
				    	
				    </li>
				    
			<?php endwhile; ?>
			
			
			
			
				    				    
				    
				    
			    </ul>
			<?php endif; ?>    
		    </div>
			    
			    
		    </div>
	    </div>
        </section>




			    <?php
				       elseif(get_row_layout() == 'highlights'): ?>     



			     
			     
			      <section  id="<?php echo (get_sub_field("anker") ? get_sub_field("anker") : sanitize_title(get_sub_field("headline"))); ?>" class="primary">
	    <div class="row animated">
					    <h2><?php the_sub_field("headline"); ?></h2>
		    <div class="row">
			    
			     <div class=" col-90 offset-5 carousel-component-three office-brands">
			    	  <?php if( have_rows('highlights_loop') ): ?>
			    
			 <ul class="primary-three-col-comp">		
<?php	
	 	// loop through the rows of data
	    while ( have_rows('highlights_loop') ) : the_row();
	    
	    ?>
			   
				    
				
				    
				 
				     <li class="c ">
				    	<div class="col col-100">
					    	<figure><?php $img = get_sub_field("bild"); 
						echo '<img src="' . $img["url"] . '" class="fit-80" alt="signvision.ch – ' . get_sub_field("headline") . '">';?>

					    	</figure>
					    	<h3><?php the_sub_field("bezeichnung"); ?></h3>
					    	<?php if(get_sub_field("linktyp") == "externer Link"): ?>
					    	
					    	
					    		<a href="<?php the_sub_field("externer_link"); ?>" target="_blank" class="hoverlink"></a>
					    	<?php elseif(get_sub_field("linktyp") == "javascript"): 
						    	
						    	list($class, $name) = explode("|", get_sub_field("javascript"));
						    	
					    	?>
					    		<a href="" class="hoverlink <?php echo $class; ?>" data-caller="<?php echo $name; ?>"></a>
					    	<?php else: ?>
					    	
					    	<?php if($pos = strpos( get_sub_field("interner_link"), "#")): ?>
					    		<a href="<?php echo str_replace($menu[0]->url, "", get_sub_field("interner_link")); ?>"  class="hoverlink"></a>
					    	<?php else: ?>
					    		<a href="<?php echo  get_sub_field("interner_link"); ?>"  class="hoverlink"></a>
					    	
					    	
					    	<?php endif; ?>
					    	<?php endif; ?>
						    	<span  class="button rounded white  rounded">Mehr</span>
				    	</div>
				    	
				    </li>
				    
			<?php endwhile; ?>
				    				    
				    
				    
			    </ul>
			<?php endif; ?>    
		    </div>
			    
			    
		    </div>
	    </div>
        </section>




			    <?php
				    
				    
				    elseif(get_row_layout() == 'vorteile'): ?>
			         <section  id="<?php echo (get_sub_field("anker") ? get_sub_field("anker") : sanitize_title(get_sub_field("headline"))); ?>" class="<?php the_sub_field("hintergrund"); ?><?php echo (get_sub_field("abstand_bereinigen") ? ' clear' : ''); ?>">
		
					    <h2><?php the_sub_field("headline"); ?></h2>
				      
					    
			
					
					  <?php if( have_rows('vorteile_loop') ): ?>
			    
			  <div class="row mlr col-list animated">
					
<?php	
	 	// loop through the rows of data
	    while ( have_rows('vorteile_loop') ) : the_row();
	    
	    ?>
				    	<div class="col col-1-3">
						<div class="col-inner ">
				<figure class="icon-holder">
					<?php
								$img = get_sub_field("bild"); 
								echo '<img src="' . $img["url"] . '" class="fit-80" alt="signvision.ch – ' . get_sub_field("bezeichnung") . '">';
								?>
				</figure>
				<h3><?php the_sub_field("bezeichnung"); ?></h3>
				<p><?php the_sub_field("inhalt"); ?></p>
			</div></div>
				 
				 <?php endwhile; ?>  
				   
			
					</div>
			<?php endif; ?>
			
			
			
			
			
			    </section>




			
			     
			   <?php
		        
		    
		       elseif( get_row_layout() == 'calltoaction' ): ?>
			   		
			   		<?php
						$bgimg = get_sub_field("hintergrund"); 
						$logo = get_sub_field("logo"); 
						$link = get_sub_field("link"); 
						
					?>
		            <section class="call-to-action c">
			            <img src="<?php echo $bgimg["url"]; ?>">
					    <div class="text">
						    <div class="inner">
						   <p>
							   <?php the_sub_field("text"); ?>
						   </p>
							    <div class="logo-call">
								          <img src="<?php echo $logo["url"]; ?>">
							    </div>
							    
							    <div class="button-group space-top">
								    <a href="<?php echo $link["url"]; ?>" target="<?php echo $link["target"]; ?>" class="button circle arrow mt primary">a</a>
							    </div>
						    </div>
						</div>
				    </section>
					  
					
					
	          <?php 
		        
		    
		       elseif( get_row_layout() == 'footer-image' ): ?>
			   		
			   		<?php
						$bgimg = get_sub_field("hintergrund"); 
					?>
		            <section id="footer-img" data-bg="<?php echo $bgimg["url"]; ?>">
					    <div class="row">
						    <div class="col col-70 offset-15 teas white">
							    <h2><?php the_sub_field("headline"); ?></h2>
							    <?php the_sub_field("inhalt"); ?>
							    
							    <div class="button-group space-top">
								    <a href="<?php the_sub_field("link"); ?>" class="button rounded primary"><?php the_sub_field("linkbezeichnung"); ?></a>
							    </div>
						    </div>
						</div>
				    </section>
					  
					
					
	          <?php 
		       
		       elseif( get_row_layout() == 'aktuelles' ): ?>
			   		
			   		
			   		<section id="<?php echo (get_sub_field("anker") ? get_sub_field("anker") : sanitize_title(get_sub_field("headline"))); ?>" class="transform-no-bottom transform-white">
			   		 	<h2><?php the_sub_field("headline"); ?></h2>
					    
					
			   		 	<div class="row calculateHeight ">  	
				   		 	
				   		 	<?php
					   		 	if( get_sub_field('beitraege') ):

					
								 	// loop through the rows of data
								    foreach(get_sub_field('beitraege') as $post) :  setup_postdata($post);
					
										?>
										
										<div class="col col-1-3 ">	<div class="news <?php echo (get_field("top-news") ? (has_post_thumbnail() ? ' hasImage top' : ' top') :  (has_post_thumbnail() ? ' hasImage breaking' : ' special')); ?>">
	<span class="date"><?php echo get_the_date(); ?></span>
					
					<a href="<?php the_permalink(); ?>" class="news-hover"></a>			
					
					<?php if(has_post_thumbnail()): ?>
					
						<figure>
						<?php the_post_thumbnail(); ?>
						</figure>
					
					<?php endif; ?>	
						
					<h3><?php the_title(); ?></h3>
											<?php the_excerpt(); ?>
											<span class="cat"><?php $cats = []; foreach((get_the_category()) as $category){
        $cats[] = $category->name;
        } echo implode(", ", $cats);	?></span>

				</div></div>
										</div>
										
										<?php
									endforeach;  wp_reset_postdata();
								endif; ?>
							
			   		 	</div>
			   		</section>
					  
					
					 <?php 
						 
						 
						  elseif( get_row_layout() == 'team' ): ?>
			   		
			   		
			   		<section  id="<?php echo (get_sub_field("anker") ? get_sub_field("anker") : sanitize_title(get_sub_field("headline"))); ?>" class="<?php the_sub_field("hintergrund"); ?>">
			   		 	<h2><?php the_sub_field("headline"); ?></h2>
					    
					    
			   		 	<div class="row">  	
				   		 	<div class="team-component">
		      				   		 	<?php
					   		 	if( get_sub_field('personen') ):
$uniq = uniqid("persons");
					$i = 1;
								 	// loop through the rows of data
								    foreach(get_sub_field('personen') as $post) :  setup_postdata($post);
					
										?>
										<div class="col col-1-3">
			      
				<figure class="person c"><?php the_post_thumbnail("large"); ?></figure>
				<small><?php the_field("kategorie"); ?></small>
				<h3><?php the_title(); ?></h3>
					<p><?php the_field("bezeichnung"); ?></p>
				
					<p><?php the_field("telefon"); ?> / <a href="mailto:<?php the_field("e-mail"); ?>">Mail</a></p>
				
		      </div>



																			
										<?php
											
									
											
											
												
											
									$i ++; endforeach;  wp_reset_postdata(); ?>
									
											
											 	
											 						    	
											 
								<?php endif; ?>
				   		 	</div>
			   		 	</div>
			   		</section>
					  
					
					 <?php 
		         elseif( get_row_layout() == 'zitat' ):
		         
		        ?>
					
					<section class="<?php the_sub_field("hintergrund"); ?>  quote">
	<div class="row">
		<blockquote><em><?php the_sub_field("zitat"); ?></em><small><?php the_sub_field("name"); ?></small></blockquote>
	</div>
	
</section>
	    


	          <?php 
		          
		            elseif( get_row_layout() == 'logos' ):
		         
		         
		     
		         
		      
		         
	?>
	
	
	  <section id="clients" class=" ">
	    <div class="row animated ">
			   		 <?php if(get_sub_field("headline")): ?>	<h2><?php the_sub_field("headline"); ?></h2><?php endif; ?>
		
<?php
		         if( get_sub_field('logos_loop') ):

	 	// loop through the rows of data
	   $images =  get_sub_field('logos_loop');
	   
	   foreach($images as $image):
	
	    ?>
	          
	          
	          
	          
	          
    
   
				
				
				<div class="col col-1-4">
					<figure class="client-image">
						<?php
							
							
								if(isset(get_post_meta($image["ID"])["_wpmf_gallery_custom_image_link"])): 
							
							echo '<a href="' . get_post_meta($image["ID"])["_wpmf_gallery_custom_image_link"][0] . '" target="_blank">';
								echo '<img src="' . $image["url"] . '">';
								
								echo '</a>';
								
								else:
								echo '<img src="' . $image["url"] . '">';
								
								endif;
								?>
					
					</figure>
				</div>
				
			
				
				<?php endforeach;  endif;?>
			
		</div>
     </section>
     <?php



		         elseif( get_row_layout() == 'facts' ):
		         
		         
		     
		         if( have_rows('facts_loop') ):
		         
		         $cols = 0;
	    while ( have_rows('facts_loop') ) : the_row();
	    	$cols++;
	    endwhile;
		         
	?>
	
	
	  <section id="<?php echo (get_sub_field("anker") ? get_sub_field("anker") : sanitize_title(get_sub_field("headline"))); ?>" class="fact-list ">
	    <div class="row animated ">
			   		 	<h2><?php the_sub_field("headline"); ?></h2>
			<div class="col <?php echo ($cols == 3 ? 'col-90 offset-5' : 'col-80 offset-10'); ?>">

<?php
	 	// loop through the rows of data
	    while ( have_rows('facts_loop') ) : the_row();
	    
	    ?>
	          
	          
	          
	          
	          
    
   
				
				
				<div class="col col-1-<?php echo $cols; ?><?php echo (get_sub_field("highlight") ? ' primary-color' : ''); ?>">
					  <h3><span><?php the_sub_field("bezeichnung"); ?></span></h3>
						<?php the_sub_field("inhalt"); ?>
				</div>
				
			
				
				<?php endwhile; ?>
			</div>
		</div>
     </section>
     <?php endif; ?>
	          
	          <?php
		        
		         elseif( get_row_layout() == 'content_transform' ):
		         
		         
		       
		         $uniqid = uniqid(time());
		         
		         $colorclass = (get_sub_field("hintergrund") == "white" || get_sub_field("hintergrund") == "odd") ? 'primary' : 'white bordered';
		         $colorclass2 = (get_sub_field("hintergrund") == "white" || get_sub_field("hintergrund") == "odd") ? 'primary' : 'white';
		         
		         
		         if($nachfolgende_elemente_erst_bei_klick_sichtbar){
			         ?>
			         
			             <section data-show-js="show-more-<?php echo $nachfolgende_elemente_id; ?>" id="<?php echo (get_sub_field("anker") ? get_sub_field("anker") : sanitize_title(get_sub_field("headline"))); ?>" class="transform colored-<?php the_sub_field("hintergrund"); ?><?php echo (get_sub_field("gerader_abschluss") ? ' onlyBottom' : ''); ?><?php echo (get_sub_field("gerader_abschluss_oben") ? ' onlyTop' : ''); ?> hidden">
		<?php
			         
		         }else{
			         ?>
			         
			             <section id="<?php echo (get_sub_field("anker") ? get_sub_field("anker") : sanitize_title(get_sub_field("headline"))); ?>" class="transform colored-<?php the_sub_field("hintergrund"); ?><?php echo (get_sub_field("gerader_abschluss") || get_sub_field("nachfolgende_elemente_erst_bei_klick_sichtbar") ? ' onlyBottom' : ''); ?><?php echo (get_sub_field("gerader_abschluss_oben") ? ' onlyTop' : ''); ?>">
		
			         <?php
		         }
		         ?>
	        
	       

		
		<?php if(get_sub_field("headline")): ?>
			<h2><?php the_sub_field("headline"); ?></h2>
		<?php endif; ?>
	    <div class="row mlr animated">
		    
		    
		    <div class="carousel-component">
			    
			    <ul>
				    
				    <li class="c">
				    <?php if(get_sub_field("bildposition")  == "left"): ?>
				    	<div class="col col-45">
					    	<figure>
					    	<?php
								$img = get_sub_field("bild"); 
								echo '<img src="' . $img["url"] . '" alt="signvision.ch – ' . get_sub_field("headline") . '">';
								?>
					    	</figure>
				    	</div>
				    	<div class="col col-50  offset-5">
				    	<?php else: ?>
				    	
				    	<div class="col col-45 fr">
					    	<figure>
					    		
					    		<?php
								$img = get_sub_field("bild"); 
								echo '<img src="' . $img["url"] . '" alt="signvision.ch – ' . get_sub_field("headline") . '">';
								?>
					    	</figure>
				    	</div>
				    	<div class="col col-50  offset-r-5">
				    	<?php endif; ?>
				    	
					    	
					    	<h3><small><?php the_sub_field("subline"); ?></small><?php the_sub_field("textline"); ?></h3>
					    	<?php the_sub_field("inhalt"); ?>
					    	
					    	<?php if(get_sub_field("mehr_inhalt")): ?>
					    		<?php if(get_sub_field("text_interner_link_oder_externer_link") == "Text"): ?>
					    		<div class="show-more" id="show-more-<?php echo $uniqid; ?>">
						    		<?php the_sub_field("mehr_inhalt_text"); ?>
					    		</div>
					    		<div class="button-group space-ml-top">
							    	<a href="#show-more-<?php echo $uniqid; ?>" class="button rounded <?php echo $colorclass; ?> js-show-more" data-read-more="Mehr dazu" data-read-less="Weniger anzeigen">Mehr dazu</a>
							    	<?php if(get_sub_field("weiterer_link_beschreibung") && get_sub_field("weiterer_link_beschreibung")): ?>
							    	<a href="<?php the_sub_field("weiterer_link"); ?>" class="button rounded ml <?php echo $colorclass2; ?>"><?php the_sub_field("weiterer_link_beschreibung"); ?></a>
							    	<?php endif; ?>
							    	<!--a href="" class="button rounded white ml bordered">Zu den Branchen</a-->
						    	</div>
					    	
					    	
								<?php elseif(get_sub_field("text_interner_link_oder_externer_link") == "interner Link" && get_sub_field("interner_link")): ?>
						    		<div class="button-group space-ml-top">
								    	<a href="<?php the_sub_field("interner_link"); ?>" class="button rounded <?php echo $colorclass; ?>"><?php the_sub_field("linkbezeichnung"); ?></a>
								    	<!--a href="" class="button rounded white ml bordered">Zu den Branchen</a-->
							    	</div>
								<?php elseif(get_sub_field("text_interner_link_oder_externer_link") == "externer Link" && get_sub_field("externer_link")): ?>
						    		<div class="button-group space-ml-top">
								    	<a href="<?php the_sub_field("externer_link"); ?>" target="_blank" class="button rounded <?php echo $colorclass; ?>"><?php the_sub_field("linkbezeichnung"); ?></a>
								    	<!--a href="" class="button rounded white ml bordered">Zu den Branchen</a-->
							    	</div>
								<?php endif; ?>
					    	
					    	
					    	
					    	
					    	
					    	<?php endif; ?>
					    	
				    	</div>
				    	
				    </li>	 				    
				    
				    
				    
			    </ul>
			    
			    
			    <?php 
				    
				      if(get_sub_field("nachfolgende_elemente_erst_bei_klick_sichtbar")){
			         $nachfolgende_elemente_erst_bei_klick_sichtbar = true;
			         $nachfolgende_elemente_id =  $uniqid = uniqid(time().'nachfolgende_elemente_erst_bei_klick_sichtbar');
			         
			         ?>
			         <div class="button-group space-top">
			         <a href="#" data-trigger="show-more-<?php echo $nachfolgende_elemente_id; ?>" class="button rounded dark bordered js-show-more-by-data" data-read-more="Alle Module anzeigen" data-read-less="Weniger Module anzeigen">Alle Module anzeigen</a>
			         </div>
			         <?php
		         }
				    
				    ?>
			    
		    </div>
		    
		    
		    
		    
		    
	    </div>
	    </section>
					  
					
					
    
	
	        		
	        <?php 
		        
		        
		        

		        
		        
		        
		        
		        
		        
		        
		        endif;
	
	    endwhile;
	
	else :
	
	    // no layouts found
	
	endif;
	
	?>
	
	     
            <?php endwhile; ?>
   
   
    
    <?php get_footer();?>