<?php
	


	
	function wplink_tiny_mce_init()
{
 ?>
    <script type="text/javascript">
    jQuery(function () {
       jQuery('input#wp-link-target').prop('checked',true);
    });
</script>    
<?php
}

add_action( 'before_wp_tiny_mce', 'wplink_tiny_mce_init' );


function wpdocs_theme_add_editor_styles() {
    add_editor_style( 'custom-editor-style.css' );
}
add_action( 'admin_init', 'wpdocs_theme_add_editor_styles' );




	
	function ACF_flexible_content_collapse() {
        ?>
        <style id="acf-flexible-content-collapse">.acf-flexible-content .acf-fields { display: none; }</style>
        <script type="text/javascript">
            jQuery(function($) {
                $('.acf-flexible-content .layout').addClass('-collapsed');
                $('#acf-flexible-content-collapse').detach();
            });
        </script>
        <?php
    }

    add_action('acf/input/admin_head', 'ACF_flexible_content_collapse');
	
	
	add_filter('relevanssi_content_to_index', 'add_extra_content', 10, 2);
add_filter('relevanssi_excerpt_content', 'add_extra_content', 10, 2);
function add_extra_content($content, $post) {
  
  
    // check if the flexible content field has rows of data
	if( have_rows('pagebuilder', $post->ID) ):
	
	 	// loop through the rows of data
	    while ( have_rows('pagebuilder', $post->ID) ) : the_row();
	
			if( get_row_layout() == 'teaser' ):  $content .= get_sub_field("teaser"); 
			elseif( get_row_layout() == 'content_transform' ):  $content .= get_sub_field("inhalt"); 
			elseif( get_row_layout() == 'statement' ):  $content .= get_sub_field("statement"); 
			elseif( get_row_layout() == 'text_zentriert' ):  $content .= get_sub_field("teaser"); 
			elseif( get_row_layout() == 'text' ):  $content .= get_sub_field("inhalt"); 
			elseif( get_row_layout() == 'zitat' ):  $content .= get_sub_field("zitat"); 
			elseif( get_row_layout() == 'tab-component' ): 
			
			
			  if( have_rows('tabs') ): 

	 while ( have_rows('tabs') ) : the_row();
	    $content .= get_sub_field("inhalt"); 
	  endwhile; 
					  endif; 
			
				
				
			elseif( get_row_layout() == 'accordion-component' ): 
			
			
			  if( have_rows('accordion') ): 

	 while ( have_rows('accordion') ) : the_row();
	    $content .= get_sub_field("inhalt"); 
	  endwhile; 
					  endif; 
			
				
		        

			endif;

		endwhile;

	endif;
  
    return $content;
}



	function enable_extended_upload ( $mime_types =array() ) {

   // The MIME types listed here will be allowed in the media library.
   // You can add as many MIME types as you want.
   $mime_types['exe']  = 'application/exe'; 

   return $mime_types;
} 
add_filter('upload_mimes', 'enable_extended_upload');


	
	add_filter('upload_mimes', 'kb_add_mimes');

function kb_add_mimes ( $kb_all_mimes=array() ) {
  $kb_all_mimes['vcf'] = 'text/x-vcard';
  return $kb_all_mimes;
}
add_filter( 'wp_get_nav_menu_items', 'prefix_nav_menu_classes', 10, 3 );

function prefix_nav_menu_classes($items, $menu, $args) {
    _wp_menu_item_classes_by_context($items);
    return $items;
}

function wp_get_menu_array($current_menu) {

 
    $array_menu = wp_get_nav_menu_items($current_menu);
    $menu = array();
    foreach ($array_menu as $m) {
        if (empty($m->menu_item_parent)) {
            $menu[$m->ID] = array();
            $menu[$m->ID]['id']      =   $m->ID;
            $menu[$m->ID]['name']       =   $m->title;
            $menu[$m->ID]['url']         =   $m->url;
            $menu[$m->ID]['classes']         =  implode(" ", $m->classes);
            $menu[$m->ID]['children']    =   array();
            
        }
    }
    $submenu = array();
    foreach ($array_menu as $m) {
        if ($m->menu_item_parent) {
            $submenu[$m->ID] = array();
            $submenu[$m->ID]['id']       =   $m->ID;
            $submenu[$m->ID]['name']    =   $m->title;
            $submenu[$m->ID]['classes']         =  implode(" ", $m->classes);
            $submenu[$m->ID]['url']  =   $m->url;
            
            $menu[$m->menu_item_parent]['children'][$m->ID] = $submenu[$m->ID];
        }
    }
    return $menu;
     
}




    add_theme_support( 'post-thumbnails' ); 
function register_my_menus() {
  register_nav_menus(
   array( 'header-menu' => __( 'Header Menu' )) );
}
add_action ('init', 'register_my_menus');

function redirect_search() {
	if (is_search() && !empty($_GET['s'])) {
		wp_redirect(home_url("/search/").urlencode(get_query_var('s')));
		exit();
	}
}
add_action('template_redirect', 'redirect_search' );
function new_excerpt_more( $more ) {

	return '';
}
add_filter('excerpt_more', 'new_excerpt_more');

function get_ID_by_slug($page_slug) {
    $page = get_page_by_path($page_slug);
    if ($page) {
        return $page->ID;
    } else {
        return null;
    }
}
function add_query_vars($aVars) {
$aVars[] = "filter_images"; // represents the name of the product category as shown in the URL
return $aVars;
}
 
// hook add_query_vars function into query_vars
add_filter('query_vars', 'add_query_vars');



function uri_segment($nr = 1){
		
	$urlArray = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$segments = explode('/', $urlArray);
	
	return $segments[$nr];
}


function remove_media_link( $form_fields, $post ) {

        unset( $form_fields['url'] );

              return $form_fields;

}
if (class_exists('MultiPostThumbnails')) {
    new MultiPostThumbnails(
        array(
            'label' => 'Beitragsbild 2',
            'id' => 'secondary-image',
            'post_type' => 'page'
        )
    );
    
     new MultiPostThumbnails(
        array(
            'label' => 'Beitragsbild 3',
            'id' => 'third-image',
            'post_type' => 'page'
        )
    );
}

add_filter( 'attachment_fields_to_edit', 'remove_media_link', 10, 2 );





//	Reduce nav classes, leaving only 'current-menu-item'
function nav_class_filter( $var ) {
return is_array($var) ? array_intersect($var, array('current-menu-item')) : '';
}
#add_filter('nav_menu_css_class', 'nav_class_filter', 100, 1);
//	Add page slug as nav IDs

function nav_id_filter( $menu_id, $item, $args, $depth  ) {

return 'nav-'.cleanname($item->title);
}


function cleanname($v) {
$v = preg_replace('/[^a-zA-Z0-9s]/', '', $v);
$v = str_replace(' ', '-', $v);
$v = strtolower($v);
return $v;
}




function cleanInput($input) {
 
  $search = array(
    '@<script[^>]*?>.*?</script>@si',   // Strip out javascript
    '@<[\/\!]*?[^<>]*?>@si',            // Strip out HTML tags
    '@<style[^>]*?>.*?</style>@siU',    // Strip style tags properly
    '@<![\s\S]*?--[ \t\n\r]*>@'         // Strip multi-line comments
  );
 
    $output = preg_replace($search, '', $input);
    return $output;
  }
  
function sanitize($input) {
    if (is_array($input)) {
        foreach($input as $var=>$val) {
	        if($var == "bemerkungen"){
	            $output[$var] = ($val);
		     }  else{
			        $output[$var] = sanitize($val);
		       } 
        }
        
    }
    else {
        if (get_magic_quotes_gpc()) {
            $input = stripslashes($input);
        }
        $input  = cleanInput($input);
        $output = ($input);
    }
    return $output;
}

function isValidEmail($email)
{
       //Perform a basic syntax-Check
       //If this check fails, there's no need to continue
       if(!filter_var($email, FILTER_VALIDATE_EMAIL))
       {
               return false;
       }

       //extract host
       list($user, $host) = explode("@", $email);
       //check, if host is accessible
       if (!checkdnsrr($host, "MX") && !checkdnsrr($host, "A"))
       {
               return false;
       }

       return true;
}



add_action( 'wp_ajax_glowaczcontact', 'c7_wp_ajax_function' );
add_action( 'wp_ajax_nopriv_glowaczcontact','c7_wp_ajax_function' );
function c7_wp_ajax_function(){
global $captcha;

if ( !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'  && $_SERVER['REQUEST_METHOD'] === 'POST'){
 
header('Content-type: application/json');


 $errorfields = array();
 
 $data = sanitize($_POST);
 unset($_POST, $data["action"], $data["nonce"]);
 $send = array();
 $required = array("name", "vorname", "email", "telefon", "strasse", "plz-ort");
  
 
 foreach($data as $key => $value){
	 
	 if(in_array($key, $required) && empty($value)){
		 $errorfields[$key] = true;
	 }else{
		 
		 $send[$key] = $value;
	 }
 }
 
 
if (! isValidEmail($data["email"])){
  $errorfields["email"] = true;
}

$answer = $data["captcha"];

if ($answer !== null) {
    if ($captcha->checkAnswer($answer)){}else{
     
       $errorfields["captcha"] = true;

    }
}


	

if($errorfields){
	$result = array("status" => "error", "fields_missing" => $errorfields);
	 exit(json_encode($result, JSON_HEX_TAG));
 
}else{
	$result = array("status" => "success");
	
	

	
	$html = '<html>
<head>
   <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
   <title>Neue Kontaktanfrage auf glowacz.de</title>
</head>
<body style="font-family: Verdana, Arial; font-size: 12px;">';
	
	
	$html .= "Neue Kontaktanfrage auf glowacz.de<br>";
	$html .= "---------------------------------<br><br>";
	unset($send["captcha"]);
 
	foreach($send as $k => $v){
		if($k !== "bemerkungen"){
		$html .= "<b>".ucfirst($k)."</b>: ".$v."<br>";
			
		}
	}
	if($data["bemerkungen"]){
		$html .= "<br><b>Bemerkungen:</b> <br><br>".nl2br($data["bemerkungen"])."<br>";
	}
	
	$html .= "</body></html>";
			
	    $subject = "Neue Kontaktanfrage auf glowacz.de von ".$send["email"];
		$to = 'post@kreativ-wolke.de';

		$headers   = array();
		$headers[] = "MIME-Version: 1.0";
		$headers[] = "Content-type: text/html; charset=utf-8";
		$headers[] = "From: ".$send["email"];
		$headers[] = "Reply-To: glowacz.de <info@glowacz.de>";
		$headers[] = "Subject: {$subject}";
		
		mail($to, $subject, $html, implode("\r\n", $headers));
		
		exit(json_encode($result, JSON_HEX_TAG));
		 

}
 

 

}
}

add_filter("post_gallery", "fix_my_gallery_wpse43558",10,2);


function fix_my_gallery_wpse43558($output, $attr) {
    global $post;

    static $instance = 0;
    $instance++;


   if ( isset( $attr['orderby'] ) ) {
        $attr['orderby'] = sanitize_sql_orderby( $attr['orderby'] );
        if ( !$attr['orderby'] )
            unset( $attr['orderby'] );
    }

    extract(shortcode_atts(array(
        'order'      => 'ASC',
        'orderby'    => 'menu_order ID',
        'id'         => $post->ID,
        'itemtag'    => 'dl',
        'icontag'    => 'dt',
        'captiontag' => 'dd',
        'columns'    => 3,
        'size'       => 'medium',
        'include'    => '',
        'exclude'    => ''
    ), $attr));

    $id = intval($id);
    if ( 'RAND' == $order )
        $orderby = 'none';

    if ( !empty($include) ) {
        $include = preg_replace( '/[^0-9,]+/', '', $include );
        $_attachments = get_posts( array('include' => $include, 'post_status' => 'inherit', 'post_type' => 'attachment', 'post_mime_type' => 'image', 'order' => $order, 'orderby' => $orderby) );

        $attachments = array();
        foreach ( $_attachments as $key => $val ) {
            $attachments[$val->ID] = $_attachments[$key];
        }
    } elseif ( !empty($exclude) ) {
        $exclude = preg_replace( '/[^0-9,]+/', '', $exclude );
        $attachments = get_children( array('post_parent' => $id, 'exclude' => $exclude, 'post_status' => 'inherit', 'post_type' => 'attachment', 'post_mime_type' => 'image', 'order' => $order, 'orderby' => $orderby) );
    } else {
        $attachments = get_children( array('post_parent' => $id, 'post_status' => 'inherit', 'post_type' => 'attachment', 'post_mime_type' => 'image', 'order' => $order, 'orderby' => $orderby) );
    }

    if ( empty($attachments) )
        return '';

    if ( is_feed() ) {
        $output = "\n";
        foreach ( $attachments as $att_id => $attachment )
            $output .= wp_get_attachment_link($att_id, $size, true) . "\n";
        return $output;
    }

    $itemtag = tag_escape($itemtag);
    $captiontag = tag_escape($captiontag);
    $columns = intval($columns);
    $itemwidth = $columns > 0 ? floor(100/$columns) : 100;
    $float = is_rtl() ? 'right' : 'left';

    $selector = "gallery-{$instance}";

    $gallery_style = $gallery_div = '';
    if ( apply_filters( 'use_default_gallery_style', true ) )
      
    $size_class = sanitize_html_class( $size );
    $gallery_div = "<div id='$selector' class='c clearfix clear gallery-component galleryid-{$id} gallery-columns-{$columns} gallery-size-{$size_class}'>";
    $output = apply_filters( 'gallery_style', $gallery_style . "\n\t\t" . $gallery_div );

    $counter = 1;
    foreach ( $attachments as $id => $attachment ) {
        $link = isset($attr['link']) && 'file' == $attr['link'] ? wp_get_attachment_image($id, $size, false, false) : wp_get_attachment_image($id, $size, true, false);
if ($counter % 3 == 0) {
        $output .= "<div class='col col-1-3'><figure class='client-image'>";
        
        }elseif ($counter % 1 == 0) {
        $output .= "<div class='col col-1-3'><figure class='client-image'>";
        
        }else{
	      $output .= "<div class='col col-1-3'><figure class='client-image'>";
  
        }
        $output .= "$link";
      
        $output .= "</figure></div>";
        
        
        $counter++;
        
    }

 
    $output .= "</div>\n";
    return $output;
}


