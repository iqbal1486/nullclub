<?php get_header("single");?>




    
    <section class=" odd">
	    	    
	    <div id="newsArchive">
	    <div class="row ">
		    <div id="category-menu">
			    <ul>
					    <?php $categories =  wp_list_categories( array(
					        'orderby'    => 'name',
					        'show_option_all' => 'Alle',
					        'title_li' => '',
					        'echo' => false,
					        'show_count' => false,
					    ) );
					    
					    
					    
					    
					    
if(strpos($categories,'current-cat') == false) { // check if the class exists
    // add the class to the All item if it doesn't exist
    $categories = str_replace('cat-item-all', 'cat-item-all current-cat', $categories);
}
				
				echo $categories; 	    
					    
					     ?> 
					</ul>
		    	<h1>Blog</h1>
		    </div>
<div class="row">



      <?php while ( have_posts() ) : the_post();?>
      
      
      
      <?php if( get_field('gallery') ): ?>
			 
     <div class="col-80 offset-10">
				 <div class="gallery dark"><ul class="owl-carousel owl-theme">
<?php	
	 	// loop through the rows of data
	    foreach(get_field("gallery") as $img): ?>
	    
	  
		  <li><img src="<?php echo $img["url"]; ?>"></li>						
		  
    <?php endforeach; ?>
				 </ul><p>&nbsp;</p></div>
				 

<?php else: ?>

     <div class="col-60 offset-20">
	<figure class="post-image"><?php the_post_thumbnail("large"); ?></figure>
     </div>
	<?php endif; ?><div class="col-60 offset-20">
	<h2><small><?php $cats = []; foreach((get_the_category()) as $category){
			
		
        $cats[] = $category->name;
        } echo implode(", ", $cats);	?></small><?php the_title(); ?></h2>
	
	
	
	<?php the_content(); ?>
	
	<p class="center"><a href="/blog" class="button odd small back-to-blog mt"> Zurück zur Übersicht</a></p>
	

      
    <?php endwhile; ?>
   
</div>
</div></div></section>
    
    <?php get_footer();?>
   