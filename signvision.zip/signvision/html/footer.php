
     <footer>
	    <div class="row">
		    <div class="col col-100">
			    <div class="row mw">
				 
				   
				    <div class="col col-25">
					    <h3><span>Unternehmen</span></h3>

					    <p>4net AG<br>
					    Wehrstrasse 2<br>CH-9015 St. Gallen</p>
					    <p>+41 71 314 22 50<br><a href="mailto:info@4net.ch">info[at]4net.ch</a></p>
					    
					    <div class="social-icons"><a href="http://www.linkedin.com/company/4net-ag" target="_blank" class="nobord"><img src="static/media/linkedin.png" width="32" height="32" alt=""></a> <a href="http://www.xing.com/companies/4netag"  class="nobord mleft20" target="_blank"><img src="static/media/xing.png"  width="32" height="32" alt=""></a></div>
					</div>
					 
				   
				    <div class="col col-25">
					    <h3><span>technologie





</span></h3>	<p>
							<a href="">Microsoft Office 365</a><br>
							<a href="">Hosted Microsoft Dynamics CRM</a><br>
							<a href="">Virtual Datacenter</a>
						</p>
					    	<!--ul class="news-list-footer">
								<li><a href="">Hallo Welt, hier bin ich <span>Unternehmen</span></a></li>
								<li><a href="">Das Neuste auf dem Markt <span>Technologie</span></a></li>
							</ul-->
					</div>
					
					 <div class="col col-25 primary-color">
					    <h3><span>Helpdesk</span></h3>
						<p>
							<span class="icon phone primary small"></span> <span class="txt">+41 (0)71 314 22 55</span><br>
							<span class="icon mail primary small"></span> <a href="mailto:info@4net.ch" class="txt">info[at]4net.ch</a><br>
							<span class="icon desktop primary small"></span> <a href="" class="txt">Fernwartung</a>
						</p>
							
							<p>Montag bis Freitag:<br>
								07.30 - 12.00<br>
								13.00 - 17.30</p>
					    
					</div>
					 
					 <div class="col col-25">
					    <h3><span>Kundenbereich</span></h3>
						<p>
							<a href="">Benutzer-Anleitungen</a><br>
							<a href="">Login 4net Workspace</a><br>
							<a href="">Outlook Web Access</a>
						</p>
							
						<form method="get" class="quick-search" action="">
							<input type="text" class="form-element rounded border white" value="">
							<button type="submit">OK</button>
							
						</form>	
					    
					</div>
					
					
					
					
					 
			    </div>
			    <hr>
			    <div class="row mw copyright">
			    <div class="col col-25">
					<p>© 4net 2018</p>
				</div>
				
				<div class="col col-25">
					<p><a href="" class="copyright-link">Impressum</a><a href="" class="copyright-link">Disclaimer</a></p>
				</div>
					 
			    </div>  
				   					
					
					
					
					 
			    </div>
			  
			   
			</div>
		    <div class="offset-5"></div>
		</div>
    </footer>

  <span id="backtotop"></span>
       
               
   
    
    			
		<script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
		<script src="static/js/app-min.js"></script>
		<script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAYzg-IsGtXcTia3cu6i8EIKvyN2B98qwY&callback=initMap"></script>
		
		   <script>
      function initMap() {
	      
	      if($"#map").length > 0){ 
	        var uluru = {lat: -25.363, lng: 131.044};
	        
	        var mapOptions = {
                    // How zoomed in you want the map to start at (always required)
                    zoom: 12,

                    // The latitude and longitude to center the map (always required)
                    center: uluru, // New York

                    // How you would like to style the map. 
                    // This is where you would paste any style found on Snazzy Maps.
                    styles:[{"featureType":"water","elementType":"geometry","stylers":[{"color":"#e9e9e9"},{"lightness":17}]},{"featureType":"landscape","elementType":"geometry","stylers":[{"color":"#f5f5f5"},{"lightness":20}]},{"featureType":"road.highway","elementType":"geometry.fill","stylers":[{"color":"#ffffff"},{"lightness":17}]},{"featureType":"road.highway","elementType":"geometry.stroke","stylers":[{"color":"#ffffff"},{"lightness":29},{"weight":0.2}]},{"featureType":"road.arterial","elementType":"geometry","stylers":[{"color":"#ffffff"},{"lightness":18}]},{"featureType":"road.local","elementType":"geometry","stylers":[{"color":"#ffffff"},{"lightness":16}]},{"featureType":"poi","elementType":"geometry","stylers":[{"color":"#f5f5f5"},{"lightness":21}]},{"featureType":"poi.park","elementType":"geometry","stylers":[{"color":"#dedede"},{"lightness":21}]},{"elementType":"labels.text.stroke","stylers":[{"visibility":"on"},{"color":"#ffffff"},{"lightness":16}]},{"elementType":"labels.text.fill","stylers":[{"saturation":36},{"color":"#333333"},{"lightness":40}]},{"elementType":"labels.icon","stylers":[{"visibility":"off"}]},{"featureType":"transit","elementType":"geometry","stylers":[{"color":"#f2f2f2"},{"lightness":19}]},{"featureType":"administrative","elementType":"geometry.fill","stylers":[{"color":"#fefefe"},{"lightness":20}]},{"featureType":"administrative","elementType":"geometry.stroke","stylers":[{"color":"#fefefe"},{"lightness":17},{"weight":1.2}]}]
                };


var mapElement = document.getElementById('map');

                // Create the Google Map using our element and options defined above
                var map = new google.maps.Map(mapElement, mapOptions);

                // Let's also add a marker while we're at it
                var marker = new google.maps.Marker({
                    position: new google.maps.LatLng(uluru.lat, uluru.lng),
                    map: map,
                });

      }}
    </script>
    
		<script src="static/js/kreativwolke-min.js"></script>
		
		
		
 


  </body>
</html>