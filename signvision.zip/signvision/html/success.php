<?php require 'header.php'; ?>
      
      

      <div id="stage">
			
			<div id="caption-holder">
				<div id="transformated-caption">
					<span>bluesign<br>technologies ag</span>
					
				</div>
			</div>
			
			
			<div id="stage-image">
				<img src="static/media/placeholders/bluesign.jpg">
			</div>
			
		</div>
    
    
    
    
    <section class="teas has-breadcrumb">
	    
	    <div class="row">
		    
		    <div class="col col-100">
		    <nav class="kw-breadcrumb-menu">
   <a href="/" class="kw-breadcrumb-menu__home"></a>
   <div class="kw-breadcrumb-menu__item">
      <div class="kw-breadcrumb-menu__block has-sub js-toggle-breadcrumb">
         <div class="kw-breadcrumb-menu__title"><span>Referenzen</span></div>
         <div class="kw-breadcrumb-menu__dropdown">
            <ul>
               <li class="is-active"><a href=""><span>Case Story bluesign 1</span></a></li>
               <li><a href=""><span>Case Story bluesign 2</span></a></li>
               <li><a href=""><span>Case Story bluesign 3</span></a></li>
            </ul>
         </div>
      </div>
   </div>
   
   <div class="kw-breadcrumb-menu__item">
      <div class="kw-breadcrumb-menu__block is-active">
         <div class="kw-breadcrumb-menu__title "><span>Case Story bluesign</span></div>
      </div>
   </div>
</nav>

   </div>
		    
	    </div>
	    
	    <div class="row animated">
		    <div class="col offset-10 col-80">
			    <h1>Für eine sichere Umwelt </h1>
<p>Geht es um ökologisch sinnvolle Produkte, denken die meisten an Lebensmittel. Dabei sind auch Marken wie Puma, Jack Wolfskin oder Mammut nachhaltig. Sie durchlaufen strengste Prozesse, bis die Kleidungsstücke in den Regalen aufliegen. Dafür sorgt die bluesign technologies ag in St.Gallen mit ihrer Datenbank, die eine umweltfreundliche Produktion sicherstellt.</p>
		    </div>
		</div>
    </section>
        
        
    
     <section class="clear odd" id="vorteile-section">
		<h2>Projektüberblick</h2>
	    <div class="row mlr col-list animated">
		    
		    

			<div class="col col-1-3">
						<div class="col-inner ">
				<figure class="icon-holder">
					<span class="icon chat big"></span>
				</figure>
				<h3>Beratung</h3>
				<p>Ausgangslage, Konzeption<br>Budget, Strategie, Auswahl </p>
			</div></div>





			<div class="col col-1-3">
						<div class="col-inner ">
				<figure class="icon-holder">
					<span class="icon tick big"></span>
				</figure>
				<h3>Realisierung</h3>
				<p>Planung, Implementierung,<br>Dokumentation, Schulung,<br>Review</p>
			</div></div>





			<div class="col col-1-3">
						<div class="col-inner ">
				<figure class="icon-holder">
					<span class="icon chat big"></span>
				</figure>				<h3>Betreuung</h3>
				<p>Support, Helpdesk, Systemüberwachung<br>Change Management<br>Weiterentwicklung


</p>
			</div></div>







		</div>
    </section>    
    
     <section class="">
		<h2>Always and everywhere </h2>
	    <div class="row mlr  animated">
		    
		    <div class="col col-90 offset-5">
				<div class="row mw animatedFadeInUp fadeInUp">
				
				
				
				  <div class="accordion light">
            <dl>
              <dt>
                <a href="#accordion1" aria-expanded="false" aria-controls="accordion1" class="accordion-title accordionTitle js-accordionTrigger"><span>Die Aufgabe</span></a>
              </dt>
              <dd class="accordion-content accordionItem is-collapsed" id="accordion1" aria-hidden="true">
                <p><strong>Leistungsstark und umfangreich</strong><br>
Bringen Sie Ihre Organisation mit Microsoft Dynamics 365 entscheidend weiter. Die Komplettlösung basiert auf einem Customer Relationship Management (CRM), was  wesentliche Vorteile hat: Sie profitieren von leistungsstarken Funktionen für das Marketing, den Vertrieb und Kundenservice. Sie haben keine Investitionskosten, sondern profitieren von transparenten, monatlichen Fixkosten pro Benutzer. Sie können auf den vollen Funktionsumfang zugreifen, mit einem Benutzer starten und je nach Bedarf wachsen.</p>
<p>
Kümmern Sie sich um Ihre Kunden und Ihr Geschäft – wir erarbeiten eine auf Ihre Bedürfnisse zugeschnittene Lösung.</p>
              </dd>


<dt>
                <a href="#accordion2" aria-expanded="false" aria-controls="accordion2" class="accordion-title accordionTitle js-accordionTrigger"><span>Die Herausforderung: Der weltweite Zugang</span></a>
              </dt>
              <dd class="accordion-content accordionItem is-collapsed" id="accordion2" aria-hidden="true">
                <p>Lorem ipsum dolor sit amet, consectetur <a href="https://www.google.com">Test</a>adipiscing elit. Morbi eu interdum diam. Donec interdum porttitor risus non bibendum. Maecenas sollicitudin eros in quam imperdiet placerat. Cras justo purus, rhoncus nec lobortis ut, iaculis vel ipsum. Donec dignissim arcu nec elit faucibus condimentum. Donec facilisis consectetur enim sit amet varius. Pellentesque justo dui, sodales quis luctus a, iaculis eget mauris. </p>
                <p>Aliquam dapibus, ante quis fringilla feugiat, mauris risus condimentum massa, at elementum libero quam ac ligula. Pellentesque at rhoncus dolor. Duis porttitor nibh ut lobortis aliquam. Nullam eu dolor venenatis mauris placerat tristique eget id dolor. Quisque blandit adipiscing erat vitae dapibus. Nulla aliquam magna nec elementum tincidunt.</p>
              </dd>



<dt>
                <a href="#accordion3" aria-expanded="false" aria-controls="accordion3" class="accordion-title accordionTitle js-accordionTrigger"><span>Die Lösung: Datenverwaltung via Cloud</span></a>
              </dt>
              <dd class="accordion-content accordionItem is-collapsed" id="accordion3" aria-hidden="true">
                <p>Lorem ipsum dolor sit amet, consectetur <a href="https://www.google.com">Test</a>adipiscing elit. Morbi eu interdum diam. Donec interdum porttitor risus non bibendum. Maecenas sollicitudin eros in quam imperdiet placerat. Cras justo purus, rhoncus nec lobortis ut, iaculis vel ipsum. Donec dignissim arcu nec elit faucibus condimentum. Donec facilisis consectetur enim sit amet varius. Pellentesque justo dui, sodales quis luctus a, iaculis eget mauris. </p>
                <p>Aliquam dapibus, ante quis fringilla feugiat, mauris risus condimentum massa, at elementum libero quam ac ligula. Pellentesque at rhoncus dolor. Duis porttitor nibh ut lobortis aliquam. Nullam eu dolor venenatis mauris placerat tristique eget id dolor. Quisque blandit adipiscing erat vitae dapibus. Nulla aliquam magna nec elementum tincidunt.</p>
              </dd>


             
                          </dl>
          </div>
 





				</div>
			</div>



		</div>
    </section>
    
  <section class="ref-component c">
	    <div class="statement-hover">
	  <div class="row"  >
	   <div id="speaker">
		   <p><small>Statement</small></p>
		   <p><em>«Kundenbedürfnisse selbstkritisch zu analysieren<br>
und flexibel auf neue Anforderungen zu reagieren,<br>
das zeichnet 4net aus.»</em></p>

<p>Christian Dickel, bluesign technologies ag</p>
		    
	    </div>
	    </div>
	    </div>
	    <img src="static/media/placeholders/referenz.jpg">
	    
	    
    </section> 
	
    
    
     
     <section class="primary">
		<h2>Facts & Links</h2>
	    <div class="row mlr  showcaseData">
		    
		    <div class="col col-1-3">
				<h3><span>Kunde</span></h3>
				
				<p>bluesign technology ag<br>
					Wehrstrasse 2<br>
					CH-9015 St. Gallen</p>
					<p><a href="">Website</a></p>
				
		    </div>
		    
		    
		     <div class="col col-1-3">
				<h3><span>technische details</span></h3>
				
			<ul><li>Betrieb eines eigenen, massgeschneiderten Virtual Datacenters</li>
				<li>Leistungsfähige und sichere IT-Infrastruktur</li>
				<li>Konsolidierte IT für das gesamte, 
	international tätige Unternehmen</li>
<li>Nahtlose Unterstützung mobiler, 
	dezentral arbeitender User</li>
	<li>Flexibel anpassbare Ressourcen 
	und Services</li><li>Fixe monatliche Kosten für klar 
	definierte Leistungen</li></ul>
				
		    </div>


 <div class="col col-1-3 highlight">
				<h3><span>zugehörige links</span></h3>
				
				<p>


Cloud Services<br>
Virtual Datacenter<br>
Security Solutions</p>

<p>

Case Story <br>
Factsheet Virtual Datacenter

  


</p>
				
		    </div>
		    
		    
		</div>
    </section>


	 <section class="cotactperson ">
	    <div class="row animated ">
		    
			
			<div class="col col-40 offset-10">
				<h3>Haben Sie Fragen zu<br>unseren Branchenlösungen?</h3>
<p class="p1">Am besten schauen wir uns das Office 365 gemeinsam an. Dann zeige ich Ihnen, wie einfach es zu handhaben ist und wie Sie es für sich nutzen können.</p>

<p><strong>Michael Isenring</strong><br />
Consultant & Account Manager<br>
Tel. +41 71 314 22 50 | <a href="mailto:alain.girardet@4net.ch">Mail</a></p>


			</div>	
				<div class="col col-45">
				<figure class="person"><img src="static/media/placeholders/isering.jpg"></figure>
			</div>
		</div>
    </section>
    

    
    
   
   <?php require 'footer.php'; ?>