<?php require 'header-fixed.php'; ?>
      
      


    
    
    
    
    <section class=" odd has-breadcrumb">
	    
	    <div class="row">
		    
		    <div class="col col-100">
		    <nav class="kw-breadcrumb-menu">
   <a href="/" class="kw-breadcrumb-menu__home"></a>
  
     
   <div class="kw-breadcrumb-menu__item">
      <div class="kw-breadcrumb-menu__block is-active">
         <div class="kw-breadcrumb-menu__title "><span>Aktuell</span></div>
      </div>
   </div>
</nav>

   </div>
		    
	    </div>
	    
	    <div class="row ">
		    	
<aside class="col col-1-4">
	<form method="get" class="quick-search light" action="">
							<input type="text" class="form-element rounded border light" placeholder="Suchbergiff ..." value="">
							<button type="submit">OK</button>
							
						</form>	

		  <h3><span>Kategorien</span></h3>
						<ul>
							<li><a href="">» Art</a></li>
							<li><a href="">» Business</a></li>
							<li><a href="">» Design</a></li>
						</ul>
						
						
						 <h3><span>Newsletter</span></h3>
						<ul>
							<li><a href="">» anmelden</a></li>
						</ul>	
</aside>
<div class="col col-70 offset-5 ">
<div class="newslist">

<div class="nitem">
	
	<div class="news special fullbg" data-bg="http://rtwp.kunden.kreativ-wolke.de/wp-content/uploads/2018/02/photo-1517620114540-4f6a4c43f8ed-1024x683.jpg">
	<span class="date">2. Februar 2018</span>
					
					<a href="" class="news-hover"></a>					
					<h3>Collaborative Law and Practice immer wichtiger</h3>
					<p>Collaborative Law and Practice gewinnt im juristischen Alltag zunehmend an Bedeutung. Die nächste Grundausbildung wird von…</p>
						
					<span class="cat">Kategorie</span>
				</div></div>

<div class="nitem">
	<div class="news special">
	<span class="date">2. Februar 2018</span>
					
					<a href="" class="news-hover"></a>			
					<h3>Vorsicht in Baustellen auf Autobahnen</h3>
					<p>Verschärfte Gerichtspraxis bei Geschwindigkeitsübertretungen in Baustellen auf Autobahnen &nbsp; In einem neuesten Entscheid hat das Bundesgericht…</p>
					
					<span class="cat">Kategorie</span>
				</div>	</div>

<div class="nitem">
	
	<div class="news special fullbg" data-bg="http://rtwp.kunden.kreativ-wolke.de/wp-content/uploads/2018/02/photo-1517620114540-4f6a4c43f8ed-1024x683.jpg">
	<span class="date">2. Februar 2018</span>
					
					<a href="" class="news-hover"></a>					
					<h3>Collaborative Law and Practice immer wichtiger</h3>
					<p>Collaborative Law and Practice gewinnt im juristischen Alltag zunehmend an Bedeutung. Die nächste Grundausbildung wird von…</p>
						
					<span class="cat">Kategorie</span>
				</div></div>


<div class="nitem">
	
	<div class="news special fullbg" data-bg="http://rtwp.kunden.kreativ-wolke.de/wp-content/uploads/2018/02/photo-1517620114540-4f6a4c43f8ed-1024x683.jpg">
	<span class="date">2. Februar 2018</span>
					
					<a href="" class="news-hover"></a>					
					<h3>Collaborative Law and Practice immer wichtiger</h3>
					<p>Collaborative Law and Practice gewinnt im juristischen Alltag zunehmend an Bedeutung. Die nächste Grundausbildung wird von…</p>
						
					<span class="cat">Kategorie</span>
				</div></div>

<div class="nitem breaking">
	<div class="news">
	<span class="date">2. Februar 2018</span>
					<a href="" class="news-hover"></a>
							<figure class="c">
	<img width="1024" height="683" src="http://rtwp.kunden.kreativ-wolke.de/wp-content/uploads/2018/02/photo-1517620114540-4f6a4c43f8ed-1024x683.jpg" class="attachment-large size-large wp-post-image" alt="" srcset="http://rtwp.kunden.kreativ-wolke.de/wp-content/uploads/2018/02/photo-1517620114540-4f6a4c43f8ed-1024x683.jpg 1024w, http://rtwp.kunden.kreativ-wolke.de/wp-content/uploads/2018/02/photo-1517620114540-4f6a4c43f8ed-300x200.jpg 300w, http://rtwp.kunden.kreativ-wolke.de/wp-content/uploads/2018/02/photo-1517620114540-4f6a4c43f8ed-768x512.jpg 768w" sizes="(max-width: 1024px) 100vw, 1024px"></figure>					
					<h3>Neue Website online</h3>
					<p>Hallo Leute Endlich balla ist es soweit Wir sind wieder…</p>
				
					<span class="cat">Kategorie</span>
				</div>    	</div>    
			

<div class="nitem">
	
	<div class="news special fullbg" data-bg="http://rtwp.kunden.kreativ-wolke.de/wp-content/uploads/2018/02/photo-1517620114540-4f6a4c43f8ed-1024x683.jpg">
	<span class="date">2. Februar 2018</span>
					
					<a href="" class="news-hover"></a>					
					<h3>Collaborative Law and Practice immer wichtiger</h3>
					<p>Collaborative Law and Practice gewinnt im juristischen Alltag zunehmend an Bedeutung. Die nächste Grundausbildung wird von…</p>
						
					<span class="cat">Kategorie</span>
				</div></div>

			
			
			</div>
			</div>
			</div>
			
			
		    
	    </section>
    
     <section id="footer-img" data-bg="static/media/footer-4net.jpg">
	    <div class="row">
		    <div class="col col-70 offset-15 teas white">
			    <h2>In besten Händen</h2>
<p>Wir sind die professionelle Adresse für IT-Services. Auch wenn die Themen technisch sind, unsere Beratung und Betreuung ist persönlich. Dabei haben wir immer den Kundennutzen im Blick. Dank umfangreicher Branchenkenntnisse und langjähriger Erfahrung haben wir schon viele Projekte erfolgreich realisiert. Auch mit Office 365.</p>
			    
			    <div class="button-group space-top">
				    <a href="http://www.4net.ch" target="_blank" class="button rounded primary">Mehr erfahren</a>
			    </div>
		    </div>
		</div>
    </section>
    
    
   
   <?php require 'footer.php'; ?>