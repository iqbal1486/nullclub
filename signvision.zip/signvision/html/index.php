<?php require 'header.php'; ?>
      
      

      <div id="stage">
			
			<div id="caption-holder">
				<div id="caption" class="animated animatedFadeInUp fadeInUp">
					<small>HOME</small>
					<span>Leading to <b>success</b> </span>
					
				</div>
			</div>
			<div id="stage-image">
				<img src="static/media/placeholders/header-home.jpg">
			</div>
			
		</div>
    
    
    
    
    <section class="teas has-breadcrumb">
	    
	    <div class="row">
		    
		    <div class="col col-100">
		    <nav class="kw-breadcrumb-menu">
   <a href="/" class="kw-breadcrumb-menu__home"></a>
  
     
   <div class="kw-breadcrumb-menu__item">
      <div class="kw-breadcrumb-menu__block is-active">
         <div class="kw-breadcrumb-menu__title "><span>Home</span></div>
      </div>
   </div>
</nav>

   </div>
		    
	    </div>
	    
	    <div class="row animated">
		    <div class="col offset-20 col-60">
			    <h1>Engagiert für Ihren Erfolg</h1>
<p>Was die IT angeht, sind wir auf Zack. Wir sammeln sämtliches Wissen, das die Informations-Technologie hervorbringt und Ihren Alltag effizienter macht. Wir stellen begeistert Neues auf die Beine, das individuell auf Sie zugeschnitten ist. Wir suchen immer nach den besten Lösungen und setzen sie gekonnt um. Kurzum, wir lieben, was wir tun. Gerne auch für Sie.</p>
		    </div>
		</div>
    </section>
    
    <section class="odd">
	    <div class="row animated">
		    <h2>Unsere Eigenschaften</h2>
		    <div class="col col-50 tcenter">
			   
			   <p><img src="static/media/placeholders/apple-mockup.png" class="fit-80"></p>
		    </div>
		    <div class="col col-50">
			    
			    <ul class="tickbox">
				    <li>
				    	<div class="list-icon">
					    	<span class="icon tick"></span>
				    	</div>
				    	<div class="list-content"><strong>Unabhängig</strong><br>Die Dienste sind offen zugänglich. Sie haben Zugriff auf deren Rechenleistung und Speichermedien.</div>
					</li>
				    <li>
						<div class="list-icon">
					    	<span class="icon tick"></span>
				    	</div>
				    	<div class="list-content"><strong>Kostenbewusst</strong><br>Mit Clouds reduzieren Sie die Investitionen in die eigene Hard- und Software. Sie profitieren von transparenten Fixkosten.</div>
				    </li>
				    <li>
						<div class="list-icon">
					    	<span class="icon tick"></span>
				    	</div>
				    	<div class="list-content"><strong>Flexibel</strong><br>Sie können mit einem Benutzer starten und je nach Bedarf wachsen. Der Funktionsumfang ist praktisch unbeschränkt.</div>
				    </li>
				    <li>
						<div class="list-icon">
					    	<span class="icon tick"></span>
				    	</div>
				    	<div class="list-content"><strong>Effizient</strong><br>Sie können in Projektteams arbeiten und Dokumente gemeinsam bearbeiten. Noch dazu orts- und zeitunabhängig.</div>
				    </li>
				</ul>
		    </div>
		</div>
    </section>
    
    
    
     <section class="clear" id="vorteile-section">
		<h2>Unsere Aufgabe </h2>
	    <div class="row mlr col-list animated">
		    
		    

			<div class="col col-1-3">
						<div class="col-inner ">
				<figure class="icon-holder">
					<span class="icon chat big"></span>
				</figure>
				<h3>Beraten</h3>
				<p>Ausgangslage, Konzeption<br>Budget, Strategie, Auswahl </p>
			</div></div>





			<div class="col col-1-3">
						<div class="col-inner ">
				<figure class="icon-holder">
					<span class="icon tick big"></span>
				</figure>
				<h3>Realisieren</h3>
				<p>Planung, Implementierung,<br>Dokumentation, Schulung,<br>Review</p>
			</div></div>





			<div class="col col-1-3">
						<div class="col-inner ">
				<figure class="icon-holder">
					<span class="icon team big"></span>
				</figure>				<h3>Begleiten</h3>
				<p>Support, Helpdesk, Systemüberwachung<br>Change Management<br>Weiterentwicklung


</p>
			</div></div>







		</div>
    </section>
    
    <section class="transform colored">
		<h2>IT-Trend: Hybrid Cloud   </h2>
	    <div class="row mlr animated">
		    
		    
		    <div class="carousel-component">
			    
			    <ul>
				    
				    <li class="c">
				    	<div class="col col-40  offset-5">
					    	
					    	<h3><small>Trends</small>Die flexible, effiziente<br> Lösung für Schulen </h3>
					    	<p>Die Hybrid Cloud ist eine Mischform – sie vereint das Beste aus der Public Cloud und der Private Cloud. Für mehr Flexibilität und Kosteneffizienz.</p>
					    	<div class="button-group space-ml-top">
						    	<a href="" class="button rounded white ">Mehr dazu</a>
						    	<!--a href="" class="button rounded white ml bordered">Zu den Branchen</a-->
					    	</div>
				    	</div>
				    	<div class="col col-50">
					    	<figure>
					    		<img src="static/media/placeholders/macbook.png">
					    	</figure>
				    	</div>
				    </li>	 				    
				    
				    
				    
			    </ul>
			    
		    </div>
		    
		    
		    
		    
		    
	    </div>
	    </section>
	    
	        <section class="transform transform-white">
		<h2>Effiziente Lösungen für Schulen</h2>
	    <div class="row mlr animated">
		    
		    
		    <div class="carousel-component">
			    
			    <ul>
				    
				    <li class="c">
				    	<div class="col col-50">
					    	<figure>
					    		<img src="static/media/placeholders/macbook.png">
					    	</figure>
				    	</div>
				    	<div class="col col-40  offset-5">
					    	
					    	<h3><small>Trends</small>Die flexible, effiziente<br> Lösung für Schulen </h3>
					    	<p>Die Hybrid Cloud ist eine Mischform – sie vereint das Beste aus der Public Cloud und der Private Cloud. Für mehr Flexibilität und Kosteneffizienz.</p>
					    	<div class="button-group space-ml-top">
						    	<a href="" class="button rounded primary ">Mehr dazu</a>
						    	<!--a href="" class="button rounded white ml bordered">Zu den Branchen</a-->
					    	</div>
				    	</div>
				    </li>	 				    
				    
				    
				    
			    </ul>
			    
		    </div>
		    
		    
		    
		    
		    
	    </div>
	    </section>
	    
	    	        <section class="transform transform-gray">
		<h2>Ganz sicher – Managed Firewall Service   </h2>
	    <div class="row mlr animated">
		    
		    
		    <div class="carousel-component">
			    
			    <ul>
				    
				    <li class="c">
				    	<div class="col col-40  offset-5">
					    	
					    	<h3><small>Trends</small>Die flexible, effiziente<br> Lösung für Schulen </h3>
					    	<p>Die Hybrid Cloud ist eine Mischform – sie vereint das Beste aus der Public Cloud und der Private Cloud. Für mehr Flexibilität und Kosteneffizienz.</p>
					    	<div class="button-group space-ml-top">
						    	<a href="" class="button rounded primary ">Mehr zu 4net</a>
						    	<!--a href="" class="button rounded white ml bordered">Zu den Branchen</a-->
					    	</div>
				    	</div>
				    	<div class="col col-50">
					    	<figure>
					    		<img src="static/media/placeholders/macbook.png">
					    	</figure>
				    	</div>
				    </li>	 				    
				    
				    
				    
			    </ul>
			    
		    </div>
		    
		    
		    
		    
		    
	    </div>
	    </section>
	    
	    
	    <section class="transform-no-bottom transform-white">
		    <h2>Aktuelles von 4net</h2>
		    
		    
		 <div class="row calculateHeight ">  	

<div class="col col-1-3 ">
	<div class="news odd special">
	<span class="date">2. Februar 2018</span>
					
					<a href="" class="news-hover"></a>			
					<h3>Vorsicht in Baustellen auf Autobahnen</h3>
					<p>Verschärfte Gerichtspraxis bei Geschwindigkeitsübertretungen in Baustellen auf Autobahnen &nbsp; In einem neuesten Entscheid hat das Bundesgericht…</p>
					
					<span class="cat">Kategorie</span>
				</div>	</div>

<div class="col col-1-3 ">
	
	<div class="news special odd fullbg" data-bg="http://rtwp.kunden.kreativ-wolke.de/wp-content/uploads/2018/02/photo-1517620114540-4f6a4c43f8ed-1024x683.jpg">
	<span class="date">2. Februar 2018</span>
					
					<a href="" class="news-hover"></a>					
					<h3>Collaborative Law and Practice immer wichtiger</h3>
					<p>Collaborative Law and Practice gewinnt im juristischen Alltag zunehmend an Bedeutung. Die nächste Grundausbildung wird von…</p>
						
					<span class="cat">Kategorie</span>
				</div></div>

<div class="col col-1-3   breaking">
	<div class="news odd">
	<span class="date">2. Februar 2018</span>
					<a href="" class="news-hover"></a>
							<figure class="c">
	<img width="1024" height="683" src="http://rtwp.kunden.kreativ-wolke.de/wp-content/uploads/2018/02/photo-1517620114540-4f6a4c43f8ed-1024x683.jpg" class="attachment-large size-large wp-post-image" alt="" srcset="http://rtwp.kunden.kreativ-wolke.de/wp-content/uploads/2018/02/photo-1517620114540-4f6a4c43f8ed-1024x683.jpg 1024w, http://rtwp.kunden.kreativ-wolke.de/wp-content/uploads/2018/02/photo-1517620114540-4f6a4c43f8ed-300x200.jpg 300w, http://rtwp.kunden.kreativ-wolke.de/wp-content/uploads/2018/02/photo-1517620114540-4f6a4c43f8ed-768x512.jpg 768w" sizes="(max-width: 1024px) 100vw, 1024px"></figure>					
					<h3>Neue Website online</h3>
					<p>Hallo Leute Endlich balla ist es soweit Wir sind wieder…</p>
				
					<span class="cat">Kategorie</span>
				</div>    	</div>    
			
			
			
			</div>
			
			
		    
	    </section>
    
     <section id="footer-img" data-bg="static/media/footer-4net.jpg">
	    <div class="row">
		    <div class="col col-70 offset-15 teas white">
			    <h2>In besten Händen</h2>
<p>Wir sind die professionelle Adresse für IT-Services. Auch wenn die Themen technisch sind, unsere Beratung und Betreuung ist persönlich. Dabei haben wir immer den Kundennutzen im Blick. Dank umfangreicher Branchenkenntnisse und langjähriger Erfahrung haben wir schon viele Projekte erfolgreich realisiert. Auch mit Office 365.</p>
			    
			    <div class="button-group space-top">
				    <a href="http://www.4net.ch" target="_blank" class="button rounded primary">Mehr erfahren</a>
			    </div>
		    </div>
		</div>
    </section>
    
    
   
   <?php require 'footer.php'; ?>