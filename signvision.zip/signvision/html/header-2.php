

 <!DOCTYPE html>
<!--[if IE 7]>
<html class="ie ie7" lang="de-DE" prefix="og: http://ogp.me/ns#">
<![endif]-->
<!--[if IE 8]>
<html class="ie ie8" lang="de-DE" prefix="og: http://ogp.me/ns#">
<![endif]-->
<!--[if !(IE 7) | !(IE 8)  ]><!-->
<html lang="de-DE" prefix="og: http://ogp.me/ns#">
<!--<![endif]-->
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1.0,user-scalable=0">
  <title></title>
  
<link href="static/css/_app.css" rel="stylesheet">
		<link href="static/css/_vendor.css" rel="stylesheet">
		<link href="static/css/_animate.css" rel="stylesheet">
		<link href="static/css/_responsive.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Open+Sans:400,400i,600,600i,700" rel="stylesheet"><link href="https://fonts.googleapis.com/css?family=PT+Serif+Caption:400,400i" rel="stylesheet">

  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-status-bar-style" content="black">
  <link rel="shortcut icon" href="static/media/favicon.ico" type="image/x-icon" />
  <link rel="apple-touch-icon" href="static/media/apple-touch-icon.png" />
  <link rel="apple-touch-icon" sizes="57x57" href="static/media/apple-touch-icon-57x57.png" />
  <link rel="apple-touch-icon" sizes="72x72" href="static/media/apple-touch-icon-72x72.png" />
  <link rel="apple-touch-icon" sizes="76x76" href="static/media/apple-touch-icon-76x76.png" />
  <link rel="apple-touch-icon" sizes="114x114" href="static/media/apple-touch-icon-114x114.png" />
  <link rel="apple-touch-icon" sizes="120x120" href="static/media/apple-touch-icon-120x120.png" />
  <link rel="apple-touch-icon" sizes="144x144" href="static/media/apple-touch-icon-144x144.png" />
  <link rel="apple-touch-icon" sizes="152x152" href="static/media/apple-touch-icon-152x152.png" />
    <!--[if IE]>
      <script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->


</head><body class="oddbg">
	<header class="">
			<div id="brand">
				<a href="">
					<img class="fit light" src="static/media/brand.png">
					<img class="fit dark" src="static/media/brand-dark.png">
					
				</a>
				<span>IT Excellence</span>
			</div>
			
			<div id="nav-handler">
				
				<div class="hamburger hamburger--spring js-hamburger">
					<div class="hamburger-box">
						<div class="hamburger-inner"></div>
					</div>
				</div>
				
				<ul class="info-handler">
					<li class="phone"><span class="info-trigger icon phone small"></span>
						<ul class="info-container">
							<li>
								 <h3><span>Kontakt</span></h3>

					    <p>4net AG<br>
					    Wehrstrasse 2<br>CH-9015 St. Gallen</p>
					    
					    <p><span class="icon phone small dark"></span> +41 (0)71 314 22 55<br>
									<span class="icon mail small dark"></span> <a href="mailto:info@4net.ch">info[at]4net.ch</a></p>
					    <p><span class="icon pin small dark"></span> <a href="">Google Maps</a></a></p>
									
								</p>
							</li>
							
						</ul>
					
					</li>
					<li class="desktop"><span class="info-trigger icon desktop small "></span>
						<ul class="info-container ">
							<li>
								<h3><span>Helpdesk</span></h3>
								<p>
									<span class="icon phone dark small"></span> +41 (0)71 314 22 55<br>
									<span class="icon mail dark small"></span> <a href="mailto:info@4net.ch">info[at]4net.ch</a><br>
									<span class="icon desktop dark small"></span> <a href="">Fernwartung</a>
								</p>
							
								<p>Montag bis Freitag:<br>07.30 - 12.00<br>13.00 - 17.30</p>
								
								<p>
									<a href="" class="button mt rounded white opacity">Download Teamviewer</a>
									
								</p>
							</li>
						
						</ul>

					
					</li>
					<li class="login"><span class="info-trigger icon login small"></span>
						<ul class="info-container ">
							<li>
								  <h3><span>Kundenbereich</span></h3>
						<p>
							<a href="">Benutzer-Anleitungen</a><br>
							<a href="">Login 4net Workspace</a><br>
							<a href="">Outlook Web Access</a>
						</p>							</li>
						
						</ul>
					</li>
					<li class="search"><span class="info-trigger icon search small"></span>
						<ul class="info-container">
							<li>
								<h3><span>Suche</span></h3>
								<form method="get" class="quick-search dark" action="">
							<input type="text" class="form-element rounded border dark" value="">
							<button type="submit">OK</button>
							
						</form>	
					    
							</li>
						
						</ul>
					</li>
				</ul>
			
			</div>
			
			
			<nav>
				<div class="row">
					<div class="col col-20 parent-nav">
						
					<?php $menu3 = 
							[
								1 => ["name" => "Industrie", "url" => "/xyz", "current" => false],
								2 => ["name" => "Pharma", "url" => "/xyz", "current" => false],
								3 => ["name" => "Dienstleister / Informatik", "url" => "/xyz", "current" => false],
								4 => ["name" => "Finanzen", "url" => "/xyz", "current" => false],
								5 => ["name" => "Bildung / Schulen", "url" => "/xyz", "current" => false],
								6 => ["name" => "NPO / Kirchen", "url" => "/xyz", "current" => false],
							];
							
							
							$menu4 = 
							[
								1 => ["name" => "CRM", "url" => "/xyz", "current" => false],
								2 => ["name" => "Collaboration", "url" => "/xyz", "current" => false],
								3 => ["name" => "Document Management", "url" => "/xyz", "current" => false],
								4 => ["name" => "Project Management", "url" => "/xyz", "current" => false],
								5 => ["name" => "Intranet / Extranet", "url" => "/xyz", "current" => false],
							];
							$menu5 = 
							[
								1 => ["name" => "Cloud Services", "url" => "/xyz", "current" => false],
								2 => ["name" => "Security Solutions", "url" => "/xyz", "current" => false],
								3 => ["name" => "IT Systems", "url" => "/xyz", "current" => false],
							];
							$menu7 = 
							[
								1 => ["name" => "Team", "url" => "/xyz", "current" => false],
								2 => ["name" => "Partner", "url" => "/xyz", "current" => false],
								3 => ["name" => "Kontakt", "url" => "/xyz", "current" => false],
							];



							 ?>
						
						<ul>
							<li><a href="">Aktuell</a></li>
							<li><a href="">Trends</a></li>
							<li><a href="" data-childmenu='<?php echo json_encode($menu3); ?>'>Branchen</a></li>
							<li><a href="" data-childmenu='<?php echo json_encode($menu4); ?>'>Lösungen</a></li>
							<li><a href="" data-childmenu='<?php echo json_encode($menu5); ?>'>Technologie</a></li>
							<li><a href="">Referenzen</a></li>
							<li><a href="" data-childmenu='<?php echo json_encode($menu7); ?>'>Über uns</a></li>
							<li><a href="">Support</a></li>
						</ul>
						
					</div>
					
					<div class="col col-30 child-nav">
						
						<ul>
							
						</ul>
						
					</div>
					
					
					<div class="col col-25 info-nav first">
						<h3>Highlights</h3>
						<p><a href="">Microsoft Office 365</a><br>
						<a href="">Microsoft Dynamics</a><br>
						<a href="">Microsoft Azure</a><br>
						<a href="">CRM Lösungen</a><br>
						<a href="">Firewall</a><br>
						<a href="">Lösungen für Schulen</a><br>
						<a href="">Success Story bluesign</a><br>
						<a href="">Neuer Webauftritt</a>
						</p>
						
					</div>
					

					<div class="col col-25 info-nav second">
	 <h3><span>Kontakt</span></h3>

					    <p>4net AG<br>
					    Wehrstrasse 2<br>CH-9015 St. Gallen</p>
					    
					    <p><span class="icon phone dark small"></span><span class="txt">+41 (0)71 314 22 55</span><br>
									<span class="icon mail dark small"></span> <a href="mailto:info@4net.ch" class="txt">info[at]4net.ch</a></p>
					    <p><span class="icon pin dark small"></span> <a href="" class="txt">Google Maps</a></a></p>
								
	</div>


				</div>
				
			</nav>
			
	
		</header>

      