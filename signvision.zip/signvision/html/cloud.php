<?php require 'header.php'; ?>
      
      

      <div id="stage">
			
			<div id="caption-holder">
				<div id="caption" class="animated animatedFadeInUp fadeInUp">
					<small>Cloud Services</small>
					<span>Agil und <b>effizient</b> </span>
					
				</div>
			</div>
			<div id="stage-image">
				<img src="static/media/placeholders/header-home.jpg">
			</div>
			
		</div>
    
    
    
    
    <section class="teas has-breadcrumb">
	    
	    <div class="row">
		    
		    <div class="col col-100">
		    <nav class="kw-breadcrumb-menu">
   <a href="/" class="kw-breadcrumb-menu__home"></a>
   <div class="kw-breadcrumb-menu__item">
      <div class="kw-breadcrumb-menu__block has-sub js-toggle-breadcrumb">
         <div class="kw-breadcrumb-menu__title"><span>Technologie</span></div>
         <div class="kw-breadcrumb-menu__dropdown">
            <ul>
               <li class="is-active"><a href=""><span>Cloud Services</span></a></li>
               <li><a href=""><span>Security Solutions</span></a></li>
               <li><a href=""><span>IT-Systems</span></a></li>
            </ul>
         </div>
      </div>
   </div>


   <div class="kw-breadcrumb-menu__item">
      <div class="kw-breadcrumb-menu__block is-active">
         <div class="kw-breadcrumb-menu__title "><span>Cloud Services</span></div>
      </div>
   </div>
</nav>

   </div>
		    
	    </div>
	    
	    <div class="row animated">
		    <div class="col offset-10 col-80">
			    <h1>Flexibles Arbeiten in der Cloud</h1>
<p>Kaum ein Software-Produkt kommt noch ohne Verbindung zur Cloud aus. Mit gutem Grund: Dank dieser Dienste arbeiten Sie flexibel, sind unabhängig und profitieren von professionell betreuten Systemen. Zu vorteilhaften, überschaubaren Konditionen. Ob Public, Private oder Hybrid Cloud: Gerne beraten wir Sie in der Wahl der passenden Cloud. </p>
		    </div>
		</div>
    </section>
        <section class="primary">
	    <div class="row animated">
		    <h2>Highlights </h2>
		    <div class="row">
			    
			     <div class=" col-90 offset-5 carousel-component-three office-brands">
			    
			    <ul class="primary-three-col-comp">
				    
				
				    
				 
				     <li class="c ">
				    	<div class="col col-100">
					    	<figure>
					    		<img src="static/media/placeholders/office365.png">
					    	</figure>
					    		<a href="" class="hoverlink"></a>
						    	<span  class="button rounded white  rounded">Microsoft Office 365</spam>
				    	</div>
				    	
				    </li>
				    
				     <li class="c">
				    	<div class="col col-100">
					    	<figure>
					    		<img src="static/media/placeholders/office365.png">
					    	</figure>
					    		<a href="" class="hoverlink"></a>
						    	<span  class="button rounded white  rounded">Microsoft Office 365</spam>
				    	</div>
				    	
				    </li>
				    
				     <li class="c">
				    	<div class="col col-100">
					    	<figure>
					    		<img src="static/media/placeholders/office365.png">
					    	</figure>
					    		<a href="" class="hoverlink"></a>
						    	<span  class="button rounded white  rounded">Microsoft Office 365</spam>
				    	</div>
				    	
				    </li>					    
				    
				    
			    </ul>
			    
		    </div>
			    
			    
		    </div>
	    </div>
        </section>
        
        
    <section class="">
	    <div class="row animated">
		    <h2>Tab-Component</h2>
        
        

	<ul class="tabs">
		<li class="tab-link current" data-tab="tab-1">Tab One</li>
		<li class="tab-link" data-tab="tab-2">Tab Two</li>
		<li class="tab-link" data-tab="tab-3">Tab Three</li>
		<li class="tab-link" data-tab="tab-4">Tab Four</li>
	</ul>

	<div id="tab-1" class="tabbed-content current">
		Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
	</div>
	<div id="tab-2" class="tabbed-content">
		 Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
	</div>
	<div id="tab-3" class="tabbed-content">
		Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
	</div>
	<div id="tab-4" class="tabbed-content">
		Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
	</div>

	    </div>
  </section>
        
</div><!-- container -->
    </section>


    <section class="odd">
	    <div class="row animated">
		    
		    
		    <h2>Unser Team</h2>
		    <div class="team-component">
		      <div class="col col-1-4">
			      
				<figure class="person c"><img src="static/media/placeholders/isering.jpg"></figure>
				<h3>Michael Isenring</h3>
				<p>Head of Datacenter / Stv. Leiter Technik</p>
				<p class="hidden-team-el"><a href="">Mail</a> | <a href="">V-Card</a></p>
		      </div>
		      
		      <div class="col col-1-4 c">
			      
				<figure class="person c"><img src="static/media/placeholders/isering.jpg"></figure>
				<h3>Michael Isenring</h3>
				<p>Head of Datacenter / Stv. Leiter Technik</p>
				<p class="hidden-team-el"><a href="">Mail</a> | <a href="">V-Card</a></p>
		      </div>
		      <div class="col col-1-4 c">
			      
				<figure class="person c"><img src="static/media/placeholders/isering.jpg"></figure>
				<h3>Michael Isenring</h3>
				<p>Head of Datacenter / Stv. Leiter Technik</p>
				<p class="hidden-team-el"><a href="">Mail</a> | <a href="">V-Card</a></p>
		      </div>
		      <div class="col col-1-4 c">
			      
				<figure class="person c"><img src="static/media/placeholders/isering.jpg"></figure>
				<h3>Michael Isenring</h3>
				<p>Head of Datacenter / Stv. Leiter Technik</p>
				<p class="hidden-team-el"><a href="">Mail</a> | <a href="">V-Card</a></p>
		      </div>
		      <div class="col col-1-4 c">
			      
				<figure class="person c"><img src="static/media/placeholders/isering.jpg"></figure>
				<h3>Michael Isenring</h3>
				<p>Head of Datacenter / Stv. Leiter Technik</p>
				<p class="hidden-team-el"><a href="">Mail</a> | <a href="">V-Card</a></p>
		      </div>
		      <div class="col col-1-4 c">
			      
				<figure class="person c"><img src="static/media/placeholders/isering.jpg"></figure>
				<h3>Michael Isenring</h3>
				<p>Head of Datacenter / Stv. Leiter Technik</p>
				<p class="hidden-team-el"><a href="">Mail</a> | <a href="">V-Card</a></p>
		      </div>
		      <div class="col col-1-4 c">
			      
				<figure class="person c"><img src="static/media/placeholders/isering.jpg"></figure>
				<h3>Michael Isenring</h3>
				<p>Head of Datacenter / Stv. Leiter Technik</p>
				<p class="hidden-team-el"><a href="">Mail</a> | <a href="">V-Card</a></p>
		      </div>
		      <div class="col col-1-4 c">
			      
				<figure class="person c"><img src="static/media/placeholders/isering.jpg"></figure>
				<h3>Michael Isenring</h3>
				<p>Head of Datacenter / Stv. Leiter Technik</p>
				<p class="hidden-team-el"><a href="">Mail</a> | <a href="">V-Card</a></p>
		      </div>
		      
		    </div> 
		    
	    </div>
    </section>
    <section class="">
	    <div class="row animated">
		    <h2>Die Vorteile auf einen Blick</h2>
		    <div class="col col-50 tcenter">
			   
			   <p><img src="static/media/placeholders/apple-mockup.png" class="fit-80"></p>
		    </div>
		    <div class="col col-50">
			    
			    <ul class="tickbox">
				    <li>
				    	<div class="list-icon">
					    	<span class="icon tick"></span>
				    	</div>
				    	<div class="list-content"><strong>Unabhängig</strong><br>Die Dienste sind offen zugänglich. Sie haben Zugriff auf deren Rechenleistung und Speichermedien.</div>
					</li>
				    <li>
						<div class="list-icon">
					    	<span class="icon tick"></span>
				    	</div>
				    	<div class="list-content"><strong>Kostenbewusst</strong><br>Mit Clouds reduzieren Sie die Investitionen in die eigene Hard- und Software. Sie profitieren von transparenten Fixkosten.</div>
				    </li>
				    <li>
						<div class="list-icon">
					    	<span class="icon tick"></span>
				    	</div>
				    	<div class="list-content"><strong>Flexibel</strong><br>Sie können mit einem Benutzer starten und je nach Bedarf wachsen. Der Funktionsumfang ist praktisch unbeschränkt.</div>
				    </li>
				    <li>
						<div class="list-icon">
					    	<span class="icon tick"></span>
				    	</div>
				    	<div class="list-content"><strong>Effizient</strong><br>Sie können in Projektteams arbeiten und Dokumente gemeinsam bearbeiten. Noch dazu orts- und zeitunabhängig.</div>
				    </li>
				</ul>
		    </div>
		</div>
    </section>
    
     <section class="primary">
	    <div class="row animated">
		    <h2>Die Vorteile auf einen Blick</h2>
		    <div class="col col-50 tcenter">
			   
			   <p><img src="static/media/placeholders/apple-mockup.png" class="fit-80"></p>
		    </div>
		    <div class="col col-50">
			    
			    <ul class="tickbox">
				    <li>
				    	<div class="list-icon">
					    	<span class="icon tick"></span>
				    	</div>
				    	<div class="list-content"><strong>Unabhängig</strong><br>Die Dienste sind offen zugänglich. Sie haben Zugriff auf deren Rechenleistung und Speichermedien.</div>
					</li>
				    <li>
						<div class="list-icon">
					    	<span class="icon tick"></span>
				    	</div>
				    	<div class="list-content"><strong>Kostenbewusst</strong><br>Mit Clouds reduzieren Sie die Investitionen in die eigene Hard- und Software. Sie profitieren von transparenten Fixkosten.</div>
				    </li>
				    <li>
						<div class="list-icon">
					    	<span class="icon tick"></span>
				    	</div>
				    	<div class="list-content"><strong>Flexibel</strong><br>Sie können mit einem Benutzer starten und je nach Bedarf wachsen. Der Funktionsumfang ist praktisch unbeschränkt.</div>
				    </li>
				    <li>
						<div class="list-icon">
					    	<span class="icon tick"></span>
				    	</div>
				    	<div class="list-content"><strong>Effizient</strong><br>Sie können in Projektteams arbeiten und Dokumente gemeinsam bearbeiten. Noch dazu orts- und zeitunabhängig.</div>
				    </li>
				</ul>
		    </div>
		</div>
    </section>
    
     <section class="odd">
		<h2>Private Cloud Services</h2>
	    <div class="row mlr  animated">
		    
		    <div class="col col-90 offset-5">
				<div class="row mw animatedFadeInUp fadeInUp">
				
				<div class="accordion-teaser">
					<p><strong>Ihre eigenen Services</strong><br>
Noch heute bevorzugen viele Unternehmen die Private Cloud. Die Gründe sind naheliegend: Datenschutz und IT-Sicherheit. Man will, dass ausschliesslich die eigenen Mitarbeitenden Zugang zu den Daten haben. Wie bei den Public Clouds können die Anwender cloud-typische Mehrwerte nutzen, die über den Webbrowser gesteuert sind. Allerdings in einer persönlichen IT-Umgebung. Die Stärke von 4net ist, die verschiedenen Clouds perfekt zu verbinden. Man spricht hierbei auch von Multi Cloud. Damit erweitern Sie Ihre private Cloud mit einem professionellen Service. Gerne sorgen wir dafür, dass Ihre IT-Umgebung reibungslos läuft und immer verfügbar ist. Dafür steht Ihnen unser professionelles und sicheres Rechenzentrum zur Verfügung.</p>
				</div>
				
				  <div class="accordion">
            <dl>
              <dt>
                <a href="#accordion1" aria-expanded="false" aria-controls="accordion1" class="accordion-title accordionTitle js-accordionTrigger"><span>Virtual Data Center</span></a>
              </dt>
             <dd class="accordion-content accordionItem is-collapsed" id="accordion1" aria-hidden="true">
                <p><strong>Leistungsstark und umfangreich</strong><br>
Bringen Sie Ihre Organisation mit Microsoft Dynamics 365 entscheidend weiter. Die Komplettlösung basiert auf einem Customer Relationship Management (CRM), was  wesentliche Vorteile hat: Sie profitieren von leistungsstarken Funktionen für das Marketing, den Vertrieb und Kundenservice. Sie haben keine Investitionskosten, sondern profitieren von transparenten, monatlichen Fixkosten pro Benutzer. Sie können auf den vollen Funktionsumfang zugreifen, mit einem Benutzer starten und je nach Bedarf wachsen.</p>
<p>
Kümmern Sie sich um Ihre Kunden und Ihr Geschäft – wir erarbeiten eine auf Ihre Bedürfnisse zugeschnittene Lösung.</p>

<p><a href="" class="button mt rounded white opacity">Ausführliche Informationen</a></p>
									
              </dd>


<dt>
                <a href="#accordion2" aria-expanded="false" aria-controls="accordion2" class="accordion-title accordionTitle js-accordionTrigger"><span>Microsoft Dynamics 365</span></a>
              </dt>
              <dd class="accordion-content accordionItem is-collapsed" id="accordion2" aria-hidden="true">
                <p>Lorem ipsum dolor sit amet, consectetur <a href="https://www.google.com">Test</a>adipiscing elit. Morbi eu interdum diam. Donec interdum porttitor risus non bibendum. Maecenas sollicitudin eros in quam imperdiet placerat. Cras justo purus, rhoncus nec lobortis ut, iaculis vel ipsum. Donec dignissim arcu nec elit faucibus condimentum. Donec facilisis consectetur enim sit amet varius. Pellentesque justo dui, sodales quis luctus a, iaculis eget mauris. </p>
                <p>Aliquam dapibus, ante quis fringilla feugiat, mauris risus condimentum massa, at elementum libero quam ac ligula. Pellentesque at rhoncus dolor. Duis porttitor nibh ut lobortis aliquam. Nullam eu dolor venenatis mauris placerat tristique eget id dolor. Quisque blandit adipiscing erat vitae dapibus. Nulla aliquam magna nec elementum tincidunt.</p>
              </dd>



<dt>
                <a href="#accordion3" aria-expanded="false" aria-controls="accordion3" class="accordion-title accordionTitle js-accordionTrigger"><span>Workplace</span></a>
              </dt>
              <dd class="accordion-content accordionItem is-collapsed" id="accordion3" aria-hidden="true">
                <p>Lorem ipsum dolor sit amet, consectetur <a href="https://www.google.com">Test</a>adipiscing elit. Morbi eu interdum diam. Donec interdum porttitor risus non bibendum. Maecenas sollicitudin eros in quam imperdiet placerat. Cras justo purus, rhoncus nec lobortis ut, iaculis vel ipsum. Donec dignissim arcu nec elit faucibus condimentum. Donec facilisis consectetur enim sit amet varius. Pellentesque justo dui, sodales quis luctus a, iaculis eget mauris. </p>
                <p>Aliquam dapibus, ante quis fringilla feugiat, mauris risus condimentum massa, at elementum libero quam ac ligula. Pellentesque at rhoncus dolor. Duis porttitor nibh ut lobortis aliquam. Nullam eu dolor venenatis mauris placerat tristique eget id dolor. Quisque blandit adipiscing erat vitae dapibus. Nulla aliquam magna nec elementum tincidunt.</p>
              </dd>



             
                          </dl>
          </div>
 





				</div>
			</div>



		</div>
    </section>
    
    
    
     
     <section>
		<h2>Public Cloud Services</h2>
	    <div class="row mlr  animated">
		    
		    <div class="col col-90 offset-5">
				<div class="row mw animatedFadeInUp fadeInUp">
				
				<div class="accordion-teaser">
					<p><strong>Ihre eigenen Services</strong><br>
Noch heute bevorzugen viele Unternehmen die Private Cloud. Die Gründe sind naheliegend: Datenschutz und IT-Sicherheit. Man will, dass ausschliesslich die eigenen Mitarbeitenden Zugang zu den Daten haben. Wie bei den Public Clouds können die Anwender cloud-typische Mehrwerte nutzen, die über den Webbrowser gesteuert sind. Allerdings in einer persönlichen IT-Umgebung. Die Stärke von 4net ist, die verschiedenen Clouds perfekt zu verbinden. Man spricht hierbei auch von Multi Cloud. Damit erweitern Sie Ihre private Cloud mit einem professionellen Service. Gerne sorgen wir dafür, dass Ihre IT-Umgebung reibungslos läuft und immer verfügbar ist. Dafür steht Ihnen unser professionelles und sicheres Rechenzentrum zur Verfügung.</p>
				</div>
				
				  <div class="accordion light">
            <dl>
              <dt>
                <a href="#accordion1" aria-expanded="false" aria-controls="accordion1" class="accordion-title accordionTitle js-accordionTrigger"><span>Virtual Data Center</span></a>
              </dt>
              <dd class="accordion-content accordionItem is-collapsed" id="accordion1" aria-hidden="true">
                <p><strong>Leistungsstark und umfangreich</strong><br>
Bringen Sie Ihre Organisation mit Microsoft Dynamics 365 entscheidend weiter. Die Komplettlösung basiert auf einem Customer Relationship Management (CRM), was  wesentliche Vorteile hat: Sie profitieren von leistungsstarken Funktionen für das Marketing, den Vertrieb und Kundenservice. Sie haben keine Investitionskosten, sondern profitieren von transparenten, monatlichen Fixkosten pro Benutzer. Sie können auf den vollen Funktionsumfang zugreifen, mit einem Benutzer starten und je nach Bedarf wachsen.</p>
<p>
Kümmern Sie sich um Ihre Kunden und Ihr Geschäft – wir erarbeiten eine auf Ihre Bedürfnisse zugeschnittene Lösung.</p>
              </dd>


<dt>
                <a href="#accordion2" aria-expanded="false" aria-controls="accordion2" class="accordion-title accordionTitle js-accordionTrigger"><span>Microsoft Dynamics 365</span></a>
              </dt>
              <dd class="accordion-content accordionItem is-collapsed" id="accordion2" aria-hidden="true">
                <p>Lorem ipsum dolor sit amet, consectetur <a href="https://www.google.com">Test</a>adipiscing elit. Morbi eu interdum diam. Donec interdum porttitor risus non bibendum. Maecenas sollicitudin eros in quam imperdiet placerat. Cras justo purus, rhoncus nec lobortis ut, iaculis vel ipsum. Donec dignissim arcu nec elit faucibus condimentum. Donec facilisis consectetur enim sit amet varius. Pellentesque justo dui, sodales quis luctus a, iaculis eget mauris. </p>
                <p>Aliquam dapibus, ante quis fringilla feugiat, mauris risus condimentum massa, at elementum libero quam ac ligula. Pellentesque at rhoncus dolor. Duis porttitor nibh ut lobortis aliquam. Nullam eu dolor venenatis mauris placerat tristique eget id dolor. Quisque blandit adipiscing erat vitae dapibus. Nulla aliquam magna nec elementum tincidunt.</p>
              </dd>



<dt>
                <a href="#accordion3" aria-expanded="false" aria-controls="accordion3" class="accordion-title accordionTitle js-accordionTrigger"><span>Workplace</span></a>
              </dt>
              <dd class="accordion-content accordionItem is-collapsed" id="accordion3" aria-hidden="true">
                <p>Lorem ipsum dolor sit amet, consectetur <a href="https://www.google.com">Test</a>adipiscing elit. Morbi eu interdum diam. Donec interdum porttitor risus non bibendum. Maecenas sollicitudin eros in quam imperdiet placerat. Cras justo purus, rhoncus nec lobortis ut, iaculis vel ipsum. Donec dignissim arcu nec elit faucibus condimentum. Donec facilisis consectetur enim sit amet varius. Pellentesque justo dui, sodales quis luctus a, iaculis eget mauris. </p>
                <p>Aliquam dapibus, ante quis fringilla feugiat, mauris risus condimentum massa, at elementum libero quam ac ligula. Pellentesque at rhoncus dolor. Duis porttitor nibh ut lobortis aliquam. Nullam eu dolor venenatis mauris placerat tristique eget id dolor. Quisque blandit adipiscing erat vitae dapibus. Nulla aliquam magna nec elementum tincidunt.</p>
              </dd>


             
                          </dl>
          </div>
 





				</div>
			</div>



		</div>
    </section>


    <section class="video-component c">
	    
	    
	    <a href="" class="show-video">
		    <small>Referenz</small>
		    Video von Cloud im Einsatz
		    <span class="rounded-btn"><span class="icon video  dark"></span></span>
		    
	    </a>
	    <span class="mask"></span>
	    <img src="static/media/placeholders/video.jpg">
	    
	    
    </section>
   
	    
	    <section class="odd">
		    <h2>Referenzen zu Cloud-Lösungen </h2>
		    
		    
		 <div class="row calculateHeight">  	
	     <div class=" col-90 offset-5 carousel-component-three newslisting dark">
			    
			    <ul class="owl-carousel owl-theme">
<li>
	<div class="news special">
	<span class="date">2. Februar 2018</span>
					
					<a href="" class="news-hover"></a>			
					<h3>Vorsicht in Baustellen auf Autobahnen</h3>
					<p>Verschärfte Gerichtspraxis bei Geschwindigkeitsübertretungen in Baustellen auf Autobahnen &nbsp; In einem neuesten Entscheid hat das Bundesgericht…</p>
					
					<span class="cat">Kategorie</span>
				</div>	</li>

<li>
	
	<div class="news special fullbg" data-bg="http://rtwp.kunden.kreativ-wolke.de/wp-content/uploads/2018/02/photo-1517620114540-4f6a4c43f8ed-1024x683.jpg">
	<span class="date">2. Februar 2018</span>
					
					<a href="" class="news-hover"></a>					
					<h3>Collaborative Law and Practice immer wichtiger</h3>
					<p>Collaborative Law and Practice gewinnt im juristischen Alltag zunehmend an Bedeutung. Die nächste Grundausbildung wird von…</p>
						
					<span class="cat">Kategorie</span>
				</div>
</li>

<li class="breaking">
	<div class="news">
	<span class="date">2. Februar 2018</span>
					<a href="" class="news-hover"></a>
							<figure class="c">
	<img width="1024" height="683" src="http://rtwp.kunden.kreativ-wolke.de/wp-content/uploads/2018/02/photo-1517620114540-4f6a4c43f8ed-1024x683.jpg" class="attachment-large size-large wp-post-image" alt="" srcset="http://rtwp.kunden.kreativ-wolke.de/wp-content/uploads/2018/02/photo-1517620114540-4f6a4c43f8ed-1024x683.jpg 1024w, http://rtwp.kunden.kreativ-wolke.de/wp-content/uploads/2018/02/photo-1517620114540-4f6a4c43f8ed-300x200.jpg 300w, http://rtwp.kunden.kreativ-wolke.de/wp-content/uploads/2018/02/photo-1517620114540-4f6a4c43f8ed-768x512.jpg 768w" sizes="(max-width: 1024px) 100vw, 1024px"></figure>					
					<h3>Neue Website online</h3>
					<p>Hallo Leute Endlich balla ist es soweit Wir sind wieder…</p>
				
					<span class="cat">Kategorie</span>
				</div>    	</li>   
				
				
				
				
				<li>
	<div class="news special">
	<span class="date">2. Februar 2018</span>
					
					<a href="" class="news-hover"></a>			
					<h3>Vorsicht in Baustellen auf Autobahnen</h3>
					<p>Verschärfte Gerichtspraxis bei Geschwindigkeitsübertretungen in Baustellen auf Autobahnen &nbsp; In einem neuesten Entscheid hat das Bundesgericht…</p>
					
					<span class="cat">Kategorie</span>
				</div>	</li>

<li>
	
	<div class="news special fullbg" data-bg="http://rtwp.kunden.kreativ-wolke.de/wp-content/uploads/2018/02/photo-1517620114540-4f6a4c43f8ed-1024x683.jpg">
	<span class="date">2. Februar 2018</span>
					
					<a href="" class="news-hover"></a>					
					<h3>Collaborative Law and Practice immer wichtiger</h3>
					<p>Collaborative Law and Practice gewinnt im juristischen Alltag zunehmend an Bedeutung. Die nächste Grundausbildung wird von…</p>
						
					<span class="cat">Kategorie</span>
				</div>
</li>

<li class="breaking">
	<div class="news">
	<span class="date">2. Februar 2018</span>
					<a href="" class="news-hover"></a>
							<figure class="c">
	<img width="1024" height="683" src="http://rtwp.kunden.kreativ-wolke.de/wp-content/uploads/2018/02/photo-1517620114540-4f6a4c43f8ed-1024x683.jpg" class="attachment-large size-large wp-post-image" alt="" srcset="http://rtwp.kunden.kreativ-wolke.de/wp-content/uploads/2018/02/photo-1517620114540-4f6a4c43f8ed-1024x683.jpg 1024w, http://rtwp.kunden.kreativ-wolke.de/wp-content/uploads/2018/02/photo-1517620114540-4f6a4c43f8ed-300x200.jpg 300w, http://rtwp.kunden.kreativ-wolke.de/wp-content/uploads/2018/02/photo-1517620114540-4f6a4c43f8ed-768x512.jpg 768w" sizes="(max-width: 1024px) 100vw, 1024px"></figure>					
					<h3>Neue Website online</h3>
					<p>Hallo Leute Endlich balla ist es soweit Wir sind wieder…</p>
				
					<span class="cat">Kategorie</span>
				</div>    	</li>    
			
			    </ul>
			
			</div>
			
			
		    
	    </section>
    
 
	
	 <section class="cotactperson ">
	    <div class="row animated ">
		    
			
			<div class="col col-40 offset-10">
				<h3>Gerne berate ich Sie.</h3>
<p class="p1">Am besten schauen wir uns das Office 365 gemeinsam an. Dann zeige ich Ihnen, wie einfach es zu handhaben ist und wie Sie es für sich nutzen können.</p>

<p><strong>Michael Isenring</strong><br />
Consultant & Account Manager<br>
Tel. +41 71 314 22 50 | <a href="mailto:alain.girardet@4net.ch">Mail</a></p>


			</div>	
				<div class="col col-45">
				<figure class="person c"><img src="static/media/placeholders/isering.jpg"></figure>
			</div>
		</div>
    </section>
    

    
    
   
   <?php require 'footer.php'; ?>