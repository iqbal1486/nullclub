<?php require 'header-2.php'; ?>

      
      

      <div id="stage">
			
			<div id="caption-holder">
				<div id="caption" class="animated animatedFadeInUp fadeInUp">
					<small>HOME</small>
					<span>Leading to <b>success</b> </span>
					
				</div>
			</div>
			<div id="stage-image">
				<img src="static/media/placeholders/header-home.jpg">
			</div>
			
		</div>
    
    
    
    
    <section class="teas has-breadcrumb">
	    
	    <div class="row">
		    
		    <div class="col col-100">
		    <nav class="kw-breadcrumb-menu">
   <a href="/" class="kw-breadcrumb-menu__home"></a>
  
     
   <div class="kw-breadcrumb-menu__item">
      <div class="kw-breadcrumb-menu__block is-active">
         <div class="kw-breadcrumb-menu__title "><span>Home</span></div>
      </div>
   </div>
</nav>

   </div>
		    
	    </div>
	    
	    <div class="row animated">
		    <div class="col offset-20 col-60">
			    <h1>Kinder in der digitalen Welt begleiten </h1>
<p>Was die IT angeht, sind wir auf Zack. Wir sammeln sämtliches Wissen, das die Informations-Technologie hervorbringt und Ihren Alltag effizienter macht. Wir stellen begeistert Neues auf die Beine, das individuell auf Sie zugeschnitten ist. Wir suchen immer nach den besten Lösungen und setzen sie gekonnt um. Kurzum, wir lieben, was wir tun. Gerne auch für Sie.</p>
		    </div>
		</div>
    </section>
    
 
 <section class="clear primary" id="vorteile-section">
		<h2>Die Vorteile auf einen Blick</h2>
	    <div class="row mlr col-list animated">
		    
		    

			<div class="col col-1-3">
						<div class="col-inner ">
				<figure class="icon-holder">
					<span class="icon chat light big"></span>
				</figure>
				<h3>Beratung</h3>
				<p>Ausgangslage, Konzeption<br>Budget, Strategie, Auswahl </p>
			</div></div>





			<div class="col col-1-3">
						<div class="col-inner ">
				<figure class="icon-holder">
					<span class="icon chat light big"></span>
				</figure>
				<h3>Realisierung</h3>
				<p>Planung, Implementierung,<br>Dokumentation, Schulung,<br>Review</p>
			</div></div>





			<div class="col col-1-3">
						<div class="col-inner ">
				<figure class="icon-holder">
					<span class="icon chat light big"></span>
				</figure>				<h3>Betreuung</h3>
				<p>Support, Helpdesk, Systemüberwachung<br>Change Management<br>Weiterentwicklung


</p>
			</div></div>







		</div>
    </section> 
    
    <section class=" odd clean">
		<h2>Die Module   </h2>
	    <div class="row mlr animated">
		    
		    
		    <div class="carousel-component">
			    
			    <ul>
				    
				    <li class="c"><div class="col col-50">
					    	<figure>
					    		<img src="static/media/placeholders/laptop.png">
					    	</figure>
				    	</div>
				    	<div class="col col-40  offset-5">
					    	
					    	<h3><small>Trends</small>Office 365 </h3>
					    	<p>Mit dem Office 365 fällt die Zusammenarbeit extrem leicht: Sie können mit Lehrpersonen, aber auch mit Lernenden unkompliziert korrespondieren, Dokumente bearbeiten und teilen, zentrale Kalender führen und Neuigkeiten veröffentlichen. Auch separate Bereiche für Gruppenarbeiten, Projektteams oder Ausbildungskurse lassen sich empfängerorientiert verwalten. Gerne unterstützen wir Sie beim Aufbau und bei der Verwaltung eines zentralen Portals. Damit macht die Arbeit in der Schule noch mehr Freude.
</p>
					    	
					    	
					    
					    	
				    	</div>
				    	
				    </li>	 				    
				    
				    
				    
			    </ul>
			    
		    </div>
		    
		    
		    
		    
		    
	    </div>
	    </section>
	    
	    
	    
	    
	    <section class="transform clean">
	    <div class="row mlr animated">
		    
		    
		    <div class="carousel-component">
			    
			    <ul>
				    
				    <li class="c">
				    	<div class="col col-40  offset-5">
					    	
					    	<h3><small>Trends</small>E-Mail </h3>
					    	<p>Mit dem Office 365 fällt die Zusammenarbeit extrem leicht: Sie können mit Lehrpersonen, aber auch mit Lernenden unkompliziert korrespondieren, Dokumente bearbeiten und teilen, zentrale Kalender führen und Neuigkeiten veröffentlichen. Auch separate Bereiche für Gruppenarbeiten, Projektteams oder Ausbildungskurse lassen sich empfängerorientiert verwalten. Gerne unterstützen wir Sie beim Aufbau und bei der Verwaltung eines zentralen Portals. Damit macht die Arbeit in der Schule noch mehr Freude.
</p>
					    	
					    	
					    
					    	
				    	</div>
				    	<div class="col col-50">
					    	<figure>
					    		<img src="static/media/placeholders/laptop.png">
					    	</figure>
				    	</div>
				    </li>	 				    
				    
				    
				    
			    </ul>
			    
		    </div>
		    
		    
		    
		    
		    
	    </div>
	    </section>
	    
	    
	    
    <section class="transform odd clean">
	    <div class="row mlr animated">
		    
		    
		    <div class="carousel-component">
			    
			    <ul>
				    
				    <li class="c"><div class="col col-50">
					    	<figure>
					    		<img src="static/media/placeholders/laptop.png">
					    	</figure>
				    	</div>
				    	<div class="col col-40  offset-5">
					    	
					    	<h3><small>Trends</small>Office 365 </h3>
					    	<p>Mit dem Office 365 fällt die Zusammenarbeit extrem leicht: Sie können mit Lehrpersonen, aber auch mit Lernenden unkompliziert korrespondieren, Dokumente bearbeiten und teilen, zentrale Kalender führen und Neuigkeiten veröffentlichen. Auch separate Bereiche für Gruppenarbeiten, Projektteams oder Ausbildungskurse lassen sich empfängerorientiert verwalten. Gerne unterstützen wir Sie beim Aufbau und bei der Verwaltung eines zentralen Portals. Damit macht die Arbeit in der Schule noch mehr Freude.
</p>
					    	
					    	
					    
					    	
				    	</div>
				    	
				    </li>	 				    
				    
				    
				    
			    </ul>
			    
		    </div>
		    
		    
		    
		    
		    
	    </div>
	    </section>
	    
	    
	    
	    
	    <section class="transform clean">
	    <div class="row mlr animated">
		    
		    
		    <div class="carousel-component">
			    
			    <ul>
				    
				    <li class="c">
				    	<div class="col col-40  offset-5">
					    	
					    	<h3><small>Trends</small>E-Mail </h3>
					    	<p>Mit dem Office 365 fällt die Zusammenarbeit extrem leicht: Sie können mit Lehrpersonen, aber auch mit Lernenden unkompliziert korrespondieren, Dokumente bearbeiten und teilen, zentrale Kalender führen und Neuigkeiten veröffentlichen. Auch separate Bereiche für Gruppenarbeiten, Projektteams oder Ausbildungskurse lassen sich empfängerorientiert verwalten. Gerne unterstützen wir Sie beim Aufbau und bei der Verwaltung eines zentralen Portals. Damit macht die Arbeit in der Schule noch mehr Freude.
</p>
					    	
					    	
					    
					    	
				    	</div>
				    	<div class="col col-50">
					    	<figure>
					    		<img src="static/media/placeholders/laptop.png">
					    	</figure>
				    	</div>
				    </li>	 				    
				    
				    
				    
			    </ul>
			    
		    </div>
		    
		    
		    
		    
		    
	    </div>
	    </section>


    <section class="transform odd clean">
	    <div class="row mlr animated">
		    
		    
		    <div class="carousel-component">
			    
			    <ul>
				    
				    <li class="c"><div class="col col-50">
					    	<figure>
					    		<img src="static/media/placeholders/laptop.png">
					    	</figure>
				    	</div>
				    	<div class="col col-40  offset-5">
					    	
					    	<h3><small>Trends</small>Office 365 </h3>
					    	<p>Mit dem Office 365 fällt die Zusammenarbeit extrem leicht: Sie können mit Lehrpersonen, aber auch mit Lernenden unkompliziert korrespondieren, Dokumente bearbeiten und teilen, zentrale Kalender führen und Neuigkeiten veröffentlichen. Auch separate Bereiche für Gruppenarbeiten, Projektteams oder Ausbildungskurse lassen sich empfängerorientiert verwalten. Gerne unterstützen wir Sie beim Aufbau und bei der Verwaltung eines zentralen Portals. Damit macht die Arbeit in der Schule noch mehr Freude.
</p>
					    	
					    	
					    
					    	
				    	</div>
				    	
				    </li>	 				    
				    
				    
				    
			    </ul>
			    
		    </div>
		    
		    
		    
		    
		    
	    </div>
	    </section>
	    
	    
<section class="primary  quote">
	<div class="row">
		<blockquote><em>«Unser Projekt erforderte grosse Flexibilität und rasche Reaktion. Beidem wurde das 4net-Team allemal gerecht.»</em><small>Hans Muster, Pfarrer Ref. Kirchgemeinde Degersheim</small></blockquote>
	</div>
	
</section>
	    
<section class="dark  quote">
	<div class="row">
		<blockquote><em>«Unser Projekt erforderte grosse Flexibilität und rasche Reaktion. Beidem wurde das 4net-Team allemal gerecht.»</em><small>Hans Muster, Pfarrer Ref. Kirchgemeinde Degersheim</small></blockquote>
	</div>
	
</section>
	    
<section class="odd  quote">
	<div class="row">
		<blockquote><em>«Unser Projekt erforderte grosse Flexibilität und rasche Reaktion. Beidem wurde das 4net-Team allemal gerecht.»</em><small>Hans Muster, Pfarrer Ref. Kirchgemeinde Degersheim</small></blockquote>
	</div>
	
</section>

	    

    <section class="video-component c">
	    
	    
	    <a href="" class="show-video">
		    <small>Referenz</small>
		    Video von Cloud im Einsatz
		    <span class="rounded-btn"><span class="icon video  dark"></span></span>
		    
	    </a>
	    <span class="mask"></span>
	    <img src="static/media/placeholders/video.jpg">
	    
	    
    </section>
    
    
     <section class="fact-list ">
	    <div class="row animated ">
		    <h2>Facts & Links</h2>
			<div class="col col-60 offset-20">
				
				
				<div class="col col-1-2">
					  <h3><span>Kategorien</span></h3>
						<ul>
							<li><a href="">» Art</a></li>
							<li><a href="">» Business</a></li>
							<li><a href="">» Design</a></li>
						</ul>
				</div>
				
				
				<div class="col col-1-2 primary">
					  <h3><span>Links & Downloads</span></h3>
						<ul>
							<li><a href="">» Art</a></li>
							<li><a href="">» Business</a></li>
							<li><a href="">» Design</a></li>
						</ul>
				</div>
			</div>
		</div>
     </section>
	 <section class="cotactperson odd">
	    <div class="row animated ">
		    
			<div class="col col-45">
				<figure class="person"><img src="static/media/placeholders/isering.jpg"></figure>
			</div>
			<div class="col col-40 offset-10">
				<h3>Gerne berate ich Sie.</h3>
<p class="p1">Am besten schauen wir uns das Office 365 gemeinsam an. Dann zeige ich Ihnen, wie einfach es zu handhaben ist und wie Sie es für sich nutzen können.</p>

<p><strong>Michael Isenring</strong><br />
Consultant & Account Manager<br>
Tel. +41 71 314 22 50 | <a href="mailto:alain.girardet@4net.ch">Mail</a></p>


			</div>	
				
		</div>
    </section>

     <section id="footer-img" data-bg="static/media/footer-4net.jpg">
	    <div class="row">
		    <div class="col col-70 offset-15 teas white">
			    <h2>In besten Händen</h2>
<p>Wir sind die professionelle Adresse für IT-Services. Auch wenn die Themen technisch sind, unsere Beratung und Betreuung ist persönlich. Dabei haben wir immer den Kundennutzen im Blick. Dank umfangreicher Branchenkenntnisse und langjähriger Erfahrung haben wir schon viele Projekte erfolgreich realisiert. Auch mit Office 365.</p>
			    
			    <div class="button-group space-top">
				    <a href="http://www.4net.ch" target="_blank" class="button rounded primary">Mehr erfahren</a>
			    </div>
		    </div>
		</div>
    </section>
    
    
   
   <?php require 'footer.php'; ?>