<?php require 'header.php'; ?>
      
      

      <div id="stage">
			
			<div id="caption-holder">
				<div id="caption" class="animated animatedFadeInUp fadeInUp">
					<small>Branchen</small>
					<span>Die digitale <b>Transformation</b> </span>
					
				</div>
			</div>
			<div id="stage-image">
				<img src="static/media/placeholders/header-home.jpg">
			</div>
			
		</div>
    
    
    
    
    <section class="teas has-breadcrumb">
	    
	    <div class="row">
		    
		    <div class="col col-100">
		    <nav class="kw-breadcrumb-menu">
   <a href="/" class="kw-breadcrumb-menu__home"></a>
   <div class="kw-breadcrumb-menu__item">
      <div class="kw-breadcrumb-menu__block has-sub js-toggle-breadcrumb is-active">
         <div class="kw-breadcrumb-menu__title"><span>Branchen</span></div>
         <div class="kw-breadcrumb-menu__dropdown">
            <ul>
               <li class="is-active"><a href=""><span>CRM</span></a></li>
               <li><a href=""><span>Collaboration</span></a></li>
               <li><a href=""><span>Document Management</span></a></li>
               <li><a href=""><span>Project Management</span></a></li>
               <li><a href=""><span>Intranet / Extranet</span></a></li>
            </ul>
         </div>
      </div>
   </div>
   
 
</nav>

   </div>
		    
	    </div>
	    
	    <div class="row animated">
		    <div class="col offset-10 col-80">
			    <h1>Branchenfokussierte IT Lösungen </h1>
<p>Jede Branche, jedes Unternehmen hat seine ganz eigenen Anforderungen an die Informationstechnik. Wir von 4net planen individuell und betreiben einen IT-Service, der speziell auf Ihre Alltagsbedürfnisse abzielt. Übergeordnet verfolgen wir jedoch bei allen dasselbe Ziel: Ihre Geschäfts- sowie Produktionsprozesse so effizient wie möglich zu gestalten.</p>
		    </div>
		</div>
    </section>
    
    <section class="odd">
		    <h2>Übersicht</h2>
	    <div class="row animated">
		    <ul class="overview-component">
			    <li>
			    	<a href=""></a>
			    	<span class="title">Industrie</span>
			    	<span class="read-more"><span class=" button rounded white">Mehr</span></span>
			    	<span class="mask"></span>
			    	<img src="static/media/placeholders/industrie.jpg">
			    </li>
			    <li>
			    	<a href=""></a>
			    	<span class="title">Pharma</span>
			    	<span class="read-more"><span class=" button rounded white">Mehr</span></span>
			    	<span class="mask"></span>
			    	<img src="static/media/placeholders/pharma.jpg">
			    </li>
			    <li>
			    	<a href=""></a>
			    	<span class="title">Dienstleister /<br> Informatik</span>
			    	<span class="read-more"><span class=" button rounded white">Mehr</span></span>
			    	<span class="mask"></span>
			    	<img src="static/media/placeholders/dienstleister.jpg">
			    </li>
			    <li>
			    	<a href=""></a>
			    	<span class="title">Finanzen</span>
			    	<span class="read-more"><span class=" button rounded white">Mehr</span></span>
			    	<span class="mask"></span>
			    	<img src="static/media/placeholders/finanzen.jpg">
			    </li>
			    <li>
			    	<a href=""></a>
			    	<span class="title">Bildung / Schulen</span>
			    	<span class="read-more"><span class=" button rounded white">Mehr</span></span>
			    	<span class="mask"></span>
			    	<img src="static/media/placeholders/schulen.jpg">
			    </li>
			    <li>
			    	<a href=""></a>
			    	<span class="title">NPOs / Kirchen</span>
			    	<span class="read-more"><span class=" button rounded white">Mehr</span></span>
			    	<span class="mask"></span>
			    	<img src="static/media/placeholders/npo.jpg">
			    </li>
			  
			    
			      
			      
		    </ul>
		</div>
    </section>
    
    
    
    <section class="clear nopad">
	
		<div class="row large image-text-revert-component">
			
			
			<div class="col col-100">
				<div class="col col-50 image c">
					<img src="static/media/placeholders/branche.jpg">
				</div>
				<div class="col col-50 text">
					<h3><small>die fertigung mit der it verzahnen</small>Industrie</h3>
					<p>Fertigungsabläufe und die IT greifen immer mehr ineinander. Deshalb benötigen Industrie-Anbieter eine Transformation, mit der sie wettbewerbsfähig zu bleiben: Eine vereinfachte Zusammenarbeit der Entwicklungs-, Konstruktions- und Produktionsteams. Echtzeit-Analysen von Produktionsdaten. Clouds, die mit der vorhandenen Infrastruktur vor Ort kombiniert sind. Zuverlässige Programme für die Markteinführung von Produkten. Wir kennen uns mit den industriellen Anforderungen aus und bieten Ihnen Lösungen, die Ihre Produktion optimieren und die Effizienz Ihrer Lieferkette steigern.</p>
					    
				    <div class="button-group space-top">
					    <a href="http://www.4net.ch" target="_blank" class="button rounded primary">Mehr erfahren</a>
				    </div>
				</div>
			</div>
			
			<div class="col col-100 odd">
				<div class="col col-50 image fr c">
					<img src="static/media/placeholders/branche.jpg">
				</div>
				<div class="col col-50 text">
					<h3><small>die fertigung mit der it verzahnen</small>Industrie</h3>
					<p>Fertigungsabläufe und die IT greifen immer mehr ineinander. Deshalb benötigen Industrie-Anbieter eine Transformation, mit der sie wettbewerbsfähig zu bleiben: Eine vereinfachte Zusammenarbeit der Entwicklungs-, Konstruktions- und Produktionsteams. Echtzeit-Analysen von Produktionsdaten. Clouds, die mit der vorhandenen Infrastruktur vor Ort kombiniert sind. Zuverlässige Programme für die Markteinführung von Produkten. Wir kennen uns mit den industriellen Anforderungen aus und bieten Ihnen Lösungen, die Ihre Produktion optimieren und die Effizienz Ihrer Lieferkette steigern.</p>
					    
				    <div class="button-group space-top">
					    <a href="http://www.4net.ch" target="_blank" class="button rounded primary">Mehr erfahren</a>
				    </div>
				</div>
			</div>
			
			
			<div class="col col-100">
				<div class="col col-50 image c">
					<img src="static/media/placeholders/branche.jpg">
				</div>
				<div class="col col-50 text">
					<h3><small>die fertigung mit der it verzahnen</small>Industrie</h3>
					<p>Fertigungsabläufe und die IT greifen immer mehr ineinander. Deshalb benötigen Industrie-Anbieter eine Transformation, mit der sie wettbewerbsfähig zu bleiben: Eine vereinfachte Zusammenarbeit der Entwicklungs-, Konstruktions- und Produktionsteams. Echtzeit-Analysen von Produktionsdaten. Clouds, die mit der vorhandenen Infrastruktur vor Ort kombiniert sind. Zuverlässige Programme für die Markteinführung von Produkten. Wir kennen uns mit den industriellen Anforderungen aus und bieten Ihnen Lösungen, die Ihre Produktion optimieren und die Effizienz Ihrer Lieferkette steigern.</p>
					    
				    <div class="button-group space-top">
					    <a href="http://www.4net.ch" target="_blank" class="button rounded primary">Mehr erfahren</a>
				    </div>
				</div>
			</div>
			
			<div class="col col-100 odd">
				<div class="col col-50 image fr c">
					<img src="static/media/placeholders/branche.jpg">
				</div>
				<div class="col col-50 text">
					<h3><small>die fertigung mit der it verzahnen</small>Industrie</h3>
					<p>Fertigungsabläufe und die IT greifen immer mehr ineinander. Deshalb benötigen Industrie-Anbieter eine Transformation, mit der sie wettbewerbsfähig zu bleiben: Eine vereinfachte Zusammenarbeit der Entwicklungs-, Konstruktions- und Produktionsteams. Echtzeit-Analysen von Produktionsdaten. Clouds, die mit der vorhandenen Infrastruktur vor Ort kombiniert sind. Zuverlässige Programme für die Markteinführung von Produkten. Wir kennen uns mit den industriellen Anforderungen aus und bieten Ihnen Lösungen, die Ihre Produktion optimieren und die Effizienz Ihrer Lieferkette steigern.</p>
					    
				    <div class="button-group space-top">
					    <a href="http://www.4net.ch" target="_blank" class="button rounded primary">Mehr erfahren</a>
				    </div>
				</div>
			</div>
			
			
			
			
			
		</div>
		
	</section>
	
	
	
	 <section class="cotactperson">
	    <div class="row animated ">
		    
			
			<div class="col col-40 offset-10">
				<h3>Haben Sie Fragen zu<br>unseren Branchenlösungen?</h3>
<p class="p1">Am besten schauen wir uns das Office 365 gemeinsam an. Dann zeige ich Ihnen, wie einfach es zu handhaben ist und wie Sie es für sich nutzen können.</p>

<p><strong>Michael Isenring</strong><br />
Consultant & Account Manager<br>
Tel. +41 71 314 22 50 | <a href="mailto:alain.girardet@4net.ch">Mail</a></p>


			</div>	
				<div class="col col-45">
				<figure class="person"><img src="static/media/placeholders/isering.jpg"></figure>
			</div>
		</div>
    </section>
    
    
   
   <?php require 'footer.php'; ?>