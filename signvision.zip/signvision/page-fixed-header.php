<?php /* Template Name: Ohne Kopfbild */ get_header();?>

      <?php
	      
	      $nachfolgende_elemente_erst_bei_klick_sichtbar = false;
	      
	       while ( have_posts() ) : the_post();?>


	      
	        <?php
	
	// check if the flexible content field has rows of data
	if( have_rows('pagebuilder') ):
	
	 	// loop through the rows of data
	    while ( have_rows('pagebuilder') ) : the_row();
	
			// check current row layout
			
			



	        if( get_row_layout() == 'statement' ): ?>
	        
	        	
			     
    
					 <section class="ref-component c">
	    <div class="statement-hover">
	  <div class="row"  >
	   <div id="speaker">
		   <p><small>Statement</small></p>
		   <p><em><?php the_sub_field("Statement"); ?></em></p>

<p><?php the_sub_field("name"); ?></p>
		    
	    </div>
	    </div>
	    </div>
	   <?php
								$img = get_sub_field("hintergrund"); 
								echo '<img src="' . $img["url"] . '" alt="4net.ch – ' . get_sub_field("headline") . '">';
								?>
	    
	    
    </section> 
    
	        		
	       
	        		
	        <?php 
		        
		         elseif( get_row_layout() == 'text' ): ?>
	        
			        <section class="textbox <?php the_sub_field("hintergrund"); ?>">	
					    <div class="row animated">
						    <div class="col offset-15 col-70">
							    <h2><?php the_sub_field("headline"); ?></h2>
								<?php the_sub_field("inhalt"); ?>
						    </div>
						</div>
				    </section>
		        
 <?php  elseif( get_row_layout() == 'teaser' ): ?>
	        
			        <section class="teas <?php the_sub_field("hintergrund"); ?>-bg">	
					    <div class="row animated">
						    <div class="col offset-15 col-70">
							    <h1><?php the_sub_field("headline"); ?></h1>
								<?php the_sub_field("teaser"); ?>
						    </div>
						</div>
				    </section>
		        
 <?php 
		           elseif( get_row_layout() == 'text_zentriert' ): ?>
	        
			        <section id="<?php echo (get_sub_field("anker") ? get_sub_field("anker") : sanitize_title(get_sub_field("headline"))); ?>" class="tac <?php echo (get_sub_field("kein_abstand_nach_unten") ? ' nopaddbot ' : ''); ?><?php the_sub_field("hintergrund"); ?>">	
					    <div class="row animated">
						    <div class="col offset-15 col-70">
							    <h1><?php the_sub_field("headline"); ?></h1>
								<?php the_sub_field("teaser"); ?>
						    </div>
						</div>
				    </section>
		        
 <?php 
 elseif( get_row_layout() == 'kontakt' ): ?>
	        
			        <section id="contact" class="contactform <?php the_sub_field("hintergrund"); ?>">	
					    <div class="row animated">
						    <div class="col offset-15 col-70 tac">
							    <h1><?php the_sub_field("headline"); ?></h1>
								<?php the_sub_field("teaser"); ?>
						    </div>
						    <br clear="all">
						    <div id="map-holder" class="row mw">
							    <div class="col map col-70">
								  <div id="map" data-latitude="<?php the_sub_field("latitude"); ?>" data-longitude="<?php the_sub_field("longitude"); ?>"></div>
							    </div>
							    <div class="col col-30 tal maptext">
								    <?php the_sub_field("kontakt-text"); ?>
							    </div>
						    </div>
						    
						    	<?php echo do_shortcode('[contact-form-7 id="348" title="Kontaktformular"]'); ?>
						    
						</div>
				    </section>
		        
 <?php 
		        
		         elseif( get_row_layout() == 'video' ): ?>
	        
    <section class="video-component c" id="<?php the_sub_field("anker"); ?>">
	    
	    
	    <a href="<?php the_sub_field("videolink"); ?>" data-lity class="show-video">
		    <small><?php the_sub_field("subline"); ?></small><br>
		    <?php the_sub_field("headline"); ?>
		    <span class="rounded-btn primary"><span class="icon video  light"></span></span>
		    
	    </a>
	    <span class="mask"></span>
	   <?php $img = get_sub_field("hintergrund"); 
						echo '<img src="' . $img["url"] . '"  alt="4net.ch – ' . get_sub_field("headline") . '">';?>
	    
	    
    </section>
    

		     <?php 
			     
			     
			     elseif( get_row_layout() == 'kontaktperson'): ?>
			     
			     
			      <section class="contactperson <?php the_sub_field("hintergrund"); ?>">
	    <div class="row animated ">
		    
		    
		    
				    <?php if(get_sub_field("bildposition")  == "left"): ?>
		    
			<div class="col col-45">
				<figure class="person"><?php $img = get_sub_field("bild"); 
						echo '<img src="' . $img["url"] . '" class="fit-80" alt="4net.ch – ' . get_sub_field("headline") . '">';?></figure>
			</div>
			
			<div class="col col-40 offset-r-10">
			<?php else:?>
			
			
			
			<div class="col col-40 offset-10">
			
			<?php endif; ?>
				<?php the_sub_field("kontaktdaten"); ?>
			</div>	
			
			
			   <?php if(get_sub_field("bildposition")  == "right"): ?>
		    
			<div class="col col-45">
				<figure class="person"><?php $img = get_sub_field("bild"); 
						echo '<img src="' . $img["url"] . '" class="fit-80" alt="4net.ch – ' . get_sub_field("headline") . '">';?></figure>
			</div>
			
			<?php endif; ?>
				
		</div>
    </section>
<?php elseif(get_row_layout() == 'link-box'): ?>

			      <section class="odd linkbox">
		    <h2><?php the_sub_field("headline"); ?></h2>
	     <?php if( have_rows('boxen') ): ?>
		      
	    <div class="row animated">
		    <ul class="overview-component">
<?php	
	 	// loop through the rows of data
	    while ( have_rows('boxen') ) : the_row();
	    
	    ?>
	    
	      <li>
			    	<a href="<?php the_sub_field("link"); ?>" class="scroll-link"></a>
			    	<span class="title"><?php $img = get_sub_field("icon"); 
						echo '<img src="' . $img["url"] . '" class="fit-80" alt="4net.ch – ' . get_sub_field("headline") . '">';?><br><?php the_sub_field("beschreibung"); ?></span>
			    	<span class="read-more"><span class=" button rounded white"><?php the_sub_field("linkbezeichnung"); ?></span></span>
			    	<span class="mask"></span>
			    	
			    	<?php $img = get_sub_field("bild"); 
						echo '<img src="' . $img["url"] . '" class="fit-80" alt="4net.ch – ' . get_sub_field("headline") . '">';?>
			    </li>
			   			  

				 
				 <?php endwhile; ?>  
		    </ul>	  
		


    <?php endif; ?>
</div>

    </section>


			     <?php elseif(get_row_layout() == 'komplexe_auflistung'): ?>
			     
			     
			 
		     <?php if( have_rows('list_loop') ): ?>
			      <section class="odd">
		    <?php if(get_sub_field("headline")): ?><h2><?php the_sub_field("headline"); ?></h2><?php endif; ?>
		      
	    <div class="row animated">
		    <ul class="overview-component">
<?php	
	 	// loop through the rows of data
	    while ( have_rows('list_loop') ) : the_row();
	    
	    ?>
	    
	      <li>
			    	<a href="#<?php echo sanitize_title(get_sub_field("subline")); ?>" class="scroll-link"></a>
			    	<span class="title"><?php the_sub_field("subline"); ?></span>
			    	<span class="read-more"><span class=" button rounded white">Mehr</span></span>
			    	<span class="mask"></span>
			    	
			    	<?php $img = get_sub_field("bild"); 
						echo '<img src="' . $img["url"] . '" class="fit-80" alt="4net.ch – ' . get_sub_field("headline") . '">';?>
			    </li>
			   			  

				 
				 <?php endwhile; ?>  
		    </ul>	  
		</div>

    </section>


    <?php endif; ?>


 <?php if( have_rows('list_loop') ): ?>
		  <section class="clear nopad">
	
		<div class="row full image-text-revert-component">

<?php	$i = 1;
	 	// loop through the rows of data
	    while ( have_rows('list_loop') ) : the_row();
	    
	    
	    if($i%2):
	    ?>
	    <div class="col col-100 listholder" id="<?php echo sanitize_title(get_sub_field("subline")); ?>">
				<div class="col col-50 image c">
					<?php $img = get_sub_field("bild"); 
						echo '<img src="' . $img["url"] . '" class="fit-80" alt="4net.ch – ' . get_sub_field("headline") . '">';?>
				</div>
				<div class="col col-50 text">
					<div class="textwrapper">
						<h3><small><?php the_sub_field("headline"); ?></small><?php the_sub_field("subline"); ?></h3>
					<?php the_sub_field("inhalt"); ?>	
					
						<?php if(get_sub_field("link") && get_sub_field("linkbezeichnung")): ?>
				  <div class="button-group space-top">
						<a href="<?php the_sub_field("link"); ?>" class="button rounded primary"><?php the_sub_field("linkbezeichnung"); ?></a>
					</div>
				
				<?php endif; ?>		
					</div>		    


				</div>
			</div>

			 <?php else: ?>
			   <div class="col col-100 odd listholder" id="<?php echo sanitize_title(get_sub_field("subline")); ?>">
			
				<div class="col col-50 text">
					<div class="textwrapper">
					<h3><small><?php the_sub_field("headline"); ?></small><?php the_sub_field("subline"); ?></h3>
					<?php the_sub_field("inhalt"); ?>	
					
						<?php if(get_sub_field("link") && get_sub_field("linkbezeichnung")): ?>
				  <div class="button-group space-top">
						<a href="<?php the_sub_field("link"); ?>" class="button rounded primary"><?php the_sub_field("linkbezeichnung"); ?></a>
					</div>
				
				<?php endif; ?>				    

					</div>
				</div>
				
					<div class="col col-50 image c">
					<?php $img = get_sub_field("bild"); 
						echo '<img src="' . $img["url"] . '" class="fit-80" alt="4net.ch – ' . get_sub_field("headline") . '">';?>
				</div>
			</div>
			 
			 
			 <?php endif; ?>  			  

				 
				 <?php $i++; endwhile; ?>  
		    
		</div>

    </section>


    <?php endif; ?>
    

	<?php elseif(get_row_layout() == 'referenzen'): ?>
  <section id="success-stories" class="<?php the_sub_field("hintergrund"); ?><?php echo (get_sub_field("abstand_bereinigen") ? ' cleaner' : ''); ?>">
		    <h2><?php the_sub_field("headline"); ?></h2>
		    
		    
		 <div class="row ">  	
	    	 <div class=" col-90 offset-5 carousel-component-three referenzen dark">
			    
			       
				      <?php if( have_rows('referenzen_loop') ): ?>
			    
			    
				
<?php	
	 	// loop through the rows of data
	    while ( have_rows('referenzen_loop') ) : the_row(); ?>
					<div class="col col-1-3 ">
											<div class="news odd ">
					<a href="<?php echo (get_sub_field("link_oder_pdf") == "PDF" ? get_sub_field("pdf") : get_sub_field("link")); ?>" class="news-hover"></a>	
								<figure>
								<?php $img = get_sub_field("bild"); 
						echo '<img src="' . $img["url"] . '" alt="4net.ch – ' . get_sub_field("titel") . '">';?>
								</figure>	
									
							<h3><?php the_sub_field("titel"); ?></h3>
							<p><?php the_sub_field("beschreibung"); ?></p>
							
							
							<?php if(get_sub_field("link_oder_pdf") == "PDF"): ?>
							
							<span class="button rounded dark bordered small  ispdf">Case story</span>
							<?php else: ?>
							
							
							<span class="button rounded small primary">Case story</span>
							
							<?php endif; ?>
							
							
							
						</div>	
									
					 </div>
					
					<?php endwhile; ?>
			    
			    <?php endif;?>
	    	 </div>
		 </div>
  </section>
			     <?php
			      
			     elseif(get_row_layout() == 'accordion-component'): $bg = get_sub_field("hintergrund"); ?>
			     
			         <section  id="<?php echo (get_sub_field("anker") ? get_sub_field("anker") : sanitize_title(get_sub_field("headline"))); ?>" class="<?php the_sub_field("hintergrund"); ?>">
	    <div class="row animated">
		    <h2><?php the_sub_field("headline"); ?></h2>
		    
			    
			    
			    
	    <div class="row mlr  animated">
		    
		    <div class="col col-90 offset-5">
				<div class="row mw animatedFadeInUp fadeInUp">
				<?php if(get_sub_field("teaser")): ?>
					<div class="accordion-teaser">
						<?php the_sub_field("teaser"); ?>
					</div>
				
				<?php endif; ?>
	            
	            
	              <?php if( have_rows('accordion') ): ?>
			    
			     <div class="accordion<?php echo ($bg == "white" ? ' light' : ''); ?>">
            <dl>
<?php	
	 	// loop through the rows of data
	    while ( have_rows('accordion') ) : the_row();
	    
	    ?>
	      <dt>
                <a href="" aria-expanded="false" data-accordname="<?php the_sub_field("bezeichnung"); ?>" aria-controls="accordion-<?php echo md5(get_sub_field("bezeichnung")); ?>" class="accordion-title accordionTitle js-accordionTrigger"><span><?php the_sub_field("bezeichnung"); ?></span></a>
              </dt>
             <dd class="accordion-content accordionItem is-collapsed" id="accordion-<?php echo md5(get_sub_field("bezeichnung")); ?>" aria-hidden="true">
               <?php the_sub_field("inhalt"); ?>

	
				
				
				<?php if(get_sub_field("linktyp") == "externer Link" && get_sub_field("externer_link")): ?>
					    	
					    	<p><a href="<?php the_sub_field("externer_link"); ?>" target="_blank" class="button  rounded white"><?php the_sub_field("linkbezeichnung"); ?></a></p>
					    	
					    	<?php elseif(get_sub_field("linktyp") == "interner Link" && get_sub_field("interner_link")): ?>
					    	
					    		<p><a href="<?php the_sub_field("interner_link"); ?>"   class="button  rounded white "><?php the_sub_field("linkbezeichnung"); ?></a></p>
					    	
					    	
					    	<?php elseif(get_sub_field("linktyp") == "Datei" && get_sub_field("datei")): ?>
					    	
					    		<p><a href="<?php the_sub_field("datei"); ?>"   class="button ispdf bordered white rounded  "><?php the_sub_field("linkbezeichnung"); ?></a></p>
					    	
					    	<?php endif; ?>
						


              </dd>
				
				
			

				 <?php endwhile; ?>  
				   
		
				
				     </dl>
          </div>
			<?php endif; ?>
			
			
            




             
                     
 





				</div>
			</div>



		</div>



			  
    </section>
			  <?php
				  
				       elseif(get_row_layout() == 'tab-component'):  ?>
			     
			         <section id="<?php echo (get_sub_field("anker") ? get_sub_field("anker") : sanitize_title(get_sub_field("headline"))); ?>"  class="<?php the_sub_field("hintergrund"); ?>">
	    <div class="row animated">
		 <?php if(get_sub_field("headline")): ?>
			<h2><?php the_sub_field("headline"); ?></h2>
		<?php endif; ?>
			    
			    
			    
	   
	              <?php if( have_rows('tabs') ): ?>
			    <div class="col-80 offset-10">
			 
			
	<ul class="tabs">	 
<?php	
	 	// loop through the rows of data
	  $i = 0;  while ( have_rows('tabs') ) : the_row();
	    
	    ?>
	    
	            

		<li class="tab-link<?php echo($i == 0 ? ' current' : ''); ?>" data-tabname="<?php the_sub_field("bezeichnung"); ?>" data-tab="tab-<?php echo md5(get_sub_field("bezeichnung")); ?>"><?php the_sub_field("bezeichnung"); ?></li>
	
				 <?php $i++; endwhile; ?>  
	</ul>

			<?php endif; 
			
	             if( have_rows('tabs') ): 

	  $i = 0;  while ( have_rows('tabs') ) : the_row();
	    ?>
	    
	    
	    <div id="tab-<?php echo md5(get_sub_field("bezeichnung")); ?>" class="tabbed-content<?php echo($i == 0 ? ' current' : ''); ?>">
		 <?php the_sub_field("inhalt"); ?>

	<?php if(get_sub_field("link") && get_sub_field("linkbezeichnung")): ?>
				  <div class="button-group space-top tal">
						<a href="<?php the_sub_field("link"); ?>" class="button mt rounded white opacity"><?php the_sub_field("linkbezeichnung"); ?></a>
					</div>
				
				<?php endif; ?> 			
	</div>
	
	               
				
				
			

				 <?php $i++;  endwhile; 
					  endif; ?>
			
			
            




             
                     
 



		</div>
		</div>



			  
    </section>
			  <?php


			     elseif(get_row_layout() == 'list'): ?>
			     
			         <section  id="<?php echo (get_sub_field("anker") ? get_sub_field("anker") : sanitize_title(get_sub_field("headline"))); ?>" class="<?php the_sub_field("hintergrund"); ?><?php echo (get_sub_field("bild_oder_zufalliger_mitarbeiter") !== "Bild") ? ' nopaddbot has-person-image': ''; ?>">
	    <div class="row animated">
		    <h2><?php the_sub_field("headline"); ?></h2>
		   
		    <div class="col col-50 fr">
			    <?php if( have_rows('liste') ): ?>
			    
			    <ul class="tickbox<?php echo (get_sub_field("bild_oder_zufalliger_mitarbeiter") ? "" : " nopadd"); ?>">
<?php	
	 	// loop through the rows of data
	    while ( have_rows('liste') ) : the_row();
	    
	    ?>
				    <li>
				    	<div class="list-icon">
					    	<span class="icon tick"></span>
				    	</div>
				    	<div class="list-content"><?php the_sub_field("bezeichnung"); ?></div>
					</li>
				 
				 <?php endwhile; ?>  
				   
			</ul>
				<?php if(get_sub_field("link") && get_sub_field("linkbezeichnung")): ?>
				  <div class="button-group space-top tal">
						<a href="<?php the_sub_field("link"); ?>" class="button rounded primary"><?php the_sub_field("linkbezeichnung"); ?></a>
					</div>
				
				<?php endif; ?>
			<?php endif; ?>
		    </div>
		    
		     <div class="col col-50 tcenter">
			   
			   <?php if(get_sub_field("bild_oder_zufalliger_mitarbeiter") !== "Bild"): 
			   
			   $args = array(
    'post_type'=>'ansprechpartner', 
    'orderby'=>'rand', 
    'posts_per_page'=>'1'
  );

  $testimonials=new WP_Query($args);

  while ($testimonials->have_posts()) : $testimonials->the_post(); 

?>

   <?php the_post_thumbnail("full"); ?>
    
    <?php

endwhile; wp_reset_postdata();


?>



			   
			   
			   <?php else: ?>
			   		<p><?php $img = get_sub_field("Bild"); 
						echo '<img src="' . $img["url"] . '" class="fit-80" alt="4net.ch – ' . get_sub_field("headline") . '">';?>
					</p>
								
								
				<?php endif; ?>
		    </div>
		</div>
    </section>
			     
			
				<?php 
					
					 elseif(get_row_layout() == 'support-box'): ?>     
			     
			     
			      <section  id="<?php echo (get_sub_field("anker") ? get_sub_field("anker") : sanitize_title(get_sub_field("headline"))); ?>" class="nopaddbot <?php the_sub_field("hintergrund"); ?><?php echo (get_sub_field("abstand_bereinigen") ? ' cleaner' : ''); ?>">
	    <div class="row animated">
					    <h2><?php the_sub_field("headline"); ?></h2>
		    <div class="row">
			    
			     <div class=" col-90 offset-5 carousel-component-three support-boxes">
			    	  <?php if( have_rows('boxen') ): ?>
			    
			 <ul class="primary-three-col-comp">		
<?php	
	 	// loop through the rows of data
	    while ( have_rows('boxen') ) : the_row();
	    
	    ?>
			   
				    
				
				    
				 
				     <li class="c ">
				    	<div class="col col-100">
					    	<figure><?php $img = get_sub_field("bild"); 
						echo '<img src="' . $img["url"] . '" class="fit-80" alt="4net.ch – ' . get_sub_field("headline") . '">';?>

					    	</figure>
					    	<h3><?php the_sub_field("beschreibung"); ?></h3>
					    
					    	
					    	
						    	<a href="<?php the_sub_field("link"); ?>"  class="button rounded white  rounded"><?php the_sub_field("linkbezeichnung"); ?></a>
				    	</div>
				    	<div class="col col-100 graybgaction">
					    	
					    		<a href="<?php the_sub_field("linkgrau"); ?>" target="_blank" class="button rounded primary  rounded" ><?php the_sub_field("linkbezeichnung_grau"); ?></a>
				    	</div>
				    	
				    	
				    </li>
				    
			<?php endwhile; ?>
				    				    
				    
				    
			    </ul>
			<?php endif; ?>    
		    </div>
			    
			    
		    </div>
	    </div>
        </section>




			    <?php
				       elseif(get_row_layout() == 'highlights'): ?>     



			     
			     
			      <section  id="<?php echo (get_sub_field("anker") ? get_sub_field("anker") : sanitize_title(get_sub_field("headline"))); ?>" class="primary">
	    <div class="row animated">
					    <h2><?php the_sub_field("headline"); ?></h2>
		    <div class="row">
			    
			     <div class=" col-90 offset-5 carousel-component-three office-brands">
			    	  <?php if( have_rows('highlights_loop') ): ?>
			    
			 <ul class="primary-three-col-comp">		
<?php	
	 	// loop through the rows of data
	    while ( have_rows('highlights_loop') ) : the_row();
	    
	    ?>
			   
				    
				
				    
				 
				     <li class="c ">
				    	<div class="col col-100">
					    	<figure><?php $img = get_sub_field("bild"); 
						echo '<img src="' . $img["url"] . '" class="fit-80" alt="4net.ch – ' . get_sub_field("headline") . '">';?>

					    	</figure>
					    	<h3><?php the_sub_field("bezeichnung"); ?></h3>
					    	<?php if(get_sub_field("linktyp") == "externer Link"): ?>
					    	
					    	
					    		<a href="<?php the_sub_field("externer_link"); ?>" target="_blank" class="hoverlink"></a>
					    	<?php elseif(get_sub_field("linktyp") == "javascript"): 
						    	
						    	list($class, $name) = explode("|", get_sub_field("javascript"));
						    	
					    	?>
					    		<a href="" class="hoverlink <?php echo $class; ?>" data-caller="<?php echo $name; ?>"></a>
					    	<?php else: ?>
					    	
					    	<?php if($pos = strpos( get_sub_field("interner_link"), "#")): ?>
					    		<a href="<?php echo str_replace($menu[0]->url, "", get_sub_field("interner_link")); ?>"  class="hoverlink"></a>
					    	<?php else: ?>
					    		<a href="<?php echo  get_sub_field("interner_link"); ?>"  class="hoverlink"></a>
					    	
					    	
					    	<?php endif; ?>
					    	<?php endif; ?>
						    	<span  class="button rounded white  rounded">Mehr</span>
				    	</div>
				    	
				    </li>
				    
			<?php endwhile; ?>
				    				    
				    
				    
			    </ul>
			<?php endif; ?>    
		    </div>
			    
			    
		    </div>
	    </div>
        </section>




			    <?php
				    
				    
				    elseif(get_row_layout() == 'vorteile'): ?>
			         <section  id="<?php echo (get_sub_field("anker") ? get_sub_field("anker") : sanitize_title(get_sub_field("headline"))); ?>" class="<?php the_sub_field("hintergrund"); ?><?php echo (get_sub_field("abstand_bereinigen") ? ' clear' : ''); ?>">
		
					    <h2><?php the_sub_field("headline"); ?></h2>
				      
					    
			
					
					  <?php if( have_rows('vorteile_loop') ): ?>
			    
			  <div class="row mlr col-list animated">
					
<?php	
	 	// loop through the rows of data
	    while ( have_rows('vorteile_loop') ) : the_row();
	    
	    ?>
				    	<div class="col col-1-3">
						<div class="col-inner ">
				<figure class="icon-holder">
					<?php
								$img = get_sub_field("bild"); 
								echo '<img src="' . $img["url"] . '" class="fit-80" alt="4net.ch – ' . get_sub_field("bezeichnung") . '">';
								?>
				</figure>
				<h3><?php the_sub_field("bezeichnung"); ?></h3>
				<p><?php the_sub_field("inhalt"); ?></p>
			</div></div>
				 
				 <?php endwhile; ?>  
				   
			
					</div>
			<?php endif; ?>
			
			
			
			
			
			    </section>




			
			     
			    <?php
		        
		    
		       elseif( get_row_layout() == 'footer-image' ): ?>
			   		
			   		<?php
						$bgimg = get_sub_field("hintergrund"); 
					?>
		            <section id="footer-img" data-bg="<?php echo $bgimg["url"]; ?>">
					    <div class="row">
						    <div class="col col-70 offset-15 teas white">
							    <h2><?php the_sub_field("headline"); ?></h2>
							    <?php the_sub_field("inhalt"); ?>
							    
							    <div class="button-group space-top">
								    <a href="<?php the_sub_field("link"); ?>" class="button rounded primary"><?php the_sub_field("linkbezeichnung"); ?></a>
							    </div>
						    </div>
						</div>
				    </section>
					  
					
					
	          <?php 
		       
		       elseif( get_row_layout() == 'aktuelles' ): ?>
			   		
			   		
			   		<section id="<?php echo (get_sub_field("anker") ? get_sub_field("anker") : sanitize_title(get_sub_field("headline"))); ?>" class="transform-no-bottom transform-white">
			   		 	<h2><?php the_sub_field("headline"); ?></h2>
					    
					
			   		 	<div class="row calculateHeight ">  	
				   		 	
				   		 	<?php
					   		 	if( get_sub_field('beitraege') ):

					
								 	// loop through the rows of data
								    foreach(get_sub_field('beitraege') as $post) :  setup_postdata($post);
					
										?>
										
										<div class="col col-1-3 ">	<div class="news <?php echo (get_field("top-news") ? (has_post_thumbnail() ? ' hasImage top' : ' top') :  (has_post_thumbnail() ? ' hasImage breaking' : ' special')); ?>">
	<span class="date"><?php echo get_the_date(); ?></span>
					
					<a href="<?php the_permalink(); ?>" class="news-hover"></a>			
					
					<?php if(has_post_thumbnail()): ?>
					
						<figure>
						<?php the_post_thumbnail(); ?>
						</figure>
					
					<?php endif; ?>	
						
					<h3><?php the_title(); ?></h3>
											<?php the_excerpt(); ?>
											<span class="cat"><?php $cats = []; foreach((get_the_category()) as $category){
        $cats[] = $category->name;
        } echo implode(", ", $cats);	?></span>

				</div></div>
										</div>
										
										<?php
									endforeach;  wp_reset_postdata();
								endif; ?>
							
			   		 	</div>
			   		</section>
					  
					
					 <?php 
						 
						 
						  elseif( get_row_layout() == 'team' ): ?>
			   		
			   		
			   		<section  id="<?php echo (get_sub_field("anker") ? get_sub_field("anker") : sanitize_title(get_sub_field("headline"))); ?>" class="<?php the_sub_field("hintergrund"); ?>">
			   		 	<h2><?php the_sub_field("headline"); ?></h2>
					    
					    
			   		 	<div class="row">  	
				   		 	<div class="team-component">
		      				   		 	<?php
					   		 	if( get_sub_field('personen') ):
$uniq = uniqid("persons");
					$i = 1;
								 	// loop through the rows of data
								    foreach(get_sub_field('personen') as $post) :  setup_postdata($post);
					
										?>
										<div class="col col-1-4">
			      
				<figure class="person c"><?php the_post_thumbnail("large"); ?></figure>
				<h3><?php the_title(); ?></h3>
				<div class="desc">
					<p><?php the_field("bezeichnung"); ?></p>
					<p class="hidden-team-el"><a href="mailto:<?php the_field("e-mail"); ?>">Mail</a> | <a href="<?php the_field("v-card"); ?>">V-Card</a></p>
				</div>
		      </div>



																			
										<?php
											
										if($i == 8){
											
											?>
											
											 <div class="show-more" id="show-more-<?php echo $uniq; ?>">
											
											<?php
										}	
											
											
									$i ++; endforeach;  wp_reset_postdata(); ?>
									
											 </div><br clear="all">
											 	<div class="button-group space-ml-top">
							    	<a href="#show-more-<?php echo $uniq; ?>" class="button rounded js-show-more white" data-read-more="Alle anzeigen" data-read-less="Weniger anzeigen">Alle anzeigen</a>
							    	<!--a href="" class="button rounded white ml bordered">Zu den Branchen</a-->
						    	</div>
					    	
											 
								<?php endif; ?>
				   		 	</div>
			   		 	</div>
			   		</section>
					  
					
					 <?php 
		         elseif( get_row_layout() == 'zitat' ):
		         
		        ?>
					
					<section class="<?php the_sub_field("hintergrund"); ?>  quote">
	<div class="row">
		<blockquote><em><?php the_sub_field("zitat"); ?></em><small><?php the_sub_field("name"); ?></small></blockquote>
	</div>
	
</section>
	    


	          <?php 
		          
		            elseif( get_row_layout() == 'logos' ):
		         
		         
		     
		         
		      
		         
	?>
	
	
	  <section id="clients" class=" ">
	    <div class="row animated ">
			   		 	<h2><?php the_sub_field("headline"); ?></h2>
		
<?php
		         if( get_sub_field('logos_loop') ):

	 	// loop through the rows of data
	   $images =  get_sub_field('logos_loop');
	   
	   foreach($images as $image):
	
	    ?>
	          
	          
	          
	          
	          
    
   
				
				
				<div class="col col-1-3">
					<figure class="client-image">
						<?php
								echo '<img src="' . $image["url"] . '">';
								?>
					</figure>
				</div>
				
			
				
				<?php endforeach;  endif;?>
			
		</div>
     </section>
     <?php



		         elseif( get_row_layout() == 'facts' ):
		         
		         
		     
		         if( have_rows('facts_loop') ):
		         
		         $cols = 0;
	    while ( have_rows('facts_loop') ) : the_row();
	    	$cols++;
	    endwhile;
		         
	?>
	
	
	  <section id="<?php echo (get_sub_field("anker") ? get_sub_field("anker") : sanitize_title(get_sub_field("headline"))); ?>" class="fact-list ">
	    <div class="row animated ">
			   		 	<h2><?php the_sub_field("headline"); ?></h2>
			<div class="col <?php echo ($cols == 3 ? 'col-90 offset-5' : 'col-80 offset-10'); ?>">

<?php
	 	// loop through the rows of data
	    while ( have_rows('facts_loop') ) : the_row();
	    
	    ?>
	          
	          
	          
	          
	          
    
   
				
				
				<div class="col col-1-<?php echo $cols; ?><?php echo (get_sub_field("highlight") ? ' primary' : ''); ?>">
					  <h3><span><?php the_sub_field("bezeichnung"); ?></span></h3>
						<?php the_sub_field("inhalt"); ?>
				</div>
				
			
				
				<?php endwhile; ?>
			</div>
		</div>
     </section>
     <?php endif; ?>
	          
	          <?php
		        
		         elseif( get_row_layout() == 'content_transform' ):
		         
		         
		       
		         $uniqid = uniqid(time());
		         
		         $colorclass = (get_sub_field("hintergrund") == "white" || get_sub_field("hintergrund") == "odd") ? 'primary' : 'white bordered';
		         $colorclass2 = (get_sub_field("hintergrund") == "white" || get_sub_field("hintergrund") == "odd") ? 'primary' : 'white';
		         
		         
		         if($nachfolgende_elemente_erst_bei_klick_sichtbar){
			         ?>
			         
			             <section data-show-js="show-more-<?php echo $nachfolgende_elemente_id; ?>" id="<?php echo (get_sub_field("anker") ? get_sub_field("anker") : sanitize_title(get_sub_field("headline"))); ?>" class="transform colored-<?php the_sub_field("hintergrund"); ?><?php echo (get_sub_field("gerader_abschluss") ? ' onlyBottom' : ''); ?><?php echo (get_sub_field("gerader_abschluss_oben") ? ' onlyTop' : ''); ?> hidden">
		<?php
			         
		         }else{
			         ?>
			         
			             <section id="<?php echo (get_sub_field("anker") ? get_sub_field("anker") : sanitize_title(get_sub_field("headline"))); ?>" class="transform colored-<?php the_sub_field("hintergrund"); ?><?php echo (get_sub_field("gerader_abschluss") || get_sub_field("nachfolgende_elemente_erst_bei_klick_sichtbar") ? ' onlyBottom' : ''); ?><?php echo (get_sub_field("gerader_abschluss_oben") ? ' onlyTop' : ''); ?>">
		
			         <?php
		         }
		         ?>
	        
	       

		
		<?php if(get_sub_field("headline")): ?>
			<h2><?php the_sub_field("headline"); ?></h2>
		<?php endif; ?>
	    <div class="row mlr animated">
		    
		    
		    <div class="carousel-component">
			    
			    <ul>
				    
				    <li class="c">
				    <?php if(get_sub_field("bildposition")  == "left"): ?>
				    	<div class="col col-45">
					    	<figure>
					    	<?php
								$img = get_sub_field("bild"); 
								echo '<img src="' . $img["url"] . '" alt="4net.ch – ' . get_sub_field("headline") . '">';
								?>
					    	</figure>
				    	</div>
				    	<div class="col col-50  offset-5">
				    	<?php else: ?>
				    	
				    	<div class="col col-45 fr">
					    	<figure>
					    		
					    		<?php
								$img = get_sub_field("bild"); 
								echo '<img src="' . $img["url"] . '" alt="4net.ch – ' . get_sub_field("headline") . '">';
								?>
					    	</figure>
				    	</div>
				    	<div class="col col-50  offset-r-5">
				    	<?php endif; ?>
				    	
					    	
					    	<h3><small><?php the_sub_field("subline"); ?></small><?php the_sub_field("textline"); ?></h3>
					    	<?php the_sub_field("inhalt"); ?>
					    	
					    	<?php if(get_sub_field("mehr_inhalt")): ?>
					    		<?php if(get_sub_field("text_interner_link_oder_externer_link") == "Text"): ?>
					    		<div class="show-more" id="show-more-<?php echo $uniqid; ?>">
						    		<?php the_sub_field("mehr_inhalt_text"); ?>
					    		</div>
					    		<div class="button-group space-ml-top">
							    	<a href="#show-more-<?php echo $uniqid; ?>" class="button rounded <?php echo $colorclass; ?> js-show-more" data-read-more="Mehr dazu" data-read-less="Weniger anzeigen">Mehr dazu</a>
							    	<?php if(get_sub_field("weiterer_link_beschreibung") && get_sub_field("weiterer_link_beschreibung")): ?>
							    	<a href="<?php the_sub_field("weiterer_link"); ?>" class="button rounded ml <?php echo $colorclass2; ?>"><?php the_sub_field("weiterer_link_beschreibung"); ?></a>
							    	<?php endif; ?>
							    	<!--a href="" class="button rounded white ml bordered">Zu den Branchen</a-->
						    	</div>
					    	
					    	
								<?php elseif(get_sub_field("text_interner_link_oder_externer_link") == "interner Link" && get_sub_field("interner_link")): ?>
						    		<div class="button-group space-ml-top">
								    	<a href="<?php the_sub_field("interner_link"); ?>" class="button rounded <?php echo $colorclass; ?>"><?php the_sub_field("linkbezeichnung"); ?></a>
								    	<!--a href="" class="button rounded white ml bordered">Zu den Branchen</a-->
							    	</div>
								<?php elseif(get_sub_field("text_interner_link_oder_externer_link") == "externer Link" && get_sub_field("externer_link")): ?>
						    		<div class="button-group space-ml-top">
								    	<a href="<?php the_sub_field("externer_link"); ?>" target="_blank" class="button rounded <?php echo $colorclass; ?>"><?php the_sub_field("linkbezeichnung"); ?></a>
								    	<!--a href="" class="button rounded white ml bordered">Zu den Branchen</a-->
							    	</div>
								<?php endif; ?>
					    	
					    	
					    	
					    	
					    	
					    	<?php endif; ?>
					    	
				    	</div>
				    	
				    </li>	 				    
				    
				    
				    
			    </ul>
			    
			    
			    <?php 
				    
				      if(get_sub_field("nachfolgende_elemente_erst_bei_klick_sichtbar")){
			         $nachfolgende_elemente_erst_bei_klick_sichtbar = true;
			         $nachfolgende_elemente_id =  $uniqid = uniqid(time().'nachfolgende_elemente_erst_bei_klick_sichtbar');
			         
			         ?>
			         <div class="button-group space-top">
			         <a href="#" data-trigger="show-more-<?php echo $nachfolgende_elemente_id; ?>" class="button rounded dark bordered js-show-more-by-data" data-read-more="Alle Module anzeigen" data-read-less="Weniger Module anzeigen">Alle Module anzeigen</a>
			         </div>
			         <?php
		         }
				    
				    ?>
			    
		    </div>
		    
		    
		    
		    
		    
	    </div>
	    </section>
					  
					
					
    
	
	        		
	        <?php 
		        
		        
		        

		        
		        
		        
		        
		        
		        
		        
		        endif;
	
	    endwhile;
	
	else :
	
	    // no layouts found
	
	endif;
	
	?>     
            <?php endwhile; ?>
   
   
    
    <?php get_footer();?>