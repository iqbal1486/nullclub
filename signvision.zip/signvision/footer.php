	
     <footer>  <span id="backtotop"></span>		

	    <div class="row">
		    <div class="col col-100">
			    <div class="row mw">
				 
				   
				    <div class="col col-25">
					    <h3><span>Kontakt</span></h3>

					    <p><strong>signvision gmbh</strong><br>
						    Flawilerstrasse 19a<br>
						    9200 Gossau<br>
						    Tel. +41 71 388 78 78
						    <br>Fax +41 71 388 78 79<br>
<a href="mailto:info@signvision.ch" class="txt">info@signvision.ch</a>
						</p>
						
						
					    
					
					</div>
					 
				   
				    <div class="col col-25">
					    <h3><span>Öffnungszeiten





</span></h3>	
				<p><strong>Montag bis Freitag</strong><br>
7.30 Uhr bis 12.00 Uhr<br>
13.00 Uhr bis 17.00 Uhr</p>
					</div>
					<div class="padspacer"></div>
					 <div class="col col-25">
					    <h3><span>Social Media</span></h3>
						    <div class="social-icons"><!--a href="https://de.linkedin.com/company/signvision" target="_blank" class="nobord"><img src="<?php bloginfo("template_directory");?>/static/media/linkedin.png" width="32" height="32" alt=""></a--> 
						    
						        <a href="https://www.youtube.com/channel/UC9z_76J5xjUgTl2HfIfCxPQ"  class="nobord nofollow" target="_blank">
							    <img src="/wp-content/themes/signvision/static/media/youtube.png"  width="32" height="32" alt="">
							 </a>
							 <a href="https://www.instagram.com/signvision.ch"  class="nobord mleft20" target="_blank">
							    <img src="/wp-content/themes/signvision/static/media/instagram.png"  width="32" height="32" alt="">
							 </a>
						    
						    <a href="https://www.facebook.com/signvision.ch/"  class="nobord mleft20" target="_blank">
							    <img src="/wp-content/themes/signvision/static/media/facebook.png"  width="32" height="32" alt="">
							    </a>
							    
							    </div>
					    
					</div>
					 
					 <div class="col col-25">
					    <h3><span>Newsletter</span></h3>
					    				<p>Ich möchte regelmässig<br>informiert werden:</p>						
							
								<?php #echo do_shortcode('[newsletter2go form_type=subscribe]'); ?>
					
						
						
<?php echo do_shortcode('[contact-form-7 id="3473" html_class="quick-search" title="Kontaktformular_copy"]'); ?>

					    
					</div>
					
					
					
					
					 
			    </div>
			    <hr>
			    <div class="row mw copyright">
			    <div class="col col-25">
					<p>© signvision <?php echo date("Y"); ?></p>
				</div>
				
				<div class="col col-25">
					<p><a href="/sonnenschutz/impressum" class="copyright-link">Impressum</a><a href="/sonnenschutz/datenschutz" class="copyright-link">Datenschutz</a></p>
				</div>
					 
			    </div>  
				   					
					
					
					
					 
			    </div>
			  
			   
			</div>
		    <div class="offset-5"></div>
    </footer>

		<script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.0/jquery.min.js"></script>
		<script src="<?php bloginfo("template_directory");?>/static/js/tooltip-min.js"></script>
		<script src="<?php bloginfo("template_directory");?>/static/js/app-min.js"></script>
		<script src="<?php bloginfo("template_directory");?>/static/js/kreativwolke-min.js"></script>
		
		<script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAYzg-IsGtXcTia3cu6i8EIKvyN2B98qwY"></script>
		
		   <script>
			   
$(window).on("load", initMap);


       function initMap() {
	      
	      if($("#map").length > 0){ 
	        var uluru = {lat: parseFloat($("#map").data("latitude")), lng: parseFloat($("#map").data("longitude"))};
	        console.log(uluru);
	        var mapOptions = {
                    // How zoomed in you want the map to start at (always required)
                    zoom: 17,

                    // The latitude and longitude to center the map (always required)
                    center: uluru, // New York

                    // How you would like to style the map. 
                    // This is where you would paste any style found on Snazzy Maps.
                    styles:[{"featureType":"water","elementType":"geometry","stylers":[{"color":"#e9e9e9"},{"lightness":17}]},{"featureType":"landscape","elementType":"geometry","stylers":[{"color":"#f5f5f5"},{"lightness":20}]},{"featureType":"road.highway","elementType":"geometry.fill","stylers":[{"color":"#ffffff"},{"lightness":17}]},{"featureType":"road.highway","elementType":"geometry.stroke","stylers":[{"color":"#ffffff"},{"lightness":29},{"weight":0.2}]},{"featureType":"road.arterial","elementType":"geometry","stylers":[{"color":"#ffffff"},{"lightness":18}]},{"featureType":"road.local","elementType":"geometry","stylers":[{"color":"#ffffff"},{"lightness":16}]},{"featureType":"poi","elementType":"geometry","stylers":[{"color":"#f5f5f5"},{"lightness":21}]},{"featureType":"poi.park","elementType":"geometry","stylers":[{"color":"#dedede"},{"lightness":21}]},{"elementType":"labels.text.stroke","stylers":[{"visibility":"on"},{"color":"#ffffff"},{"lightness":16}]},{"elementType":"labels.text.fill","stylers":[{"saturation":36},{"color":"#333333"},{"lightness":40}]},{"elementType":"labels.icon","stylers":[{"visibility":"off"}]},{"featureType":"transit","elementType":"geometry","stylers":[{"color":"#f2f2f2"},{"lightness":19}]},{"featureType":"administrative","elementType":"geometry.fill","stylers":[{"color":"#fefefe"},{"lightness":20}]},{"featureType":"administrative","elementType":"geometry.stroke","stylers":[{"color":"#fefefe"},{"lightness":17},{"weight":1.2}]}]
                };


				var mapElement = document.getElementById('map');

                // Create the Google Map using our element and options defined above
                var map = new google.maps.Map(mapElement, mapOptions);
var icon = {
    url: "/sonnenschutz/wp-content/themes/signvision/static/media/map-icon.svg", // url
    scaledSize: new google.maps.Size(50, 50), // scaled size
    origin: new google.maps.Point(0,0), // origin
    anchor: new google.maps.Point(0, 0) // anchor
};

                // Let's also add a marker while we're at it
                var marker = new google.maps.Marker({
                    position: new google.maps.LatLng(uluru.lat, uluru.lng),
                    map: map,
                    icon: icon
                                    });
                
             

        var infowindow = new google.maps.InfoWindow({
          content: contentString
        });

      
        marker.addListener('click', function() {
          infowindow.open(map, marker);
        });
        
        

				
			}
      }
    </script>
		
 </div>
<?php wp_footer(); ?>
    
    <script>
document.addEventListener( 'wpcf7mailsent', function( event ) {
    location = 'https://www.signvision.ch/sonnenschutz/kontakt/danke/';
}, false );
</script>

  </body>
</html>