<?php /* Template Name: Einstieg */ get_header("einstieg");?>


   <div id="welcome">
	   <div class="welcome-col dark" style="background: url(http://signvision.kunden.kreativ-wolke.de/wp-content/uploads/2018/09/03-1920x930px.jpg) center center no-repeat; background-size: cover; ">
		   <div class="mask"></div>
		   <a href="" class="welcome-link"></a>
		   <div class="brand">
			   <img src="<?php bloginfo( 'template_directory' ); ?>/static/media/logo1@2x.png">
		   </div>
		   <div class="arrow">
			   <img src="<?php bloginfo( 'template_directory' ); ?>/static/media/icons/arrow.svg">
		   </div>
	   </div>
	   
	   <div class="welcome-col light" style="background: url(http://signvision.kunden.kreativ-wolke.de/wp-content/uploads/2018/09/02-1920x930px.jpg) center center no-repeat; background-size: cover; ">
		   <div class="mask"></div>
		   <a href="" class="welcome-link"></a>
		   <div class="brand">
			   <img src="<?php bloginfo( 'template_directory' ); ?>/static/media/logo2@2x.png">
		   </div>
		   <div class="arrow">
			   <img src="<?php bloginfo( 'template_directory' ); ?>/static/media/icons/arrow.svg">
		   </div>
	   </div>
	   
	   
   </div>
   
    
    <?php get_footer("einstieg");?>