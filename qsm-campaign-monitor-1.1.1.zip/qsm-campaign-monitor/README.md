# QSM - Campaign Monitor Integration
Adds Campaign Monitor integration to quizzes and surveys created using Quiz And Survey Master.

## Getting Started
This can be downloaded as a zip and installed as-is with no build script needing to be run.

## Versioning
We use [SemVer](http://semver.org/) for versioning. For the versions available, see [the releases in this repository](https://github.com/QuizandSurveyMaster/qsm-campaign-monitor/releases).

## License
This project is licensed under the GPLv2 License - see the [LICENSE file](https://github.com/QuizandSurveyMaster/qsm-campaign-monitor/blob/master/LICENSE) for details.

## Support ##
This is a developer's portal for Quiz And Survey Master and should _not_ be used for support. Please [create a support ticket here](https://quizandsurveymaster.com/quiz/contact/).

