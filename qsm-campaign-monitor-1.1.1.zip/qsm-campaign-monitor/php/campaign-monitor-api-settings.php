<?php
function qmn_generate_campaign_monitor_page()
{
	?>
	
	
	<div class="wrap">
	
	<h2><?php _e( 'Campaign  Integration', 'qsm-campaign-monitor' ); ?></h2>
	<form method="post" action="options.php">
		<?php settings_fields('qmn_campaign_monitor_settings'); ?>
		<?php $qmn_campaign_monitor_api = get_option('qmn_campaign_monitor_option'); ?>
	
            <p><?php _e( 'Please refer to the documentation for help with API keys, installation, and other information.', 'qsm-campaign-monitor' ); ?></p>
		<h3><?php _e( 'Table Settings', 'qsm-campaign-monitor' ); ?></h3>
        <table class="form-table">
            <tr valign="top"><th scope="row"><?php _e( 'What is your API Key?', 'qsm-campaign-monitor' ); ?></th>
                <td><input name="qmn_campaign_monitor_option[api_key]" type="text" value="<?php echo $qmn_campaign_monitor_api['api_key']; ?>" /></td>
            </tr>
        </table>
        <p class="submit">
        	<input type="submit" class="button-primary" value="<?php _e( 'Save Changes', 'qsm-campaign-monitor' ) ?>" />
        </p>
    </form>

	
	
	
	</div>	
	<?php
}




?>