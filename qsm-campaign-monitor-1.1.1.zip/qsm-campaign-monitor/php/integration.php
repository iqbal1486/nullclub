<?php
/**
 * This file handles the actual checkbox and subscribing.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Creates the checkbox, if enabled
 *
 * @since 1.1.0
 */
function qsm_addon_campaign_monitor_integration_checkbox() {
	$settings = QSM_Campaign_Monitor_Integration::get_quiz_settings();
	// If converkit integration is enabled, the checkbox is set to be shown, and the text for the checkbox is not empty.
	if ( 'yes' === $settings['enable'] && 'show' === $settings['display'] && ! empty( $settings['text'] ) ) {
		?>
		<div class="qsm_contact_div qsm-contact-type-checkbox">
			<input type='checkbox' name='qsm_campaign_monitor_checkbox' id='qsm_campaign_monitor_checkbox' value='1' />
			<label for='qsm_campaign_monitor_checkbox' class='qsm-campaign-monitor-label mlw_qmn_question qsm_question'><?php echo esc_html( $settings['text'] ); ?></label>
		</div>
		<?php
	}
}

/**
 * Subscribes user to the mailing list, if enabled
 *
 * @since 1.1.0
 * @param string $content The results page content from filter.
 * @param array  $options The settings for the quiz.
 * @param array  $quiz_results The data for the user's quiz session.
 * @return string The modified content to send back to filter.
 */
function qsm_addon_campaign_monitor_integration_subscribe( $content, $options, $quiz_results ) {
	global $mlwQuizMasterNext;
	$settings       = QSM_Campaign_Monitor_Integration::get_quiz_settings();
	$addon_settings = QSM_Campaign_Monitor_Integration::get_settings();

	// If api_key is entered and campaign monitor is enabled and either the checkbox was checked or the checkbox is set to be hidden.
	if ( ! empty( $addon_settings['api_key'] ) && 'yes' === $settings['enable'] && ( isset( $_POST['qsm_campaign_monitor_checkbox'] ) || 'hide' === $settings['display'] ) ) {
		$user_email = isset( $quiz_results['user_email'] ) ? sanitize_email( $quiz_results['user_email'] ) : '';
		$user_name  = isset( $quiz_results['user_name'] ) ? sanitize_text_field( $quiz_results['user_name'] ) : '';

		if ( ! class_exists( 'CS_REST_Subscribers' ) ) {
			include 'campaign-monitor/csrest_subscribers.php';
		}
		$auth = array( 'api_key' => $addon_settings['api_key'] );
		$wrap = new CS_REST_Subscribers( $settings['list'], $auth );

		$result = $wrap->add(array(
			'EmailAddress'   => $user_email,
			'Name'           => $user_name,
			'Resubscribe'    => true,
			'ConsentToTrack' => 'Yes',
		));
		if ( ! $result->was_successful() ) {
			$msg = "Error given: {$result->response->Message}";
			$mlwQuizMasterNext->log_manager->add( 'Error With Campaign Monitor API Call', $msg, 0, 'error' );
		}
	}
	return $content;
}
