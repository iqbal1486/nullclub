<?php
/**
 * This file handles the Quiz Settings tab for the addon
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers your tab in the quiz settings page
 *
 * @since 1.1.0
 * @return void
 */
function qsm_addon_campaign_monitor_integration_register_quiz_settings_tabs() {
	global $mlwQuizMasterNext;
	if ( ! is_null( $mlwQuizMasterNext ) && ! is_null( $mlwQuizMasterNext->pluginHelper ) && method_exists( $mlwQuizMasterNext->pluginHelper, 'register_quiz_settings_tabs' ) ) {
		$mlwQuizMasterNext->pluginHelper->register_quiz_settings_tabs( 'Campaign Monitor', 'qsm_addon_campaign_monitor_integration_quiz_settings_tabs_content' );
	}
}

/**
 * Generates the content for your quiz settings tab
 *
 * @since 1.1.0
 * @return void
 */
function qsm_addon_campaign_monitor_integration_quiz_settings_tabs_content() {

	global $mlwQuizMasterNext;

	$addon_settings = QSM_Campaign_Monitor_Integration::get_settings();
	if ( empty( $addon_settings['api_key'] ) ) {

		$mlwQuizMasterNext->alertManager->newAlert(__( 'You have not set up the API key on the Addon Settings page yet!', 'qsm-campaign-monitor' ), 'error' );
		return;
	}

	// If nonce is set and correct, save the form.
	if ( isset( $_POST['campaign_monitor_integration_nonce'] ) && wp_verify_nonce( $_POST['campaign_monitor_integration_nonce'], 'campaign_monitor_integration') ) {
		$settings = array(
			'enable'  => sanitize_text_field( $_POST['campaign_monitor_enable'] ),
			'display' => sanitize_text_field( $_POST['campaign_monitor_checkbox_display'] ),
			'text'    => sanitize_text_field( $_POST['campaign_monitor_checkbox_text'] ),
			'list'    => sanitize_text_field( $_POST['campaign_monitor_list_id'] ),
		);
		$mlwQuizMasterNext->pluginHelper->update_quiz_setting( 'campaign_monitor_settings', $settings );
		$mlwQuizMasterNext->alertManager->newAlert( __( 'Your Campaign Monitor settings has been saved successfully!', 'qsm-campaign-monitor' ), 'success' );
	}

	// Loads the settings.
	$settings = QSM_Campaign_Monitor_Integration::get_quiz_settings();
	?>
	<div id="tabs-campaign_monitor-integration" class="mlw_tab_content">
		<h2>	<?php _e( 'Campaign Monitor Integration', 'qsm-campaign-monitor' ); ?>
		</h2>
		<form action="" method="post">
			<button class="button-primary">	<?php _e( 'Save Settings', 'qsm-campaign-monitor' ); ?>
		</button>
			<table class="form-table" style="width: 100%;">
				<tr valign="top">
					<th scope="row"><label for="campaign_monitor_enable"><?php _e( 'Enable Campaign Monitor Integration for this quiz?', 'qsm-campaign-monitor' ); ?>
		</label></th>
					<td>
						<input type="radio" id="campaign_monitor_enable_radio1" name="campaign_monitor_enable" <?php checked( $settings['enable'], 'yes' ); ?> value='yes' /><label for="campaign_monitor_enable_radio1"><?php _e( 'Yes', 'qsm-campaign-monitor' ); ?>
		</label><br>
						<input type="radio" id="campaign_monitor_enable_radio2" name="campaign_monitor_enable" <?php checked( $settings['enable'], 'no' ); ?> value='no' /><label for="campaign_monitor_enable_radio2">	<?php _e( 'No', 'qsm-campaign-monitor' ); ?>
		</label><br>
					</td>
				</tr>
				<tr valign="top">
					<th scope="row"><label for="campaign_monitor_checkbox_display">	<?php _e( 'Display checkbox for optional subscribing or hide checkbox for automatic subscribing?', 'qsm-campaign-monitor' ); ?>
		</label></th>
					<td>
						<input type="radio" id="campaign_monitor_checkbox_display_radio1" name="campaign_monitor_checkbox_display" <?php checked( $settings['display'], 'show' ); ?> value='show' /><label for="campaign_monitor_checkbox_display_radio1"><?php _e( 'Show', 'qsm-campaign-monitor' ); ?>
		</label><br>
						<input type="radio" id="campaign_monitor_checkbox_display_radio2" name="campaign_monitor_checkbox_display" <?php checked( $settings['display'], 'hide' ); ?> value='hide' /><label for="campaign_monitor_checkbox_display_radio2"><?php _e( 'Hide', 'qsm-campaign-monitor' ); ?>
		</label><br>
					</td>
				</tr>
				<tr valign="top">
					<th scope="row"><label for="campaign_monitor_checkbox_text"><?php _e( 'Text displayed next to checkbox if shown?', 'qsm-campaign-monitor' ); ?>
		</label></th>
					<td>
						<input type="text" name="campaign_monitor_checkbox_text" id="campaign_monitor_checkbox_text" value="<?php echo esc_attr( $settings['text'] ); ?>" >
					</td>
				</tr>
				<tr valign="top">
					<th scope="row"><label for="campaign_monitor_subscribe_form">	<?php _e( 'Subscribe user to list:', 'qsm-campaign-monitor' ); ?>
		</label></th>
					<td>
						<input type="text" name="campaign_monitor_list_id" id="campaign_monitor_list_id" value="<?php echo esc_attr( $settings['list'] ); ?>" >
					</td>
				</tr>
			</table>
			<?php wp_nonce_field( 'campaign_monitor_integration', 'campaign_monitor_integration_nonce' ); ?>
			<button class="button-primary">	<?php _e( 'Save Settings', 'qsm-campaign-monitor' ); ?>
		</button>
		</form>
	</div>
	<?php
}
?>
