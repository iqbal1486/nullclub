<?php
/**
 * Plugin Name: QSM - Campaign Monitor Integration
 * Plugin URI: https://quizandsurveymaster.com/
 * Description: Adds Campaign Monitor integration to your quizzes or surveys
 * Text Domain:qsm-campaign-monitor
 * Author: Frank Corso
 * Author URI: https://quizandsurveymaster.com/
 * Version: 1.1.1
 *
 * @author Frank Corso
 * @version 1.1.1
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


/**
 * This class is the main class of the plugin
 *
 * When loaded, it loads the included plugin files and add functions to hooks or filters. The class also handles the admin menu
 *
 * @since 1.1.0
 */
class QSM_Campaign_Monitor_Integration {

	/**
	 * Version Number
	 *
	 * @var string
	 * @since 1.1.0
	 */
	public $version = '1.1.1';

	/**
	 * Main Construct Function
	 *
	 * Call functions within class
	 *
	 * @since 1.1.0
	 * @uses QSM_Convertkit_Integration::load_dependencies() Loads required filed
	 * @uses QSM_Convertkit_Integration::add_hooks() Adds actions to hooks and filters
	 * @uses QSM_EDD_Integration::check_license() Checks the license for the addon
	 * @return void
	 */
	public function __construct() {
		$this->load_dependencies();
		$this->add_hooks();
		$this->check_license();
	}

	/**
	 * Load File Dependencies
	 *
	 * @since 1.1.0
	 * @return void
	 * @todo If you are not setting up the addon settings tab, the quiz settings tab, or variables, simply remove the include file below
	 */
	public function load_dependencies() {
		include 'php/addon-settings-tab-content.php';
		include 'php/quiz-settings-tab-content.php';
		include 'php/integration.php';
	}

	/**
	 * Add Hooks
	 *
	 * Adds functions to relavent hooks and filters
	 *
	 * @since 1.1.0
	 * @return void
	 * @todo If you are not setting up the addon settings tab, the quiz settings tab, or variables, simply remove the relevant add_action below
	 */
	public function add_hooks() {
		add_action( 'admin_init', 'qsm_addon_campaign_monitor_integration_register_quiz_settings_tabs' );
		add_action( 'admin_init', 'qsm_addon_campaign_monitor_integration_register_addon_settings_tabs' );
		add_action( 'qsm_contact_fields_end', 'qsm_addon_campaign_monitor_integration_checkbox' );
		add_filter( 'qmn_after_results_text', 'qsm_addon_campaign_monitor_integration_subscribe', 10, 3 );
	    		add_action( 'admin_init', array( $this, 'qsm_addon_qsm_campaign_monitor_textdomain' ) );
	}

	/**
	 * Retrieves addon settings for this plugin.
	 *
	 * @since 1.1.0
	 * @return array The addon settings for the plugin
	 */
	public static function get_settings() {
		$addon_data     = get_option( 'qsm_addon_campaign_monitor_integration_settings', '' );
		$addon_defaults = array(
			'license_key' => '',
			'api_key'     => '',
		);
		return wp_parse_args( $addon_data, $addon_defaults );
	}

	/**
	 * Retrieves plugin settings for an individual quiz
	 *
	 * @since 1.1.0
	 * @return array The settings for the plugin
	 */
	public static function get_quiz_settings() {
		global $mlwQuizMasterNext;
		$settings          = $mlwQuizMasterNext->pluginHelper->get_quiz_setting( 'campaign_monitor_settings' );
		$settings_defaults = array(
			'enable'  => 'no',
			'display' => 'show',
			'text'    => 'Subscribe me to your newsletter!',
			'list'    => 'none',
		);
		return wp_parse_args( $settings, $settings_defaults );
	}

	/**
	 * Checks license
	 *
	 * Checks to see if license is active and, if so, checks for updates
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public function check_license() {
		if ( ! class_exists( 'EDD_SL_Plugin_Updater' ) ) {
			include 'php/EDD_SL_Plugin_Updater.php';
		}

		// Retrieve our license key from the DB.
		$addon_data = get_option( 'qsm_addon_campaign_monitor_integration_settings', '' );
		if ( isset( $addon_data['license_key'] ) ) {
			$license_key = trim( $addon_data['license_key'] );
		} else {
			$license_key = '';
		}

		// Setup the updater.
		$edd_updater = new EDD_SL_Plugin_Updater( 'https://quizandsurveymaster.com', __FILE__, array(
			'version'   => $this->version,
			'license'   => $license_key,
			'item_name' => 'Campaign Monitor Integration',
			'author'    => 'Frank Corso',
		));
	}
		/**
     * Adds localization support 
     */
    public function qsm_addon_qsm_campaign_monitor_textdomain() {
        load_plugin_textdomain( 'qsm-campaign-monitor', false, dirname( plugin_basename( __FILE__ ) ) . '/lang/' );
    }
}


/**
 * Loads the addon if QSM is installed and activated
 *
 * @since 1.1.0
 */
function qsm_addon_campaign_monitor_integration_load() {
	// Make sure QSM is active.
	if ( class_exists( 'MLWQuizMasterNext' ) ) {
		$qsm_campaign_monitor_integration = new QSM_Campaign_Monitor_Integration();
	} else {
		add_action( 'admin_notices', 'qsm_addon_campaign_monitor_integration_missing_qsm' );
	}
}
add_action( 'plugins_loaded', 'qsm_addon_campaign_monitor_integration_load' );

/**
 * Display notice if Quiz And Survey Master isn't installed
 *
 * @since 1.1.0
 */
function qsm_addon_campaign_monitor_integration_missing_qsm() {
	echo '<div class="error"><p>';
	_e( 'QSM - Campaign Monitor Integration requires Quiz And Survey Master. Please install and activate the Quiz And Survey Master plugin.', 'qsm-campaign-monitor' ); 
	echo '</p></div>';
}