Payeezy Payment Method
=========

This plugin/addon needs to be uploaded to the "/wp-content/plugins/" directory on your server or installed using the WordPress plugins installer.

Then you will need to go to the Event Espresso Payment options page to activate the payment method and set the required settings.