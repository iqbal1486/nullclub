<p>
	<strong><?php esc_html_e('First Data Payeezy Gateway', 'event_espresso'); ?></strong>
</p>
<p>
	<?php printf( esc_html__('This is a brief description for the options that are required to setup the Payeezy Gateway. More information can be found in the %1$s First Data Payeezy Gateway API Library. %2$s'), '<a href="https://support.payeezy.com/hc/en-us/sections/200873599-Gateway-API-Library" target="_blank">', '</a>' ); ?>
</p>
<ul>
	<li>
		<strong><?php esc_html_e('Gateway ID (Exact ID)', 'event_espresso'); ?></strong><br/>
		<?php esc_html_e('Also known as the Gateway ID, this value identifies the Merchant and Terminal under which the transaction is to be processed.'); ?><br/>
		<?php printf( esc_html__('The Gateway ID can be found on the %1$sAdministration%2$s tab under Terminals and then Details.'), '<a href="https://globalgatewaye4.firstdata.com/terminal" target="_blank">', '</a>' ); ?><br/>
	</li>
	<li>
		<strong><?php esc_html_e('Password', 'event_espresso'); ?></strong><br/>
		<?php esc_html_e('Authenticates the Payeezy Gateway Web Service API request, this value should not be exposed to the public.'); ?><br/>
		<?php printf( esc_html__('The Password can be set/generated on the Terminal Details page, %1$sAdministration%2$s section.'), '<a href="https://globalgatewaye4.firstdata.com/terminal" target="_blank">', '</a>' ); ?><br/>
	</li>
	<li>
		<strong><?php esc_html_e('HMAC Key', 'event_espresso'); ?></strong><br/>
		<?php esc_html_e('SHA-1 HMAC hash calculation is offered to increase the security of transaction processing through this interface.'); ?><br/>
		<?php printf( esc_html__('For more details on how the HMAC Key can be obtained please visit %1$this documentation page%2$s.'), '<a href="https://support.payeezy.com/hc/en-us/articles/203731149-API-Security-HMAC-Hash" target="_blank">', '</a>' ); ?><br/>
	</li>
	<li>
		<strong><?php esc_html_e('HMAC Key ID', 'event_espresso'); ?></strong><br/>
		<?php esc_html_e('The HMAC Key identifier. Can be found right above the HMAC Key.'); ?><br/>
	</li>
	<li>
		<strong><?php esc_html_e('Level 3 Data Supported', 'event_espresso'); ?></strong><br/>
		<?php esc_html_e('The following properties are used to populate additional information about the transaction, including shipping details and line item information.'); ?><br/>
		<?php printf( esc_html__('Level 3 Data can be enabled on the Terminal Details page, %1$sAdministration%2$s section.'), '<a href="https://globalgatewaye4.firstdata.com/terminal" target="_blank">', '</a>' ); ?><br/>
		<?php esc_html_e('Please note that Level 3 data is not supported for American Express card types.'); ?><br/>
	</li>
	<li>
		<strong><?php esc_html_e('Card Types Supported', 'event_espresso'); ?></strong><br/>
		<?php esc_html_e('Select card types that should be allowed to be used at the checkout.', 'event_espresso'); ?>
	</li>
</ul>

<p><strong>
	<?php printf( esc_html__('To set up your Payeezy merchant account for this payment method correctly please refer to%1$s these notes%2$s .', 'event_espresso'), '<a href="https://support.payeezy.com/hc/en-us/articles/203826339-Merchant-Terminal-Settings-in-Payeezy-Gateway-Payment-Pages" target="_blank">', '</a>');?>
</p></strong>
<p><strong>
	<?php printf( esc_html__('* In order to have a better fraud protection it is recommended to use the %1$s"E-commerce (CVV2)"%2$s Terminal type.', 'event_espresso'), '<a href="https://support.payeezy.com/hc/en-us/articles/204504175-How-to-generate-unsuccessful-transactions-during-testing-" target="_blank">', '</a>');?>
</p></strong>