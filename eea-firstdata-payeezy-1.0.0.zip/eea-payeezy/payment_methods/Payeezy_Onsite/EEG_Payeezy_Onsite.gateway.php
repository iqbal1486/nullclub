<?php if ( ! defined('EVENT_ESPRESSO_VERSION') ) { exit('NO direct script access allowed'); }

/**
 * ----------------------------------------------
 *
 * Class  EEG_Payeezy_Onsite
 *
 * @package			Event Espresso
 * @subpackage		eea-first-data-payeezy
 * @author			Event Espresso
 * @version		 	$VID:$
 *
 * ----------------------------------------------
 */
class EEG_Payeezy_Onsite extends EE_Onsite_Gateway {

	/**
	 * Payeezy Exact ID.
	 *  @var string
	 */
	protected $_exact_id = null;

	/**
	 * Payeezy account Password.
	 *  @var string
	 */
	protected $_password = null;


	/**
	 * Payeezy HMAC Key.
	 *  @var string
	 */
	protected $_hmac_key = null;

	/**
	 * Payeezy HMAC Key ID.
	 *  @var string
	 */
	protected $_hmac_key_id = null;

	/**
	 * Level 3 Properties supported.
	 *  @var boolean
	 */
	protected $_lvl_3_data;

	/**
	 * Endpoint URL.
	 * @var $_gateway_endpoint string
	 */
	protected $_gateway_endpoint = null;

	/**
	 * All the currencies supported by this gateway.
	 *  @var array
	 */
	protected $_currencies_supported = array(
		'USD',
		'CAD',
		'AUD'
	);


	/**
	 * Do some setup.
	 *
	 * @param type $settings_array
	 */
	public function set_settings( $settings_array ) {
		parent::set_settings($settings_array);

		if ( $this->_debug_mode ) {
			$this->_gateway_endpoint = 'https://api.demo.globalgatewaye4.firstdata.com/transaction/v21';
		} else {
			$this->_gateway_endpoint = 'https://api.globalgatewaye4.firstdata.com/transaction/v21';
		}
	}


	/**
	 * Process the payment.
	 *
	 * @param EEI_Payment $payment
	 * @param array  $billing_info
	 * @return EE_Payment|EEI_Payment
	 */
	public function do_direct_payment( $payment, $billing_info = null ) {

		// Payment OK?
		if ( ! ($payment instanceof EEI_Payment) ) {
			$payment->set_gateway_response( __('Error. No associated payment was found.', 'event_espresso') );
			$payment->set_status( $this->_pay_model->failed_status() );
			return $payment;
		}
		// Transaction OK?
		$transaction = $payment->transaction();
		if ( ! ($transaction instanceof EEI_Transaction) ) {
			$payment->set_gateway_response( __('Could not process this payment because it has no associated transaction.', 'event_espresso') );
			$payment->set_status( $this->_pay_model->failed_status() );
			return $payment;
		}
		// Primary attendee OK?
		$primary_registration = $transaction->primary_registration();
		$primary_attendee = ( $primary_registration instanceof EEI_Registration ) ? $primary_registration->attendee() : false;
		if ( ! ($primary_attendee instanceof EE_Attendee) ) {
			$payment->set_gateway_response( __('Could not process this payment because it has no associated Attendee.', 'event_espresso') );
			$payment->set_status( $this->_pay_model->failed_status() );
			return $payment;
		}

		// Prep. the request data.
		$txn_reference_no = wp_generate_password(8);
		$payment->set_txn_id_chq_nmbr(sprintf(esc_html__('Reference: %1$s', 'event_espresso'), $txn_reference_no));
		$request_content = array(
			'gateway_id' => $this->_exact_id,
			'password' => $this->_password,
			'transaction_type' => '00',
			'amount' => $this->format_currency($payment->amount()),
			'currency_code' => $payment->currency_code(),
			'ecommerce_flag' => '7',	// ECI Indicator – Channel Encrypted Transaction (a transaction between a card-holder and a merchant consummated via the Internet where the transaction includes the use of transaction encryption such as SSL, but authentication was not performed.).
			'reference_no' => $txn_reference_no,

			'cc_number' => $billing_info['credit_card'],
			'cc_expiry' => $billing_info['exp_month'] . $billing_info['exp_year'],
			'cardholder_name' => substr($billing_info['cardholder_name'], 0, 30),
			'cvd_presence_ind' => '1',
			'cvd_code' => $billing_info['card_cvv'],
			'credit_card_type' => $billing_info['card_type'],

			'client_email' => $billing_info['email'],
			'address' => array(
				'address1' => substr($billing_info['address'], 0, 30),
				'address2' => substr($billing_info['address2'], 0, 28),
				'city' => substr($billing_info['city'], 0, 20),
				'state' => $billing_info['state'],
				'zip' => substr($billing_info['zip'], 0, 10),
				'country_code' => $billing_info['country'],
				'phone_number' => substr(isset( $billing_info['phone'] ) ? $billing_info['phone'] : $primary_attendee->phone(), 0, 14),
				'phone_type' => 'W'	// Work phone number.
			),
			'partial_redemption' => 0	// if enabled - a partial redemption will be returned if only a portion of the requested funds are available.
		);

		// Show itemized list if Level 3 Properties are enabled on the account.
		// Payeezy only supports Level III processing for Visa and MasterCard.
		if ( $this->_money->compare_floats($payment->amount(), $transaction->total(), '==')
			&& ($billing_info['card_type'] === 'Visa' || $billing_info['card_type'] === 'MasterCard') 
			&& $this->_lvl_3_data 
		) {
			$discount_amt = 0;
			$itemized_sum = 0;
			$line_items = array();
			$total_line_items = $transaction->total_line_item();
			// Go through each item that's in the list.
			foreach ( $total_line_items->get_items() as $line_item ) {
				if ( $line_item instanceof EE_Line_Item ) {
					$unit_price = $line_item->unit_price();
					$line_item_quantity = $line_item->quantity();
					// This is a discount.
					// The separate 'discount' parameter doesn't influence the line items Total Amount calculated by Payeezy so we add those discounts to the list.
					if ( $line_item->total() < 0 ) {
						$discount_amt += abs($line_item->total());
						$unit_price = $line_item->total();
						$line_item_quantity = 1;
					}
                    $itemized_sum += $line_item->total();
					
					$l_item = array(
						'commodity_code'      => '860',	// TICKETS, COUPON BOOKS, SALES BOOKS, SCRIPT BOOKS, ETC.
						'description'         => substr($this->_format_line_item_name($line_item, $payment), 0, 26),
						'line_item_total'     => $this->format_currency($line_item->total()),
						'product_code'        => substr($line_item->code(), -12),
						'quantity'            => $line_item_quantity,
						'unit_cost'           => $this->format_currency($unit_price),
						// Our line item is a discount so we skip the per item discounts and just use total discount amount.
						'discount_amount'     => '0',
						'discount_indicator'  => 0,
						'gross_net_indicator' => 0,
						'unit_of_measure'     => 'ST'	// Unknown (other types don't match).
					);
					array_push($line_items, $l_item);
				}
			}

			$itemized_sum_diff_from_txn_total = round( $transaction->total() - $itemized_sum - $total_line_items->get_total_tax(), 2 );
			// If we were not able to recognize some item like promotion, surcharge or cancellation,
			// we add the difference as an extra line item.
			if ( $this->_money->compare_floats( $itemized_sum_diff_from_txn_total, 0, '!=' ) ) {
				$l_item = array(
					'commodity_code'      => '860',	// Tickets.
					'description'         => __( 'Other', 'event_espresso' ),	// promotion/surcharge/cancellation
					'line_item_total'     => $this->format_currency($itemized_sum_diff_from_txn_total),
					'product_code'        => substr($payment->TXN_ID(), -12),
					'quantity'            => 1,
					'unit_cost'           => $this->format_currency($itemized_sum_diff_from_txn_total),
					'discount_amount'     => '0',
					'discount_indicator'  => 0,
					'gross_net_indicator' => 0,
					'unit_of_measure'     => 'ST'	// Unknown (other types don't match).
				);
				array_push($line_items, $l_item);
			}
			// Item's sale and tax amount.
			$lvl3_data['tax_amount'] = $this->format_currency($total_line_items->get_total_tax());
			$lvl3_data['discount_amount'] = $discount_amt;
			$lvl3_data['duty_amount'] = '0';
			$lvl3_data['freight_amount'] = '0';
			$lvl3_data['line_items'] = $line_items;
			// Add lvl3 data to the request.
			$request_content['level3'] = $lvl3_data;
			// Tax value included in total amount.
			$request_content['tax1_amount'] = $this->format_currency($total_line_items->get_total_tax());
		} elseif ( $this->_lvl_3_data && ($billing_info['card_type'] === 'Visa' || $billing_info['card_type'] === 'MasterCard') ) {
			// Just one Item.
			$line_items[0] = array(
				'commodity_code'      => '860',	// Tickets.
				'description'         => substr($this->_format_partial_payment_line_item_name($payment), 0, 26),
				'line_item_total'     => $this->format_currency($payment->amount()),
				'product_code'        => substr($payment->TXN_ID(), -12),
				'quantity'            => 1,
				'unit_cost'           => $this->format_currency($payment->amount()),
				'discount_amount'     => '0',
				'discount_indicator'  => 0,
				'gross_net_indicator' => 0,
				'unit_of_measure'     => 'ITM'	// Item.
			);
			// Item's sale and tax amount.
			$lvl3_data['tax_amount'] = '0';
			$lvl3_data['discount_amount'] = '0';
			$lvl3_data['duty_amount'] = '0';
			$lvl3_data['freight_amount'] = '0';
			$lvl3_data['line_items'] = $line_items;
			// Add lvl3 data to the request.
			$request_content['level3'] = $lvl3_data;
		}
		// Filling out shipping information only if this is a Visa or MasterCard checkout.
		if ( $this->_lvl_3_data && ($billing_info['card_type'] === 'Visa' || $billing_info['card_type'] === 'MasterCard') ) {
			if ( ($primary_attendee->address() || $primary_attendee->address2()) 
				&& $primary_attendee->city() 
				&& $primary_attendee->zip() 
				&& $primary_attendee->country_ID() ) 
			{
				// If we have the main shipping info for our primary attendee we should be able to use that.
				$shipto_data['ship_to_address'] = array(
					'address_1' => strtoupper(substr($primary_attendee->address().' '.$primary_attendee->address2(), 0, 28)),
					'city' => strtoupper(substr($primary_attendee->city(), 0, 20)),
					'state' => $primary_attendee->state_abbrev(),
					'country' => $primary_attendee->country_ID(),
					'zip' => $primary_attendee->zip(),
					'email' => $primary_attendee->email(),
					'phone' => $primary_attendee->phone()
				);
			} else {
				// otherwise we use the info from the billing form.
				$shipto_data['ship_to_address'] = array(
					'address_1' => strtoupper(substr($billing_info['address'].' '.$billing_info['address2'], 0, 28)),
					'city' => strtoupper(substr($billing_info['city'], 0, 20)),
					'state' => $billing_info['state'],
					'country' => $billing_info['country'],
					'zip' => $billing_info['zip'],
					'email' => $billing_info['email'],
					'phone' => $billing_info['phone']
				);
			}
			// Add shipping data to the request.
			$request_content['level3'] = $request_content['level3'] + $shipto_data;
		}
		
		// Filter the data.
		$request_content = apply_filters('FHEE__EEG_Payeezy_Onsite__do_direct_payment__request_content', $request_content, $this); 

		// Prep the HMAC Hash.
		$sha1_request = sha1(json_encode($request_content));
		$hash_time = date("c");
		$hash_data = array('POST', 'application/json', $sha1_request, $hash_time, parse_url($this->_gateway_endpoint, PHP_URL_PATH));
		$hash_str = implode("\n", $hash_data);
		$auth_str = base64_encode(hash_hmac('sha1', $hash_str, $this->_hmac_key, TRUE));
		// Request parameters.
		$post_params = array(
			'method' => 'POST',
			'timeout' => 60,
			'redirection' => 5,
			'blocking' => true,
			'headers' => array(
				'Content-Type' => 'application/json',
				'charset' => 'utf-8',
				'x-gge4-date' => $hash_time,
				'x-gge4-content-sha1' => $sha1_request,
				'Authorization' => 'GGE4_API ' . $this->_hmac_key_id . ':' . $auth_str
			),
			'body' => json_encode($request_content)
		);
        //in case things blow up when we send this request, let's remember what it was
        $this->_log_clean_request($request_content, $payment, 'Payeezy sale request Parameters');
		// Send a Purchase request.
		$response = wp_remote_post($this->_gateway_endpoint, $post_params);
		
		if ( $response instanceof WP_Error ) {
            $payment->set_status($this->_pay_model->failed_status());
            $payment->set_gateway_response(
                sprintf(
                    __('There was an error communicating with the Payeezy server. The error was %1$s',
                        'event_espresso'),
                    $response->get_error_message()
                )
            );
            $payment->set_details( $response );
        }
        else if(is_array($response)){
			$resp_body = isset($response['body']) ? $response['body'] : false;
			$resp_data = json_decode($resp_body, true);
			if ( is_array($resp_data)
                 && isset($resp_data['transaction_error'],$resp_data['transaction_approved'],$resp_data['exact_resp_code'])
            ){
			    if( ! $resp_data['transaction_error']
                 && $resp_data['transaction_approved']
                 && $resp_data['exact_resp_code'] === '00' ) {
                    // Approved payment.
                    $payment->set_status( $this->_pay_model->approved_status() );
                    $payment->set_gateway_response( $resp_data['exact_message'] );
                } elseif ( isset($resp_data['bank_message'])
                    && ! $resp_data['transaction_error']
                           && ! $resp_data['transaction_approved']
                           && $resp_data['exact_resp_code'] === '00' ) {
                    // Bank declined.
                    $payment->set_status( $this->_pay_model->declined_status() );
                    $payment->set_gateway_response( $resp_data['bank_message'] );
                } elseif ( isset($resp_data['exact_message'])
                        && $resp_data
                       && $resp_data['transaction_error'] ) {
                    // Processing error.
                    $payment->set_status( $this->_pay_model->failed_status() );
                    $payment->set_gateway_response( $resp_data['exact_message'] );
                }
                unset($resp_data['cvd_code']);
                $payment->set_details( $resp_data );
                if(isset($resp_data['authorization_num'])){
                    $payment->set_txn_id_chq_nmbr(sprintf(esc_html__('%1$s, Auth: %2$s','event_espresso'), $payment->txn_id_chq_nmbr(), $resp_data['authorization_num']));
                }
            } elseif ( ! $resp_data && $resp_body && strpos($resp_body, 'Bad Request') !== false ) {	// Excluding 'Server Error' here. No need to display those to the registrant. More info will be in the Logs.
				// eCommerce error response.
				$resp_msg = explode('-', $resp_body);
				$payment->set_status( $this->_pay_model->failed_status() );
				$payment->set_gateway_response( (isset($resp_msg[1])) ? $resp_msg[1] : $resp_body );
				$payment->set_details( $resp_body );
			} else {
				// Unknown error.
				$payment->set_status( $this->_pay_model->failed_status() );
				$payment->set_gateway_response( __('Undefined gateway response received.', 'event_espresso') );
				$payment->set_details( $response );
			}
		}else{
		    //that's really weird. The response wasn't a WP_Error, or a normal array. It was a string or null? Weird.
            $payment->set_status($this->_pay_model->failed_status());
            $payment->set_gateway_response(
                    __('There was an error communicating with the Payeezy server, but there is no error data.',
                        'event_espresso')
            );
            $payment->set_details( $response );
        }
        $this->_log_clean_response($response, $payment, 'Payeezy sale request Response');
		return $payment;
	}


	/**
	 * Logs the request data safely by trying to clear out the sensitive data
	 *
	 * @param array $request
	 * @param EEI_Payment $payment
	 * @param string $data_info
	 * @return void
	 */
	private function _log_clean_request( $request, $payment, $data_info ) {
		$cleaned_request_content = $request;
		unset( $cleaned_request_content['password'] );
		unset( $cleaned_request_content['cc_number'] );
		unset( $cleaned_request_content['cc_expiry'] );
		unset( $cleaned_request_content['cvd_code'] );
		$this->log(array($data_info => $cleaned_request_content), $payment);
	}


	/**
	 * Logs the response data safely by trying to clear out the sensitive data.
	 *
	 * @param array $response
	 * @param EEI_Payment $payment
	 * @param string $data_info
	 * @return void
	 */
	private function _log_clean_response( $response, $payment, $data_info ) {
		$this->log(array($data_info => $response), $payment);
	}
}
// End of file EEG_Payeezy_Onsite.pm.php
// Location: wp-content/plugins/espresso-payeezy/payment_methods/Payeezy_Onsite/