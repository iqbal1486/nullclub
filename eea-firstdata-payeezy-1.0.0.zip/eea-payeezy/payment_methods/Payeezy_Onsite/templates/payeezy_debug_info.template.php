<?php if ( ! defined('EVENT_ESPRESSO_VERSION') ) { exit('NO direct script access allowed'); } ?>

<div id="payeezy-sandbox-panel" class="sandbox-panel">

	<h4 class="important-notice"><?php esc_html_e('Debug Mode is turned ON.', 'event_espresso'); ?></h4>

	<h4><?php esc_html_e('How do I test specific error codes?', 'event_espresso'); ?></h4>

	<p>
		<?php esc_html_e('You can use the dollar amounts between 5000.00 - 5999.00 to trigger a variety of Bank Responses and the penny amounts (5000.00 - 5000.99) for eCommerce Responses.', 'event_espresso'); ?>
	</p

	<p><strong><?php esc_html_e('Test Cards', 'event_espresso'); ?></strong><p/>
	<div class="tbl-wrap">
		<table id="payeezy-test-credit-cards" class="test-credit-card-data-tbl small-text">
			<thead>
				<tr>
					<th><?php echo esc_html__('Card Number', 'event_espresso'); ?></th>
					<th><?php echo esc_html__('Card Type', 'event_espresso'); ?></th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td>4111111111111111</td>
					<td>Visa</td>
				</tr>
				<tr>
					<td>5500000000000004</td>
					<td>MasterCard</td>
				</tr>
				<tr>
					<td>340000000000009</td>
					<td>American Express</td>
				</tr>
				<tr>
					<td>6011000000000004</td>
					<td>Discover</td>
				</tr>
				<tr>
					<td>36438999960016</td>
					<td>Diners Club</td>
				</tr>
			</tbody>
		</table>
	</div>

	<p><strong><?php esc_html_e('Test CVD/CVV/CVV2', 'event_espresso'); ?></strong><p/>
	<div class="tbl-wrap">
		<table id="payeezy-test-cvv" class="test-cvv-data-tbl small-text">
			<thead>
				<tr>
					<th><?php echo esc_html__('Verification Value', 'event_espresso'); ?></th>
					<th><?php echo esc_html__('Error Response', 'event_espresso'); ?></th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td>123</td>
					<td><?php echo esc_html__('Card is authentic', 'event_espresso'); ?></td>
				</tr>
				<tr>
					<td>234</td>
					<td><?php echo esc_html__('CVV2 does not match', 'event_espresso'); ?></td>
				</tr>
			</tbody>
		</table>
	</div>

	<p>
		<?php printf( esc_html__( 'More details can be found here: %1$s How to generate unsuccessful transactions during testing %2$s.', 'event_espresso'), '<a href="https://support.payeezy.com/hc/en-us/articles/204504175-How-to-generate-unsuccessful-transactions-during-testing-" target="_blank">', '</a>');?>
	</p>

</div>