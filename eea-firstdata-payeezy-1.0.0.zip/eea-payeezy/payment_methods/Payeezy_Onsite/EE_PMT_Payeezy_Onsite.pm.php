<?php if ( ! defined('EVENT_ESPRESSO_VERSION') ) { exit('NO direct script access allowed'); }

/**
 * ----------------------------------------------
 *
 * Class  EE_PMT_Payeezy_Onsite
 *
 * @package			Event Espresso
 * @subpackage		eea-first-data-payeezy
 * @author			Event Espresso
 * @version		 	$VID:$
 *
 * ----------------------------------------------
 */
class EE_PMT_Payeezy_Onsite extends EE_PMT_Base {

	/**
     * Class constructor.
     */
	public function __construct( $pm_instance = null ) {
		require_once(EEA_PAYEEZY_PM_PLUGIN_PATH . 'payment_methods' . DS . 'Payeezy_Onsite' . DS . 'EEG_Payeezy_Onsite.gateway.php');
		$this->_gateway = new EEG_Payeezy_Onsite();
		$this->_pretty_name = __('First Data Payeezy', 'event_espresso');
		$this->_default_description = __('Please provide the following billing information.', 'event_espresso');
		$this->_template_path = EEA_PAYEEZY_PM_PLUGIN_PATH . 'payment_methods' . DS . 'Payeezy_Onsite' . DS . 'templates' . DS;
		$this->_default_button_url = null;
		$this->_requires_https = true;

		parent::__construct($pm_instance);
	}


	/**
	 * Adds the help tab.
	 *
	 * @see EE_PMT_Base::help_tabs_config()
	 * @return array
	 */
	public function help_tabs_config() {
		return array(
			$this->get_help_tab_name() => array(
				'title' => __('Payeezy Settings', 'event_espresso'),
				'filename' => 'payeezy_onsite'
			)
		);
	}


	/**
	 * Gets the form for all the settings related to this payment method.
	 *
	 * @return EE_Payment_Method_Form
	 */
	public function generate_new_settings_form() {
		$form = new EE_Payment_Method_Form( array(
			'extra_meta_inputs' => array(
				'exact_id' => new EE_Text_Input( array(
					'html_label_text' => sprintf( __('Gateway ID %s', 'event_espresso'), $this->get_help_tab_link() ),
					'required' => true
				)),
				'password' => new EE_Password_Input( array(
					'html_label_text' => sprintf( __('Password %s', 'event_espresso'), $this->get_help_tab_link() ),
					'required' => true
				)),
				'hmac_key_id' => new EE_Text_Input( array(
					'html_label_text' => sprintf( __('HMAC Key ID %s', 'event_espresso'), $this->get_help_tab_link() ),
					'required' => true
				)),
				'hmac_key' => new EE_Password_Input( array(
					'html_label_text' => sprintf( __('HMAC Key %s', 'event_espresso'), $this->get_help_tab_link() ),
					'required' => true
				)),
				'lvl_3_data' => new EE_Yes_No_Input( array(
					'html_label_text' => __('Level 3 Data Supported', 'event_espresso'),
					'required' => true,
					'default' => true
				)),
				'credit_card_types' => new EE_Checkbox_Multi_Input( EE_PMT_Payeezy_Onsite::card_types_supported(), array(
					'html_label_text' => __('Card Types Supported', 'event_espresso'),
					'required' => true
				))
			)
		));

		return $form;
	}


	/**
	 *  Creates a billing form for this payment method type.
	 *
	 * @param \EE_Transaction $transaction
	 * @return \EE_Billing_Info_Form
	 */
	public function generate_new_billing_form( EE_Transaction $transaction = null, $extra_args = array() ) {
		$allowed_types = $this->_pm_instance->get_extra_meta('credit_card_types', true);
		// If allowed types is a string or empty array or null.
		if ( empty($allowed_types) ) {
			$allowed_types = array();
		}

		$form = new EE_Billing_Attendee_Info_Form(
			$this->_pm_instance,
			array(
				'name' => 'Payeezy_Onsite_Billing_Form',
				'html_id' => 'eea-payeezy-billing-form',
				'html_class' => 'ee-billing-form',
				'subsections' => array(
					'card_type' => new EE_Select_Input( 
						array_intersect_key(EE_PMT_Payeezy_Onsite::card_types_supported(), array_flip($allowed_types)),
						array(
							'html_class' => 'eea-payeezy-billing-form-card-cvv',
							'html_label_text' => __( 'Card Type', 'event_espresso' ),
							'required' => true
						)
					),
					'credit_card' => new EE_Credit_Card_Input( array(
						'html_class' => 'eea-payeezy-billing-form-credit-card',
						'html_label_text' => __('Card Number', 'event_espresso'),
						'required' => true
					)),
					'exp_month' => new EE_Credit_Card_Month_Input( true, array(
						'html_class' => 'eea-payeezy-billing-form-exp-month',
						'html_label_text' =>  __( 'Expiry Month', 'event_espresso' ),
						'required' => true
					)),
					'exp_year' => new EE_Credit_Card_Year_Input( array(
						'html_class' => 'eea-payeezy-billing-form-exp-year',
						'html_label_text' => __( 'Expiry Year', 'event_espresso' ),
						'required' => true
					    ),
                        false//use TWO digits for the year only; not four
                    ),
					'card_cvv' => new EE_CVV_Input( array(
						'html_class' => 'eea-payeezy-billing-form-card-cvv',
						'html_label_text' => __( 'CVV', 'event_espresso' ),
						'required' => true
					)),
					'cardholder_name' => new EE_Text_Input( array(
						'html_class' => 'eea-payeezy-billing-form-card-holder-name',
						'html_label_text' => __( 'Name on Card', 'event_espresso' ),
						'required' => true
					)),
				)
			)
		);

		return $this->generate_billing_form_debug_content( $form );
	}


	/**
	 *  Possibly adds debug content to the billing form.
	 *
	 *	@param \EE_Billing_Info_Form $billing_form
	 *	@return \EE_Billing_Info_Form
	 */
	public function generate_billing_form_debug_content( EE_Billing_Info_Form $billing_form ) {
		if ( $this->_pm_instance->debug_mode() ) {
			$billing_form->add_subsections(
				array('fyi_about_autofill' => $billing_form->payment_fields_autofilled_notice_html()),
				'account_type'
			);
			$billing_form->add_subsections(
				array('debug_content' => new EE_Form_Section_HTML_From_Template($this->_template_path . 'payeezy_debug_info.template.php')),
				'account_type'
			);

			$billing_form->get_input('credit_card')->set_default('4111111111111111');
			$billing_form->get_input('exp_month')->set_default('12');
			$billing_form->get_input('exp_year')->set_default(date("Y") + 2);
			$billing_form->get_input('card_cvv')->set_default('123');
			$billing_form->get_input('cardholder_name')->set_default('Test Customer');
		}
		return $billing_form;
	}


	/**
	 * Returns an array of all the payment cards possibly supported by Payeezy.
	 * Keys are their values, values are their pretty names.
	 *
	 * @return array
	 */
	public static function card_types_supported() {
		return array(
			'Visa'=>             __('Visa', 'event_espresso'),
			'American Express'=> __('American Express', 'event_espresso'),
			'MasterCard'=>       __('MasterCard', 'event_espresso'),
			'Discover'=>         __('Discover', 'event_espresso '),
			'Diners Club'=>      __('Diners Club', 'event_espresso'),
			'Debit'=>            __('Debit', 'event_espresso')
		);
	}

	
	/**
	 * Override the parent so we get the state and country abbreviations.
	 *
	 * @param EE_Billing_Info_Form $billing_form
	 * @return array
	 */
	protected function _get_billing_values_from_form( $billing_form ) {
		$values = $billing_form->input_values(true, false);
		$state_input = $billing_form->get_input('state');
		if ( $state_input instanceof EE_State_Select_Input ) {
			$state_abbrev = EEM_State::instance()->get_var( array( array( 'STA_ID' => $state_input->normalized_value() ) ), 'STA_abbrev' );
			$values['state'] = $state_abbrev;
		}
		if ( $billing_form->get_input_value('country') ) {
			$values['country'] = $billing_form->get_input_value( 'country' );
		}
		return $values;
	}
}
// End of file EE_PMT_Payeezy_Onsite.pm.php
// Location: wp-content/plugins/espresso-payeezy/payment_methods/Payeezy_Onsite/